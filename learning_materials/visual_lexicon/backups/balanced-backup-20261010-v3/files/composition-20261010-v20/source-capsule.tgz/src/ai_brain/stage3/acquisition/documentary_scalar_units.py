"""Closed joint-parent scalar unit proof, never independent source authority."""
import ast
import hashlib
import math
import re
import unicodedata
from fractions import Fraction

_META = dict(documentary_role='PROSE', quotation=False, chunk_count=1,
             hidden_descendant=False, unresolved_reference=False,
             reported=False, parent_count=1)
_UNITS = {'1': ((0,0,0), Fraction(1)), 'm': ((1,0,0), Fraction(1)),
          'cm': ((1,0,0), Fraction(1,100)), 'mm': ((1,0,0), Fraction(1,1000)),
          'km': ((1,0,0), Fraction(1000)), 's': ((0,0,1), Fraction(1)),
          'min': ((0,0,1), Fraction(60)), 'h': ((0,0,1), Fraction(3600)),
          'kg': ((0,1,0), Fraction(1)), 'g': ((0,1,0), Fraction(1,1000))}
_NAME = r'[A-Za-z][A-Za-z0-9_]{0,15}'
_LAYOUT = re.compile(r'[ \t\r\n]+')
_CONDITION = re.compile(r'For ([A-Za-z][A-Za-z0-9 ]{0,79})\.')
_LITERAL = re.compile(rf'({_NAME}) has unit ([A-Za-z0-9]{{1,20}})\.')
_IDENTITY = re.compile(rf'({_NAME}) is identical to ({_NAME})\.')
_DERIVATIVE = re.compile(rf'({_NAME}) is the (first|second) time derivative of ({_NAME}) with respect to ({_NAME})\.')
_INTRO = re.compile(r'(?:the[ \t]+)?(?:equation|relation)[ \t]+is[ \t]+', re.I)
_QUALIFIED = re.compile(r'\b(?:according\s+to|claims?|reported|reports?|says?|said|may|might|could|unless|except|approximately|approximate|not|never)\b', re.I)


def exact_scalar_decimals(text):
    """Finite literal decimal lowering for IR, never altering source evidence."""
    def decimal(match):
        number = Fraction(match[0])
        if number.numerator.bit_length() > 512 or number.denominator.bit_length() > 512:
            raise ValueError('decimal constant exceeds exact arithmetic limit')
        return f'({number.numerator}/{number.denominator})'

    lowered = re.sub(r'(?<![\w.])\d+\.\d+(?![\w.])', decimal, text)
    # The existing IR parser permits negative integer constants, not arbitrary
    # unary expressions. Lower only a literal unary negative rational; retain
    # the preceding operator and do not consume a binary subtraction sign.
    return re.sub(r'(^|[=(*/+\-])([ \t]*)-\((\d+)/(\d+)\)',
                  lambda m: m[1] + m[2] + f'(-{m[3]}/{m[4]})', lowered)


def _scalar(text):
    if not re.fullmatch(r'[A-Za-z0-9_+*/(). \t-]{1,300}', text):
        raise ValueError('unsupported scalar spelling')
    nodes = list(ast.walk(ast.parse(text.strip(), mode='eval')))
    if len(nodes) > 100:
        raise ValueError('scalar node bound')
    names = set()
    for node in nodes:
        if type(node) is ast.Name:
            if re.fullmatch(_NAME, node.id) is None:
                raise ValueError('scalar symbol bound')
            names.add(node.id)
        elif type(node) is ast.Constant:
            if type(node.value) not in (int, float):
                raise ValueError('scalar constant type')
            if type(node.value) is float and not math.isfinite(node.value):
                raise ValueError('nonfinite scalar')
            if type(node.value) is int and node.value.bit_length() > 512:
                raise ValueError('integer bound')
        elif type(node) not in (ast.Expression, ast.BinOp, ast.UnaryOp, ast.Load,
                               ast.Add, ast.Sub, ast.Mult, ast.Div, ast.UAdd, ast.USub):
            raise ValueError('unsupported scalar operator')
    return names


def _formula(original, start):
    end, depth = start, 0
    while end < len(original):
        c = original[end]
        if c == '(':
            depth += 1
            if depth > 16: raise ValueError('parenthesis bound')
        elif c == ')':
            depth -= 1
            if depth < 0: raise ValueError('unmatched parenthesis')
        decimal = c == '.' and end > start and end+1 < len(original) and original[end-1].isdigit() and original[end+1].isdigit()
        attribute = c == '.' and end+1 < len(original) and (original[end+1].isalpha() or original[end+1] == '_')
        if c in '.;!?' and not decimal and not attribute or c in '\r\n': break
        end += 1
    if depth: raise ValueError('unclosed parenthesis')
    stop = end
    while end > start and original[end-1] in ' \t': end -= 1
    expression = original[start:end]
    if expression.count('=') != 1 or len(expression) > 450:
        raise ValueError('bounded unique equality required')
    left, right = expression.split('=')
    names = _scalar(left) | _scalar(right)
    # Closed joint grammar requires literal sentence termination, not prose tail.
    if stop == len(original) or original[stop] != '.':
        raise ValueError('equation sentence requires exact terminator')
    return expression, end, stop+1, names


def _build_bridge(original, metadata):
    if type(original) is not str or not 1 <= len(original) <= 12000:
        raise ValueError('bounded whole original required')
    if type(metadata) is not dict or set(metadata) != set(_META):
        raise ValueError('exact metadata required')
    if any(type(metadata[k]) is not type(v) or metadata[k] != v for k,v in _META.items()):
        raise ValueError('unqualified single complete parent')
    if any(unicodedata.category(c) in {'Cc','Cf'} and c not in '\t\r\n' for c in original):
        raise ValueError('hidden original controls')
    if _QUALIFIED.search(original): raise ValueError('qualified original model')
    proofs, partition, formulas, formula_names = [], [], [], set()
    offset = 0

    def event(kind, start, end):
        partition.append(dict(kind=kind, span=[start,end], text=original[start:end]))

    def layout():
        nonlocal offset
        match = _LAYOUT.match(original, offset)
        if match:
            event('LAYOUT', offset, match.end())
            offset = match.end()

    layout()
    condition = _CONDITION.match(original, offset)
    if condition is None: raise ValueError('explicit leading condition required')
    condition_span = [offset, condition.end()]
    event('CONDITION', offset, condition.end())
    offset = condition.end()
    symbols = set()
    while offset < len(original):
        layout()
        if offset == len(original): break
        start = offset
        intro = _INTRO.match(original, offset)
        if intro:
            if len(formulas) >= 8: raise ValueError('equation count bound')
            expression, end, consumed, names = _formula(original, intro.end())
            formulas.append(dict(expression=expression, span=[intro.end(),end],
                                 introduction_span=[start,intro.end()]))
            formula_names.update(names)
            event('EQUATION', start, consumed)
            offset = consumed
            continue
        match = _LITERAL.match(original, offset)
        if match:
            symbol, unit = match.groups()
            if unit not in _UNITS: raise ValueError('unknown literal root unit')
            proof = dict(kind='LITERAL', symbol=symbol, declaration_span=[start,match.end()],
                         unit_span=[match.start(2),match.end(2)], unit_spelling=unit)
        else:
            match = _IDENTITY.match(original, offset)
            if match:
                symbol, source = match.groups()
                if symbol == source: raise ValueError('self identity')
                proof = dict(kind='IDENTITY', symbol=symbol, declaration_span=[start,match.end()],
                             source_symbol=source)
            else:
                match = _DERIVATIVE.match(original, offset)
                if not match: raise ValueError('unconsumed original clause at '+str(offset))
                symbol, order, quantity, time = match.groups()
                if symbol in {quantity,time} or quantity == time: raise ValueError('self derivative')
                proof = dict(kind='TIME_DERIVATIVE', symbol=symbol,
                             declaration_span=[start,match.end()], quantity_symbol=quantity,
                             time_symbol=time, order=1 if order == 'first' else 2)
        if symbol in symbols or len(proofs) >= 16: raise ValueError('binding collision or count bound')
        symbols.add(symbol)
        proof['proof_id'] = 'proof.'+str(len(proofs))
        proofs.append(proof)
        event('DECLARATION', start, match.end())
        offset = match.end()
    if not formulas or not proofs: raise ValueError('joint source declarations and equation required')
    by_symbol = {p['symbol']:p for p in proofs}
    resolved, visiting = {}, set()

    def resolve(symbol):
        if symbol in resolved: return resolved[symbol]
        if symbol not in by_symbol or symbol in visiting: raise ValueError('missing root or cycle')
        visiting.add(symbol)
        proof = by_symbol[symbol]
        if proof['kind'] == 'LITERAL':
            dimension, scale = _UNITS[proof['unit_spelling']]
        elif proof['kind'] == 'IDENTITY':
            dimension, scale = resolve(proof['source_symbol'])
        else:
            time = by_symbol.get(proof['time_symbol'])
            if time is None or time['kind'] != 'LITERAL': raise ValueError('literal time root required')
            td, ts = _UNITS[time['unit_spelling']]
            if td != (0,0,1): raise ValueError('time dimension required')
            qd, qs = resolve(proof['quantity_symbol'])
            dimension = tuple(a-proof['order']*b for a,b in zip(qd,td))
            scale = qs / ts**proof['order']
        visiting.remove(symbol)
        resolved[symbol] = dimension, scale
        return dimension, scale

    bindings = []
    for proof in proofs:
        dimension, scale = resolve(proof['symbol'])
        bindings.append(dict(symbol=proof['symbol'], dimension=list(dimension),
                             scale_numerator=scale.numerator, scale_denominator=scale.denominator,
                             proof_id=proof['proof_id']))
    if not formula_names or not formula_names <= symbols:
        raise ValueError('equation symbol without source binding')
    sha = hashlib.sha256(original.encode('utf-8')).hexdigest()
    return dict(version=1, original_text=original, original_sha256=sha,
        parent_span=[0,len(original)], metadata=dict(metadata), condition_span=condition_span,
        capture=dict(status='CAPTURED', complete_parent_text=original, parent_sha256=sha,
                     formulas=formulas, equation_authority=False),
        proofs=proofs, bindings=bindings, partition=partition,
        equation_authority=False, installed=False)


def _exact(actual, expected):
    if type(actual) is not type(expected): return False
    if type(expected) is dict:
        return set(actual) == set(expected) and all(type(k) is str for k in actual) and all(_exact(actual[k],v) for k,v in expected.items())
    if type(expected) is list:
        return len(actual) == len(expected) and all(_exact(a,b) for a,b in zip(actual,expected))
    return actual == expected


def validate_bridge(original, wire):
    if type(wire) is not dict or type(wire.get('metadata')) is not dict:
        raise ValueError('exact joint wire required')
    try:
        expected = build_bridge(original, wire['metadata'])
    except (SyntaxError, RecursionError, OverflowError) as error:
        raise ValueError('invalid bounded source grammar') from error
    if not _exact(wire, expected): raise ValueError('exact typed whole original replay differs')
    return True



def build_bridge(original, metadata):
    try:
        return _build_bridge(original, metadata)
    except (SyntaxError, RecursionError, OverflowError) as error:
        raise ValueError('invalid bounded source grammar') from error

