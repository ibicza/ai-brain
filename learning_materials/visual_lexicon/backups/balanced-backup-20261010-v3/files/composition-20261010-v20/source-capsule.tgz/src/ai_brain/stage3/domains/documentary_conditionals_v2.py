"""Prospective installed conditional V2 source replay; not enabled yet.

Only the public installed loader may supply a pack to this route. Its derived
context tuple is not an authentication token for caller-created pack objects.
"""

from __future__ import annotations

from dataclasses import dataclass

from ai_brain.stage2.facts.canonical import canonical_json, content_hash
from ai_brain.stage3.acquisition import documentary_logic as v1
from ai_brain.stage3.acquisition.documentary_conditional_bridge_v2 import (
    convert_v1_rule_v2,
)
from ai_brain.stage3.acquisition.documentary_conditional_v2 import (
    DOCUMENTARY_CONDITIONAL_V2,
    bind_scope_v2,
    derive_conditionals_v2,
    parse_conditional_payload_v2,
    parse_conditional_query_v2,
)
from ai_brain.stage3.acquisition.documentary_reader_conditionals_v2 import (
    extract_reader_conditionals_v2,
)
from ai_brain.stage3.domains.document_retrieval import excerpt_payload
from ai_brain.stage3.domains.documentary_context_inventory import (
    UnsupportedDocumentaryContext as UnsupportedConditional,
)
from ai_brain.stage3.domains.documentary_context_inventory import (
    original_context_index as _origin_index,
)
from ai_brain.stage3.knowledge_ir.records import (
    EpistemicCharacter,
    InterpretationContent,
)


def _neighbors(rows, index):
    context_id, origin = rows[index]
    following = (
        rows[index + 1][1]
        if (index + 1 < len(rows) and rows[index + 1][0] == context_id)
        else None
    )
    preceding = (
        rows[index - 1][1] if index and rows[index - 1][0] == context_id else None
    )
    return origin, following, preceding


@dataclass(frozen=True)
class _InstalledRule:
    record: object
    partition: tuple
    origin_index: int
    payload: dict


def _reserved(pack):
    for record in pack.knowledge_records:
        content = record.content
        if (
            isinstance(content, InterpretationContent)
            and type(content.perspective) is str
            and content.perspective.startswith("DOCUMENTARY_CONDITIONAL_")
        ):
            if content.perspective not in {
                v1.DOCUMENTARY_CONDITIONAL_V1,
                DOCUMENTARY_CONDITIONAL_V2,
            }:
                raise ValueError("unknown reserved conditional category")
            yield record


def _validated_rules(pack):
    rows, lookup = _origin_index(pack)
    by_id = {record.knowledge_id: record for record in pack.knowledge_records}
    bindings = {binding.binding_id: binding for binding in pack.source_bindings}
    if len(by_id) != len(pack.knowledge_records):
        raise ValueError("duplicate installed record identity")
    if len(bindings) != len(pack.source_bindings):
        raise ValueError("duplicate installed source binding identity")
    result = []
    for record in _reserved(pack):
        content = record.content
        if (
            type(content.supported_record_ids) is not tuple
            or len(content.supported_record_ids) != 1
            or content.supported_record_ids != record.dependencies
            or content.contrast_record_ids
            or record.required_capability_ids
            or record.applicability_refs
            or record.epistemic_character is not EpistemicCharacter.INTERPRETIVE
        ):
            raise ValueError("invalid installed conditional dependency authority")
        source = by_id.get(content.supported_record_ids[0])
        if source is None or (origin := excerpt_payload(source)) is None:
            raise ValueError("conditional source excerpt missing")
        # Fresh generic replay validates each binding against some original
        # segment. It does not establish that the rule and its sole supporting
        # excerpt name THE SAME segment. Coherent rehashing must not split the
        # displayed proof lineage from the clause actually replayed below.
        if any(
            type(refs) is not tuple
            or len(refs) != 1
            or type(refs[0]) is not str
            for refs in (record.provenance_refs, source.provenance_refs)
        ):
            raise ValueError("conditional requires one exact source binding")
        own = bindings.get(record.provenance_refs[0])
        direct = bindings.get(source.provenance_refs[0])
        if own is None or direct is None or any(
            getattr(own, field) != getattr(direct, field)
            for field in (
                "document_hashes",
                "segment_hashes",
                "evidence_hashes",
                "source_hashes",
            )
        ):
            raise ValueError("conditional rule and excerpt source lineage differs")
        encoded = canonical_json(origin)
        if encoded not in lookup:
            raise ValueError("conditional excerpt not in fresh complete source")
        index = lookup[encoded]
        origin, following, preceding = _neighbors(rows, index)
        scope = v1.documentary_scope(origin)
        if content.perspective == v1.DOCUMENTARY_CONDITIONAL_V1:
            parsed = v1.parse_conditional_payload(content.claim_text)
            candidates = tuple(
                v1.bind_scope(candidate, scope)
                for candidate in v1.extract_documentary_conditionals(
                    origin, following, preceding
                )
            )
        else:
            parsed = parse_conditional_payload_v2(content.claim_text)
            candidates = tuple(
                bind_scope_v2(candidate, scope)
                for candidate in extract_reader_conditionals_v2(
                    origin, following, preceding
                )
            )
        if canonical_json(parsed.to_dict()) not in {
            canonical_json(x) for x in candidates
        }:
            raise ValueError("installed conditional differs from complete original")
        result.append(
            _InstalledRule(record, (rows[index][0], scope), index, parsed.to_dict())
        )
    return rows, tuple(result)


def validate_installed_conditionals_v2(pack):
    """Supplemental reserved-category replay, after fresh loader context attach.

    V1-only meaning is unchanged. A V2-bearing pack validates all reserved
    records before installation/runtime; it does not convert unapproved rules.
    """
    reserved = tuple(_reserved(pack))
    if any(
        record.content.perspective == DOCUMENTARY_CONDITIONAL_V2 for record in reserved
    ):
        _validated_rules(pack)


def _complete_inventory(rows, partition, installed):
    """Recognized raw rules are coverage evidence, NEVER unapproved premises."""
    expected = set()
    for index, (context_id, origin) in enumerate(rows):
        if context_id != partition[0]:
            continue
        if v1._documentary_provenance_scope(origin) != partition[1]:
            continue
        if (
            origin.get("documentary_role") != "PROSE"
            or origin.get("quotation") is not False
        ):
            continue
        if origin.get("documentary_math_presence") is not False:
            continue
        original, following, preceding = _neighbors(rows, index)
        legacy = v1.extract_documentary_conditionals(original, following, preceding)
        try:
            extended = extract_reader_conditionals_v2(original, following, preceding)
        except ValueError as error:
            raise UnsupportedConditional(
                "complete source parent grouping unsupported"
            ) from error
        legacy_sentences = {candidate["sentence"] for candidate in legacy}
        for candidate in (
            *legacy,
            *(
                candidate
                for candidate in extended
                if candidate["sentence"] not in legacy_sentences
            ),
        ):
            expected.add(
                (index, candidate["schema_version"], candidate["sentence_sha256"])
            )
            if len(expected) > v1.MAX_RULES:
                raise OverflowError("conditional inventory exceeds shared rule budget")
    approved = {
        (
            item.origin_index,
            item.payload["schema_version"],
            item.payload["sentence_sha256"],
        )
        for item in installed
    }
    if not expected or expected != approved:
        raise UnsupportedConditional(
            "recognized source conditional inventory is not completely approved"
        )


def _failure(pack, status, reason, **details):
    return {
        "status": status,
        "domain_id": pack.manifest.domain_id,
        "pack_hash": pack.manifest.pack_content_hash,
        "reason": reason,
        **details,
    }


def assess_task_v2(pack, task):
    """One complete literal engine; no positive V1 retry or source rule insertion."""
    try:
        rows, installed = _validated_rules(pack)
        if len(installed) > v1.MAX_RULES:
            raise OverflowError("installed shared conditional rule budget exceeded")
        initial = derive_conditionals_v2((), task)
        if initial["status"] == "INVALID_CONDITIONAL_INPUT":
            return _failure(pack, "INVALID_REQUEST", "Invalid complete V2 task")
        groups = {}
        for item in installed:
            author = item.payload["source_author"]
            if task["author"] is not None and (
                author is None
                or v1.normalize_atom(author) != v1.normalize_atom(task["author"])
            ):
                continue
            groups.setdefault(item.partition, []).append(item)
        productive = []
        for partition, items in sorted(groups.items()):
            _complete_inventory(rows, partition, items)
            rules = []
            by_id = {item.record.knowledge_id: item for item in items}
            for item in items:
                try:
                    payload = (
                        convert_v1_rule_v2(item.payload)
                        if item.payload["schema_version"] == 1
                        else item.payload
                    )
                    origin, following, preceding = _neighbors(rows, item.origin_index)
                    witnesses = tuple(
                        bind_scope_v2(candidate, partition[1])
                        for candidate in extract_reader_conditionals_v2(
                            origin, following, preceding
                        )
                    )
                    if canonical_json(payload) not in {
                        canonical_json(x) for x in witnesses
                    }:
                        raise ValueError(
                            "converted clause lacks complete source-context witness"
                        )
                except ValueError as error:
                    raise UnsupportedConditional(
                        "not every approved rule converts with complete context"
                    ) from error
                rules.append((item.record.knowledge_id, payload))
            result = derive_conditionals_v2(tuple(rules), task)
            if result["status"] == "BOUND_EXCEEDED":
                raise OverflowError("conditional closure/depth budget exceeded")
            if result["status"] in {"INVALID_CONDITIONAL_INPUT", "SCOPE_CONFLICT"}:
                raise ValueError("invalid combined installed conditional input")
            if result["status"] == "CONTESTED":
                return _failure(
                    pack,
                    "CONTESTED_CONDITIONAL_DERIVATION",
                    "Contradictory hypothetical or reviewed source clauses",
                    conflicts=result["conflicts"],
                )
            if result["status"] == "DERIVED" and (
                task["goal"] is None or result["goal_follows"] is True
            ):
                productive.append((partition, result, by_id))
        if initial["status"] == "CONTESTED":
            return _failure(
                pack,
                "CONTESTED_CONDITIONAL_DERIVATION",
                "Contradictory hypothetical premises",
                conflicts=initial["conflicts"],
            )
        if len(productive) > 1:
            return _failure(
                pack,
                "AMBIGUOUS_SOURCE_SCOPE",
                "Select an exact reviewed original context",
                source_scope_candidates=[content_hash(p) for p, _, _ in productive],
            )
        if not productive:
            return _failure(
                pack,
                "NEEDS_NEW_CAPABILITY",
                "No complete reviewed source derivation for this request; unknown is not false",
            )
        partition, result, by_id = productive[0]
        steps = [
            {
                **step,
                "record_schema_version": by_id[step["rule_id"]].payload[
                    "schema_version"
                ],
                "source_context_id": partition[0],
                "clause_witnesses": [
                    *step["antecedent_witnesses"],
                    *step["consequent_witnesses"],
                ],
            }
            for step in result["proof_steps"]
        ]
        value = {
            "scope": "DOCUMENTARY_CONDITIONAL_DERIVATION_V2",
            "schema_version": 2,
            "source_context_id": partition[0],
            "source_scope": list(partition[1]),
            "assumptions": result["assumptions"],
            "assumptions_are_hypothetical": True,
            "conclusions": result["conclusions"],
            "source_code_executed": False,
            "source_assertions_independently_verified": False,
            "unrecognized_source_semantics_assessed": False,
            "conditional_inventory_policy": "COMPLETE_FINITE_RECOGNIZED_RULES_APPROVED_V1",
            "query_hash": content_hash(task),
        }
        if task["goal"] is not None:
            value.update(goal=task["goal"]["text"], goal_follows=True)
        from ai_brain.stage3.domains.semantic_reasoning import _answer

        answer = _answer(
            pack,
            tuple(by_id[key].record for key in result["used_rule_ids"]),
            "DOCUMENTED_CONDITIONAL_CONCLUSIONS",
            value,
            steps,
        )
        answer["truth_status"] = (
            "CONDITIONAL_ON_ASSUMPTIONS_AND_REVIEWED_SOURCE_ASSERTIONS_NOT_INDEPENDENT_FACT_VERIFICATION"
        )
        answer["derivation_hash"] = content_hash(
            {
                "pack_hash": answer["pack_hash"],
                "query_hash": value["query_hash"],
                "partition": partition,
                "proof_steps": steps,
                "evidence_hashes": [item["record_hash"] for item in answer["evidence"]],
            }
        )
        return answer
    except UnsupportedConditional as error:
        return _failure(pack, "NEEDS_NEW_CAPABILITY", str(error))
    except OverflowError as error:
        return _failure(pack, "RESOURCE_LIMIT", str(error))
    except (ValueError, KeyError, TypeError, RecursionError) as error:
        return _failure(pack, "STALE_AUTHORITY", str(error))


def assess_conditionals_v2(pack, reference, arguments):
    if (
        reference is not None
        or type(arguments) is not dict
        or set(arguments) != {"question"}
        or type(arguments["question"]) is not str
    ):
        return _failure(pack, "INVALID_REQUEST", "Exact complete V2 question required")
    task = parse_conditional_query_v2(arguments["question"])
    if task is None:
        return _failure(
            pack, "INVALID_REQUEST", "Unsupported complete V2 query grammar"
        )
    return assess_task_v2(pack, task)
