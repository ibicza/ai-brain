"""Explicit symbol/unit declarations only, without guessing physical meanings."""

from __future__ import annotations

import re

_UNIT_NAMES = {
    "metre": "m",
    "metres": "m",
    "meter": "m",
    "meters": "m",
    "centimetre": "cm",
    "centimetres": "cm",
    "centimeter": "cm",
    "centimeters": "cm",
    "millimetre": "mm",
    "millimetres": "mm",
    "millimeter": "mm",
    "millimeters": "mm",
    "kilometre": "km",
    "kilometres": "km",
    "kilometer": "km",
    "kilometers": "km",
    "second": "s",
    "seconds": "s",
    "minute": "min",
    "minutes": "min",
    "hour": "h",
    "hours": "h",
    "kilogram": "kg",
    "kilograms": "kg",
    "gram": "g",
    "grams": "g",
    "newton": "N",
    "newtons": "N",
    "hertz": "Hz",
}


def explicit_unit_spelling(text):
    """Translate only literal SI spellings, never infer a unit from a quantity.

    This is a lexical representation policy. Unknown words remain in the result
    so a conflicting/unsupported declaration cannot disappear during admission.
    """
    if type(text) is not str or len(text) > 120:
        raise ValueError("unit spelling exceeds limit")
    text = text.strip().replace("−", "-").replace("²", "^2").replace("³", "^3")
    text = re.sub(
        r"\b(?:squared|square)\s+([A-Za-z]+)\b", r"\1^2", text, flags=re.IGNORECASE
    )
    text = re.sub(
        r"\b(?:cubed|cubic)\s+([A-Za-z]+)\b", r"\1^3", text, flags=re.IGNORECASE
    )
    text = re.sub(r"\bper\b", "/", text, flags=re.IGNORECASE)
    text = re.sub(
        r"[A-Za-z]+", lambda match: _UNIT_NAMES.get(match[0].casefold(), match[0]), text
    )
    text = re.sub(r"\b([A-Za-z]+)-([0-9]{1,2})\b", r"\1^-\2", text)
    # Spaces between distinct unit factors denote a product, not a name join.
    text = re.sub(r"(?<=[A-Za-z0-9])\s+(?=[A-Za-z])", "*", text)
    return re.sub(r"\s+", "", text)


def explicit_unit_declarations(text, symbol):
    """Recognize notation and literal measurement declarations in local evidence.

    All declarations are returned, including unsupported units. The caller must
    reject conflicts and validate the unit grammar; unsupported declarations must
    not disappear simply because another declaration looks acceptable.
    """
    if len(text) > 100000 or not re.fullmatch(r"[A-Za-z]\w{0,15}", symbol):
        raise ValueError("unit declaration context exceeds limit")
    name = re.escape(symbol)
    declarations = [
        re.sub(r"^in\s+", "", declaration.strip(), flags=re.IGNORECASE)
        for declaration in re.findall(rf"\b{name}\s*[\[(]([^\])]+)[\])]", text)
    ]
    # Stop at punctuation/newlines rather than reading a later prose clause as
    # a unit. Preserve unknown unit tokens so validation fails closed.
    token = r"([^\n,;.!?]{1,120})"
    for pattern in (
        rf"\b{name}\s+(?i:is measured in|has unit|has units of)\s+{token}",
        rf"\b(?i:(?:the\s+)?unit of)\s+{name}\s+(?i:is)\s+{token}",
    ):
        declarations.extend(re.findall(pattern, text))
    # A variable may be explicitly bound to a prose quantity before its unit.
    # No quantity-name -> dimension/standard-unit lookup is performed here.
    # Keep whole unknown unit phrases, including conflicts, for the validator.
    for pattern in (
        rf"\b{name}\s+(?i:(?:is|denotes|represents)\s+[^\n.!?;]{{1,100}}?\s+(?:measured\s+)?in)\s+([^\n,;.!?]{{1,120}})",
        rf"\b{name}\s+(?i:(?:is|denotes|represents)\s+[^\n.!?;]{{1,100}}?)\s*\((?i:in\s+)([^)\n]{{1,120}})\)",
    ):
        declarations.extend(re.findall(pattern, text))
    return tuple(
        dict.fromkeys(
            explicit_unit_spelling(declaration) for declaration in declarations
        )
    )
