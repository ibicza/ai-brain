"""Internal reader convention and exact V1-to-V2 replay, not source authority.

These helpers do not grant approval or authenticate a supplied dictionary.
Callers must use fresh complete reader replay and validate installed lineage.
Unconvertible operands are a whole-collection refusal, never dropped rules.
"""

from ai_brain.stage3.acquisition import documentary_logic as v1
from ai_brain.stage3.acquisition.documentary_conditional_v2 import (
    ConditionalRuleV2,
    QueryTaskV2,
)
from ai_brain.stage3.acquisition.documentary_surface_logic import (
    parse_literal_clause_v2,
)


def reader_parse_view_v2(origin: dict) -> dict:
    """Prepare a copy of CURRENT reader metadata; original payload stays exact.

    Current ordinary reader null means no alternative rendering. The strict
    pure context wrapper remains unchanged: a caller's present-null field is
    not automatically safe. This adapter is an internal reader-contract seam.
    Multi-chunk parent reconstruction is deliberately not invented here.
    """
    if (
        type(origin) is not dict
        or type(origin.get("text")) is not str
        or type(origin.get("chunk_count")) is not int
        or origin["chunk_count"] != 1
        or type(origin.get("chunk_index")) is not int
        or origin["chunk_index"] != 0
        or "documentary_original_text" not in origin
        or "documentary_rendering_basis" not in origin
    ):
        raise ValueError("unsupported complete current-reader parent")
    original = origin["documentary_original_text"]
    basis = origin["documentary_rendering_basis"]
    if original is None:
        if basis is not None:
            raise ValueError("null alternative conflicts with reader rendering")
        return {**origin, "documentary_original_text": origin["text"]}
    if (
        type(original) is not str
        or basis != "PRESENTATIONAL_REPEAT_OF_ORIGINAL_DL_LABEL"
    ):
        raise ValueError("unsupported reader alternate original")
    return dict(origin)


def _convert_atom(atom: v1.Atom):
    parsed = parse_literal_clause_v2(atom.text)
    if parsed is None or (parsed.text, parsed.identity, parsed.polarity) != (
        atom.text,
        atom.identity,
        atom.polarity,
    ):
        raise ValueError("V1 literal atom has no exact V2 interpretation")
    return parsed


def convert_v1_rule_v2(payload):
    """Reparse every operand and whole original sentence without translation."""
    rule = v1.parse_conditional_payload(payload)
    if not rule.scope:
        raise ValueError("installed conversion requires documentary scope")
    converted = ConditionalRuleV2(
        tuple(_convert_atom(atom) for atom in rule.antecedents),
        tuple(_convert_atom(atom) for atom in rule.consequents),
        rule.sentence,
        rule.source_author,
        rule.scope,
    )
    if converted.to_dict()["sentence_sha256"] != rule.to_dict()["sentence_sha256"]:
        raise ValueError("converted original sentence changed")
    return converted.to_dict()


def convert_v1_query_v2(payload):
    """All premises, goal and attribution convert atomically or fail."""
    if type(payload) is not dict:
        raise ValueError("query conversion requires exact wire dictionary")
    task = v1._parse_query(payload)
    return QueryTaskV2(
        tuple(_convert_atom(atom) for atom in task.assumptions),
        _convert_atom(task.goal) if task.goal is not None else None,
        task.author,
    ).to_dict()
