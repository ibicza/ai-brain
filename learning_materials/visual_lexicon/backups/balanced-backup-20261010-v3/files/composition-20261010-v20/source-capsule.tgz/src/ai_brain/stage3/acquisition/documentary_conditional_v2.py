"""Prospective literal v2 rules and hypothetical proofs; no installed route yet.

An exact surface proposition is not an empirical fact, a resolved entity or an
executed action. Scope must be supplied by trusted acquisition, not source prose.
"""

from __future__ import annotations

import hashlib
import json
import re
import unicodedata
from dataclasses import dataclass, replace
from typing import Any

from ai_brain.stage3.acquisition import documentary_logic as v1
from ai_brain.stage3.acquisition.documentary_surface_logic import (
    LiteralClause,
    parse_literal_clause_v2,
)
from ai_brain.stage3.acquisition.documentary_surface_payload import (
    _exact,
    clause_payload,
    parse_clause_payload,
)

DOCUMENTARY_CONDITIONAL_V2 = "DOCUMENTARY_CONDITIONAL_V2"
SCHEMA_VERSION = 2


def _atoms(values: Any) -> tuple[LiteralClause, ...]:
    if type(values) is not list or not 0 < len(values) <= v1.MAX_ASSUMPTIONS:
        raise ValueError("invalid v2 atom list")
    atoms = tuple(parse_clause_payload(value) for value in values)
    if len({atom.identity for atom in atoms}) != len(atoms):
        raise ValueError("duplicate v2 atom")
    return atoms


def _split(text: str) -> tuple[LiteralClause, ...]:
    parts = v1._CONJUNCTION.split(text)
    if len({word.casefold() for word in parts[1::2]}) > 1:
        raise ValueError("mixed v2 conjunctions")
    atoms = tuple(parse_literal_clause_v2(part.strip()) for part in parts[::2])
    if any(atom is None for atom in atoms):
        raise ValueError("unsupported complete v2 operand")
    return _atoms([clause_payload(atom) for atom in atoms])


def _sentence(text: str):
    if not v1._safe_string(text, v1.MAX_SENTENCE_CHARS):
        raise ValueError("invalid v2 sentence")
    match = re.fullmatch(
        r"\s*(?:If|When)\s+(.+?),\s*(?:then\s+)?(.+?)\.\s*",
        text,
        re.IGNORECASE | re.DOTALL,
    )
    if match is None:
        raise ValueError("unsupported v2 sentence")
    return _split(match[1]), _split(match[2])


def _tuple_atoms(atoms: Any) -> None:
    if type(atoms) is not tuple or not 0 < len(atoms) <= v1.MAX_ASSUMPTIONS:
        raise ValueError("invalid v2 clause tuple")
    _atoms([clause_payload(atom) for atom in atoms])


@dataclass(frozen=True)
class ConditionalRuleV2:
    antecedents: tuple[LiteralClause, ...]
    consequents: tuple[LiteralClause, ...]
    sentence: str
    source_author: str | None = None
    scope: tuple[str, ...] = ()
    schema_version: int = SCHEMA_VERSION

    def __post_init__(self):
        if (
            type(self.schema_version) is not int
            or self.schema_version != SCHEMA_VERSION
        ):
            raise ValueError("invalid v2 rule version")
        _tuple_atoms(self.antecedents)
        _tuple_atoms(self.consequents)
        if not v1._safe_string(self.source_author, 128, nullable=True):
            raise ValueError("invalid v2 author")
        v1._validate_scope(self.scope)
        antecedents, consequents = _sentence(self.sentence)
        if not _exact(
            (
                [clause_payload(a) for a in self.antecedents],
                [clause_payload(a) for a in self.consequents],
            ),
            (
                [clause_payload(a) for a in antecedents],
                [clause_payload(a) for a in consequents],
            ),
        ):
            raise ValueError("v2 clauses differ from complete source sentence")

    def to_dict(self):
        return {
            "schema_version": self.schema_version,
            "antecedents": [clause_payload(atom) for atom in self.antecedents],
            "consequents": [clause_payload(atom) for atom in self.consequents],
            "sentence": self.sentence,
            "sentence_sha256": hashlib.sha256(
                self.sentence.encode("utf-8")
            ).hexdigest(),
            "source_author": self.source_author,
            "scope": list(self.scope),
        }


def parse_conditional_payload_v2(payload: Any) -> ConditionalRuleV2:
    if type(payload) is str:
        if not 0 < len(payload) <= v1.MAX_PAYLOAD_CHARS:
            raise ValueError("v2 rule payload exceeds bounds")
        try:
            payload = json.loads(payload, object_pairs_hook=v1._json_object)
        except (ValueError, RecursionError) as error:
            raise ValueError("invalid v2 rule JSON") from error
    if (
        type(payload) is not dict
        or set(payload)
        != {
            "schema_version",
            "antecedents",
            "consequents",
            "sentence",
            "sentence_sha256",
            "source_author",
            "scope",
        }
        or type(payload["scope"]) is not list
    ):
        raise ValueError("invalid v2 rule fields")
    rule = ConditionalRuleV2(
        _atoms(payload["antecedents"]),
        _atoms(payload["consequents"]),
        payload["sentence"],
        payload["source_author"],
        tuple(payload["scope"]),
        payload["schema_version"],
    )
    if not _exact(payload, rule.to_dict()):
        raise ValueError("v2 rule fields differ from exact original replay")
    if len(json.dumps(rule.to_dict(), ensure_ascii=False)) > v1.MAX_PAYLOAD_CHARS:
        raise ValueError("v2 canonical rule exceeds bounds")
    return rule


def canonical_json_v2(payload: Any) -> str:
    return json.dumps(
        parse_conditional_payload_v2(payload).to_dict(),
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    )


def bind_scope_v2(payload: Any, scope: tuple[str, ...]) -> dict:
    v1._validate_scope(scope)
    if not scope:
        raise ValueError("installed v2 rule requires scope")
    return replace(parse_conditional_payload_v2(payload), scope=scope).to_dict()


def extract_conditionals_v2(
    text: str, source_author: str | None = None
) -> tuple[dict, ...]:
    if (
        type(text) is not str
        or len(text) > v1.MAX_SOURCE_CHARS
        or v1._INSTRUCTION.search(text)
        or v1._QUOTED_DOCUMENT.search(text)
        or v1._qualified_parent(text)
        or not v1._safe_string(source_author, 128, nullable=True)
    ):
        return ()
    result = []
    seen = set()
    sentences = re.findall(r"[^.!?]+[.!?]|[^.!?]+$", text)
    for index, raw in enumerate(sentences):
        if (
            index
            and v1._QUALIFIER_START.search(sentences[index - 1].strip())
            or index + 1 < len(sentences)
            and v1._QUALIFIER_START.search(sentences[index + 1].strip())
        ):
            continue
        try:
            sentence = raw.strip()
            antecedents, consequents = _sentence(sentence)
            payload = ConditionalRuleV2(
                antecedents,
                consequents,
                sentence,
                source_author,
            ).to_dict()
            encoded = canonical_json_v2(payload)
        except ValueError:
            continue
        if encoded not in seen:
            seen.add(encoded)
            result.append(payload)
        if len(result) > v1.MAX_RULES:
            return ()
    return tuple(result)


@dataclass(frozen=True)
class QueryTaskV2:
    assumptions: tuple[LiteralClause, ...]
    goal: LiteralClause | None = None
    author: str | None = None
    schema_version: int = SCHEMA_VERSION

    def __post_init__(self):
        if (
            type(self.schema_version) is not int
            or self.schema_version != SCHEMA_VERSION
        ):
            raise ValueError("invalid v2 task version")
        _tuple_atoms(self.assumptions)
        if self.goal is not None:
            clause_payload(self.goal)
        if not v1._safe_string(self.author, 128, nullable=True):
            raise ValueError("invalid v2 task author")

    def to_dict(self):
        return {
            "schema_version": self.schema_version,
            "assumptions": [clause_payload(atom) for atom in self.assumptions],
            "goal": clause_payload(self.goal) if self.goal is not None else None,
            "author": self.author,
        }


def _query(payload: Any) -> QueryTaskV2:
    if type(payload) is not dict or set(payload) != {
        "schema_version",
        "assumptions",
        "goal",
        "author",
    }:
        raise ValueError("invalid v2 task fields")
    task = QueryTaskV2(
        _atoms(payload["assumptions"]),
        parse_clause_payload(payload["goal"]) if payload["goal"] is not None else None,
        payload["author"],
        payload["schema_version"],
    )
    if not _exact(payload, task.to_dict()):
        raise ValueError("v2 task differs from exact replay")
    return task


def parse_conditional_query_v2(question: str) -> dict | None:
    """Pure task parser; selecting it is explicit, never a v1 retry policy."""
    if not v1._safe_string(question, v1.MAX_QUERY_CHARS):
        return None
    text = question.strip()
    author = None
    attributed = re.fullmatch(
        r"(.+?)(?:,\s*|\s+)according to\s+([^?]+)\??",
        text,
        re.IGNORECASE,
    )
    if attributed:
        text, author = attributed[1].strip(), attributed[2].strip()
        if not text.endswith("?"):
            text += "?"
    assumptions = None
    goal = None
    for pattern in (
        r"What follows if (.+)\?",
        r"If (.+), what follows\?",
        r"Given (.+), what follows\?",
    ):
        match = re.fullmatch(pattern, text, re.IGNORECASE)
        if match:
            assumptions = match[1]
            break
    if assumptions is None:
        match = re.fullmatch(
            r"Does (.+) follow if (.+)\?",
            text,
            re.IGNORECASE,
        )
        if match:
            goal, assumptions = match.groups()
    if assumptions is None:
        return None
    try:
        atoms = tuple(atom for part in assumptions.split(";") for atom in _split(part))
        goal_atom = parse_literal_clause_v2(goal.strip()) if goal is not None else None
        if goal is not None and goal_atom is None:
            return None
        return QueryTaskV2(atoms, goal_atom, author).to_dict()
    except ValueError:
        return None


def derive_conditionals_v2(rules: Any, query: Any) -> dict:
    """Complete round-based closure inside one source scope; no installed authority."""
    result = {
        "schema_version": SCHEMA_VERSION,
        "status": "NO_DERIVATION",
        "conclusions": [],
        "proof_steps": [],
        "used_rule_ids": [],
        "conflicts": [],
        "assumptions": [],
        "goal_follows": None,
        "goal_assumed": False,
        "assumptions_are_hypothetical": True,
        "source_assertions_are_empirical_proof": False,
    }
    try:
        task = _query(query)
        result["assumptions"] = [atom.text for atom in task.assumptions]
        result["goal_assumed"] = task.goal is not None and any(
            atom.identity == task.goal.identity for atom in task.assumptions
        )
        if type(rules) not in {tuple, list}:
            raise ValueError("invalid v2 rule collection")
        if len(rules) > v1.MAX_RULES:
            result["status"] = "BOUND_EXCEEDED"
            return result
        parsed = []
        identifiers = set()
        for entry in rules:
            if type(entry) is not tuple or len(entry) != 2:
                raise ValueError("invalid v2 rule entry")
            identifier, payload = entry
            if (
                type(identifier) is not str
                or not identifier.strip()
                or len(identifier) > 256
                or identifier in identifiers
                or any(
                    char.isspace() or unicodedata.category(char) in {"Cc", "Cf", "Cs"}
                    for char in identifier
                )
            ):
                raise ValueError("invalid v2 rule identifier")
            identifiers.add(identifier)
            rule = parse_conditional_payload_v2(payload)
            if task.author is None or (
                rule.source_author is not None
                and v1.normalize_atom(rule.source_author)
                == v1.normalize_atom(task.author)
            ):
                parsed.append((identifier, rule))
    except (ValueError, TypeError, RecursionError):
        result["status"] = "INVALID_CONDITIONAL_INPUT"
        return result
    if parsed and (
        any(not rule.scope for _, rule in parsed)
        or len({rule.scope for _, rule in parsed}) != 1
        or len(
            {
                v1.normalize_atom(rule.source_author) if rule.source_author else None
                for _, rule in parsed
            }
        )
        != 1
    ):
        result["status"] = "SCOPE_CONFLICT"
        return result
    known = {atom.identity: atom for atom in task.assumptions}
    initial = set(known)
    depths = {identity: 0 for identity in known}
    steps = []
    used = []
    fired = set()
    while True:
        conflicts = v1._conflicts(known)
        if conflicts:
            result.update(
                status="CONTESTED",
                conflicts=conflicts,
                proof_steps=steps,
                used_rule_ids=used,
            )
            return result
        snapshot = set(known)
        changed = False
        for identifier, rule in sorted(parsed, key=lambda item: item[0]):
            if identifier in fired or not all(
                atom.identity in snapshot for atom in rule.antecedents
            ):
                continue
            novel = [atom for atom in rule.consequents if atom.identity not in known]
            if not novel:
                fired.add(identifier)
                continue
            depth = 1 + max(depths[atom.identity] for atom in rule.antecedents)
            if depth > v1.MAX_DEPTH or len(known) + len(novel) > v1.MAX_CLOSURE:
                result.update(
                    status="BOUND_EXCEEDED", proof_steps=steps, used_rule_ids=used
                )
                return result
            for atom in novel:
                known[atom.identity] = atom
                depths[atom.identity] = depth
            fired.add(identifier)
            used.append(identifier)
            steps.append(
                {
                    "rule_id": identifier,
                    "sentence_sha256": rule.to_dict()["sentence_sha256"],
                    "antecedents": [atom.text for atom in rule.antecedents],
                    "consequents": [atom.text for atom in rule.consequents],
                    "antecedent_witnesses": [
                        clause_payload(atom) for atom in rule.antecedents
                    ],
                    "consequent_witnesses": [
                        clause_payload(atom) for atom in rule.consequents
                    ],
                    "span_coordinates": "CLAUSE_TEXT_CHARACTERS_NOT_ORIGINAL_RAW_BYTES",
                    "depth": depth,
                }
            )
            changed = True
        if not changed:
            break
    conclusions = [known[identity].text for identity in sorted(set(known) - initial)]
    result.update(
        status="DERIVED" if conclusions else "NO_DERIVATION",
        conclusions=conclusions,
        proof_steps=steps,
        used_rule_ids=used,
        goal_follows=task.goal.identity in (set(known) - initial)
        if task.goal is not None
        else None,
    )
    return result
