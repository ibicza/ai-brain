"""Typed scalar witness replay at candidate and installed custody boundaries."""
from dataclasses import asdict
import json

from ai_brain.stage2.facts.canonical import canonical_json, content_hash
from ai_brain.stage3.acquisition.documentary_inline_equations import parent_eligible
from ai_brain.stage3.acquisition.documentary_scalar_units import build_bridge, exact_scalar_decimals
from ai_brain.stage3.knowledge_ir.records import (
    Applicability, DimensionVector, EpistemicCharacter, Expression,
    ExpressionKind, InterpretationContent, KnowledgeKind, QuantityTypeRef,
    RuleContent, UnitRef, ValueTypeKind, ValueTypeRef, VariableBinding,
)

ROLE = 'SOURCE_SCALAR_UNIT_WITNESS_V1'
PREFIX = 'source-derived-unit:'


def reserved(content):
    return isinstance(content, InterpretationContent) and (
        type(content.perspective) is str and content.perspective.startswith('SOURCE_SCALAR_UNIT_WITNESS')
        or type(content.claim_text) is str and 'SOURCE_SCALAR_UNIT_WITNESS' in content.claim_text
    )


def derived(content):
    return isinstance(content, RuleContent) and any(
        type(v.semantic_entity_role) is str and v.semantic_entity_role.startswith('source-derived-unit')
        for v in content.variables
    )


def payload(proposal):
    from ai_brain.stage3.acquisition.direct_material import EXCERPT_PREFIX
    description = getattr(proposal.proposed_content, 'description_en', '')
    if type(description) is str and description.startswith(EXCERPT_PREFIX):
        return json.loads(description[len(EXCERPT_PREFIX):])
    return None


def derive(origin):
    if origin.get('documentary_role') != 'PROSE' or not parent_eligible(origin):
        raise ValueError('scalar witness requires qualified complete prose parent')
    structure = origin.get('documentary_structure') or {}
    metadata = dict(documentary_role='PROSE', quotation=origin.get('quotation'),
        chunk_count=origin.get('chunk_count'), hidden_descendant=bool(structure.get('skipped_descendant_presence')),
        unresolved_reference=False, reported=False, parent_count=1)
    # Closed parser consumes every source character, so references/report text
    # cannot be silently erased by false metadata defaults.
    wire = build_bridge(origin['text'], metadata)
    return dict(role=ROLE, wire=wire, source_payload_hash=content_hash(origin),
                raw_source_sha256=origin['original_bytes_hash'],
                reader_profile=origin['reader_profile'])


def _body(content, origin):
    if type(content) is not InterpretationContent or content.perspective != ROLE:
        raise ValueError('unknown reserved scalar witness type/version')
    expected = derive(origin)
    if type(content.claim_text) is not str or canonical_json(expected) != content.claim_text:
        raise ValueError('scalar witness differs from complete original replay')
    return expected['wire']


def variable(name, wire, witness_id):
    rows = [r for r in wire['bindings'] if r['symbol'] == name]
    if len(rows) != 1: raise ValueError('missing unique rooted variable')
    row = rows[0]
    length, mass, time = row['dimension']
    dimension = DimensionVector(length=length, mass=mass, time=time)
    unit = UnitRef('si.'+content_hash(asdict(dimension))[:16], dimension)
    value_type = ValueTypeRef(ValueTypeKind.QUANTITY,
        quantity_type=QuantityTypeRef('quantity.'+name, dimension, unit))
    proof = next(p for p in wire['proofs'] if p['proof_id'] == row['proof_id'])
    role = ('source-unit:'+proof['unit_spelling'] if proof['kind'] == 'LITERAL'
            else PREFIX+witness_id+':'+name)
    return VariableBinding(name, value_type, 'equation', semantic_entity_role=role)


def _rule_matches(content, wire, witness_id):
    from ai_brain.stage3.acquisition.extractors import _math_expression
    import ast
    if type(content) is not RuleContent: raise ValueError('exact derived equation required')
    expected = []
    for formula in wire['capture']['formulas']:
        sides = exact_scalar_decimals(formula['expression']).split('=')
        names = sorted({n.id for side in sides for n in ast.walk(ast.parse(side.strip(),mode='eval')) if type(n) is ast.Name})
        variables = tuple(variable(name,wire,witness_id) for name in names)
        types = {v.variable_id:v.value_type for v in variables}
        expression = Expression(ExpressionKind.EQUAL,
            children=tuple(_math_expression(side.strip(),types) for side in sides),
            result_type=ValueTypeRef(ValueTypeKind.BOOLEAN))
        condition = wire['original_text'][slice(*wire['condition_span'])][4:-1].strip()
        expected.append(RuleContent(expression,variables,Applicability((condition,))))
    if canonical_json(asdict(content)) not in {canonical_json(asdict(e)) for e in expected}:
        raise ValueError('derived rule differs from source proof/formula')


def _requires_derived(wire):
    import ast
    names = {n.id for formula in wire['capture']['formulas']
             for side in formula['expression'].split('=')
             for n in ast.walk(ast.parse(side.strip(), mode='eval')) if type(n) is ast.Name}
    return any(p['symbol'] in names and p['kind'] != 'LITERAL' for p in wire['proofs'])


def _sole_candidate_origin(source, support):
    origin = payload(source)
    if origin is None: raise ValueError('scalar source excerpt missing')
    rows = [row for item in support.values() if (row := payload(item)) is not None
            and row.get('file') == origin['file'] and row.get('original_bytes_hash') == origin['original_bytes_hash']]
    if len(rows) != 1: raise ValueError('scalar source requires sole complete original parent')
    return origin


def validate_candidate(proposal, support):
    if isinstance(proposal.proposed_content, RuleContent) and type(support) is dict:
        for source in support.values():
            if source.source_bundle_id != proposal.source_bundle_id or source.segment_ids != proposal.segment_ids:
                continue
            origin = payload(source)
            if origin is None: continue
            try:
                required = _requires_derived(derive(origin)['wire'])
            except ValueError:
                continue
            if required and not derived(proposal.proposed_content):
                raise ValueError('original requires derived witness, erased roles forbidden')
    linked = type(support) is dict and isinstance(proposal.proposed_content, RuleContent) and any(
        reserved(p.proposed_content) and p.source_bundle_id == proposal.source_bundle_id
        and p.segment_ids == proposal.segment_ids for p in support.values())
    if not (reserved(proposal.proposed_content) or derived(proposal.proposed_content) or linked):
        return
    if type(support) is not dict: raise ValueError('scalar source replay support required')
    if reserved(proposal.proposed_content):
        content = proposal.proposed_content
        if (type(content.supported_record_ids) is not tuple or len(content.supported_record_ids) != 1
                or content.contrast_record_ids != () or proposal.proposed_dependencies != content.supported_record_ids
                or proposal.proposed_kind is not KnowledgeKind.INTERPRETATION
                or proposal.proposed_epistemic_character is not EpistemicCharacter.INTERPRETIVE
                or proposal.proposed_capabilities != () or proposal.proposed_applicability != ()):
            raise ValueError('exact witness evidence dependencies required')
        source = support.get(content.supported_record_ids[0])
        if source is None: raise ValueError('scalar source dependency missing')
        origin = _sole_candidate_origin(source,support)
        _body(content,origin)
        if proposal.source_bundle_id != source.source_bundle_id or proposal.segment_ids != source.segment_ids:
            raise ValueError('scalar witness lineage differs')
    else:
        roles = [v.semantic_entity_role for v in proposal.proposed_content.variables
                 if type(v.semantic_entity_role) is str and v.semantic_entity_role.startswith('source-derived-unit')]
        parts = [r.split(':') for r in roles]
        if not parts or any(len(p) != 3 or p[0] != 'source-derived-unit' for p in parts) or len({p[1] for p in parts}) != 1:
            raise ValueError('malformed derived witness role')
        witness_id = parts[0][1]
        witness = support.get(witness_id)
        if witness is None or not reserved(witness.proposed_content): raise ValueError('derived witness missing')
        validate_candidate(witness,support)
        source_id = witness.proposed_content.supported_record_ids[0]
        source = support[source_id]
        if (proposal.proposed_dependencies != (source_id,witness_id)
                or proposal.segment_ids != source.segment_ids or proposal.source_bundle_id != source.source_bundle_id
                or proposal.proposed_kind is not KnowledgeKind.EQUATION_RULE
                or proposal.proposed_epistemic_character is not EpistemicCharacter.DETERMINISTIC
                or proposal.proposed_capabilities != ('generic.scalar_equation_solver.v1',)
                or proposal.proposed_applicability != ()):
            raise ValueError('derived equation exact authority/lineage differs')
        _rule_matches(proposal.proposed_content,derive(payload(source))['wire'],witness_id)


def validate_installed(pack):
    records = pack.knowledge_records
    policies = [r for r in records if reserved(r.content)]
    equations = [r for r in records if derived(r.content)]
    has_rules = any(isinstance(r.content, RuleContent) for r in records)
    # Legacy in-memory selection facades need not expose documentary fields.
    # Absence is only outside this optional lane when no reserved carrier or
    # derived role requests it. Actual loader-authenticated documentary packs
    # still undergo source-driven detection even after complete label erasure.
    custody = getattr(pack, 'documentary_custody', None)
    if not policies and not equations and (not has_rules or custody is None): return
    if custody is None:
        raise ValueError('scalar witness requires installed documentary custody')
    from ai_brain.stage3.domains.documentary_context_inventory import original_context_index
    from ai_brain.stage3.domains.document_retrieval import excerpt_payload
    from ai_brain.stage3.domains.documentary_api_policy import _source_union
    rows, lookup = original_context_index(pack)
    # Source-driven requirement survives erasing every reserved label/record.
    # No new requirement imposed on genuinely non-documentary packs above.
    required_origins = []
    if has_rules:
        for _, origin in rows:
            try:
                if _requires_derived(derive(origin)['wire']):
                    required_origins.append(content_hash(origin))
            except ValueError:
                continue
    by_id = {r.knowledge_id:r for r in records}
    bindings = {b.binding_id:b for b in pack.source_bindings}
    if len(by_id) != len(records) or len(bindings) != len(pack.source_bindings):
        raise ValueError('duplicate scalar installed identity')
    wires, sources = {}, {}
    for witness in policies:
        content = witness.content
        if (type(content.supported_record_ids) is not tuple or len(content.supported_record_ids) != 1
                or content.contrast_record_ids != () or witness.dependencies != content.supported_record_ids
                or witness.kind is not KnowledgeKind.INTERPRETATION
                or witness.epistemic_character is not EpistemicCharacter.INTERPRETIVE
                or witness.required_capability_ids != () or witness.applicability_refs != ()):
            raise ValueError('installed witness authority differs')
        source = by_id.get(content.supported_record_ids[0])
        origin = excerpt_payload(source) if source is not None else None
        encoded = canonical_json(origin)
        if origin is None or encoded not in lookup: raise ValueError('witness lacks fresh complete source custody')
        context_id = rows[lookup[encoded]][0]
        if sum(c == context_id for c,_ in rows) != 1: raise ValueError('scalar original must contain sole complete parent')
        _source_union(witness,(source,),bindings)
        wires[witness.knowledge_id] = _body(content,origin)
        sources[witness.knowledge_id] = source
    authenticated_origins = [content_hash(excerpt_payload(source)) for source in sources.values()]
    if any(identity not in authenticated_origins for identity in required_origins):
        # Missing direct source association is not proof that this complete
        # original is irrelevant. Conservatively refuse ambiguous documentary
        # packs rather than accept full witness/role erasure.
        raise ValueError('complete original requires missing scalar unit witness')
    # Related same-source rules cannot erase their role/dependency and escape
    # as ordinary equations. Compare actual source bindings, not actor labels.
    for record in records:
        if not isinstance(record.content, RuleContent) or record in equations:
            continue
        own = bindings.get(record.provenance_refs[0]) if type(record.provenance_refs) is tuple and len(record.provenance_refs) == 1 else None
        if set(record.dependencies) & (set(wires) | {s.knowledge_id for s in sources.values()}) or own is not None and any(
            own.segment_hashes == bindings[source.provenance_refs[0]].segment_hashes
            and own.document_hashes == bindings[source.provenance_refs[0]].document_hashes
            for source in sources.values()):
            equations.append(record)
    for rule in equations:
        parts = [v.semantic_entity_role.split(':') for v in rule.content.variables
                 if type(v.semantic_entity_role) is str and v.semantic_entity_role.startswith('source-derived-unit')]
        if not parts or any(len(p) != 3 or p[0] != 'source-derived-unit' for p in parts) or len({p[1] for p in parts}) != 1:
            raise ValueError('invalid installed derived role')
        witness_id = parts[0][1]
        if witness_id not in wires: raise ValueError('installed equation witness missing')
        source = sources[witness_id]
        if (rule.dependencies != (source.knowledge_id,witness_id)
                or rule.kind is not KnowledgeKind.EQUATION_RULE
                or rule.epistemic_character is not EpistemicCharacter.DETERMINISTIC
                or rule.required_capability_ids != ('generic.scalar_equation_solver.v1',)
                or rule.applicability_refs != ()):
            raise ValueError('installed scalar equation dependencies differ')
        _source_union(rule,(source,),bindings)
        _rule_matches(rule.content,wires[witness_id],witness_id)
