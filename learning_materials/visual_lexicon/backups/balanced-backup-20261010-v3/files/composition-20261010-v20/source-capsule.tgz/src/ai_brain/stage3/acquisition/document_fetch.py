"""Explicit public HTTPS acquisition. HTML references are never followed."""

from __future__ import annotations

import http.client
import ipaddress
import re
import socket
import time
import urllib.error
import urllib.parse
import urllib.request

from ai_brain.stage2.facts.canonical import bytes_hash
from ai_brain.stage3.acquisition.document_readers import MAX_INPUT_BYTES


def validate_source_url(url):
    if type(url) is not str or len(url) > 2048:
        raise ValueError("invalid source URL")
    parsed = urllib.parse.urlsplit(url)
    if (
        parsed.scheme != "https"
        or not parsed.hostname
        or parsed.username
        or parsed.password
        or parsed.port not in {None, 443}
        or parsed.fragment
    ):
        raise ValueError(
            "source URL must be public HTTPS without credentials, fragment or custom port"
        )
    addresses = socket.getaddrinfo(parsed.hostname, 443, type=socket.SOCK_STREAM)
    if not addresses or any(
        not ipaddress.ip_address(item[4][0]).is_global for item in addresses
    ):
        raise ValueError("private/local source URL is forbidden")
    return parsed


class _Redirects(urllib.request.HTTPRedirectHandler):
    max_redirections = 3
    max_repeats = 1

    def redirect_request(self, request, response, code, message, headers, new_url):
        validate_source_url(new_url)
        return super().redirect_request(
            request, response, code, message, headers, new_url
        )


class _PinnedConnection(http.client.HTTPSConnection):
    def connect(self):
        # TLS verifies the hostname, but the socket uses a validated numeric
        # address. A second DNS resolution cannot redirect it to a private IP.
        addresses = socket.getaddrinfo(self.host, self.port, type=socket.SOCK_STREAM)
        if not addresses or any(
            not ipaddress.ip_address(item[4][0]).is_global for item in addresses
        ):
            raise ValueError("private/local HTTPS endpoint is forbidden")
        raw_socket = socket.create_connection(
            (addresses[0][4][0], self.port), self.timeout
        )
        try:
            self.sock = self._context.wrap_socket(raw_socket, server_hostname=self.host)
        except OSError:
            raw_socket.close()
            raise


class _PinnedHTTPS(urllib.request.HTTPSHandler):
    def https_open(self, request):
        return self.do_open(_PinnedConnection, request, context=self._context)


def fetch_document(url):
    """The caller explicitly selects each URL; no crawler, assets or code load."""
    parsed = validate_source_url(url)
    opener = urllib.request.build_opener(
        urllib.request.ProxyHandler({}), _Redirects(), _PinnedHTTPS()
    )
    request = urllib.request.Request(
        url,
        headers={
            "User-Agent": "ai-brain-document-reader/1.0",
            "Accept-Encoding": "identity",
        },
    )
    try:
        with opener.open(request, timeout=20) as response:
            final_url = response.geturl()
            validate_source_url(final_url)
            length = response.headers.get("Content-Length")
            if length and int(length) > MAX_INPUT_BYTES:
                raise ValueError("remote document exceeds 64 MiB limit")
            started, chunks, total = time.monotonic(), [], 0
            while True:
                if time.monotonic() - started > 40:
                    raise TimeoutError("source download exceeded total time limit")
                chunk = response.read(min(65536, MAX_INPUT_BYTES + 1 - total))
                if not chunk:
                    break
                chunks.append(chunk)
                total += len(chunk)
                if total > MAX_INPUT_BYTES:
                    raise ValueError("remote document exceeds limit")
            raw = b"".join(chunks)
            if not raw or len(raw) > MAX_INPUT_BYTES:
                raise ValueError("remote document empty or exceeds limit")
            media = response.headers.get_content_type()
    except (urllib.error.URLError, TimeoutError) as error:
        raise ValueError(f"source unavailable: {url}: {error}") from error
    name = urllib.parse.unquote(parsed.path.rsplit("/", 1)[-1]) or "index"
    name = re.sub(r"[^\w.-]", "_", name)[:120]
    if "." not in name:
        name += (
            ".pdf"
            if media == "application/pdf"
            else ".html"
            if media == "text/html"
            else ".txt"
        )
    return raw, f"{parsed.hostname}-{bytes_hash(url.encode())[:10]}-{name}", final_url
