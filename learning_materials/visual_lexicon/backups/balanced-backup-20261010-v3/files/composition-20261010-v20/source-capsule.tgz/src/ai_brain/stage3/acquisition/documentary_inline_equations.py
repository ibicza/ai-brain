"""Finite source-bound equation capture, not equation or installation authority.

Original complete parents survive unchanged. No evaluation, source execution,
ambient units, implicit multiplication, or typographic equation repair.
"""
import ast
import hashlib
import math
from pathlib import Path
import re
import unicodedata

INLINE_EQUATIONS_VERSION = 1
INTRO = re.compile(r'(?<!\w)(?:the\s+)?(?:equation|relation)\s+is\s+', re.I)
_REPORT = re.compile(r'\b(?:according\s+to|claims?|claimed|believes?|believed|says?|said|argues?|argued|reports?|reported|writes?|wrote)\b', re.I)


def _side(text):
    if not re.fullmatch(r'[A-Za-z0-9_+*/(). \t-]{1,300}', text):
        raise ValueError('unsupported literal scalar spelling')
    nodes = list(ast.walk(ast.parse(text.strip(), mode='eval')))
    if len(nodes) > 100:
        raise ValueError('AST bound')
    for node in nodes:
        if isinstance(node, ast.Name):
            if not re.fullmatch(r'[A-Za-z][A-Za-z0-9_]{0,31}', node.id):
                raise ValueError('name bound')
        elif isinstance(node, ast.Constant):
            if type(node.value) not in (int, float):
                raise ValueError('constant type')
            if type(node.value) is float and not math.isfinite(node.value):
                raise ValueError('nonfinite number')
            if type(node.value) is int and node.value.bit_length() > 512:
                raise ValueError('integer bound')
        elif type(node) not in (ast.Expression, ast.BinOp, ast.UnaryOp, ast.Load,
                               ast.Add, ast.Sub, ast.Mult, ast.Div, ast.UAdd, ast.USub):
            raise ValueError('unsupported operator/call/attribute')


def capture_original(parent):
    base = dict(equation_authority=False)
    try:
        if type(parent) is not str or not 1 <= len(parent) <= 12000:
            raise ValueError('complete parent bound')
        base.update(complete_parent_text=parent,
                    parent_sha256=hashlib.sha256(parent.encode('utf-8')).hexdigest())
        if any(unicodedata.category(c) in {'Cc', 'Cf'} and c not in '\t\r\n' for c in parent):
            raise ValueError('hidden documentary control')
        matches = list(INTRO.finditer(parent))
        if len(matches) > 8:
            raise ValueError('capture bound')
        formulas = []
        for match in matches:
            start = match.end()
            end, depth = start, 0
            while end < len(parent):
                c = parent[end]
                if c == '(':
                    depth += 1
                    if depth > 16:
                        raise ValueError('parenthesis bound')
                elif c == ')':
                    depth -= 1
                    if depth < 0:
                        raise ValueError('unmatched parenthesis')
                decimal = c == '.' and end > start and end + 1 < len(parent) and parent[end-1].isdigit() and parent[end+1].isdigit()
                attribute = c == '.' and end + 1 < len(parent) and (parent[end+1].isalpha() or parent[end+1] == '_')
                if c in '.;!?' and not decimal and not attribute or c in '\r\n':
                    break
                end += 1
            if depth:
                raise ValueError('unclosed parenthesis')
            while end > start and parent[end-1] in ' \t':
                end -= 1
            expression = parent[start:end]
            if expression.count('=') != 1 or len(expression) > 450:
                raise ValueError('unique bounded equality required')
            left, right = expression.split('=')
            _side(left)
            _side(right)
            formulas.append(dict(expression=expression, span=(start, end),
                                 introduction_span=(match.start(), match.end())))
        return dict(base, status='CAPTURED' if formulas else 'NO_CAPTURE', formulas=tuple(formulas))
    except (ValueError, SyntaxError, RecursionError, OverflowError) as error:
        return dict(base, status='REFUSED', reason=str(error), formulas=())


def validate_capture(parent, captured):
    """Exact deterministic replay binds every introduction and character span."""
    if type(parent) is not str or type(captured) is not dict:
        raise ValueError('capture typed evidence')
    if captured.get('status') != 'CAPTURED' or captured.get('equation_authority') is not False:
        raise ValueError('capture status/authority differs')
    formulas = captured.get('formulas')
    if type(formulas) is not tuple or not 1 <= len(formulas) <= 8:
        raise ValueError('formula evidence cardinality')
    previous = 0
    for formula in formulas:
        if type(formula) is not dict or set(formula) != {'expression', 'span', 'introduction_span'}:
            raise ValueError('formula exact fields')
        for name in ('introduction_span', 'span'):
            span = formula[name]
            if type(span) is not tuple or len(span) != 2 or any(type(v) is not int for v in span) or not 0 <= span[0] < span[1] <= len(parent):
                raise ValueError('source interval bounds/types')
        intro, expression = formula['introduction_span'], formula['span']
        if intro[0] < previous or intro[1] != expression[0] or parent[slice(*expression)] != formula['expression'] or INTRO.fullmatch(parent[slice(*intro)]) is None:
            raise ValueError('source interval/order/text mismatch')
        previous = expression[1]
    if captured != capture_original(parent):
        raise ValueError('capture does not replay whole source parent')
    return True


def parent_eligible(payload):
    structure = payload.get('documentary_structure') or {}
    if (payload.get('documentary_role') not in {'PROSE', 'MATH_NOTATION'} or payload.get('quotation')
            or type(payload.get('chunk_count')) is not int or payload['chunk_count'] != 1
            or payload.get('documentary_note_label') is not None
            or structure.get('skipped_descendant_presence')
            or structure and structure.get('well_nested') is not True):
        return False
    parent = payload.get('text')
    if type(parent) is not str:
        return False
    if any(unicodedata.category(c) in {'Cc', 'Cf'} and c not in '\t\r\n' for c in parent):
        return False
    if '`' in parent or '~~~' in parent or any(c in parent for c in ('"', '“', '”', '«', '»', '‘', '’')):
        return False
    return not (re.search(r"(?<![A-Za-z])'[^']+'", parent)
                or re.search(r'(?m)^\s*>', parent) or _REPORT.search(parent))


def equation_parent_eligibility(payloads):
    """Carry only literal fence custody, never units/claims, across TXT parents."""
    fences, last_line, eligible = {}, {}, []
    for payload in payloads:
        file = payload.get('file')
        inside = False
        if type(file) is str and Path(file).suffix.lower() in {'.txt', '.md', '.markdown', '.rst'}:
            line = payload.get('line_start')
            if type(line) is not int or line < last_line.get(file, -1):
                raise ValueError('source parent ordering required for fence custody')
            last_line[file] = line
            marker = fences.get(file)
            inside = marker is not None
            for source_line in payload.get('text', '').split('\n'):
                event = re.match(r'^[ \t]*(`{3,}|~{3,})', source_line)
                if event:
                    inside = True
                    spelling = event[1]
                    if marker is None:
                        marker = spelling
                    elif spelling[0] == marker[0] and len(spelling) >= len(marker) and not source_line[event.end():].strip(' \t\r'):
                        marker = None
            fences[file] = marker
        eligible.append(not inside and parent_eligible(payload))
    return tuple(eligible)
