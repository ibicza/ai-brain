"""Read ordinary documents into documentary passages, not executable claims.

Readers preserve origin/locations, never execute source, follow HTML resources,
or interpret directives embedded in untrusted text. PDF parsing is isolated.
"""

from __future__ import annotations

import ast
import io
import json
import re
import subprocess
import sys
import tokenize
from html import escape
from html.parser import HTMLParser
from pathlib import Path
from typing import ClassVar
from urllib.parse import unquote, urlsplit

from ai_brain.stage2.facts.canonical import bytes_hash, content_hash
from ai_brain.stage3.acquisition.math_notation import latex_scalar, mathml_scalar
from ai_brain.stage3.capabilities.scalar_equation_solver import NeedsNewCapability
from ai_brain.stage3.domains.javadoc_clause_view import has_hidden_controls

MAX_INPUT_BYTES = 64 * 1024 * 1024
MAX_EXTRACTED_BYTES = 8 * 1024 * 1024
MAX_BLOCKS = 8192
BLOCK_CHARS = 1800
READER_VERSION = "1.6.9"


def reader_profile():
    import pypdf

    return content_hash(
        {
            "version": READER_VERSION,
            "pypdf": pypdf.__version__,
            "reader": bytes_hash(Path(__file__).read_bytes()),
            "documentary_characters": bytes_hash(
                Path(__file__).parent.parent.joinpath("domains", "javadoc_clause_view.py").read_bytes()
            ),
            "math_notation": bytes_hash(
                Path(__file__).with_name("math_notation.py").read_bytes()
            ),
            "worker": bytes_hash(
                Path(__file__).with_name("pdf_text_worker.py").read_bytes()
            ),
            "max_input": MAX_INPUT_BYTES,
            "max_text": MAX_EXTRACTED_BYTES,
            "max_blocks": MAX_BLOCKS,
        }
    )


def read_document(raw: bytes, name: str) -> dict:
    if not raw or len(raw) > MAX_INPUT_BYTES:
        raise ValueError("document is empty or exceeds the 64 MiB input limit")
    suffix = Path(name).suffix.casefold()
    issues = []
    if suffix == ".pdf":
        blocks, issues = _pdf(raw)
        format_name = "pdf-text-layer"
    elif suffix in {".html", ".htm"}:
        parser = _DocumentHTML()
        parser.feed(_decode(raw))
        parser.close()
        blocks = parser.finish()
        format_name = "static-html"
    elif suffix == ".py":
        blocks = _python(raw)
        format_name = "python-docstrings-ast"
    elif suffix == ".java":
        blocks = _java(raw)
        format_name = "java-documentation-ast"
    elif suffix in {
        ".js",
        ".ts",
        ".c",
        ".h",
        ".cpp",
        ".hpp",
        ".cs",
        ".go",
        ".rs",
        ".kt",
    }:
        blocks = _comment_documentation(_decode(raw))
        format_name = "c-style-documentation-lexical"
        issues.append(
            {
                "status": "DOCUMENTATION_ONLY",
                "reason": "No semantic callable/type authority; comments are documentary evidence only.",
            }
        )
    elif suffix in {".txt", ".md", ".markdown", ".rst"}:
        decoded = _decode(raw)
        blocks = _paragraphs(decoded, markup=suffix)
        if suffix == ".txt":
            author = _gutenberg_author(decoded)
            if author:
                for block in blocks:
                    block.update(author)
        format_name = "plain-document"
    else:
        raise NeedsNewCapability(
            f"NEEDS_NEW_CAPABILITY: unsupported document format {suffix}"
        )
    if (
        len(blocks) > MAX_BLOCKS
        or sum(len(b["text"].encode("utf-8")) for b in blocks) > MAX_EXTRACTED_BYTES
    ):
        raise ValueError("extracted document exceeds passage/text limits")
    if not blocks and suffix in {
        ".py",
        ".java",
        ".js",
        ".ts",
        ".c",
        ".h",
        ".cpp",
        ".hpp",
        ".cs",
        ".go",
        ".rs",
        ".kt",
    }:
        issues.append(
            {
                "status": "NO_DOCUMENTATION",
                "reason": "No documentary comments/docstrings; program behavior is not inferred.",
            }
        )
        return {"format": format_name, "blocks": [], "issues": issues}
    if not blocks or (
        suffix in {".html", ".htm"}
        and not any(block["text"].strip() for block in blocks)
    ):
        raise NeedsNewCapability(
            "NEEDS_NEW_CAPABILITY: no readable documentary material; OCR or another reader may be required"
        )
    return {"format": format_name, "blocks": blocks, "issues": issues}


def _decode(raw):
    if raw.startswith((b"\xff\xfe", b"\xfe\xff")):
        return raw.decode("utf-16", errors="strict")
    encoding = "utf-8-sig"
    match = re.search(rb"charset\s*=\s*[\"']?([\w-]+)", raw[:2048], re.IGNORECASE)
    if match:
        declared = match[1].decode("ascii").lower()
        if declared not in {
            "utf-8",
            "utf8",
            "windows-1251",
            "windows-1252",
            "iso-8859-1",
        }:
            raise NeedsNewCapability(
                f"NEEDS_NEW_CAPABILITY: unsupported charset {declared}"
            )
        encoding = declared
    return (
        raw.decode(encoding, errors="strict").replace("\r\n", "\n").replace("\r", "\n")
    )


def _gutenberg_author(text):
    """Read declared header metadata only; this does not authenticate an author."""
    prefix = text[:8192]
    marker = re.search(
        r"(?im)^\*{3}\s+START OF (?:THE|THIS) PROJECT GUTENBERG (?:EBOOK|ETEXT)\b[^\n]*\*{3}\s*$",
        prefix,
    )
    if marker is None:
        return None
    header = prefix[: marker.start()]
    titles = list(re.finditer(r"(?im)^Title:[ \t]*(\S[^\n]*)$", header))
    authors = list(re.finditer(r"(?im)^Author:[ \t]*(\S[^\n]*)$", header))
    if len(titles) != 1 or len(authors) != 1:
        return None
    author = authors[0]
    name = author[1].strip()
    if len(name) > 256:
        return None
    # Do not silently select the first name from a multiline author field.
    after = header[author.end() :].splitlines()
    if len(after) > 1 and after[1].strip() and after[1][:1].isspace():
        return None
    line = text.count("\n", 0, author.start()) + 1
    return {
        "source_author": name,
        "source_author_basis": "DOCUMENTARY_DECLARED_SOURCE_AUTHOR",
        "source_author_evidence": {
            "text": author[0],
            "line_start": line,
            "line_end": line,
        },
    }


def _pieces(text, *, preserve_whitespace=False):
    text = text if preserve_whitespace else text.strip()
    cursor, count = 0, 0
    while cursor < len(text):
        count += 1
        if count > MAX_BLOCKS:
            raise ValueError("paragraph exceeds passage limit")
        cut = min(cursor + BLOCK_CHARS, len(text))
        if cut < len(text):
            boundary = text.rfind(" ", cursor + BLOCK_CHARS // 2, cut)
            if boundary > cursor:
                cut = boundary
        yield text[cursor:cut] if preserve_whitespace else text[cursor:cut].strip()
        cursor = cut
        while not preserve_whitespace and cursor < len(text) and text[cursor].isspace():
            cursor += 1


def _block(
    text,
    title="",
    heading_path=(),
    line_start=None,
    line_end=None,
    page=None,
    symbol=None,
    signature=None,
    declaration_kind=None,
    quotation=False,
    documentary_role="PROSE",
    signature_language=None,
    signature_display=None,
    signature_qualification_basis=(),
    member_anchor=None,
    documentary_note_label=None,
    documentary_note_label_origin=None,
    documentary_rendering_basis=None,
    documentary_math_presence=False,
    documentary_context_marker=None,
):
    if type(documentary_math_presence) is not bool:
        raise ValueError("documentary math presence must be a reader boolean")
    pieces = list(
        _pieces(text, preserve_whitespace=documentary_role == "LITERAL_EXAMPLE")
    )
    if documentary_role == "SOURCE_CONTEXT_MARKER":
        expected_marker = {
            "schema_version": 1,
            "reason": "RECOGNIZED_RESTRICTION_WITHOUT_RENDERED_TEXT",
            "math_event": documentary_math_presence,
            "quotation_event": quotation,
            "scope": "READER_EVENT_CONTEXT_NOT_SOURCE_ASSERTION",
            "inference_authority": False,
        }
        if (
            type(text) is not str
            or text != ""
            or type(quotation) is not bool
            or not (quotation or documentary_math_presence)
            or type(documentary_context_marker) is not dict
            or documentary_context_marker != expected_marker
            or type(documentary_context_marker.get("schema_version")) is not int
            or type(documentary_context_marker.get("math_event")) is not bool
            or type(documentary_context_marker.get("quotation_event")) is not bool
            or documentary_context_marker.get("inference_authority") is not False
            or documentary_rendering_basis is not None
        ):
            raise ValueError("exact inert reader event marker required")
        pieces = [""]
    elif documentary_context_marker is not None:
        raise ValueError("reader event marker cannot label source prose")
    return [
        {
            "text": piece,
            "title": title,
            "heading_path": list(heading_path),
            "line_start": line_start,
            "line_end": line_end,
            "page": page,
            "symbol": symbol,
            "signature": signature,
            "signature_language": signature_language,
            "signature_display": signature_display,
            "signature_qualification_basis": list(signature_qualification_basis),
            "member_anchor": member_anchor,
            "documentary_note_label": documentary_note_label,
            "documentary_note_label_origin": documentary_note_label_origin,
            "documentary_rendering_basis": documentary_rendering_basis,
            "documentary_original_text": (
                piece[len(documentary_note_label) + 1 :]
                if ordinal == 0 and piece.startswith(documentary_note_label + " ")
                else piece
            )
            if documentary_rendering_basis
            == "PRESENTATIONAL_REPEAT_OF_ORIGINAL_DL_LABEL"
            else None,
            "declaration_kind": declaration_kind,
            "quotation": quotation,
            "documentary_role": documentary_role,
            "documentary_math_presence": documentary_math_presence
            or documentary_role == "MATH_NOTATION",
            "chunk_index": ordinal,
            "chunk_count": len(pieces),
            **(
                {"documentary_context_marker": dict(documentary_context_marker)}
                if documentary_context_marker is not None
                else {}
            ),
        }
        for ordinal, piece in enumerate(pieces)
    ]


def _paragraphs(text, *, page=None, markup=None):
    blocks, pending, headings = [], [], []
    first = 1
    role = "PROSE"
    fence = None
    literal_indent = None
    rst_literal_pending = False
    markup_enabled = markup in {".md", ".markdown", ".rst"}

    def flush(last):
        if pending:
            blocks.extend(
                _block(
                    "\n".join(pending),
                    headings[-1] if headings else "",
                    headings,
                    first,
                    last,
                    page,
                    quotation=role == "PROSE"
                    and any(line.lstrip().startswith(">") for line in pending),
                    documentary_role=role,
                )
            )
            pending.clear()

    # Only physical CR/LF layout creates source lines. C1 separators must not
    # become new prose or end a fenced example through splitlines().
    lines = text.replace("\r\n", "\n").replace("\r", "\n").split("\n")
    if lines and lines[-1] == "":
        lines.pop()
    for number, line in enumerate(lines, 1):
        if fence is not None:
            if role != "LITERAL_EXAMPLE" and has_hidden_controls(line):
                raise NeedsNewCapability("Hidden documentary math characters")
            pending.append(line)
            closing = re.fullmatch(
                r" {0,3}(" + re.escape(fence[0]) + r"{" + str(fence[1]) + r",})[ \t]*",
                line,
            )
            if closing:
                flush(number)
                fence, role = None, "PROSE"
            continue
        opening = (
            re.match(r"^ {0,3}(`{3,}|~{3,})([^\n]*)$", line) if markup_enabled else None
        )
        if opening and not (opening[1][0] == "`" and "`" in opening[2]):
            if has_hidden_controls(line):
                raise NeedsNewCapability("Hidden documentary fence metadata characters")
            flush(number - 1)
            literal_indent, rst_literal_pending = None, False
            first = number
            fence = (opening[1][0], len(opening[1]))
            language = opening[2].strip().casefold()
            role = (
                "MATH_NOTATION"
                if language in {"math", "latex", "tex"}
                else "LITERAL_EXAMPLE"
            )
            pending.append(line)
            continue
        indent = len(line) - len(line.lstrip(" \t"))
        if literal_indent is not None:
            if not line.strip(" \t") or indent >= literal_indent:
                if role != "LITERAL_EXAMPLE" and has_hidden_controls(line):
                    raise NeedsNewCapability("Hidden documentary math characters")
                pending.append(line)
                continue
            flush(number - 1)
            literal_indent, role = None, "PROSE"
        directive = (
            re.match(
                r"^\s*\.\.\s+(code(?:-block)?|sourcecode|parsed-literal|literalinclude|math)::",
                line,
            )
            if markup == ".rst"
            else None
        )
        if directive:
            if has_hidden_controls(line):
                raise NeedsNewCapability("Hidden documentary directive characters")
            flush(number - 1)
            first = number
            role = "MATH_NOTATION" if directive[1] == "math" else "LITERAL_EXAMPLE"
            pending.append(line)
            literal_indent = indent + 1
            rst_literal_pending = False
            continue
        if (
            markup_enabled
            and line.strip(" \t")
            and line.startswith(("    ", "\t"))
            and (not pending or rst_literal_pending)
        ):
            flush(number - 1)
            first, role = number, "LITERAL_EXAMPLE"
            literal_indent = 1 if line.startswith("\t") else 4
            pending.append(line)
            rst_literal_pending = False
            continue
        if has_hidden_controls(line):
            raise NeedsNewCapability("Hidden documentary prose characters")
        heading = re.match(r"^(#{1,6})\s+(.+)$", line)
        rst_heading = number < len(lines) and bool(
            re.fullmatch(r"[=-]{3,}", lines[number])
        )
        if heading or rst_heading:
            flush(number - 1)
            if heading:
                depth, title = len(heading[1]), heading[2].strip()
            else:
                depth, title = 1, line.strip()
            headings[:] = headings[: depth - 1] + [title]
        elif rst_heading is False and re.fullmatch(r"[=-]{3,}", line) and number > 1:
            continue
        elif not line.strip():
            flush(number - 1)
        else:
            if not pending:
                first = number
            pending.append(line)
            rst_literal_pending = markup == ".rst" and line.rstrip().endswith("::")
    flush(len(lines))
    return blocks


def _signature_link_type(display, href, title, owner, owner_class):
    """Resolve explicit documentary class links without opening any resource."""
    display = " ".join(display.split())
    identifier = r"[A-Za-z_$]\w*(?:\.[A-Za-z_$]\w*)*"
    if not re.fullmatch(identifier, display) or len(href) > 2048 or len(title) > 512:
        return None
    if re.search(r"[\x00-\x20\x7f]", href):
        return None
    try:
        target = urlsplit(href)
    except ValueError:
        return None
    if target.scheme not in {"", "http", "https"} or target.query:
        return None
    # A type-parameter link points at the owner page, not at a class named L/T.
    if title and not re.fullmatch(
        r"(?:class(?: or interface)?|interface|enum(?: class)?|record class|annotation (?:type|interface)) in "
        + identifier,
        title,
    ):
        return None
    declared_package = title.rsplit(" in ", 1)[-1] if title else None
    path = unquote(target.path)
    if "\\" in path or re.search(r"[\x00-\x20\x7f]", path):
        return None
    if not path:
        if (
            target.fragment
            and owner
            and owner_class
            and display in {owner_class, owner_class.rsplit(".", 1)[-1]}
        ):
            package = owner[: -len(owner_class) - 1]
            if declared_package and declared_package != package:
                return None
            return owner
        return None
    segments = path.split("/")
    filename = segments.pop()
    if not filename.endswith(".html"):
        return None
    target_class = filename[:-5]
    if not re.fullmatch(identifier, target_class):
        return None
    short_display = (
        display[len(declared_package) + 1 :]
        if declared_package and display.startswith(declared_package + ".")
        else display
    )
    if target_class != short_display and not target_class.endswith("." + short_display):
        return None
    if target.scheme or target.netloc or path.startswith("/"):
        if not declared_package:
            return None
        package_parts = declared_package.split(".")
        if segments[-len(package_parts) :] != package_parts:
            return None
        return declared_package + "." + target_class
    if not owner or not owner_class or not owner.endswith("." + owner_class):
        return None
    package_parts = owner[: -len(owner_class) - 1].split(".")
    for segment in segments:
        if segment in {"", "."}:
            continue
        if segment == "..":
            if not package_parts:
                return None
            package_parts.pop()
        elif re.fullmatch(r"[A-Za-z_$]\w*", segment):
            package_parts.append(segment)
        else:
            return None
    package = ".".join(package_parts)
    if declared_package and package != declared_package:
        return None
    return package + "." + target_class if package else None


def _recognized_math_event(tag, attributes):
    return tag.rsplit(":", 1)[-1] == "math" or (
        tag == "img" and "mwe-math-fallback" in (attributes.get("class") or "")
    )


class _DocumentaryEventClassifier(HTMLParser):
    """Classify recognized markup restrictions without rendering source text."""

    EVENT_LIMIT = MAX_BLOCKS * 8

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.math = False
        self.quotation = False
        self.events = 0

    def _event(self):
        self.events += 1
        if self.events > self.EVENT_LIMIT:
            raise ValueError("documentary event classification limit")

    def handle_starttag(self, tag, attrs):
        self._event()
        tag = tag.casefold()
        # Hidden and empty markup are still source restrictions. This helper
        # neither reconstructs prose nor promotes mathematical token strings.
        self.math = self.math or _recognized_math_event(tag, dict(attrs))
        self.quotation = self.quotation or tag in {"q", "blockquote"}

    def handle_endtag(self, tag):
        self._event()

    def handle_data(self, data):
        self._event()

    def handle_comment(self, data):
        self._event()


class _DocumentHTML(HTMLParser):
    """Select visible article/main text; links remain text, resources stay inert."""

    SKIP: ClassVar[set[str]] = {
        "script",
        "style",
        "head",
        "nav",
        "footer",
        "template",
        "iframe",
        "object",
        "embed",
        "svg",
    }
    BLOCK: ClassVar[set[str]] = {
        "p",
        "div",
        "li",
        "dt",
        "dd",
        "pre",
        "tr",
        "section",
        "article",
        "main",
        "blockquote",
    }
    VOID: ClassVar[set[str]] = {
        "img",
        "br",
        "hr",
        "meta",
        "link",
        "input",
        "source",
        "wbr",
        "area",
        "base",
        "embed",
    }

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.stack, self.headings, self.parts, self.blocks = [], [], [], []
        self.first_line = 1
        self.in_main = False
        self.seen_main = False
        self.structure_stack = []
        self.structure_root = {"children": 0, "last_child": None, "gap": True}
        self.structure_events = 0
        self.structure_well_nested = True
        self.structure_frames = {}
        self.selected_structure_roots = []
        self.class_identities = []
        self.definition_term = ""
        self.definition_symbol = ""
        self.definition_stack = []
        self.math_parts = None
        self.math_depth = 0
        # These are reader-owned parent contexts, not source-declared authority.
        # Later math/quote events taint earlier flushes of the same parent.
        self.math_contexts = []
        self.unparented_math_context = self._new_context()
        self.javadoc_owner = ""
        self.javadoc_package = ""
        self.javadoc_class = ""
        self.members = []
        self.captures = []
        self.notes = []
        self.rows = []
        self.signature_flush = False
        self.legacy_headers = []
        self.legacy_details = []
        self.legacy_anchor = None
        self.legacy_package = ""
        self.legacy_class = ""
        self.signature_elements = []
        self.inline_literals = []
        self.inline_example_contexts = set()
        self.javadoc_class_structure = False
        self.legacy_javadoc_details = False

    def _javadoc_owner(self):
        return self.javadoc_owner or (
            self.javadoc_package + "." + self.javadoc_class
            if self.javadoc_package and self.javadoc_class
            else ""
        )

    def _capture_complete(self, kind, text, capture=None):
        text = " ".join(text.split())
        if kind == "signature-type-link":
            member = self.members[-1] if self.members else {}
            qualified = _signature_link_type(
                text,
                capture["href"],
                capture["title"],
                member.get("owner") or self._javadoc_owner(),
                self.javadoc_class,
            )
            if qualified and qualified != text:
                basis = {
                    "display_type": text,
                    "qualified_type": qualified,
                    "href": capture["href"],
                    "basis": "EXPLICIT_DOCUMENTARY_LINK_TARGET",
                }
                for signature, start in capture["signature_starts"]:
                    if len(signature.setdefault("type_bindings", [])) >= 128:
                        raise ValueError("signature type-link limit")
                    signature["parts"][start:] = [qualified]
                    signature["type_bindings"].append(basis)
        elif kind == "inheritance" and re.fullmatch(
            r"(?:[A-Za-z_$]\w*\.)+[A-Za-z_$]\w*", text
        ):
            # The current class, not a linked superclass, has the matching name.
            if self.javadoc_class and text.endswith("." + self.javadoc_class):
                self.javadoc_owner = text
        elif kind == "sub-title":
            package = re.fullmatch(
                r"Package\s+((?:[A-Za-z_$]\w*\.)*[A-Za-z_$]\w*)", text
            )
            if package:
                self.javadoc_package = package[1]
        elif kind == "legacy-package" and re.fullmatch(
            r"(?:[A-Za-z_$]\w*\.)+[A-Za-z_$]\w*", text
        ):
            self.javadoc_package = text
            self.legacy_package = text
        elif kind == "legacy-class-title":
            identity = re.fullmatch(
                r"(?:Class|Interface|Enum|Annotation Type)\s+([A-Za-z_$]\w*(?:\.[A-Za-z_$]\w*)*)(?:<[^\n]*>)?",
                text,
            )
            if identity:
                self.javadoc_class = identity[1]
                self.legacy_class = identity[1]
                self._remember_class_identity(identity[1], text)
        elif kind == "legacy-member-title" and self.members:
            member = self.members[-1]
            member["title_confirmed"] = text == member["name"]
        elif kind in {"member-signature", "legacy-member-signature"} and self.members:
            member = self.members[-1]
            display = " ".join(
                "".join(capture.get("display_parts", capture["parts"])).split()
            )
            if len(display) > 800 or len(text) > 2048:
                return False
            if kind == "legacy-member-signature" and not (
                re.search(r"\b(?:public|protected|private)\b", text)
                and re.search(
                    r"(?<![\w.$])" + re.escape(member["name"]) + r"\s*\(", text
                )
            ):
                return False
            member["signature"] = text
            member["signature_display"] = display
            member["signature_qualification_basis"] = capture.get("type_bindings", [])
            owner = member.get("owner") or self._javadoc_owner()
            if owner:
                member["symbol"] = owner + "." + member["name"]
            return True
        return False

    def _math_context(self):
        # Inline example/pre flushes do not start a new prose paragraph. Prefer
        # its active textual owner over an internal presentation container.
        for context in reversed(self.math_contexts):
            if context["tag"] in {"p", "li", "dt", "dd", "tr"}:
                return context
        return (
            self.math_contexts[-1]
            if self.math_contexts
            else self.unparented_math_context
        )

    def _new_context(self, **owner):
        member = getattr(self, "members", [])
        member = member[-1] if member else {}
        symbol = member.get("symbol")
        return {
            "math": False,
            "quotation": False,
            "blocks": [],
            "finalized": False,
            "in_main": self.in_main,
            "structure": self._current_structure(),
            "identity": {
                "title": symbol or (self.headings[-1] if self.headings else ""),
                "heading_path": (*self.headings, symbol)
                if symbol
                else tuple(self.headings),
                "symbol": symbol,
                "signature": member.get("signature"),
                "signature_language": "java" if member.get("signature") else None,
                "signature_display": member.get("signature_display"),
                "signature_qualification_basis": member.get(
                    "signature_qualification_basis", ()
                ),
                "member_anchor": member.get("anchor"),
                "declaration_kind": member.get("declaration_kind"),
                "line_start": self.getpos()[0],
            },
            **owner,
        }

    def _current_structure(self):
        if not self.structure_stack:
            return None
        return dict(self.structure_stack[-1]["view"])

    def _start_structure(self, tag):
        self.structure_events += 1
        if self.structure_events > MAX_BLOCKS * 8 or len(self.structure_stack) >= 128:
            raise ValueError("HTML structural traversal limit exceeded")
        parent = (
            self.structure_stack[-1] if self.structure_stack else self.structure_root
        )
        parent["children"] += 1
        parent_view = parent.get("view")
        path = [
            *(parent_view["element_path"] if parent_view else []),
            self.structure_events,
        ]
        view = {
            "schema_version": 1,
            "coordinate_basis": "HTML_PARSER_START_EVENTS_NOT_RAW_BYTES",
            "element_path": path,
            "tag_path": [*(parent_view["tag_path"] if parent_view else []), tag],
            "direct_child_ordinal": parent["children"],
            "previous_sibling_path": parent["last_child"],
            "gap_before_whitespace_only": parent["gap"],
        }
        parent["last_child"], parent["gap"] = path, True
        frame = {
            "view": view,
            "children": 0,
            "last_child": None,
            "gap": True,
            "skipped": False,
            "non_text": False,
        }
        self.structure_frames[self.structure_events] = frame
        return frame

    def _remember_class_identity(self, name, text):
        structure = self._current_structure()
        if structure is None:
            return
        if len(self.class_identities) >= 32:
            raise ValueError("HTML class identity limit exceeded")
        self.class_identities.append(
            {
                "class_name": name,
                "header_text": text,
                "element_path": structure["element_path"],
            }
        )

    def _completed_structure(self, structure):
        frame = self.structure_frames[structure["element_path"][-1]]
        return {
            **structure,
            "direct_child_count": frame["children"],
            "skipped_descendant_presence": frame["skipped"],
            "non_text_token_presence": frame["non_text"],
            "well_nested": self.structure_well_nested,
        }

    def _attach_structure(self, block, structure, member=None):
        if structure is not None:
            block["documentary_structure"] = {
                **structure,
                "callable_element_path": (member or {}).get("structure_path"),
            }

    def _structure_gap(self):
        parent = (
            self.structure_stack[-1] if self.structure_stack else self.structure_root
        )
        parent["gap"] = False

    def handle_comment(self, data):
        self._non_text_event()

    def handle_pi(self, data):
        self._non_text_event()

    def handle_decl(self, decl):
        self._non_text_event()

    def unknown_decl(self, data):
        self._non_text_event()

    def _non_text_event(self):
        self._structure_gap()
        for frame in self.structure_stack:
            frame["non_text"] = True

    def _close_structure(self, tag):
        index = next(
            (
                index
                for index in range(len(self.structure_stack) - 1, -1, -1)
                if self.structure_stack[index]["view"]["tag_path"][-1] == tag
            ),
            None,
        )
        if tag not in self.VOID and (
            index is None or index != len(self.structure_stack) - 1
        ):
            self.structure_well_nested = False
        if index is not None:
            del self.structure_stack[index:]

    def _finalize_context(self, context):
        if context["finalized"]:
            return
        context["finalized"] = True
        if context["blocks"] or not (context["math"] or context["quotation"]):
            return
        marker = {
            "schema_version": 1,
            "reason": "RECOGNIZED_RESTRICTION_WITHOUT_RENDERED_TEXT",
            "math_event": context["math"],
            "quotation_event": context["quotation"],
            "scope": "READER_EVENT_CONTEXT_NOT_SOURCE_ASSERTION",
            "inference_authority": False,
        }
        identity = dict(context["identity"])
        if re.fullmatch(r"h[1-6]", context.get("tag", "")):
            identity.update(
                title=self.headings[-1] if self.headings else "",
                heading_path=tuple(self.headings),
            )
        block = _block(
            "",
            **identity,
            line_end=self.getpos()[0],
            quotation=context["quotation"],
            documentary_math_presence=context["math"],
            documentary_role="SOURCE_CONTEXT_MARKER",
            documentary_context_marker=marker,
        )[0]
        self._attach_structure(
            block, context["structure"], context.get("member_structure")
        )
        context["blocks"].append(block)
        self.blocks.append((context["in_main"], block))
        if len(self.blocks) > MAX_BLOCKS:
            raise ValueError("HTML exceeds passage limit")

    def _mark_math(self):
        context = self._math_context()
        if context["math"]:
            return
        self._capture_unparented_event(context)
        context["math"] = True
        for block in context["blocks"]:
            block["documentary_math_presence"] = True

    def _mark_quotation(self):
        context = self._math_context()
        if context["quotation"]:
            return
        self._capture_unparented_event(context)
        context["quotation"] = True
        for block in context["blocks"]:
            block["quotation"] = True

    def _capture_unparented_event(self, context):
        # A pending unparented owner may have been created before <main> entered
        # the stack. Its FIRST actual event, not that earlier reset, identifies
        # the selection/heading/member scope of an otherwise empty passage.
        if "tag" not in context and not (context["math"] or context["quotation"]):
            current = self._new_context()
            context["in_main"] = current["in_main"]
            context["identity"] = current["identity"]
            context["structure"] = current["structure"]

    def _flush(self, heading=None):
        literal = bool(self.inline_literals) or any(
            tag == "pre" and not skip for tag, skip in self.stack
        )
        text = "".join(self.parts)
        if not literal:
            text = text.strip()
        self.parts.clear()
        if not text.strip(" \t\r\n"):
            return
        if heading is not None:
            self.headings[:] = self.headings[: heading - 1] + [text]
            if heading == 1:
                identity = re.match(
                    r"^(?:Class|Interface|Enum(?: Class)?|Record Class|Annotation Interface)\s+([A-Za-z_$]\w*(?:\.[A-Za-z_$]\w*)*)",
                    text,
                )
                if identity:
                    self.javadoc_class = identity[1]
                    self._remember_class_identity(identity[1], text)
            return
        member = self.members[-1] if self.members else {}
        signature = member.get("signature")
        symbol = member.get("symbol")
        role = (
            "DOCUMENTARY_SIGNATURE"
            if self.signature_flush
            or (
                any(tag == "dt" and not skip for tag, skip in self.stack)
                and "(" in self.definition_term
                and not self.notes
            )
            else "LITERAL_EXAMPLE"
            if literal
            else "PROSE"
        )
        note_label, note_origin, rendering_basis = None, None, None
        math_context = self._math_context()
        math_presence = math_context["math"]
        quotation = math_context["quotation"] or any(
            tag in {"blockquote", "q"} and not skip for tag, skip in self.stack
        )
        origin_start = self.first_line
        if self.notes and any(tag == "dd" and not skip for tag, skip in self.stack):
            note = self.notes[-1]
            math_presence = math_presence or note.get("label_math_presence", False)
            quotation = quotation or note.get("label_quotation", False)
            note_label = note["label"] or None
            if note_label:
                note_origin = {
                    "text": note_label,
                    "line_start": note.get("label_line_start"),
                    "line_end": note.get("label_line_end"),
                }
                if not literal:
                    text = note_label + " " + text
                    rendering_basis = "PRESENTATIONAL_REPEAT_OF_ORIGINAL_DL_LABEL"
                    if note_origin["line_start"] is not None:
                        origin_start = min(origin_start, note_origin["line_start"])
        if not signature:
            signature = (
                self.definition_term[:800] if "(" in self.definition_term else None
            )
            symbol = (
                self.definition_symbol
                or re.sub(
                    r"^(?:(?:class|classmethod|staticmethod|async)\s+)+",
                    "",
                    self.definition_term.split("(", 1)[0],
                )
                if "(" in self.definition_term
                else None
            )
        for block in _block(
            text,
            symbol
            or self.definition_term
            or (self.headings[-1] if self.headings else ""),
            (*self.headings, symbol)
            if symbol
            else (*self.headings, self.definition_term)
            if self.definition_term
            else self.headings,
            origin_start,
            self.getpos()[0],
            symbol=symbol,
            signature=signature,
            signature_language="java" if member and signature else None,
            signature_display=member.get("signature_display"),
            signature_qualification_basis=member.get(
                "signature_qualification_basis", ()
            ),
            member_anchor=member.get("anchor"),
            quotation=quotation,
            documentary_role=role,
            declaration_kind=member.get("declaration_kind") if signature else None,
            documentary_note_label=note_label,
            documentary_note_label_origin=note_origin,
            documentary_rendering_basis=rendering_basis,
            documentary_math_presence=math_presence,
        ):
            structure = (
                self._current_structure()
                if (literal and self.inline_literals)
                or (
                    "tag" not in math_context
                    and not (math_context["math"] or math_context["quotation"])
                )
                else math_context["structure"]
            )
            self._attach_structure(block, structure, member)
            self.blocks.append((self.in_main, block))
            math_context["blocks"].append(block)
            # A quoted ancestor is represented by its actual quoted descendant,
            # not an additional empty marker after that descendant closes.
            for ancestor in self.math_contexts:
                if ancestor is not math_context and ancestor["quotation"] and quotation:
                    ancestor["blocks"].append(block)
            if len(self.blocks) > MAX_BLOCKS:
                raise ValueError("HTML exceeds passage limit")

    def handle_starttag(self, tag, attrs):
        tag = tag.casefold()
        structure = self._start_structure(tag)
        # Inline <q> may close before the prose parent flushes, or be empty or
        # hidden. Its recognition is provenance only; display stays untouched.
        if tag == "q":
            self._mark_quotation()
        attributes = dict(attrs)
        style = re.sub(r"\s+", "", attributes.get("style") or "").lower()
        hidden = (
            "hidden" in attributes
            or attributes.get("aria-hidden") == "true"
            or "display:none" in style
            or "visibility:hidden" in style
        )
        classes = (attributes.get("class") or "").split()
        # Sphinx's permalink control is presentation, not part of the callable
        # spelling (nor of a heading). Literal pilcrows elsewhere remain text.
        skip = (
            hidden
            or tag in self.SKIP
            or (tag == "a" and "headerlink" in classes)
            or any(item[1] for item in self.stack)
        )
        if skip:
            structure["skipped"] = True
            for frame in self.structure_stack:
                frame["skipped"] = True
        if self.math_parts is not None:
            # Rendering captures MathML separately, but structural witnesses
            # still traverse its actual owners, hidden children and end tags.
            if tag not in self.VOID:
                self.structure_stack.append(structure)
            self.math_parts.append(re.sub(r"/\s*>$", ">", self.get_starttag_text()))
            self.math_depth += 1
            if self.math_depth > 24 or sum(map(len, self.math_parts)) > 12000:
                raise ValueError("MathML capture limit")
            return
        if tag in {"main", "article"} and not skip and not self.in_main:
            self.selected_structure_roots.append(structure["view"])
        # Hidden notation still belongs to its visible source parent. Neither
        # successful scalar rendering nor an empty/invalid fallback alt makes
        # the parent eligible as a plain-prose conditional source.
        if _recognized_math_event(tag, attributes):
            self._mark_math()
        if tag.rsplit(":", 1)[-1] == "math" and not skip:
            if not self.parts:
                self.first_line = self.getpos()[0]
            self.math_parts = [re.sub(r"/\s*>$", ">", self.get_starttag_text())]
            self.math_depth = 1
            self.structure_stack.append(structure)
            return
        if (
            tag == "img"
            and not skip
            and "mwe-math-fallback" in (attributes.get("class") or "")
        ):
            self._math_text(attributes.get("alt") or "", latex=True)
            return
        if tag in self.BLOCK or tag == "dl" or re.fullmatch(r"h[1-6]", tag):
            self._flush()
            self._finalize_context(self.unparented_math_context)
            self.unparented_math_context = self._new_context()
            if (tag in self.BLOCK and tag not in {"main", "article"}) or re.fullmatch(
                r"h[1-6]", tag
            ):
                self.math_contexts.append(
                    self._new_context(
                        depth=len(self.stack),
                        tag=tag,
                        structure=structure["view"],
                        member_structure=dict(self.members[-1]) if self.members else {},
                    )
                )
        if tag == "blockquote":
            self._mark_quotation()
        if not skip:
            if (tag == "section" and "class-description" in classes) or (
                tag == "div" and "type-signature" in classes
            ):
                self.javadoc_class_structure = True
            if (
                tag == "code"
                and not self.inline_literals
                and not any(tag == "pre" and not skipped for tag, skipped in self.stack)
                and not any(
                    capture["kind"] in {"member-signature", "legacy-member-signature"}
                    for capture in self.captures
                )
            ):
                prefix = " ".join("".join(self.parts).split())[-1200:]
                scope = next(
                    (
                        index
                        for index in range(len(self.stack) - 1, -1, -1)
                        if self.stack[index][0] in {"p", "div", "li", "dd"}
                    ),
                    None,
                )
                explicit = re.search(
                    r"\b(?:for example|for instance)\b|\bexamples?\s*:|\blike in\s*$",
                    prefix,
                    re.IGNORECASE,
                )
                continuation = scope in self.inline_example_contexts and re.search(
                    r"\b(?:when )?compared to\s*$", prefix, re.IGNORECASE
                )
                if explicit or continuation:
                    self._flush()
                    self.inline_literals.append(len(self.stack))
                    if scope is not None:
                        self.inline_example_contexts.add(scope)
            if tag == "div" and "header" in classes:
                self.legacy_headers.append(len(self.stack))
            if self.legacy_headers and "subTitle" in classes:
                self.captures.append(
                    {"depth": len(self.stack), "kind": "legacy-package", "parts": []}
                )
            if self.legacy_headers and tag == "h2" and "title" in classes:
                self.captures.append(
                    {
                        "depth": len(self.stack),
                        "kind": "legacy-class-title",
                        "parts": [],
                    }
                )
            if tag == "div" and "details" in classes:
                self.legacy_details.append({"depth": len(self.stack), "kind": None})
            identity = attributes.get("name") or attributes.get("id") or ""
            if (
                tag in {"a", "li"}
                and self.legacy_details
                and self.legacy_package
                and self.legacy_class
            ):
                detail = self.legacy_details[-1]
                if identity in {
                    "method_detail",
                    "constructor_detail",
                    "method-detail",
                    "constructor-detail",
                }:
                    self.legacy_javadoc_details = True
                    detail["kind"] = (
                        "constructor_declaration"
                        if identity.startswith("constructor")
                        else "method_declaration"
                    )
                elif detail["kind"] and identity and len(identity) <= 1024:
                    method = re.fullmatch(
                        r"([A-Za-z_$]\w*)\([^\n]*\)", identity
                    ) or re.fullmatch(r"([A-Za-z_$]\w*)-[\w.$\[\]-]*-", identity)
                    self.legacy_anchor = (
                        {
                            "name": method[1],
                            "scope": detail["depth"],
                            "declaration_kind": detail["kind"],
                            "owner": self.legacy_package + "." + self.legacy_class,
                            "anchor": identity,
                        }
                        if method
                        else None
                    )
            if (
                tag == "li"
                and "blockList" in classes
                and self.legacy_anchor
                and self.legacy_details
                and self.legacy_anchor["scope"] == self.legacy_details[-1]["depth"]
            ):
                self.members.append(
                    {
                        **self.legacy_anchor,
                        "depth": len(self.stack),
                        "legacy": True,
                        "structure_path": structure["view"]["element_path"],
                    }
                )
                self.legacy_anchor = None
            member = self.members[-1] if self.members else {}
            if (
                member.get("legacy")
                and tag == "h4"
                and not member.get("signature_attempted")
            ):
                self.captures.append(
                    {
                        "depth": len(self.stack),
                        "kind": "legacy-member-title",
                        "parts": [],
                    }
                )
            if (
                tag == "pre"
                and member.get("legacy")
                and member.get("title_confirmed")
                and not member.get("signature_attempted")
            ):
                member["signature_attempted"] = True
                self.captures.append(
                    {
                        "depth": len(self.stack),
                        "kind": "legacy-member-signature",
                        "parts": [],
                    }
                )
            if tag == "tr":
                self.rows.append({"depth": len(self.stack), "cells": 0})
            if tag in {"td", "th"} and self.rows:
                if self.rows[-1]["cells"]:
                    self.parts.append(" | ")
                self.rows[-1]["cells"] += 1
            if tag == "section" and "detail" in classes:
                identity = attributes.get("id") or ""
                method = re.match(r"^([A-Za-z_$]\w*)\([^\n]*\)$", identity)
                if method:
                    self.members.append(
                        {
                            "depth": len(self.stack),
                            "name": method[1],
                            "declaration_kind": "method_declaration",
                            "anchor": identity,
                            "structure_path": structure["view"]["element_path"],
                        }
                    )
                elif re.fullmatch(r"<init>\([^\n]*\)", identity) and self.javadoc_class:
                    self.members.append(
                        {
                            "depth": len(self.stack),
                            "name": self.javadoc_class.rsplit(".", 1)[-1],
                            "declaration_kind": "constructor_declaration",
                            "anchor": identity,
                            "structure_path": structure["view"]["element_path"],
                        }
                    )
            for kind in ("inheritance", "sub-title", "member-signature"):
                if kind in classes:
                    if kind == "member-signature" and self.members:
                        self.javadoc_class_structure = True
                    self.captures.append(
                        {"depth": len(self.stack), "kind": kind, "parts": []}
                    )
            if tag == "span" and "element-name" in classes:
                self.signature_elements.append(len(self.stack))
            if tag == "a" and not self.signature_elements:
                signatures = [
                    capture
                    for capture in self.captures
                    if capture["kind"]
                    in {"member-signature", "legacy-member-signature"}
                ]
                if signatures:
                    self.captures.append(
                        {
                            "depth": len(self.stack),
                            "kind": "signature-type-link",
                            "parts": [],
                            "href": attributes.get("href") or "",
                            "title": attributes.get("title") or "",
                            "signature_starts": [
                                (capture, len(capture["parts"]))
                                for capture in signatures
                            ],
                        }
                    )
            if (
                tag == "dl"
                and self.members
                and ("notes" in classes or self.members[-1].get("legacy"))
            ):
                self.notes.append({"depth": len(self.stack), "label": ""})
        if tag == "dl":
            self.definition_stack.append((self.definition_term, self.definition_symbol))
            self.definition_term = ""
            self.definition_symbol = ""
        elif tag == "dt":
            self.definition_term = ""
            identity = attributes.get("id") or ""
            self.definition_symbol = (
                identity
                if re.fullmatch(r"(?:[A-Za-z_]\w*\.)+[A-Za-z_]\w*", identity)
                else ""
            )
        if tag == "br" and not skip:
            self.parts.append("\n")
        if tag not in self.VOID:
            self.stack.append((tag, skip))
            self.structure_stack.append(structure)
        self.in_main = any(t in {"main", "article"} and not s for t, s in self.stack)
        self.seen_main = self.seen_main or self.in_main

    def handle_endtag(self, tag):
        tag = tag.casefold()
        if self.math_parts is not None:
            self._close_structure(tag)
            self.math_parts.append(f"</{tag}>")
            self.math_depth -= 1
            if self.math_depth == 0:
                self._math_text("".join(self.math_parts))
                self.math_parts = None
            return
        closing_depth = next(
            (
                index
                for index in range(len(self.stack) - 1, -1, -1)
                if self.stack[index][0] == tag
            ),
            None,
        )
        if tag not in self.VOID and (
            closing_depth is None or closing_depth != len(self.stack) - 1
        ):
            self.structure_well_nested = False
        if closing_depth is not None:
            ending = [
                capture
                for capture in self.captures
                if capture["depth"] >= closing_depth
            ]
            for capture in reversed(ending):
                accepted = self._capture_complete(
                    capture["kind"], "".join(capture["parts"]), capture
                )
                self.signature_flush = (
                    self.signature_flush
                    or capture["kind"] == "member-signature"
                    or (capture["kind"] == "legacy-member-signature" and accepted)
                )
            self.captures = [
                capture for capture in self.captures if capture["depth"] < closing_depth
            ]
        if tag == "dt":
            self.definition_term = "".join(self.parts).strip()[:800]
            if self.notes:
                self.notes[-1]["label"] = self.definition_term
                self.notes[-1]["label_math_presence"] = self._math_context()["math"]
                self.notes[-1]["label_quotation"] = self._math_context()[
                    "quotation"
                ] or any(
                    element in {"blockquote", "q"} and not skip
                    for element, skip in self.stack
                )
                self.notes[-1]["label_line_start"] = self.first_line
                self.notes[-1]["label_line_end"] = self.getpos()[0]
        if tag == "code" and closing_depth in self.inline_literals:
            self._flush()
        if tag in self.BLOCK or re.fullmatch(r"h[1-6]", tag):
            self._flush(int(tag[1]) if re.fullmatch(r"h[1-6]", tag) else None)
        if tag == "dl":
            self._flush()
            self.definition_term, self.definition_symbol = (
                self.definition_stack.pop() if self.definition_stack else ("", "")
            )
        self.signature_flush = False
        if closing_depth is not None:
            for context in reversed(self.math_contexts):
                if context["depth"] >= closing_depth:
                    self._finalize_context(context)
            self.math_contexts = [
                context
                for context in self.math_contexts
                if context["depth"] < closing_depth
            ]
            if tag in self.BLOCK or tag == "dl" or re.fullmatch(r"h[1-6]", tag):
                self._finalize_context(self.unparented_math_context)
                self.unparented_math_context = self._new_context()
            self.notes = [note for note in self.notes if note["depth"] < closing_depth]
            self.members = [
                member for member in self.members if member["depth"] < closing_depth
            ]
            self.rows = [row for row in self.rows if row["depth"] < closing_depth]
            self.signature_elements = [
                depth for depth in self.signature_elements if depth < closing_depth
            ]
            self.inline_literals = [
                depth for depth in self.inline_literals if depth < closing_depth
            ]
            self.inline_example_contexts = {
                depth for depth in self.inline_example_contexts if depth < closing_depth
            }
            self.legacy_headers = [
                depth for depth in self.legacy_headers if depth < closing_depth
            ]
            self.legacy_details = [
                detail
                for detail in self.legacy_details
                if detail["depth"] < closing_depth
            ]
            if self.legacy_anchor and self.legacy_anchor["scope"] >= closing_depth:
                self.legacy_anchor = None
        for index in range(len(self.stack) - 1, -1, -1):
            if self.stack[index][0] == tag:
                self.stack[index:] = []
                break
        self._close_structure(tag)
        self.in_main = any(t in {"main", "article"} and not s for t, s in self.stack)

    def handle_data(self, data):
        if data.strip():
            self._structure_gap()
        if self.math_parts is not None:
            self.math_parts.append(escape(data, quote=False))
            if sum(map(len, self.math_parts)) > 12000:
                raise ValueError("MathML capture limit")
            return
        if any(skip for _, skip in self.stack):
            return
        literal = bool(self.inline_literals) or any(
            tag == "pre" and not skip for tag, skip in self.stack
        )
        # Identity captures are documentary even inside a signature <pre>.
        # Inert examples retain their characters; skipped scripts stay inert.
        if (not literal or self.captures) and has_hidden_controls(data):
            raise NeedsNewCapability("Hidden documentary HTML characters")
        for capture in self.captures:
            capture["parts"].append(data)
            if capture["kind"] in {"member-signature", "legacy-member-signature"}:
                capture.setdefault("display_parts", []).append(data)
        if not self.parts:
            self.first_line = self.getpos()[0]
        self.parts.append(data)

    def _math_text(self, notation, *, latex=False):
        self._mark_math()
        if not self.parts and latex:
            self.first_line = self.getpos()[0]
        try:
            converted = latex_scalar(notation) if latex else mathml_scalar(notation)
            self.parts.append(
                ("\n" + converted + "\n") if "=" in converted else converted
            )
        except ValueError:
            # Keep original bytes in CAS. An explicit marker prevents surrounding
            # prose from silently becoming an executable formula/definition.
            self.parts.append(" [UNSUPPORTED_MATH_NOTATION] ")

    def finish(self):
        if self.math_parts is not None:
            self._mark_math()
            self.parts.append(" [UNSUPPORTED_MATH_NOTATION] ")
        self._flush()
        for context in reversed(self.math_contexts):
            self._finalize_context(context)
        self._finalize_context(self.unparented_math_context)
        if self.stack or self.structure_stack:
            self.structure_well_nested = False
        selected = [b for main, b in self.blocks if main]
        result = selected if self.seen_main else [b for _, b in self.blocks]
        for block in result:
            if "documentary_structure" in block:
                block["documentary_structure"] = self._completed_structure(
                    block["documentary_structure"]
                )
        owner = self._javadoc_owner()
        modern = (
            self.javadoc_class_structure
            and owner
            and self.javadoc_class
            and owner.endswith("." + self.javadoc_class)
        )
        legacy = (
            self.legacy_javadoc_details and self.legacy_package and self.legacy_class
        )
        if modern or legacy:
            root = (
                self._completed_structure(
                    {
                        **self.selected_structure_roots[0],
                        "callable_element_path": None,
                    }
                )
                if len(self.selected_structure_roots) == 1
                else None
            )
            class_structure = {
                "schema_version": 1,
                "coordinate_basis": "HTML_PARSER_START_EVENTS_NOT_RAW_BYTES",
                "class_identities": self.class_identities,
                "root_structure": root,
            }
            basis = {
                "kind": "EXPLICIT_JAVADOC_CLASS_STRUCTURE",
                "class_name": self.javadoc_class if modern else self.legacy_class,
                "qualified_class": owner
                if modern
                else self.legacy_package + "." + self.legacy_class,
            }
            enclosing_blocks = [
                ordinal
                for ordinal, block in enumerate(result, 1)
                if not block.get("signature") and not block.get("symbol")
            ]
            for block in result:
                block["documentary_context"] = "JAVA_API_DOCUMENTATION"
                block["documentary_context_basis"] = basis
                block["documentary_html_class_structure"] = class_structure
                if block.get("signature") and block.get("symbol"):
                    # Structural coverage, not inferred obligation semantics.
                    # Rejection of an overview during review must not erase its
                    # existence from the installed callable's context boundary.
                    block["documentary_enclosing_context_blocks"] = enclosing_blocks
        return result


def _documentation_blocks(text, title, owners, start, end, **identity):
    """Split prose from inert examples; locations conservatively cover the raw doc.

    AST docstring cleaning and comment-prefix removal change column positions,
    so sub-passages retain the original documentation span, not invented lines.
    Raw bytes remain authoritative in CAS.
    """
    if re.search(r"<pre\b", text, re.IGNORECASE):
        parser = _DocumentHTML()
        parser.feed(text)
        parser.close()
        passages = []
        for block in parser.finish():
            if block["documentary_role"] in {
                "LITERAL_EXAMPLE",
                "SOURCE_CONTEXT_MARKER",
            }:
                passages.append(block)
            else:
                regenerated = _paragraphs(block["text"], markup=".rst")
                for passage in regenerated:
                    if "documentary_structure" in block:
                        passage["documentary_structure"] = dict(
                            block["documentary_structure"]
                        )
                    # Re-paragraphing is a presentation adapter, not a license
                    # to clear reader-classified parent provenance restrictions.
                    passage["documentary_math_presence"] = (
                        passage["documentary_math_presence"]
                        or block["documentary_math_presence"]
                    )
                    passage["quotation"] = passage["quotation"] or block["quotation"]
                passages.extend(regenerated)
    else:
        passages = _paragraphs(text, markup=".rst")
        if "<" in text:
            classifier = _DocumentaryEventClassifier()
            try:
                if len(text) > MAX_INPUT_BYTES:
                    raise ValueError("documentary classification input limit")
                classifier.feed(text)
                classifier.close()
                math, quotation = classifier.math, classifier.quotation
            except (ValueError, AssertionError, RecursionError):
                # Unknown classification cannot license inference. Keep the
                # exact legacy raw-markup display, but clamp the whole context.
                math, quotation = True, True
            for passage in passages:
                passage["documentary_math_presence"] = (
                    passage["documentary_math_presence"] or math
                )
                passage["quotation"] = passage["quotation"] or quotation
    for passage in passages:
        passage.update(identity)
        passage["title"] = title
        passage["heading_path"] = list(owners) + passage["heading_path"]
        passage["line_start"], passage["line_end"] = start, end
    return passages


def _python(raw):
    if len(raw) > 8 * 1024 * 1024:
        raise ValueError("Python AST input exceeds limit")
    encoding, _ = tokenize.detect_encoding(io.BytesIO(raw).readline)
    text = raw.decode(encoding)
    try:
        tree = ast.parse(text)
    except (SyntaxError, RecursionError) as error:
        raise NeedsNewCapability(
            "NEEDS_NEW_CAPABILITY: invalid or unsupported Python syntax"
        ) from error
    result = []

    def visit(node, prefix=()):
        is_symbol = isinstance(
            node, (ast.Module, ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)
        )
        current = (*prefix, node.name) if hasattr(node, "name") else prefix
        original_doc = ast.get_docstring(node, clean=False) if is_symbol else None
        if original_doc:
            if has_hidden_controls(original_doc):
                raise NeedsNewCapability("Hidden documentary Python docstring characters")
            value = node.body[0].value
            doc = ast.get_docstring(node, clean=True)
            signature = None
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                signature = f"{node.name}({ast.unparse(node.args)})"
                if node.returns is not None:
                    signature += " -> " + ast.unparse(node.returns)
            symbol = ".".join(current) or "module"
            result.extend(
                _documentation_blocks(
                    doc,
                    symbol,
                    current,
                    value.lineno,
                    value.end_lineno,
                    symbol=symbol,
                    signature=signature,
                    signature_language="python" if signature else None,
                )
            )
        for child in ast.iter_child_nodes(node):
            visit(child, current if is_symbol else prefix)

    visit(tree)
    return result


def _java(raw):
    import tree_sitter_java
    from tree_sitter import Language, Parser

    if len(raw) > 8 * 1024 * 1024:
        raise ValueError("Java AST input exceeds limit")
    raw.decode("utf-8", errors="strict")
    root = Parser(Language(tree_sitter_java.language())).parse(raw).root_node
    if root.has_error:
        raise NeedsNewCapability(
            "NEEDS_NEW_CAPABILITY: invalid or unsupported Java syntax"
        )
    package_nodes = [
        node for node in root.named_children if node.type == "package_declaration"
    ]
    if len(package_nodes) > 1:
        raise NeedsNewCapability(
            "NEEDS_NEW_CAPABILITY: ambiguous Java package identity"
        )
    package = []
    if package_nodes:
        # Package has no 'name' field in this grammar. Its unique identifier
        # subtree excludes annotations; AST comments never become name parts.
        identifiers = [
            node
            for node in package_nodes[0].named_children
            if node.type in {"identifier", "scoped_identifier"}
        ]
        if len(identifiers) != 1:
            raise NeedsNewCapability(
                "NEEDS_NEW_CAPABILITY: unsupported Java package identity"
            )
        package_pending = [identifiers[0]]
        while package_pending:
            part = package_pending.pop()
            if part.type == "identifier":
                package.append(raw[part.start_byte : part.end_byte].decode("utf-8"))
                if len(package) > 32 or sum(map(len, package)) > 1024:
                    raise NeedsNewCapability(
                        "NEEDS_NEW_CAPABILITY: Java package identity exceeds limit"
                    )
            elif part.type == "scoped_identifier":
                package_pending.extend(reversed(part.named_children))
            elif part.type not in {"block_comment", "line_comment"}:
                raise NeedsNewCapability(
                    "NEEDS_NEW_CAPABILITY: unsupported Java package identity"
                )
    declarations, comments = [], []
    pending = [(root, tuple(package))]
    kinds = {
        "class_declaration",
        "interface_declaration",
        "enum_declaration",
        "record_declaration",
        "method_declaration",
        "constructor_declaration",
        "field_declaration",
    }
    while pending:
        node, owners = pending.pop()
        current = owners
        if node.type in kinds:
            name = node.child_by_field_name("name")
            if node.type == "field_declaration" and name is None:
                variables = [
                    child
                    for child in node.named_children
                    if child.type == "variable_declarator"
                ]
                # A shared comment on multiple variables has no unique member.
                if len(variables) == 1:
                    name = variables[0].child_by_field_name("name")
            current = (
                (*owners, raw[name.start_byte : name.end_byte].decode("utf-8"))
                if name
                else owners
            )
            declarations.append((node, current))
        if (
            node.type == "block_comment"
            and raw[node.start_byte : node.start_byte + 3] == b"/**"
        ):
            comments.append(node)
        pending.extend((child, current) for child in reversed(node.named_children))
    declarations.sort(key=lambda item: item[0].start_byte)
    associated_comments = []
    for comment in sorted(comments, key=lambda node: node.start_byte):
        associated = next(
            (
                (node, names)
                for node, names in declarations
                if node.start_byte >= comment.end_byte
                and not raw[comment.end_byte : node.start_byte].strip()
            ),
            None,
        )
        associated_comments.append((comment, associated))
    declaration_documentation = {
        associated[0].start_byte: {
            "comment_start_byte": comment.start_byte,
            "comment_end_byte": comment.end_byte,
        }
        for comment, associated in associated_comments
        if associated
        and associated[0].type
        in {
            "class_declaration",
            "interface_declaration",
            "enum_declaration",
            "record_declaration",
        }
    }
    result = []
    for comment, associated in associated_comments:
        symbol, signature, owners, declaration_kind = None, None, (), None
        if associated:
            node, owners = associated
            declaration_kind = node.type
            symbol = ".".join(owners)
            body = node.child_by_field_name("body")
            end = body.start_byte if body else node.end_byte
            if end - node.start_byte > 8192:
                raise NeedsNewCapability(
                    "NEEDS_NEW_CAPABILITY: complete Java signature exceeds limit"
                )
            signature = raw[node.start_byte : end].decode("utf-8").strip()
            if len(signature) > 2048:
                raise NeedsNewCapability(
                    "NEEDS_NEW_CAPABILITY: complete Java signature exceeds limit"
                )
        enclosing_declarations = []
        enclosing_documentation = []
        enclosing_original_bindings = []
        if associated:
            for parent, names in declarations:
                if (
                    parent.type
                    in {
                        "class_declaration",
                        "interface_declaration",
                        "enum_declaration",
                        "record_declaration",
                    }
                    and parent.start_byte < node.start_byte
                    and parent.end_byte >= node.end_byte
                ):
                    parent_body = parent.child_by_field_name("body")
                    parent_end = (
                        parent_body.start_byte if parent_body else parent.end_byte
                    )
                    header = raw[parent.start_byte : parent_end].decode("utf-8").strip()
                    if len(header) > 2048 or len(enclosing_declarations) >= 32:
                        raise NeedsNewCapability(
                            "NEEDS_NEW_CAPABILITY: enclosing Java declaration exceeds limit"
                        )
                    enclosing_declarations.append(
                        {"symbol": ".".join(names), "signature": header}
                    )
                    documentation = declaration_documentation.get(parent.start_byte)
                    enclosing_original_bindings.append(
                        {
                            "symbol": ".".join(names),
                            "declaration_start_byte": parent.start_byte,
                            "declaration_header_end_byte": parent_end,
                            "declaration_end_byte": parent.end_byte,
                            "documentation_span": [
                                documentation["comment_start_byte"],
                                documentation["comment_end_byte"],
                            ]
                            if documentation
                            else None,
                        }
                    )
                    if parent.start_byte in declaration_documentation:
                        enclosing_documentation.append(
                            {
                                "symbol": ".".join(names),
                                **declaration_documentation[parent.start_byte],
                            }
                        )
        package_signature = (
            raw[package_nodes[0].start_byte : package_nodes[0].end_byte].decode("utf-8")
            if package_nodes
            else ""
        )
        if len(package_signature) > 2048:
            raise NeedsNewCapability(
                "NEEDS_NEW_CAPABILITY: Java package declaration exceeds limit"
            )
        text = raw[comment.start_byte + 3 : comment.end_byte - 2].decode("utf-8")
        # Validate the original comment before margin/line/strip rendering can
        # erase controls. Source method bodies are not documentary authority.
        if has_hidden_controls(text):
            raise NeedsNewCapability("Hidden documentary Java comment characters")
        # The AST supplies the original source-line margin. Remove exactly that
        # structural margin on continuation lines, not their additional indent.
        # Common-indent/dedent guesses can turn a real indented example into
        # inference prose. Conversely retaining the Java source margin hides
        # ordinary Returns/Throws/Unless paragraphs as an inert RST example.
        line_start = raw.rfind(b"\n", 0, comment.start_byte) + 1
        margin = raw[line_start : comment.start_byte].decode("utf-8")
        if margin and not margin.strip(" \t"):
            lines = text.splitlines(keepends=True)
            text = lines[0] + "".join(line.removeprefix(margin) for line in lines[1:])
        text = re.sub(r"(?m)^\s*\* ?", "", text).strip()
        result.extend(
            _documentation_blocks(
                text,
                symbol or "Javadoc",
                owners,
                comment.start_point.row + 1,
                comment.end_point.row + 1,
                symbol=symbol,
                signature=signature,
                signature_language="java" if signature else None,
                declaration_kind=declaration_kind,
                documentary_java_original_binding={
                    "schema_version": 1,
                    "coordinate_basis": "ORIGINAL_UTF8_BYTES",
                    "comment_span": [comment.start_byte, comment.end_byte],
                    "declaration_span": [node.start_byte, end, node.end_byte]
                    if associated
                    else None,
                },
                documentary_enclosing_java_original_bindings=enclosing_original_bindings,
                documentary_enclosing_java_declarations=enclosing_declarations,
                documentary_enclosing_java_documentation=enclosing_documentation,
                documentary_java_package_signature=package_signature,
                documentary_context="JAVA_API_DOCUMENTATION",
                documentary_context_basis={
                    "kind": "JAVA_AST_DOCUMENTATION",
                    "declaration_kind": declaration_kind,
                },
            )
        )
    return result


def _comment_documentation(text):
    # Strings and ordinary comments take precedence over documentary comments.
    tokens = re.compile(
        r'"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'|`(?:\\.|[^`\\])*`|//[^\n]*|(?P<doc>/\*\*.*?\*/)|/\*.*?\*/',
        re.DOTALL,
    )
    result = []
    for match in tokens.finditer(text):
        if match["doc"] is None:
            continue
        original_doc = match["doc"][3:-2]
        if has_hidden_controls(original_doc):
            raise NeedsNewCapability("Hidden documentary comment characters")
        doc = re.sub(r"(?m)^\s*\* ?", "", original_doc).strip()
        start = text.count("\n", 0, match.start()) + 1
        end = start + match["doc"].count("\n")
        result.extend(
            _documentation_blocks(doc, "Documentation comment", (), start, end)
        )
    return result


def _pdf(raw):
    if not raw.startswith(b"%PDF-"):
        raise ValueError("invalid PDF header")
    worker = Path(__file__).with_name("pdf_text_worker.py")
    try:
        completed = subprocess.run(
            [sys.executable, "-I", "-s", "-B", str(worker)],
            input=raw,
            capture_output=True,
            timeout=45,
            check=False,
        )
    except subprocess.TimeoutExpired as error:
        raise NeedsNewCapability("NEEDS_NEW_CAPABILITY: PDF reader timeout") from error
    try:
        result = json.loads(completed.stdout)
    except (ValueError, UnicodeError) as error:
        raise NeedsNewCapability(
            "NEEDS_NEW_CAPABILITY: PDF worker resource limit or reader failure"
        ) from error
    if completed.returncode or "error" in result:
        raise NeedsNewCapability(
            "NEEDS_NEW_CAPABILITY: " + result.get("reason", "PDF reader failure")
        )
    blocks, issues = [], []
    for page in result["pages"]:
        if not page["text"].strip():
            issues.append(
                {
                    "page": page["page"],
                    "status": "OCR_REQUIRED" if page["has_image"] else "EMPTY_PAGE",
                }
            )
        blocks.extend(_paragraphs(page["text"], page=page["page"]))
    return blocks, issues
