"""Finite whole-paragraph API purpose grammar, never a behavior authority.

Installed context admission and policy wire parsing are separate capabilities.
This classifier alone cannot authorize a scenario or execute source examples.
"""

from __future__ import annotations

import json
import re

_PURPOSES = (
    "text formatting",
    "string processing",
    "number conversion",
    "numeric calculation",
    "value comparison",
    "document processing",
)
_PURPOSE = "(?:" + "|".join(map(re.escape, _PURPOSES)) + ")"
_INFORMATIONAL = re.compile(
    r"(?:This (?:class|interface) (?:documents|provides|contains) "
    r"(?:routines|methods|functions)"
    r"|A (?:collection|set) of (?:routines|methods|functions) for "
    + _PURPOSE
    + r"|This class provides (?:routines|methods|functions) for "
    + _PURPOSE
    + r"|(?:Utility|Helper) class for "
    + _PURPOSE
    + r"|(?:Math|Numeric|String|Text|Document) utility (?:methods|functions))\."
)
DOCUMENTARY_API_CONTEXT_POLICY_V1 = "DOCUMENTARY_API_CONTEXT_POLICY_V1"
API_CONTEXT_SCOPE = "SOURCE_DECLARED_MEMBER_CONTEXT_NOT_JAVA_EXECUTION"
MAX_CONTEXT_NODES = 256
MAX_CONTEXT_BYTES = 256 * 1024
API_SCOPES = ("MEMBER", "CLASS", "PACKAGE", "FILE", "MODULE", "DEFAULT", "INHERITED")
API_LICENSE_ROLES = frozenset(
    {
        "MEMBER_CONTEXT",
        "NOMINAL_IDENTITY",
        "INFORMATIONAL_PURPOSE",
        "EXAMPLE_INTRODUCTION",
        "INERT_LITERAL_EXAMPLE",
        "OTHER_CALLABLE",
    }
)


def _fields(value, keys):
    if type(value) is not dict or set(value) != set(keys):
        raise ValueError("exact API context fields required")


def _text(value, maximum, *, nullable=False, layout=False):
    if nullable and value is None:
        return
    if (
        type(value) is not str
        or not 0 < len(value) <= maximum
        or not value.strip()
        or any(
            (ord(char) < 32 and not (layout and char in "\t\r\n"))
            or 0xD800 <= ord(char) <= 0xDFFF
            for char in value
        )
    ):
        raise ValueError("bounded literal API context string required")


def _hash(value):
    if type(value) is not str or re.fullmatch(r"[0-9a-f]{64}", value) is None:
        raise ValueError("exact API context SHA256 required")


def _json_pairs(rows):
    result = {}
    for key, value in rows:
        if key in result:
            raise ValueError("duplicate API context JSON key")
        result[key] = value
    return result


def _noninteger_number(value):
    raise ValueError("noninteger API context JSON number")


def _json_work(text):
    depth, quoted, escaped = 0, False, False
    for char in text:
        if quoted:
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == '"':
                quoted = False
        elif char == '"':
            quoted = True
        elif char in "[{":
            depth += 1
        elif char in "]}":
            depth -= 1
        if not 0 <= depth <= 32:
            raise ValueError("API context JSON depth limit")
    if quoted or depth:
        raise ValueError("incomplete API context JSON")


def parse_api_context_policy(payload):
    """Strict primitive syntax only; authentic source replay remains mandatory.

    Hash-shaped IDs and a recognized role are NOT a license. The installed
    admission seam must regenerate and exactly compare this complete body from
    fresh original reader rows and independently validated typed provenance.
    """
    if type(payload) is not str or not 0 < len(payload) <= MAX_CONTEXT_BYTES:
        raise ValueError("bounded API context JSON string required")
    try:
        if len(payload.encode("utf-8")) > MAX_CONTEXT_BYTES:
            raise ValueError("API context policy byte limit")
        _json_work(payload)
        body = json.loads(
            payload,
            object_pairs_hook=_json_pairs,
            parse_float=_noninteger_number,
            parse_constant=_noninteger_number,
        )
    except (UnicodeError, RecursionError, json.JSONDecodeError) as error:
        raise ValueError("invalid API context JSON") from error
    _fields(
        body,
        (
            "schema_version",
            "policy_kind",
            "context_id",
            "source_identity",
            "target",
            "inventory_hash",
            "scope_observations",
            "licenses",
            "scope",
        ),
    )
    if (
        type(body["schema_version"]) is not int
        or body["schema_version"] != 1
        or body["policy_kind"] != DOCUMENTARY_API_CONTEXT_POLICY_V1
        or body["scope"] != API_CONTEXT_SCOPE
    ):
        raise ValueError("unsupported API context version/kind/scope")
    _hash(body["context_id"])
    _hash(body["inventory_hash"])
    source = body["source_identity"]
    _fields(
        source,
        ("file", "original_bytes_hash", "source_url", "format", "reader_profile"),
    )
    _text(source["file"], 256)
    if (
        source["file"].startswith("/")
        or "\\" in source["file"]
        or ":" in source["file"]
        or any(part in {"", ".", ".."} for part in source["file"].split("/"))
    ):
        raise ValueError("inert original API source name required")
    _hash(source["original_bytes_hash"])
    _hash(source["reader_profile"])
    _text(source["source_url"], 4096, nullable=True)
    _text(source["format"], 128)
    target = body["target"]
    _fields(
        target,
        (
            "symbol",
            "signature",
            "signature_display",
            "signature_language",
            "member_anchor",
            "source_author",
            "parameters",
            "content_fingerprint",
        ),
    )
    _text(target["symbol"], 512)
    _text(target["signature"], 2048, layout=True)
    _text(target["signature_display"], 2048, nullable=True, layout=True)
    _text(target["member_anchor"], 1024, nullable=True)
    _text(target["source_author"], 128, nullable=True)
    _hash(target["content_fingerprint"])
    if target["signature_language"] != "java":
        raise ValueError("unsupported API context language")
    parameters = target["parameters"]
    if type(parameters) is not list or len(parameters) > 16:
        raise ValueError("bounded ordered API parameters required")
    names = set()
    for parameter in parameters:
        if type(parameter) is not list or len(parameter) != 2:
            raise ValueError("exact API parameter pair required")
        for value in parameter:
            _text(value, 512)
        if parameter[0] in names:
            raise ValueError("duplicate API parameter name")
        names.add(parameter[0])
    licenses = body["licenses"]
    if type(licenses) is not list or not 0 < len(licenses) <= MAX_CONTEXT_NODES:
        raise ValueError("bounded complete API license rows required")
    nodes = set()
    for license_row in licenses:
        _fields(license_row, ("node_id", "source_payload_hash", "role"))
        _hash(license_row["node_id"])
        _hash(license_row["source_payload_hash"])
        if (
            type(license_row["role"]) is not str
            or license_row["role"] not in API_LICENSE_ROLES
            or license_row["node_id"] in nodes
        ):
            raise ValueError("unsupported/duplicate API license role/node")
        nodes.add(license_row["node_id"])
    observations = body["scope_observations"]
    _fields(observations, API_SCOPES)
    for name, observation in observations.items():
        _fields(
            observation, ("artifact_status", "witness_node_ids", "external_semantics")
        )
        if (
            type(observation["artifact_status"]) is not str
            or observation["artifact_status"]
            not in {
                "PRESENT_IN_THIS_SOURCE",
                "VERIFIED_ABSENT_IN_THIS_SOURCE",
                "UNAVAILABLE_NOT_ABSENT",
            }
            or observation["external_semantics"] != "UNAVAILABLE_NOT_ABSENT"
        ):
            raise ValueError("unsupported API scope observation")
        witnesses = observation["witness_node_ids"]
        if type(witnesses) is not list or len(witnesses) > MAX_CONTEXT_NODES:
            raise ValueError("bounded API scope witnesses required")
        for witness in witnesses:
            _hash(witness)
        if len(set(witnesses)) != len(witnesses) or not set(witnesses) <= nodes:
            raise ValueError("duplicate/unknown API scope witness")
        if (
            observation["artifact_status"] == "PRESENT_IN_THIS_SOURCE"
            and name != "FILE"
            and not witnesses
        ):
            raise ValueError("present API scope needs structural witnesses")
    return body


def classify_api_informational(text):
    """License every complete sentence, without dropping unknown residue.

    Exact finite English forms only. Whitespace normalization is rendering, not
    a synonym/case/quotation/qualification interpretation. No caller values,
    source names or particular library identities enter this classification.
    """
    if type(text) is not str or not text or len(text) > 20000:
        return None
    from ai_brain.stage3.domains.javadoc_clause_view import has_hidden_controls
    if has_hidden_controls(text):
        return None
    normalized = " ".join(text.split())
    if not normalized:
        return None
    position = 0
    while position < len(normalized):
        match = _INFORMATIONAL.match(normalized, position)
        if match is None:
            return None
        position = match.end()
        if position < len(normalized):
            if normalized[position] != " ":
                return None
            position += 1
    return "INFORMATIONAL_PURPOSE"
