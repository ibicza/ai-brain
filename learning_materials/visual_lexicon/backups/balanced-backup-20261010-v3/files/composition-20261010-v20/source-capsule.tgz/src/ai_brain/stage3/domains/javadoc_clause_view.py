"""Closed, inert rendering of one documentary clause, never Java execution.

The caller retains the exact original clause. The physical-tag projector never
discards unknown tags/markup or resolves links and inherited docs. Rendering
supports atoms, finite comparisons/signs and a complete three-item return list.
"""

from __future__ import annotations

import re
import unicodedata

MAX_CLAUSE_BYTES = 4096
_NAME = r"[A-Za-z_$][A-Za-z0-9_$]{0,63}"
_EXCEPTION = rf"{_NAME}(?:\.{_NAME}){{0,3}}"
_ATOM = re.compile(rf"(?:{_NAME}|-?(?:0|[1-9][0-9]{{0,39}}))\Z")
_INLINE = re.compile(r"\{@code\s+([^{}]+)\}")
_COMPARISON = re.compile(rf"{_NAME}\s*(?:==|<|>)\s*{_NAME}\Z")
_REGION = re.compile(r"[<>]\s*0\Z")


def documentary_tag_clauses(source: str) -> tuple[str, ...]:
    """Split at physical block-tag boundaries, retaining exact clause spellings.

    No tag is discarded or interpreted here. Unknown tags, markup and unknown
    qualifiers remain original required clauses and fail semantic admission.
    Offsets must still be bound by the caller to whole reader-owned payloads.
    """
    if type(source) is not str or has_hidden_controls(source):
        raise ValueError("Exact control-free documentary source required")
    if len(source) > 20062:
        raise ValueError("Documentary source clause projection limit")
    clauses = []
    for paragraph in re.split(r"\n[ \t]*\n", source):
        starts = [match.start() for match in re.finditer(r"(?m)^[ \t]*@[A-Za-z]+\b", paragraph)]
        positions = sorted(set((0, *starts, len(paragraph))))
        clauses.extend(paragraph[left:right].strip(" \t\r\n")
                       for left,right in zip(positions,positions[1:])
                       if paragraph[left:right].strip(" \t\r\n"))
    if len(clauses) > 48:
        raise ValueError("Documentary source clause count limit")
    return tuple(clauses)


def has_hidden_controls(source: str) -> bool:
    """Reject control, format and surrogate characters except layout whitespace."""
    return any(char not in "\t\r\n" and unicodedata.category(char) in {"Cc", "Cf", "Cs"}
               for char in source)


def documentary_clause_view(source: str) -> str:
    """Return a whole single-clause parsing view or reject without a prefix.

    No HTML, entity decoding, link resolution, comment delimiter stripping,
    unknown annotation removal, script interpretation or Java evaluation.
    Whitespace is rendering only; control/format characters are not silently
    normalized away. All admitted inline atoms must have word boundaries.
    """
    if type(source) is not str:
        raise ValueError("Exact documentary clause string required")
    if len(source) > MAX_CLAUSE_BYTES:
        raise ValueError("Documentary clause rendering limit")
    try:
        if len(source.encode("utf-8")) > MAX_CLAUSE_BYTES:
            raise ValueError("Documentary clause rendering limit")
    except UnicodeError as error:
        raise ValueError("Invalid documentary clause Unicode") from error
    if has_hidden_controls(source):
        raise ValueError("Hidden documentary clause characters")
    text = " ".join(source.split())
    if text.startswith("@return") and re.fullmatch(r"@return\s*<ul>.*</ul>", text):
        body = re.fullmatch(r"@return\s*<ul>(.*)</ul>", text)[1].strip()
        # Comparisons inside code contain < or >: scan the complete list using
        # bounded inline atoms as opaque lexical tokens, not arbitrary HTML.
        items = list(re.finditer(r"<li>(.*?)</li>", body))
        if len(items) != 3 or any(body[a:b].strip() for a,b in
                zip((0, *(match.end() for match in items)),
                    (*(match.start() for match in items),len(body)))):
            raise ValueError("Complete three-item documentary return list required")
        text = "Returns " + "; ".join(match[1].strip() for match in items)
    elif "<ul" in text or "<li" in text or "</ul" in text or "</li" in text:
        raise ValueError("Unknown documentary list shape")
    pieces, position = [], 0
    for match in _INLINE.finditer(text):
        atom = match[1].strip()
        if not (_ATOM.fullmatch(atom) or _COMPARISON.fullmatch(atom) or _REGION.fullmatch(atom)):
            raise ValueError("Only atomic inline code is supported")
        if (
            position > 0 and match.start() == position
            or match.start() and re.match(r"[\w$]", text[match.start() - 1])
            or match.end() < len(text) and re.match(r"[\w$]", text[match.end()])
        ):
            raise ValueError("Inline code must not splice identifiers")
        pieces.extend((text[position:match.start()], atom))
        position = match.end()
    pieces.append(text[position:])
    text = "".join(pieces)
    if "{" in text or "}" in text:
        raise ValueError("Unknown or incomplete inline documentation")
    if text.startswith("@return "):
        text = "Returns " + text[len("@return "):]
    else:
        match = re.fullmatch(rf"@param ({_NAME}) (.+)", text)
        if match:
            text = f"Parameters: {match[1]} - {match[2]}"
        else:
            match = re.fullmatch(rf"@(?:throws|exception) ({_EXCEPTION}) (.+)", text)
            if match:
                text = f"Throws {match[1]} {match[2]}"
    if not text or "@" in text:
        raise ValueError("Complete single documentary clause required")
    if re.search(r"<[A-Za-z/!]", text) or "&" in text:
        raise ValueError("Unknown documentary markup or entity")
    return text
