"""Domain-independent queries over current, approved, installed knowledge.

No source files, evaluator answers, domain names, network, learned weights or
executable source participate in answering. New domains are pack data. Missing
relations are unknown, not false; interpretations stay attributed and contested.
"""

from __future__ import annotations

import re
from collections import deque
from dataclasses import asdict
from fractions import Fraction

from ai_brain.stage3.acquisition.source_descriptions import (
    DESCRIPTION_PERSPECTIVES,
    description_context_flags,
)
from ai_brain.stage3.capabilities.models import CapabilityRequirement
from ai_brain.stage3.capabilities.resolution import resolve_capability
from ai_brain.stage3.capabilities.scalar_equation_solver import (
    NeedsNewCapability,
    solve_scalar_equation,
)
from ai_brain.stage3.domains.aliases import AliasLookupStatus, resolve_alias
from ai_brain.stage3.domains.document_limits import MAX_DOCUMENTARY_PACK_RECORDS
from ai_brain.stage3.domains.registry import InstalledDomainRegistry
from ai_brain.stage3.domains.request_verification import verified_request
from ai_brain.stage3.knowledge_ir.records import (
    ClaimSchemaContent,
    ConceptContent,
    DefinitionContent,
    EntityTypeContent,
    EpistemicCharacter,
    ExpressionKind,
    InterpretationContent,
    RelationContent,
    RuleContent,
    TemporalRelationContent,
)

_MAX_RECORDS = MAX_DOCUMENTARY_PACK_RECORDS
_MAX_TEXT = 512


class InstalledKnowledgeService:
    def __init__(self, registry: InstalledDomainRegistry):
        self.registry = registry

    @verified_request
    def search(self, question, *, domain_id=None, limit=5):
        """Retrieve across current installed domains; never read acquisition."""
        from ai_brain.stage3.domains.document_retrieval import search_installed_records

        if domain_id is not None and (
            type(domain_id) is not str or not domain_id or len(domain_id) > _MAX_TEXT
        ):
            return {"status": "INVALID_REQUEST", "hits": []}
        try:
            if (
                self.registry.capability_registry is None
                or self.registry.provider_registry is None
            ):
                return {"status": "STALE_AUTHORITY", "hits": []}
            self.registry.capability_registry.verify(self.registry.provider_registry)
            domains = {item.domain_id for item in self.registry.list()}
            if domain_id is not None:
                if domain_id not in domains:
                    return {"status": "DOMAIN_NOT_INSTALLED", "hits": []}
                domains = {domain_id}
            if len(domains) > 64:
                return {"status": "RESOURCE_LIMIT", "hits": []}
            packs = []
            for identity in sorted(domains):
                current = self.registry.show(identity)
                if current.status.value == "DEPRECATED":
                    continue
                if not self.registry.verify_currentness(identity, current.pack_version)[
                    "current"
                ]:
                    return {"status": "STALE_AUTHORITY", "hits": []}
                packs.append(
                    self.registry.load_installed_pack(identity, current.pack_version)
                )
            return search_installed_records(tuple(packs), question, limit)
        except (ValueError, KeyError, OSError):
            return {"status": "STALE_AUTHORITY", "hits": []}

    @verified_request
    def reason(self, question, *, domain_id=None, arguments=None):
        from ai_brain.stage3.domains.semantic_reasoning import reason_installed

        return reason_installed(
            self, question, domain_id=domain_id, arguments=arguments
        ) or {
            "status": "INSUFFICIENT_EVIDENCE",
            "reason": "No supported typed reasoning request or installed knowledge",
        }

    @verified_request
    def ask(self, question, *, domain_id=None, limit=5, arguments=None):
        from ai_brain.stage3.domains.semantic_reasoning import reason_installed

        if type(limit) is not int or not 1 <= limit <= 20:
            return {"status": "INVALID_REQUEST", "hits": []}
        semantic = reason_installed(
            self, question, domain_id=domain_id, arguments=arguments
        )
        if semantic is not None:
            return semantic
        if type(question) is str and re.match(
            r"^\s*(?:execute|run|calculate|compute|выполни|запусти|вычисли|посчитай|реши)\b",
            question,
            re.IGNORECASE,
        ):
            return {
                "status": "NEEDS_NEW_CAPABILITY",
                "hits": [],
                "reason": "Documentary retrieval cannot execute imported source.",
            }
        result = self.search(question, domain_id=domain_id, limit=limit)
        if result["status"] != "RETRIEVED":
            return result
        hits = result["hits"]
        if domain_id is None and len(result["domain_candidates"]) > 1:
            first = hits[0]
            competing = [
                hit
                for hit in result["domain_candidates"]
                if hit["domain_id"] != first["domain_id"]
                and (
                    hit["matched_terms"] == first["matched_terms"]
                    or Fraction(hit["score"])
                    >= Fraction(first["score"]) * Fraction(85, 100)
                )
            ]
            if competing:
                return {
                    **result,
                    "status": "AMBIGUOUS_DOMAIN",
                    "reason": "Several subjects match; select --domain-id or refine the question.",
                }
        return {
            **result,
            "status": "EXTRACTIVE_ANSWER",
            "answer_mode": "QUOTED_EVIDENCE_NO_GENERATIVE_SYNTHESIS",
        }

    @verified_request
    def query(
        self,
        domain_id: str,
        operation: str,
        *,
        reference: str | None = None,
        arguments: dict | None = None,
        pack_version: str | None = None,
    ) -> dict:
        if (
            type(domain_id) is not str
            or not domain_id
            or len(domain_id) > _MAX_TEXT
            or type(operation) is not str
            or len(operation) > _MAX_TEXT
            or (
                reference is not None
                and (type(reference) is not str or len(reference) > _MAX_TEXT)
            )
            or (arguments is not None and type(arguments) is not dict)
        ):
            return _answer(
                "INVALID_REQUEST", domain_id="", reason="invalid query shape"
            )
        args = {} if arguments is None else arguments
        try:
            if (
                self.registry.capability_registry is None
                or self.registry.provider_registry is None
            ):
                return _answer("STALE_AUTHORITY", domain_id=domain_id)
            self.registry.capability_registry.verify(self.registry.provider_registry)
            current = self.registry.verify_currentness(domain_id, pack_version)
            if not current["current"]:
                return _answer("STALE_AUTHORITY", domain_id=domain_id)
            pack = self.registry.load_installed_pack(domain_id, pack_version)
        except KeyError:
            return _answer("DOMAIN_NOT_INSTALLED", domain_id=domain_id)
        except (ValueError, OSError):
            return _answer("STALE_AUTHORITY", domain_id=domain_id)
        base = {"domain_id": domain_id, "pack_hash": pack.manifest.pack_content_hash}
        records = pack.knowledge_records
        if len(records) > _MAX_RECORDS:
            return _answer("RESOURCE_LIMIT", **base)
        if operation == "search":
            from ai_brain.stage3.domains.document_retrieval import (
                search_installed_records,
            )

            if (
                reference is not None
                or set(args) - {"question", "limit"}
                or "question" not in args
            ):
                return _answer("INVALID_REQUEST", **base)
            return search_installed_records(
                (pack,), args["question"], args.get("limit", 5)
            )
        if operation == "list":
            if args or reference is not None:
                return _answer("INVALID_REQUEST", **base)
            return _answer(
                "SUPPORTED",
                **base,
                value=[
                    {
                        "knowledge_id": item.knowledge_id,
                        "kind": item.kind.value,
                        "references": sorted(_references(item)),
                    }
                    for item in records
                ],
            )
        if operation == "documented_scenario":
            from ai_brain.stage3.domains.semantic_reasoning import (
                assess_installed_scenario,
            )

            return assess_installed_scenario(pack, reference, args)
        if operation == "documentary_source_context":
            if reference is not None or args:
                return _answer("INVALID_REQUEST", **base)
            from ai_brain.stage3.domains.documentary_context_inventory import (
                UnsupportedDocumentaryContext,
                describe_original_context,
            )

            try:
                return describe_original_context(pack)
            except UnsupportedDocumentaryContext:
                return _answer(
                    "NEEDS_NEW_CAPABILITY", **base,
                    reason="Fresh complete original context required",
                )
        if operation == "documented_api_context":
            from ai_brain.stage3.domains.documentary_api_context import (
                describe_api_context,
            )

            return describe_api_context(pack, reference, args)
        if operation == "documented_scenario_v2":
            from ai_brain.stage3.domains.documentary_api_policy import (
                assess_api_scenario_v2,
            )

            return assess_api_scenario_v2(pack, reference, args)
        if operation == "documented_conditionals_v2":
            from ai_brain.stage3.domains.documentary_conditionals_v2 import (
                assess_conditionals_v2,
            )

            return assess_conditionals_v2(pack, reference, args)
        if operation not in {
            "lookup",
            "solve",
            "taxonomy",
            "temporal",
            "interpretations",
            "contract",
        }:
            return _answer(
                "NEEDS_NEW_CAPABILITY", **base, reason="operation is not installed"
            )
        if operation == "interpretations":
            if args:
                return _answer("INVALID_REQUEST", **base)
            selected = tuple(
                item
                for item in records
                if isinstance(item.content, InterpretationContent)
                and item.content.perspective not in DESCRIPTION_PERSPECTIVES
                and item.content.perspective != "DOCUMENTARY_CONDITIONAL_V2"
            )
            if reference is not None:
                targets = {item.knowledge_id for item in _find(pack, reference)}
                selected = tuple(
                    item
                    for item in selected
                    if targets
                    & {
                        *item.content.supported_record_ids,
                        *item.content.contrast_record_ids,
                    }
                    or reference == item.content.perspective
                )
            if not selected:
                return _answer("INSUFFICIENT_EVIDENCE", **base)
            return _supported(
                pack,
                selected,
                [asdict(item.content) for item in selected],
                status="CONTESTED"
                if len({item.content.perspective for item in selected}) > 1
                or any(
                    item.epistemic_character.value == "CONTESTED" for item in selected
                )
                else "ATTRIBUTED_INTERPRETATION",
            )
        if operation in {"taxonomy", "temporal"}:
            key = "ancestor" if operation == "taxonomy" else "after"
            if (
                set(args) != {key}
                or type(args[key]) is not str
                or len(args[key]) > _MAX_TEXT
            ):
                return _answer("INVALID_REQUEST", **base)
            starts, ends = _find(pack, reference), _find(pack, args[key])
            if len(starts) > 1 or len(ends) > 1:
                return _answer("AMBIGUOUS_REFERENCE", **base)
            if len(starts) != 1 or len(ends) != 1:
                return _answer("INSUFFICIENT_EVIDENCE", **base)
            path = _relation_path(
                records,
                starts[0].knowledge_id,
                ends[0].knowledge_id,
                "is_a" if operation == "taxonomy" else "precedes",
            )
            if not path:
                return _answer(
                    "INSUFFICIENT_EVIDENCE",
                    **base,
                    reason="no installed relation proves the request",
                )
            return _supported(
                pack,
                (*starts, *path, *ends),
                {
                    "relation": "is_a" if operation == "taxonomy" else "precedes",
                    "subject": starts[0].knowledge_id,
                    "object": ends[0].knowledge_id,
                    "steps": len(path),
                },
            )
        selected = _find(pack, reference)
        if reference is None and operation == "solve":
            selected = tuple(
                item for item in records if isinstance(item.content, RuleContent)
            )
        if len(selected) > 1:
            return _answer("AMBIGUOUS_REFERENCE", **base)
        if not selected:
            return _answer("INSUFFICIENT_EVIDENCE", **base)
        record = selected[0]
        if operation == "lookup":
            if args:
                return _answer("INVALID_REQUEST", **base)
            from ai_brain.stage3.domains.document_retrieval import excerpt_payload

            excerpt = excerpt_payload(record)
            if excerpt is not None:
                return _supported(pack, selected, excerpt, status="SOURCE_EXCERPT")
            if (
                isinstance(record.content, InterpretationContent)
                and record.content.perspective == "DOCUMENTARY_CONDITIONAL_V2"
            ):
                return _supported(
                    pack,
                    selected,
                    {
                        "text": record.content.claim_text,
                        "schema_version": 2,
                        "scope": "REVIEWED_SOURCE_CLAUSE_NOT_EMPIRICAL_FACT",
                        "conditional_evaluation_performed": False,
                        "hypothetical_assumptions_required": True,
                        "source_code_executed": False,
                    },
                    status="SOURCE_CONDITIONAL_ONLY",
                )
            if (
                isinstance(record.content, InterpretationContent)
                and record.content.perspective in DESCRIPTION_PERSPECTIVES
            ):
                return _supported(
                    pack,
                    selected,
                    {
                        "text": record.content.claim_text,
                        "kind": record.content.perspective,
                        "description_is_inference_authority": False,
                        **description_context_flags(record.content.perspective),
                    },
                    status="SOURCE_DESCRIPTION_ONLY",
                )
            return _supported(
                pack,
                selected,
                asdict(record.content),
                status="ATTRIBUTED_INTERPRETATION"
                if isinstance(record.content, InterpretationContent)
                else "CONTESTED"
                if record.epistemic_character is EpistemicCharacter.CONTESTED
                else "SUPPORTED",
            )
        if operation == "contract":
            if args:
                return _answer("INVALID_REQUEST", **base)
            if not isinstance(record.content, ClaimSchemaContent):
                return _answer("INSUFFICIENT_EVIDENCE", **base)
            return _supported(
                pack, selected, asdict(record.content), status="DOCUMENTED_CONTRACT"
            )
        if not isinstance(record.content, RuleContent):
            return _answer(
                "NEEDS_NEW_CAPABILITY",
                **base,
                reason="reference is not an installed equation",
            )
        return self._solve(pack, record, args)

    def _solve(self, pack, record, args):
        base = {
            "domain_id": pack.manifest.domain_id,
            "pack_hash": pack.manifest.pack_content_hash,
        }
        if (
            set(args) != {"known", "unknown", "conditions"}
            or type(args["known"]) is not dict
            or type(args["unknown"]) is not str
            or len(args["unknown"]) > 128
            or type(args["conditions"]) is not list
            or len(args["conditions"]) > 64
            or any(
                type(item) is not str or len(item) > _MAX_TEXT
                for item in args["conditions"]
            )
            or len(args["known"]) > 64
            or any(
                type(key) is not str or len(key) > 128 or not _bounded_number(value)
                for key, value in args["known"].items()
            )
        ):
            return _answer("INVALID_REQUEST", **base)
        rule = record.content
        if record.epistemic_character is not EpistemicCharacter.DETERMINISTIC:
            return _answer(
                "NEEDS_NEW_CAPABILITY",
                **base,
                reason="non-deterministic rule is descriptive only",
            )
        if not _bounded_expression(rule.expression):
            return _answer(
                "NEEDS_NEW_CAPABILITY",
                **base,
                reason="expression exceeds bounded solver scope",
            )
        if not {
            *rule.applicability.preconditions,
            *rule.applicability.assumptions,
        } <= set(args["conditions"]):
            return _answer(
                "APPLICABILITY_REQUIRED",
                **base,
                reason="explicit rule conditions are missing",
                value={"required_conditions": list(rule.applicability.preconditions)},
            )
        # This facade cannot silently execute approximations, exceptions, or
        # temporal conditions for which it has no condition evaluator.
        if (
            rule.approximation_conditions
            or rule.applicability.exclusions
            or rule.applicability.exceptions
            or rule.applicability.valid_from
            or rule.applicability.valid_to
            or rule.applicability.unsupported_cases
            or rule.applicability.required_capabilities
        ):
            return _answer(
                "NEEDS_NEW_CAPABILITY",
                **base,
                reason="additional applicability evaluator required",
            )
        requirement = next(
            (
                item
                for item in pack.manifest.required_capabilities
                if item.capability_id == "generic.scalar_equation_solver.v1"
            ),
            None,
        )
        if (
            requirement is None
            or requirement.capability_id not in record.required_capability_ids
        ):
            return _answer(
                "NEEDS_NEW_CAPABILITY",
                **base,
                reason="equation solver not installed for this rule",
            )
        resolution = resolve_capability(
            self.registry.capability_registry,
            CapabilityRequirement(
                requirement.capability_id, requirement.version_range, "USER_RUNTIME"
            ),
            requesting_domain_id=pack.manifest.domain_id,
            requesting_pack_hash=pack.manifest.pack_content_hash,
            provider_registry=self.registry.provider_registry,
        )
        if (
            resolution.receipt is None
            or resolution.descriptor.provider_id != "generic.scalar_equation_solver"
        ):
            return _answer(
                "NEEDS_NEW_CAPABILITY",
                **base,
                reason="current exact solver authority unavailable",
            )
        try:
            result = solve_scalar_equation(rule, args["known"], args["unknown"])
            values = {**args["known"], args["unknown"]: result.exact_value}
            for variable in rule.variables:
                value = Fraction(str(values[variable.variable_id]))
                if (
                    variable.minimum is not None and value < Fraction(variable.minimum)
                ) or (
                    variable.maximum is not None and value > Fraction(variable.maximum)
                ):
                    return _answer(
                        "APPLICABILITY_VIOLATED",
                        **base,
                        reason="variable range violated",
                    )
        except NeedsNewCapability as error:
            return _answer("NEEDS_NEW_CAPABILITY", **base, reason=str(error))
        except (ValueError, ZeroDivisionError):
            return _answer(
                "INVALID_REQUEST", **base, reason="invalid exact input or rule range"
            )
        return _supported(pack, (record,), asdict(result), status="SOLVED_EXACT")


def _bounded_number(value):
    return (
        type(value) is int
        and value.bit_length() <= 512
        or type(value) is str
        and 0 < len(value) <= 128
        and re.fullmatch(
            r"(?:[+-]?[0-9]+/[+-]?[0-9]+|[+-]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+))", value
        )
        is not None
    )


def _bounded_expression(expression):
    pending = [(expression, 0, 1)]
    count = 0
    bit_cost = 0
    while pending:
        item, depth, weight = pending.pop()
        count += 1
        bit_cost += weight
        if count > 256 or depth > 32 or bit_cost > 256:
            return False
        if item.kind is ExpressionKind.CONSTANT and not _bounded_number(item.value):
            return False
        if item.kind is ExpressionKind.POWER and (
            len(item.children) != 2
            or item.children[1].kind is not ExpressionKind.CONSTANT
            or type(item.children[1].value) is not int
            or not -32 <= item.children[1].value <= 32
        ):
            return False
        if item.kind is ExpressionKind.POWER:
            weight *= max(1, abs(item.children[1].value))
        pending.extend((child, depth + 1, weight) for child in item.children)
    return True


def _references(record):
    content = record.content
    result = {record.knowledge_id}
    if isinstance(content, DefinitionContent):
        result.add(content.term_id)
    elif isinstance(content, EntityTypeContent):
        result.add(content.entity_type_id)
    elif isinstance(content, ConceptContent):
        result.update((content.canonical_name_ru, content.canonical_name_en))
    elif isinstance(content, ClaimSchemaContent) and content.receiver_type:
        result.add(f"{content.receiver_type}.{content.predicate_id}")
        parameters = ",".join(value for _, value in content.parameters)
        result.add(f"{content.receiver_type}.{content.predicate_id}({parameters})")
    return result


def _find(pack, reference):
    if reference is None:
        return ()
    if pack.alias_semantics is not None:
        resolved = resolve_alias(pack.alias_semantics, reference)
        if resolved.status is not AliasLookupStatus.NOT_FOUND:
            return tuple(
                item
                for item in pack.knowledge_records
                if item.knowledge_id in resolved.record_ids
            )
    return tuple(
        item for item in pack.knowledge_records if reference in _references(item)
    )


def _relation_path(records, start, target, predicate):
    adjacency = {}
    for record in records:
        content = record.content
        if (
            (
                isinstance(content, RelationContent)
                and predicate == "is_a"
                or isinstance(content, TemporalRelationContent)
                and predicate == "precedes"
            )
            and content.predicate_id == predicate
            and record.epistemic_character
            in {EpistemicCharacter.DETERMINISTIC, EpistemicCharacter.EMPIRICAL}
            and not record.applicability_refs
        ):
            adjacency.setdefault(content.subject_id, []).append(
                (content.object_id, record)
            )
    pending = deque(((start, ()),))
    visited = {start}
    while pending:
        node, path = pending.popleft()
        for neighbor, record in adjacency.get(node, ()):
            if neighbor == target:
                return (*path, record)
            if neighbor not in visited:
                visited.add(neighbor)
                pending.append((neighbor, (*path, record)))
    return ()


def _supported(pack, records, value, *, status="SUPPORTED"):
    # Both public facades expose the same original dependency evidence and
    # epistemic boundary. Import locally to avoid a module-level dependency cycle.
    from ai_brain.stage3.domains.semantic_reasoning import _answer as typed_answer

    try:
        return {**typed_answer(pack, records, status, value), "reason": None}
    except OverflowError:
        return _answer(
            "RESOURCE_LIMIT",
            domain_id=pack.manifest.domain_id,
            reason="evidence closure exceeds limit",
        )


def _answer(
    status, *, domain_id, pack_hash=None, value=None, evidence=None, reason=None
):
    return {
        "status": status,
        "domain_id": domain_id,
        "pack_hash": pack_hash,
        "value": value,
        "evidence": evidence or [],
        "reason": reason,
    }
