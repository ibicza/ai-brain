"""Current-reader conditional proposals; dictionaries are not source authority."""

from ai_brain.stage3.acquisition import documentary_logic as v1
from ai_brain.stage3.acquisition.documentary_conditional_bridge_v2 import (
    reader_parse_view_v2,
)
from ai_brain.stage3.acquisition.documentary_conditional_context_v2 import (
    _file,
    extract_documentary_conditionals_v2,
)


def extract_reader_conditionals_v2(origin, following=None, preceding=None):
    """Called only on actual freshly produced/replayed current reader origins.

    Adapt nullable originals without changing evidence. Unrelated valid source
    partitions are isolated BEFORE attempting their unsupported parent grouping.
    Unknown provenance is not treated as unrelated. Same-scope unsupported
    grouping raises, so a caller cannot keep a conveniently parsed rule subset.
    """
    scope = v1.documentary_scope(origin)
    original_file = _file(origin)

    def neighbor(adjacent):
        if adjacent is None:
            return None
        adjacent_scope = v1._documentary_provenance_scope(adjacent)
        adjacent_file = _file(adjacent)
        if adjacent_scope != scope or adjacent_file != original_file:
            return None
        return reader_parse_view_v2(adjacent)

    return extract_documentary_conditionals_v2(
        reader_parse_view_v2(origin), neighbor(following), neighbor(preceding)
    )
