"""Bounded held pack bytes. Static reparse checks are not an OS race sandbox."""

from __future__ import annotations

import hashlib
import os
import stat
from dataclasses import dataclass
from pathlib import Path
from types import MappingProxyType

from ai_brain.stage2.facts.canonical import content_hash

PACK_FILES = frozenset(
    {
        "manifest.json",
        "knowledge.jsonl",
        "concept_graph.json",
        "exercise_families.json",
        "capability_requirements.json",
        "adapter_bindings.json",
        "evaluation_manifest.json",
        "source_bindings.json",
        "pack_manifest.json",
    }
)
OPTIONAL_FILES = frozenset(
    {
        "approval.json",
        "java_evidence_closure.json",
        "java_production_closure.json",
        "alias_semantics.json",
        "documentary_source_closure.json",
        "documentary_source_bytes.bin",
    }
)
MAX_FILE_BYTES = 64 * 1024 * 1024
MAX_TREE_BYTES = 512 * 1024 * 1024
MAX_TREE_ENTRIES = 4096
IO_CHUNK_BYTES = 1024 * 1024


def checked_directory(path):
    path = Path(os.path.abspath(path))
    for ancestor in reversed((path, *path.parents)):
        info = ancestor.lstat()
        not_reparse(info)
        if not stat.S_ISDIR(info.st_mode):
            raise ValueError("pack ancestor is not a directory")
    return path


def not_reparse(info):
    if stat.S_ISLNK(info.st_mode) or getattr(info, "st_file_attributes", 0) & 0x400:
        raise ValueError("pack symlinks/junctions/reparse points are forbidden")


def stamp(info):
    return (
        info.st_dev,
        info.st_ino,
        info.st_size,
        info.st_mtime_ns,
        getattr(info, "st_birthtime_ns", info.st_ctime_ns),
    )


def _file_info(path):
    info = path.lstat()
    not_reparse(info)
    if not stat.S_ISREG(info.st_mode):
        raise ValueError("pack entry is not a regular file")
    maximum = (
        256 * 1024 if path.name == "documentary_source_closure.json" else MAX_FILE_BYTES
    )
    if info.st_size > maximum:
        from ai_brain.stage3.domains.documentary_custody import ResourceLimitError

        raise ResourceLimitError("pack file exceeds resource policy")
    return info


def _held_read(path, info, *, retain):
    fd = os.open(
        path, os.O_RDONLY | getattr(os, "O_BINARY", 0) | getattr(os, "O_NOFOLLOW", 0)
    )
    try:
        opened = os.fstat(fd)
        not_reparse(opened)
        if not stat.S_ISREG(opened.st_mode) or stamp(opened) != stamp(info):
            raise ValueError("pack file changed before read")
        digest, parts, used = hashlib.sha256(), [], 0
        while used < info.st_size:
            chunk = os.read(fd, min(IO_CHUNK_BYTES, info.st_size - used))
            if not chunk:
                raise ValueError("pack file truncated during read")
            used += len(chunk)
            digest.update(chunk)
            if retain:
                parts.append(chunk)
        final = os.fstat(fd)
    finally:
        os.close(fd)
    after = path.lstat()
    not_reparse(after)
    if stamp(info) != stamp(final) or stamp(info) != stamp(after):
        raise ValueError("pack file changed during read")
    return digest.hexdigest(), b"".join(parts) if retain else None


@dataclass(frozen=True)
class PackSnapshot:
    root: Path
    files: object
    stamps: tuple
    bytes_hash: str
    directory_stamp: tuple

    def assert_current(self):
        checked_directory(self.root)
        if stamp(self.root.lstat()) != self.directory_stamp:
            raise ValueError("pack directory changed during request")
        entries = []
        for entry in self.root.iterdir():
            entries.append(entry)
            if len(entries) > len(PACK_FILES | OPTIONAL_FILES):
                raise ValueError("too many pack entries during request")
        if {p.name for p in entries} != set(self.files):
            raise ValueError("pack entries changed during request")
        for name, expected in self.stamps:
            if stamp(_file_info(self.root / name)) != expected:
                raise ValueError("pack changed during request")


def capture_pack(root, *, budget=None):
    from ai_brain.stage3.domains.documentary_custody import QueryBudget

    budget = QueryBudget() if budget is None else budget
    root = checked_directory(root)
    directory_stamp = stamp(root.lstat())
    entries = []
    for entry in root.iterdir():
        entries.append(entry)
        if len(entries) > len(PACK_FILES | OPTIONAL_FILES):
            raise ValueError("too many pack entries")
    names = {p.name for p in entries}
    if PACK_FILES - names:
        raise ValueError(f"domain pack files missing: {sorted(PACK_FILES - names)}")
    if names - (PACK_FILES | OPTIONAL_FILES):
        raise ValueError(
            f"unexpected domain pack entry: {sorted(names - (PACK_FILES | OPTIONAL_FILES))}"
        )
    # Documentary metadata is a separately capped subset of captured raw IO.
    # Preflight it before ANY file read, not after allocating the held snapshot.
    if "documentary_source_closure.json" in names:
        metadata = _file_info(root / "documentary_source_closure.json")
        budget.reserve(metadata_io=metadata.st_size)
    files, stamps, rows = {}, [], []
    for path in sorted(entries):
        info = _file_info(path)
        if (
            path.name == "documentary_source_closure.json"
            and info.st_size != metadata.st_size
        ):
            raise ValueError("documentary metadata size changed after budget preflight")
        budget.reserve(
            raw_io=info.st_size, raw_hash=info.st_size, payload=2 * info.st_size
        )
        digest, data = _held_read(path, info, retain=True)
        files[path.name] = data
        stamps.append((path.name, stamp(info)))
        rows.append((path.name, digest))
    # Fixed ASCII filenames/digest rows have an exact canonical byte length.
    size = 2 + max(0, len(rows) - 1) + sum(7 + len(n) + len(h) for n, h in rows)
    budget.reserve(canonical_hash=size, payload=size)
    value = PackSnapshot(
        root,
        MappingProxyType(files),
        tuple(stamps),
        content_hash(tuple(rows)),
        directory_stamp,
    )
    value.assert_current()
    return value


def stream_tree_hash(root):
    """Preserve old sorted relative-name/hash semantics, including backup trees."""
    root = checked_directory(root)
    pending, files, visited, total = [root], [], 0, 0
    while pending:
        directory = pending.pop()
        for path in directory.iterdir():
            visited += 1
            if visited > MAX_TREE_ENTRIES:
                raise ValueError("pack tree entry ceiling exceeded")
            info = path.lstat()
            not_reparse(info)
            if stat.S_ISDIR(info.st_mode):
                pending.append(path)
            else:
                info = _file_info(path)
                total += info.st_size
                if total > MAX_TREE_BYTES:
                    raise ValueError("pack tree byte ceiling exceeded")
                files.append((path, info))
    rows = []
    for path, info in sorted(files):
        digest, _ = _held_read(path, info, retain=False)
        rows.append((path.relative_to(root).as_posix(), digest))
    checked_directory(root)
    return content_hash(tuple(rows))
