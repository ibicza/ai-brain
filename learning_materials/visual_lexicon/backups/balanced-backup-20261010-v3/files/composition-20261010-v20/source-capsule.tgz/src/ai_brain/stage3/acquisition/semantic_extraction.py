"""Bounded, domain-independent extraction from ordinary documentary passages.

Patterns propose source assertions, not independently verified world facts.
Unknown grammar, modality and missing equation context remain review questions.
No source instructions, imported programs, model weights or eval are executed.
"""

from __future__ import annotations

import ast
import re
import unicodedata
from collections import defaultdict
from dataclasses import asdict, replace
from decimal import Decimal, localcontext
from fractions import Fraction
from pathlib import Path

from ai_brain.stage2.facts.canonical import bytes_hash, canonical_json, content_hash
from ai_brain.stage3.acquisition.documentary_api_content import (
    build_documentary_api_content,
)
from ai_brain.stage3.acquisition.documentary_clauses import (
    contains_passive_report,
    extract_definition_contexts,
    extract_definition_paragraphs,
    extract_definition_reported_paragraphs,
    split_documentary_sentences,
)
from ai_brain.stage3.acquisition.documentary_conditional_v2 import (
    DOCUMENTARY_CONDITIONAL_V2,
    bind_scope_v2,
    parse_conditional_payload_v2,
)
from ai_brain.stage3.acquisition.documentary_logic import (
    DOCUMENTARY_CONDITIONAL_V1,
    bind_scope,
    documentary_scope,
    extract_documentary_conditionals,
    parse_conditional_payload,
)
from ai_brain.stage3.acquisition.documentary_reader_conditionals_v2 import (
    extract_reader_conditionals_v2,
)
from ai_brain.stage3.acquisition.documentary_relations import (
    inventory_documentary_parent,
    parse_documentary_relations,
)
from ai_brain.stage3.acquisition.extractors import _math_expression
from ai_brain.stage3.acquisition.documentary_inline_equations import (
    capture_original,
    equation_parent_eligibility,
    validate_capture,
)
from ai_brain.stage3.acquisition.math_notation import latex_scalar, normalize_symbols
from ai_brain.stage3.acquisition.models import (
    ExtractionMethod,
    KnowledgeProposal,
    ProposalStatus,
)
from ai_brain.stage3.acquisition.quantity_context import (
    explicit_unit_declarations,
    explicit_unit_spelling,
)
from ai_brain.stage3.acquisition.reported_context import (
    validate_reported_context_record,
)
from ai_brain.stage3.acquisition.source_descriptions import (
    DEFINITION_CONTEXT,
    DESCRIPTION_PERSPECTIVES,
    PARAGRAPH_CONTEXT,
    REPORTED_PARAGRAPH_CONTEXT,
    naming_contexts,
    qualified_description,
    trailing_qualification,
)
from ai_brain.stage3.acquisition.version import (
    KNOWLEDGE_PROPOSAL_SCHEMA_VERSION,
    SOURCE_COMPILER_VERSION,
)
from ai_brain.stage3.domains.document_limits import MAX_DOCUMENTARY_PACK_RECORDS
from ai_brain.stage3.knowledge_ir.records import (
    Applicability,
    CausalClaimContent,
    ConceptContent,
    DefinitionContent,
    DimensionVector,
    EntityTypeRef,
    EpistemicCharacter,
    Expression,
    ExpressionKind,
    InterpretationContent,
    KnowledgeKind,
    KnowledgeRecord,
    ProcedureContent,
    ProcedureStep,
    ProcedureStepKind,
    QuantityTypeRef,
    RelationContent,
    RuleContent,
    UnitRef,
    ValueTypeKind,
    ValueTypeRef,
    VariableBinding,
)
from ai_brain.stage3.knowledge_ir.validation import record_content_hash, validate_record
from ai_brain.stage3.knowledge_ir.version import UNIVERSAL_KNOWLEDGE_IR_SCHEMA_VERSION

STEP_PREFIX = "DOCUMENTED_STEP_V1\n"
MAX_API_CONTEXT_BLOCKS = 32
_NAME = r"[\w][\w /()'’–-]{0,100}?"
_MODAL = re.compile(
    r"\b(?:may|might|could|sometimes|possibly|approximately|normally|usually|often|rarely|"
    r"typically|frequently|generally|not|never|if|when|unless|except)\b|"
    r"\bonly\s+(?:during|after|before|for|under)\b|"
    r"\b(?:now|currently|today)\s+(?:a|an|the)\b|"
    r"\b(?:может|возможно|иногда|примерно|не|никогда|если|когда|кроме)\b",
    re.IGNORECASE,
)
_UNITS = {
    "1": (DimensionVector(), Fraction(1)),
    "m": (DimensionVector(length=1), Fraction(1)),
    "cm": (DimensionVector(length=1), Fraction(1, 100)),
    "mm": (DimensionVector(length=1), Fraction(1, 1000)),
    "km": (DimensionVector(length=1), Fraction(1000)),
    "s": (DimensionVector(time=1), Fraction(1)),
    "min": (DimensionVector(time=1), Fraction(60)),
    "h": (DimensionVector(time=1), Fraction(3600)),
    "kg": (DimensionVector(mass=1), Fraction(1)),
    "g": (DimensionVector(mass=1), Fraction(1, 1000)),
    "N": (DimensionVector(length=1, mass=1, time=-2), Fraction(1)),
    "Hz": (DimensionVector(time=-1), Fraction(1)),
}


def _equation_context_refuses(source_context):
    """Negative qualification only; never supplies units or applicability."""
    return bool(
        _MODAL.search(source_context)
        or "?" in source_context
        or re.search(
            r"\b(?:approximate(?:ly)?|empirical|estimate|heuristic|may|might|could|примерно|приблизительно|эмпирически|возможно)\b",
            source_context,
            re.IGNORECASE,
        )
    )


def semantic_profile():
    # Changes to arithmetic conversion/IR validation also require fresh review.
    from ai_brain.stage3.acquisition import extractors
    from ai_brain.stage3.acquisition.documentary_replay import custody_profile
    from ai_brain.stage3.knowledge_ir import validation

    return content_hash(
        {
            "version": 11,
            "scalar_unit_helpers": {
                name: bytes_hash(Path(__file__).with_name(name).read_bytes())
                for name in ("documentary_scalar_units.py", "documentary_scalar_policy.py")
            },
            "scalar_unit_compiler": bytes_hash(Path(__file__).with_name("compiler.py").read_bytes()),
            "scalar_unit_loader": bytes_hash(Path(__file__).parents[1].joinpath("domains/loader.py").read_bytes()),
            "scalar_unit_runtime": bytes_hash(Path(__file__).parents[1].joinpath("domains/semantic_reasoning.py").read_bytes()),
            "inline_equations": bytes_hash(
                Path(__file__).with_name("documentary_inline_equations.py").read_bytes()
            ),
            "extractor": bytes_hash(Path(__file__).read_bytes()),
            "math_parser": bytes_hash(Path(extractors.__file__).read_bytes()),
            "validator": bytes_hash(Path(validation.__file__).read_bytes()),
            "review_policy": bytes_hash(
                Path(__file__).with_name("semantic_material.py").read_bytes()
            ),
            "math_notation": bytes_hash(
                Path(__file__).with_name("math_notation.py").read_bytes()
            ),
            "source_descriptions": bytes_hash(
                Path(__file__).with_name("source_descriptions.py").read_bytes()
            ),
            "quantity_context": bytes_hash(
                Path(__file__).with_name("quantity_context.py").read_bytes()
            ),
            "documentary_relations": bytes_hash(
                Path(__file__).with_name("documentary_relations.py").read_bytes()
            ),
            "record_budget": MAX_DOCUMENTARY_PACK_RECORDS,
            "document_signatures": bytes_hash(
                Path(__file__).with_name("document_signatures.py").read_bytes()
            ),
            "documentary_api_content": bytes_hash(
                Path(__file__).with_name("documentary_api_content.py").read_bytes()
            ),
            "api_context_review_helpers": {
                name: bytes_hash(Path(__file__).with_name(name).read_bytes())
                for name in (
                    "models.py",
                    "persistence.py",
                    "source_review_metadata.py",
                    "documentary_api_context.py",
                    "documentary_api_licensing.py",
                    "documentary_api_policy.py",
                )
            },
            "documentary_logic": bytes_hash(
                Path(__file__).with_name("documentary_logic.py").read_bytes()
            ),
            "conditional_v2_helpers": {
                name: bytes_hash(Path(__file__).with_name(name).read_bytes())
                for name in (
                    "documentary_surface_logic.py",
                    "documentary_surface_payload.py",
                    "documentary_conditional_v2.py",
                    "documentary_conditional_context_v2.py",
                    "documentary_conditional_bridge_v2.py",
                    "documentary_reader_conditionals_v2.py",
                )
            },
            "conditional_v2_runtime": bytes_hash(
                Path(__file__)
                .parents[1]
                .joinpath("domains/documentary_conditionals_v2.py")
                .read_bytes()
            ),
            "documentary_clauses": bytes_hash(
                Path(__file__).with_name("documentary_clauses.py").read_bytes()
            ),
            "reported_context": bytes_hash(
                Path(__file__).with_name("reported_context.py").read_bytes()
            ),
            "reported_context_loader": bytes_hash(
                Path(__file__).parents[1].joinpath("domains/loader.py").read_bytes()
            ),
            "reported_context_install": bytes_hash(
                Path(__file__).parents[1].joinpath("domains/registry.py").read_bytes()
            ),
            "compiler": bytes_hash(
                Path(__file__).with_name("compiler.py").read_bytes()
            ),
            "documentary_custody_profile": custody_profile(),
        }
    )


def term_key(text):
    value = " ".join(unicodedata.normalize("NFKC", text).casefold().split()).strip(
        " .:;"
    )
    return re.sub(r"^(?:a|an|the)\s+", "", value)


def parse_unit(text):
    """Small explicit SI unit grammar; no unit guessing or arbitrary expressions."""
    if type(text) is not str or len(text) > 40:
        raise ValueError("unsupported unit")
    text = explicit_unit_spelling(text).replace("·", "*")
    parts = re.split(r"([*/])", text)
    if len(parts) > 15:
        raise ValueError("unit exceeds limit")
    dimension, scale, sign = DimensionVector(), Fraction(1), 1
    for part in parts:
        if part in {"*", "/"}:
            sign = -1 if part == "/" else 1
            continue
        match = re.fullmatch(r"([A-Za-z]+|1)(?:\^(-?\d{1,2}))?", part)
        if not match or match[1] not in _UNITS:
            raise ValueError("unknown unit")
        exponent = int(match[2] or 1) * sign
        if not -12 <= exponent <= 12:
            raise ValueError("unit exponent exceeds limit")
        base, factor = _UNITS[match[1]]
        values = {
            key: value + asdict(base)[key] * exponent
            for key, value in asdict(dimension).items()
        }
        if any(abs(value) > 24 for value in values.values()):
            raise ValueError("unit dimension exceeds limit")
        dimension = DimensionVector(**values)
        scale *= factor**exponent
    return dimension, scale


def _candidate_record(proposal, stamp):
    return KnowledgeRecord(
        proposal.proposal_id,
        proposal.source_bundle_id,
        proposal.proposed_kind,
        UNIVERSAL_KNOWLEDGE_IR_SCHEMA_VERSION,
        proposal.proposed_epistemic_character,
        proposal.segment_ids,
        proposal.proposed_dependencies,
        proposal.proposed_applicability,
        proposal.proposed_capabilities,
        stamp,
        proposal.proposed_content,
        "",
    )


def validate_candidate(proposal, stamp, *, supporting_proposals=None):
    from ai_brain.stage3.acquisition.documentary_scalar_policy import validate_candidate as validate_scalar_candidate
    validate_scalar_candidate(proposal, supporting_proposals)
    from ai_brain.stage3.acquisition.documentary_api_policy import (
        reserved_api_policy,
        validate_api_policy_candidate,
    )

    if reserved_api_policy(proposal.proposed_content):
        validate_api_policy_candidate(proposal, supporting_proposals)
    record = _candidate_record(proposal, stamp)
    content = record.content
    if (
        isinstance(content, InterpretationContent)
        and content.perspective == REPORTED_PARAGRAPH_CONTEXT
    ):
        if supporting_proposals is None:
            raise ValueError("reported paragraph requires source/target replay support")
        if type(record.dependencies) is not tuple or any(
            type(identity) is not str for identity in record.dependencies
        ):
            raise ValueError("reported paragraph references require exact tuples")
        by_id = {
            identity: _candidate_record(supporting_proposals[identity], stamp)
            for identity in record.dependencies
            if identity in supporting_proposals
        }
        validate_reported_context_record(record, by_id)
    if isinstance(content, InterpretationContent) and content.perspective in {
        DOCUMENTARY_CONDITIONAL_V1,
        DOCUMENTARY_CONDITIONAL_V2,
    }:
        # M33-local syntax admission, not authority: installation replays source
        # bytes and runtime re-derives the rule from its documentary dependency.
        parsed = (
            parse_conditional_payload(content.claim_text)
            if content.perspective == DOCUMENTARY_CONDITIONAL_V1
            else parse_conditional_payload_v2(content.claim_text)
        )
        if (
            not parsed.scope
            or len(content.supported_record_ids) != 1
            or content.supported_record_ids != record.dependencies
            or content.contrast_record_ids
            or record.required_capability_ids
            or record.applicability_refs
            or record.epistemic_character is not EpistemicCharacter.INTERPRETIVE
        ):
            raise ValueError("conditional requires one reviewed documentary dependency")
        if content.perspective == DOCUMENTARY_CONDITIONAL_V2:
            source = (
                supporting_proposals.get(content.supported_record_ids[0])
                if supporting_proposals is not None
                else None
            )
            if (
                source is None
                or source.proposal_id != content.supported_record_ids[0]
                or proposal.source_bundle_id != source.source_bundle_id
                or type(proposal.segment_ids) is not tuple
                or proposal.segment_ids != source.segment_ids
            ):
                raise ValueError("conditional candidate source lineage differs")
    validate_record(replace(record, content_hash=record_content_hash(record)))


class _Extraction:
    def __init__(self, direct, segments, stamp):
        self.direct, self.segments, self.stamp = direct, segments, stamp
        self.proposals_by_id = {item.proposal_id: item for item in direct}
        self.proposals, self.questions, self.terms = [], [], {}
        self.semantic_count = 0
        self.current = None
        self.current_context = ()
        self.proposal_ids, self.question_keys = set(), set()

    def question(self, reason, excerpt):
        item = {
            "reason": reason,
            "source_proposal_id": excerpt.proposal_id,
            "source_segment_ids": list(excerpt.segment_ids),
            "status": "REVIEW_REQUIRED",
            "silently_installed": False,
        }
        key = (reason, excerpt.proposal_id)
        if key not in self.question_keys:
            self.question_keys.add(key)
            self.questions.append(item)
            if len(self.questions) > 4096:
                raise ValueError(
                    "semantic review question limit exceeded; split sources"
                )

    def add(
        self,
        content,
        kind,
        epistemic,
        excerpt,
        dependencies=(),
        capabilities=(),
        context=(),
    ):
        context = tuple(
            {
                item.proposal_id: item for item in (*self.current_context, *context)
            }.values()
        )
        body = {
            "proposal_id": "",
            "source_bundle_id": excerpt.source_bundle_id,
            "segment_ids": tuple(
                dict.fromkeys(
                    (
                        *excerpt.segment_ids,
                        *(segment for item in context for segment in item.segment_ids),
                    )
                )
            ),
            "proposed_kind": kind,
            "proposed_epistemic_character": epistemic,
            "proposed_content": content,
            "proposed_dependencies": tuple(
                dict.fromkeys(
                    (
                        excerpt.proposal_id,
                        *dependencies,
                        *(item.proposal_id for item in context),
                    )
                )
            ),
            "proposed_applicability": (),
            "proposed_capabilities": capabilities,
            "extraction_method": ExtractionMethod.DETERMINISTIC_PATTERN,
            "status": ProposalStatus.REVIEW_REQUIRED,
            "ambiguity_fields": ("source_assertion_requires_explicit_semantic_review",),
            "compiler_version": SOURCE_COMPILER_VERSION,
            "schema_version": KNOWLEDGE_PROPOSAL_SCHEMA_VERSION,
        }
        body["proposal_id"] = "proposal.semantic." + content_hash(body)[:32]
        proposal = KnowledgeProposal(**body, proposal_hash=content_hash(body))
        validate_candidate(
            proposal, self.stamp, supporting_proposals=self.proposals_by_id
        )
        if proposal.proposal_id not in self.proposal_ids:
            self.proposal_ids.add(proposal.proposal_id)
            self.proposals.append(proposal)
            self.proposals_by_id[proposal.proposal_id] = proposal
            if len(self.proposals) + len(self.direct) > MAX_DOCUMENTARY_PACK_RECORDS:
                raise ValueError("semantic candidate limit exceeded; split sources")
        return proposal.proposal_id

    def term(self, name, excerpt):
        name = name.strip(" .:;")
        key = term_key(name)
        if key not in self.terms:
            self.terms[key] = self.add(
                ConceptContent(
                    name,
                    name,
                    f"Source-named term: {name}",
                    f"Source-named term: {name}",
                ),
                KnowledgeKind.CONCEPT,
                EpistemicCharacter.INTERPRETIVE,
                excerpt,
            )
        return self.terms[key]

    def sentence(self, sentence, excerpt):
        # Citation markers are documentary metadata, not part of a term/speaker.
        # Original bytes and passages remain untouched and are cited as evidence.
        sentence = re.sub(r"\[\d{1,4}\]", "", sentence).strip()
        # Explicit metalinguistic subject markers are not part of the term.
        # Keep the complete original passage as evidence, never infer synonyms.
        sentence = re.sub(r"^(?:The\s+)?term\s+", "", sentence, flags=re.IGNORECASE)
        if len(sentence) > 700 or not sentence:
            return
        if sentence.endswith("?"):
            self.question("question_not_promoted_to_assertion", excerpt)
            return
        if "[UNSUPPORTED_MATH_NOTATION]" in sentence:
            self.question("unsupported_math_notation_not_promoted", excerpt)
            return
        if contains_passive_report(sentence):
            # A separately retained unresolved paragraph is documentary context,
            # not permission to make this reported sentence a typed definition.
            self.question("passive_report_not_promoted_to_assertion", excerpt)
            return
        surface = parse_documentary_relations(sentence)
        parent_guarded = False
        current = getattr(self, "current", None)
        if current is not None:
            # Newly admitted surface relations must also be admitted by the
            # whole reader-owned paragraph. A full stop does not license dropping
            # a following applicability restriction such as 'The claim is valid
            # only for ...'. Truncated chunks cannot establish this completeness.
            parent = parse_documentary_relations(
                re.sub(r"\[\d{1,4}\]", "", current["text"])
            )
            complete_parent = (
                type(current.get("chunk_count")) is int and current["chunk_count"] == 1
            )
            parent_guarded = not complete_parent or any(
                item.reason
                in {
                    "qualified_conditional_or_unresolved_report",
                    "unsafe_or_quoted_passage",
                }
                for item in parent.review_reasons
            )
            allowed_sentences = (
                {" ".join(item.source.text.split()) for item in parent.assertions}
                if complete_parent
                else set()
            )
            surface = replace(
                surface,
                assertions=tuple(
                    item
                    for item in surface.assertions
                    if " ".join(item.source.text.split()) in allowed_sentences
                ),
            )
        if len(surface.assertions) > 1 and "," not in sentence:
            # A bare noun coordination may denote one compound component. Pure
            # surface candidates are not enough to publish multiple installed
            # edges without explicit list punctuation; no Cartesian expansion.
            surface = replace(surface, assertions=())
        if surface.attributed_claims:
            # The helper supplies only explicit named source labels. Preserve
            # the complete attributed claim, including terminal punctuation,
            # negation and qualification; never turn it into an empirical edge.
            for attributed in surface.attributed_claims:
                perspective = attributed.speaker
                if perspective in DESCRIPTION_PERSPECTIVES or perspective.startswith(
                    "DOCUMENTARY_CONDITIONAL_"
                ):
                    perspective = "SOURCE_ATTRIBUTED_SPEAKER:" + perspective
                target = self.term(attributed.topic, excerpt)
                self.add(
                    InterpretationContent(
                        sentence[attributed.claim.start : attributed.source.end],
                        perspective,
                        (target,),
                    ),
                    KnowledgeKind.INTERPRETATION,
                    EpistemicCharacter.INTERPRETIVE,
                    excerpt,
                    (target,),
                )
                self.semantic_count += 1
            return
        active_attribution = re.fullmatch(
            rf"({_NAME})\s+(?:argued|claimed|contended|asserted|wrote)\s+that\s+(.+)",
            sentence,
            re.IGNORECASE,
        )
        if active_attribution:
            perspective, claim = (
                value.strip() for value in active_attribution.groups()
            )
            topic_match = re.fullmatch(
                rf"({_NAME})\s+(?:was|were|is|are)\s+(.+)", claim, re.IGNORECASE
            )
            unresolved = {
                "it",
                "he",
                "she",
                "they",
                "we",
                "this",
                "that",
                "these",
                "those",
                "someone",
                "somebody",
                "the author",
                "the historian",
                "the speaker",
            }
            if (
                topic_match is None
                or term_key(perspective) in unresolved
                or term_key(topic_match[1]) in unresolved
                or re.search(
                    r"\b(?:argued|claimed|contended|asserted|wrote|according to)\b",
                    claim,
                    re.IGNORECASE,
                )
            ):
                self.question(
                    "active_report_requires_explicit_speaker_and_topic", excerpt
                )
                return
            # Keep a reported position as an interpretation, never a definition,
            # rule or unqualified fact. Speaker/topic are explicit source labels;
            # no pronoun resolution, nested reporting or background identity joins.
            if perspective in DESCRIPTION_PERSPECTIVES or perspective.startswith(
                "DOCUMENTARY_CONDITIONAL_"
            ):
                perspective = "SOURCE_ATTRIBUTED_SPEAKER:" + perspective
            target = self.term(topic_match[1].strip(), excerpt)
            self.add(
                InterpretationContent(claim, perspective, (target,)),
                KnowledgeKind.INTERPRETATION,
                EpistemicCharacter.INTERPRETIVE,
                excerpt,
                (target,),
            )
            self.semantic_count += 1
            return
        # Attributed interpretations are deliberately not promoted to facts.
        match = re.fullmatch(
            r"(?:According to|По мнению)\s+([^,]{1,100}),\s*(.+)",
            sentence,
            re.IGNORECASE,
        )
        if match:
            perspective = match[1].strip()
            # Source-supplied author labels cannot impersonate machine-generated
            # documentary classifications used by the installed reasoner.
            if perspective in DESCRIPTION_PERSPECTIVES or perspective.startswith(
                "DOCUMENTARY_CONDITIONAL_"
            ):
                perspective = "SOURCE_ATTRIBUTED_SPEAKER:" + perspective
            claim = re.sub(
                r"^published in \d{4},\s*", "", match[2].strip(), flags=re.IGNORECASE
            )
            topic = re.split(
                r"\s+(?:was|were|is|are|был|была|является)\s+",
                claim,
                maxsplit=1,
                flags=re.IGNORECASE,
            )[0]
            if term_key(topic) in {
                "it",
                "he",
                "she",
                "they",
                "we",
                "this",
                "that",
                "these",
                "those",
                "someone",
                "somebody",
                "the author",
                "the historian",
                "the speaker",
            } or re.search(
                r"\b(?:argued|argues|claimed|claims|contended|asserted|wrote|"
                r"according to|reported|believed)\b",
                claim,
                re.IGNORECASE,
            ):
                self.question("attribution_requires_explicit_unreported_topic", excerpt)
                return
            target = self.term(topic[:100], excerpt)
            self.add(
                InterpretationContent(claim, perspective, (target,)),
                KnowledgeKind.INTERPRETATION,
                EpistemicCharacter.INTERPRETIVE,
                excerpt,
                (target,),
            )
            self.semantic_count += 1
            return
        if sentence.startswith(('"', "“", "«", ">")) or re.search(
            r"\b(?:according to|believed?|argued?|claimed?|wrote|writes|reported?|"
            r"по мнению|считал|утверждал)\b",
            sentence,
            re.IGNORECASE,
        ):
            self.question(
                "quotation_or_reporting_requires_explicit_attribution", excerpt
            )
            return
        if parent_guarded and not _MODAL.search(sentence):
            # All legacy/new relation branches below share this guard. Literal
            # definitions remain INTERPRETIVE source descriptors, not empirical
            # relation/conditional authority; full unresolved paragraph context
            # is retained separately and returned alongside the descriptor.
            self.question("whole_paragraph_qualification_not_promoted", excerpt)
        if _MODAL.search(sentence):
            description = qualified_description(sentence, _MODAL)
            if description:
                self.description(description, excerpt)
                return
            if re.search(
                r"\b(?:is|are|causes?|leads?|part|вызывает|является)\b",
                sentence,
                re.IGNORECASE,
            ):
                self.question(
                    "negated_modal_or_qualified_statement_not_promoted", excerpt
                )
            return
        relation = re.fullmatch(
            rf"({_NAME})\s+(is a kind of|is a type of|is part of|is a component of|is a constituent of|является видом|является частью|"
            rf"causes|leads to|вызывает|приводит к)\s+({_NAME})[.!]?",
            sentence,
            re.IGNORECASE,
        )
        if relation and not parent_guarded:
            left, predicate, right = relation.groups()
            subject, target = self.term(left, excerpt), self.term(right, excerpt)
            if predicate.casefold() in {"causes", "leads to", "вызывает", "приводит к"}:
                content = CausalClaimContent(subject, target, sentence)
                kind = KnowledgeKind.CAUSAL_RULE
            else:
                taxonomy = predicate.casefold() in {
                    "is a kind of",
                    "is a type of",
                    "является видом",
                }
                content = RelationContent(
                    subject,
                    "is_a" if taxonomy else "part_of",
                    target,
                    EntityTypeRef("documented.entity"),
                    EntityTypeRef("documented.entity"),
                )
                kind = (
                    KnowledgeKind.TAXONOMY_EDGE
                    if taxonomy
                    else KnowledgeKind.PART_WHOLE_RELATION
                )
            self.add(
                content, kind, EpistemicCharacter.EMPIRICAL, excerpt, (subject, target)
            )
            self.semantic_count += 1
            return
        # Only explicitly stated structural membership. 'contains', 'houses',
        # proximity and possessives do not establish a part-whole relation.
        components = re.fullmatch(
            rf"({_NAME})\s+(?:has a component called|has a part called|consists of)\s+({_NAME})[.!]?",
            sentence,
            re.IGNORECASE,
        )
        if components and not surface.assertions and not parent_guarded:
            whole, part = components.groups()
            if re.search(r"\b(?:and|or)\b|[,;]", part, re.IGNORECASE):
                self.question("compound_membership_requires_explicit_binding", excerpt)
                return
            subject, target = self.term(part, excerpt), self.term(whole, excerpt)
            self.add(
                RelationContent(
                    subject,
                    "part_of",
                    target,
                    EntityTypeRef("documented.entity"),
                    EntityTypeRef("documented.entity"),
                ),
                KnowledgeKind.PART_WHOLE_RELATION,
                EpistemicCharacter.EMPIRICAL,
                excerpt,
                (subject, target),
            )
            self.semantic_count += 1
            return
        if surface.assertions:
            for assertion in surface.assertions:
                subject = self.term(assertion.subject, excerpt)
                target = self.term(assertion.object, excerpt)
                if assertion.predicate == "causes":
                    content = CausalClaimContent(subject, target, assertion.source.text)
                    kind = KnowledgeKind.CAUSAL_RULE
                else:
                    content = RelationContent(
                        subject,
                        assertion.predicate,
                        target,
                        EntityTypeRef("documented.entity"),
                        EntityTypeRef("documented.entity"),
                    )
                    kind = (
                        KnowledgeKind.TAXONOMY_EDGE
                        if assertion.predicate == "is_a"
                        else KnowledgeKind.PART_WHOLE_RELATION
                    )
                self.add(
                    content,
                    kind,
                    EpistemicCharacter.EMPIRICAL,
                    excerpt,
                    (subject, target),
                )
                self.semantic_count += 1
            # A copular classification also retains its literal documentary
            # definition. A reviewed taxonomy edge is not a reason to lose the
            # original descriptive answer, and no lemma/synonym is invented.
            if any(item.predicate != "is_a" for item in surface.assertions):
                return
        alias_definition = re.fullmatch(
            rf"({_NAME}),\s+or\s+({_NAME}),\s+(?:is|was)\s+(.+)",
            sentence,
            re.IGNORECASE,
        )
        definition = re.fullmatch(
            rf"({_NAME})\s+(?:is defined as|are defined as|means|refers to|называется|"
            rf"означает|это|is|are)\s+(.+)",
            sentence,
            re.IGNORECASE,
        )
        historical_definition = re.fullmatch(
            rf"({_NAME})\s+was\s+((?:a|an|the)\s+.+)", sentence, re.IGNORECASE
        )
        # Explicit noun apposition, not an inferred definition from a narrative.
        apposition = re.search(
            r"\b(?:a|an|of|called|named)\s+([\w][\w'’-]*(?:\s+[\w'’-]+){0,3}),\s+"
            r"((?:a|an)\s+.+)",
            sentence,
            re.IGNORECASE,
        )
        definitions = []
        if alias_definition:
            definitions.extend(
                (name, alias_definition[3]) for name in alias_definition.groups()[:2]
            )
        elif definition:
            definitions.append((definition[1], definition[2]))
        elif historical_definition:
            definitions.append((historical_definition[1], historical_definition[2]))
        if apposition:
            definitions.append((apposition[1], apposition[2]))
        for name, description in definitions:
            if name.lower().startswith(("for ", "if ", "when ")) or "=" in sentence:
                return
            target = self.term(name, excerpt)
            # Distinct source definitions retain distinct identities/values.
            content = DefinitionContent(
                "term." + content_hash((target, sentence, excerpt.proposal_id))[:24],
                description.rstrip("."),
                description.rstrip("."),
            )
            self.add(
                content,
                KnowledgeKind.DEFINITION,
                EpistemicCharacter.INTERPRETIVE,
                excerpt,
                (target,),
            )
            self.semantic_count += 1

    def description(self, description, excerpt):
        name, claim, perspective = description
        target = self.term(name, excerpt)
        self.add(
            InterpretationContent(claim, perspective, (target,)),
            KnowledgeKind.INTERPRETATION,
            EpistemicCharacter.INTERPRETIVE,
            excerpt,
            (target,),
        )
        self.semantic_count += 1

    def documentary_context(self, payload, excerpt):
        """Retain complete definition explanations without upgrading their authority."""
        owned = set()
        for context in extract_definition_contexts(payload["text"], metadata=payload):
            if len(context.sentences) > 1:
                owned.add(context.full_description.text)
                self.description(
                    (
                        context.subject,
                        context.full_description.text,
                        DEFINITION_CONTEXT,
                    ),
                    excerpt,
                )
        # This envelope deliberately does not resolve the subsequent sentences'
        # subjects. It is original paragraph context, not an expanded definition.
        for context in extract_definition_paragraphs(payload["text"], metadata=payload):
            if len(context.sentences) > 1 and context.paragraph.text not in owned:
                owned.add(context.paragraph.text)
                self.description(
                    (context.subject, context.paragraph.text, PARAGRAPH_CONTEXT),
                    excerpt,
                )
        for context in extract_definition_reported_paragraphs(
            payload["text"], metadata=payload
        ):
            if context.paragraph.text not in owned:
                owned.add(context.paragraph.text)
                self.description(
                    (
                        context.subject,
                        context.paragraph.text,
                        REPORTED_PARAGRAPH_CONTEXT,
                    ),
                    excerpt,
                )

        # Explicit named labels in a complete qualified parent are retrieval
        # anchors only. Keep every qualification and unresolved reference in
        # the claim; do not create a rule, quantified instance or resolved edge.
        if (
            payload.get("documentary_role") == "PROSE"
            and not payload.get("quotation")
            and type(payload.get("chunk_count")) is int
            and payload["chunk_count"] == 1
        ):
            inventory = inventory_documentary_parent(payload["text"])
            if (
                inventory is not None
                and (inventory.qualifications or inventory.references)
                and len(split_documentary_sentences(payload["text"])) > 1
            ):
                existing = {
                    context.subject
                    for context in extract_definition_paragraphs(
                        payload["text"], metadata=payload
                    )
                    if context.paragraph.text in owned
                }
                for subject in inventory.subjects:
                    if subject.text not in existing:
                        self.description(
                            (subject.text, inventory.parent.text, PARAGRAPH_CONTEXT),
                            excerpt,
                        )

    def conditionals(
        self, payload, excerpt, following_payload=None, preceding_payload=None
    ):
        """Only explicit source sentences propose reviewed, scoped hypothetical rules."""
        try:
            scope = documentary_scope(payload)
        except ValueError:
            return
        legacy = extract_documentary_conditionals(
            payload, following_payload, preceding_payload
        )
        for candidate in legacy:
            bound = bind_scope(candidate, scope)
            self.add(
                InterpretationContent(
                    canonical_json(bound),
                    DOCUMENTARY_CONDITIONAL_V1,
                    (excerpt.proposal_id,),
                ),
                KnowledgeKind.INTERPRETATION,
                EpistemicCharacter.INTERPRETIVE,
                excerpt,
            )
            self.semantic_count += 1
        try:
            extended = extract_reader_conditionals_v2(
                payload, following_payload, preceding_payload
            )
        except ValueError:
            # Unsupported complete reader grouping cannot create a partial V2
            # source proposal. Legacy V1 proposal meaning remains unchanged.
            return
        legacy_sentences = {candidate["sentence"] for candidate in legacy}
        for candidate in extended:
            if candidate["sentence"] in legacy_sentences:
                continue
            bound = bind_scope_v2(candidate, scope)
            self.add(
                InterpretationContent(
                    canonical_json(bound),
                    DOCUMENTARY_CONDITIONAL_V2,
                    (excerpt.proposal_id,),
                ),
                KnowledgeKind.INTERPRETATION,
                EpistemicCharacter.INTERPRETIVE,
                excerpt,
            )
            self.semantic_count += 1

    def captions(self, text, excerpt):
        # A documentary term/symbol colon is an explicit label-description
        # construction. Do not turn a heading's surrounding narrative into it.
        for paragraph in re.split(r"\n\s*\n", text):
            caption = re.fullmatch(
                rf"\s*({_NAME})(?:\s*\(([A-Za-zα-ω][\w]{{0,15}})\))?:\s+(.{{3,700}})",
                " ".join(paragraph.split()),
                re.IGNORECASE,
            )
            if not caption:
                continue
            name, _, description = caption.groups()
            if name.casefold() in {
                "unit",
                "units",
                "note",
                "warning",
                "example",
                "equation",
            }:
                continue
            if (
                "?" in description
                or _MODAL.search(description)
                or "=" in description
                or "[UNSUPPORTED_MATH_NOTATION]" in description
            ):
                self.question("qualified_caption_requires_review", excerpt)
                continue
            if description.startswith(('"', "“", "«", ">")) or re.search(
                r"\b(?:according to|believed?|claimed?|argued?|wrote|reported?)\b",
                description,
                re.IGNORECASE,
            ):
                self.question("quoted_caption_requires_attribution", excerpt)
                continue
            target = self.term(name, excerpt)
            self.add(
                DefinitionContent(
                    "term."
                    + content_hash((target, paragraph, excerpt.proposal_id))[:24],
                    description.rstrip("."),
                    description.rstrip("."),
                ),
                KnowledgeKind.DEFINITION,
                EpistemicCharacter.INTERPRETIVE,
                excerpt,
                (target,),
            )
            self.semantic_count += 1

    def equation(self, text, excerpt, context=(), context_text="", scalar_witness=None):
        source_context = normalize_symbols(text + "\n" + context_text)
        if "[UNSUPPORTED_MATH_NOTATION]" in text:
            self.question("unsupported_math_notation_not_promoted", excerpt)
            return
        # TeX is decoded only inside explicit math delimiters. Ordinary text
        # and source function calls retain the stricter original AST policy.
        prepared = normalize_symbols(text)
        notation_pattern = r"\$\$[\s\S]*?\$\$|\\\[[\s\S]*?\\\]|\\\([\s\S]*?\\\)"
        remainder = re.sub(notation_pattern, "", text)
        if any(marker in remainder for marker in ("$$", r"\[", r"\]", r"\(", r"\)")):
            self.question("unbalanced_math_delimiter_not_promoted", excerpt)
            return
        for notation in re.findall(notation_pattern, text):
            try:
                prepared = prepared.replace(
                    normalize_symbols(notation), "\n" + latex_scalar(notation) + "\n"
                )
            except ValueError as error:
                self.question("unsupported_math_notation: " + str(error), excerpt)
                return
        for line in prepared.splitlines():
            match = re.fullmatch(
                r"\s*(?:Equation:\s*)?([A-Za-z0-9_+*/(). ^-]{1,140}\s*=\s*[A-Za-z0-9_+*/(). ^-]{1,300})[.;]?\s*",
                line,
                re.IGNORECASE,
            )
            if not match:
                continue
            equation = match[1].replace("^", "**")
            # AST is inspected only; calls, attributes and implicit multiplication are rejected.
            try:
                if _equation_context_refuses(source_context):
                    raise ValueError(
                        "qualified or approximate formula requires another reviewed policy"
                    )

                from ai_brain.stage3.acquisition.documentary_scalar_units import exact_scalar_decimals
                equation = exact_scalar_decimals(equation)
                trees = [
                    ast.parse(side.strip(), mode="eval") for side in equation.split("=")
                ]
                if sum(1 for tree in trees for _ in ast.walk(tree)) > 100:
                    raise ValueError("expression node limit")
                names = sorted(
                    {
                        node.id
                        for tree in trees
                        for node in ast.walk(tree)
                        if isinstance(node, ast.Name)
                    }
                )
                if not names or len(names) > 16:
                    raise ValueError("a bounded source-bound variable set is required")
                variables = []
                for name in names:
                    declarations = explicit_unit_declarations(source_context, name)
                    units = set(declarations)
                    rooted_binding = None
                    if not units and scalar_witness is not None:
                        from ai_brain.stage3.acquisition.documentary_scalar_policy import variable
                        witness_id, wire = scalar_witness
                        rooted_binding = variable(name, wire, witness_id)
                        dimension = rooted_binding.value_type.quantity_type.dimension
                        row = next(r for r in wire["bindings"] if r["symbol"] == name)
                        source_scale = Fraction(row["scale_numerator"], row["scale_denominator"])
                        source_unit = None
                    elif len(units) != 1:
                        raise ValueError(f"missing or ambiguous unit for {name}")
                    else:
                        source_unit = units.pop()
                        dimension, source_scale = parse_unit(source_unit)
                    unit = UnitRef(
                        "si." + content_hash(asdict(dimension))[:16], dimension
                    )
                    value_type = ValueTypeRef(
                        ValueTypeKind.QUANTITY,
                        quantity_type=QuantityTypeRef(
                            "quantity." + name, dimension, unit
                        ),
                    )
                    minimum, maximum = None, None
                    if re.search(
                        rf"\b{re.escape(name)}\s*(?:>(?!=)|<(?!=))", source_context
                    ):
                        raise ValueError(
                            "strict numeric bounds require a separate condition evaluator"
                        )
                    for operator, bound in re.findall(
                        rf"\b{re.escape(name)}\s*(>=|<=)\s*([+-]?\d+(?:\.\d+)?)",
                        source_context,
                    ):
                        canonical = Fraction(bound) * source_scale
                        denominator = canonical.denominator
                        for factor in (2, 5):
                            while denominator % factor == 0:
                                denominator //= factor
                        if denominator != 1:
                            raise ValueError(
                                "non-finite decimal SI bound requires another representation"
                            )
                        with localcontext() as decimal_context:
                            decimal_context.prec = (
                                len(str(abs(canonical.numerator)))
                                + len(str(canonical.denominator))
                                + 8
                            )
                            value = str(
                                Decimal(canonical.numerator)
                                / Decimal(canonical.denominator)
                            )
                        if operator == ">=":
                            minimum = (
                                value
                                if minimum is None
                                else str(max(Decimal(minimum), Decimal(value)))
                            )
                        else:
                            maximum = (
                                value
                                if maximum is None
                                else str(min(Decimal(maximum), Decimal(value)))
                            )
                    variables.append(
                        VariableBinding(
                            name,
                            value_type,
                            "equation",
                            minimum=minimum,
                            maximum=maximum,
                            semantic_entity_role=(rooted_binding.semantic_entity_role if rooted_binding is not None
                                                  else "source-unit:" + source_unit),
                        )
                    )
                conditions = re.findall(
                    r"(?:^|[\n.!?]\s*)(?:For|Assuming|При|Если)\s+([^\n.!?]{3,200})[.!?]?",
                    source_context,
                    re.IGNORECASE,
                )
                if len(set(conditions)) != 1:
                    raise ValueError("missing or ambiguous explicit applicability")
                condition = conditions[0].strip()
                if _MODAL.search(condition):
                    raise ValueError("unsupported qualified applicability")
                types = {
                    variable.variable_id: variable.value_type for variable in variables
                }
                expression = Expression(
                    ExpressionKind.EQUAL,
                    children=tuple(
                        _math_expression(side.strip(), types)
                        for side in equation.split("=")
                    ),
                    result_type=ValueTypeRef(ValueTypeKind.BOOLEAN),
                )
                self.add(
                    RuleContent(
                        expression, tuple(variables), Applicability((condition,))
                    ),
                    KnowledgeKind.EQUATION_RULE,
                    EpistemicCharacter.DETERMINISTIC,
                    excerpt,
                    capabilities=("generic.scalar_equation_solver.v1",),
                    context=context,
                    dependencies=(scalar_witness[0],) if scalar_witness is not None else (),
                )
                self.semantic_count += 1
            except (ValueError, SyntaxError, RecursionError) as error:
                self.question("equation_context_required: " + str(error), excerpt)

    def api(self, payload, excerpt, context=()):
        if not payload.get("signature") or not payload.get("symbol"):
            return
        if payload.get("format") == "java-documentation-ast" and payload.get(
            "declaration_kind"
        ) not in {"method_declaration", "constructor_declaration"}:
            return
        try:
            content = build_documentary_api_content(payload).content
        except ValueError as error:
            self.question(str(error), excerpt)
            return
        self.add(
            content,
            KnowledgeKind.CLAIM_SCHEMA,
            EpistemicCharacter.INTERPRETIVE,
            excerpt,
            context=context,
        )
        self.semantic_count += 1

    def procedure(self, text, payload, excerpt, context=()):
        numbered = re.findall(r"(?m)^\s*(\d{1,2})[.)]\s+([^\n]+)", text)
        if len(numbered) < 2:
            return
        if [int(n) for n, _ in numbered] != list(range(1, len(numbered) + 1)) or len(
            numbered
        ) > 20:
            self.question("procedure_order_ambiguous", excerpt)
            return
        refs, steps = [], []
        output_type = ValueTypeRef(ValueTypeKind.STRING)
        for ordinal, (_, instruction) in enumerate(numbered, 1):
            value = STEP_PREFIX + canonical_json(
                {"ordinal": ordinal, "text": instruction}
            )
            label = f"documented step {excerpt.proposal_id} {ordinal}"
            ref = self.add(
                ConceptContent(label, label, value, value),
                KnowledgeKind.CONCEPT,
                EpistemicCharacter.INTERPRETIVE,
                excerpt,
                context=context,
            )
            refs.append(ref)
            steps.append(
                ProcedureStep(
                    f"step{ordinal}",
                    ProcedureStepKind.READ_FACT,
                    (),
                    output_type,
                    authority_ref=ref,
                    next_step_ids=(f"step{ordinal + 1}",),
                )
            )
        steps.append(
            ProcedureStep(
                f"step{len(steps) + 1}",
                ProcedureStepKind.PRODUCE_TYPED_OUTPUT,
                (),
                output_type,
            )
        )
        self.add(
            ProcedureContent("step1", tuple(steps), output_type),
            KnowledgeKind.PROCEDURE,
            EpistemicCharacter.DETERMINISTIC,
            excerpt,
            tuple(refs),
            context=context,
        )
        self.semantic_count += 1


def extract_semantic_proposals(direct_proposals, segments, stamp):
    """Original passages remain source dependencies of every extracted candidate."""
    import json

    from ai_brain.stage3.acquisition.direct_material import EXCERPT_PREFIX

    extraction = _Extraction(direct_proposals, segments, stamp)
    payloads = [
        json.loads(item.proposed_content.description_en[len(EXCERPT_PREFIX) :])
        for item in direct_proposals
    ]
    equation_eligible = equation_parent_eligibility(payloads)
    api_groups, api_examples, api_context_groups, procedure_groups = (
        defaultdict(list),
        defaultdict(list),
        defaultdict(list),
        defaultdict(list),
    )
    for position, payload in enumerate(payloads):
        if payload.get("signature") and payload.get("symbol"):
            # All associated documentation is required context, even when its
            # quote/example classification forbids using it as a source rule.
            # Keeping that context is not promoting quoted prose to authority.
            api_context_groups[
                (payload["file"], payload["symbol"], payload["signature"])
            ].append(position)
        if payload.get("documentary_role") == "SOURCE_CONTEXT_MARKER":
            continue
        if payload.get("quotation"):
            continue
        if payload.get("documentary_role") == "LITERAL_EXAMPLE":
            if payload.get("signature") and payload.get("symbol"):
                api_examples[
                    (payload["file"], payload["symbol"], payload["signature"])
                ].append(position)
            continue
        if payload.get("signature") and payload.get("symbol"):
            api_groups[
                (payload["file"], payload["symbol"], payload["signature"])
            ].append(position)
        else:
            procedure_groups[
                (payload["file"], tuple(payload["heading_path"]), payload["title"])
            ].append(position)
    for index, excerpt in enumerate(direct_proposals):
        payload = payloads[index]
        extraction.current = payload
        text = payload["text"]
        if payload.get("documentary_role") == "SOURCE_CONTEXT_MARKER":
            extraction.question(
                "recognized_empty_context_not_inference_authority", excerpt
            )
            continue
        if payload.get("documentary_role") == "LITERAL_EXAMPLE":
            extraction.question("literal_example_not_promoted_to_assertion", excerpt)
            continue
        if payload.get("quotation"):
            extraction.question(
                "quoted_passage_requires_attribution_not_promoted", excerpt
            )
            continue
        if payload.get(
            "documentary_context"
        ) == "JAVA_API_DOCUMENTATION" and not payload.get("signature"):
            # A reviewed API overview describes programs, not empirical world
            # causation. Keep its source excerpts; unknown semantics require
            # review instead of acquiring fact/rule authority from prose.
            extraction.question(
                "api_overview_retained_as_documentary_evidence", excerpt
            )
            continue
        before = extraction.semantic_count
        extraction.conditionals(
            payload,
            excerpt,
            payloads[index + 1] if index + 1 < len(payloads) else None,
            payloads[index - 1] if index else None,
        )
        if not payload.get("signature"):
            extraction.documentary_context(payload, excerpt)
        api_indices = api_groups.get(
            (payload["file"], payload.get("symbol"), payload.get("signature")), []
        )
        if api_indices and index == api_indices[0]:
            context_indices = api_context_groups[
                (payload["file"], payload.get("symbol"), payload.get("signature"))
            ]
            example_indices = api_examples.get(
                (payload["file"], payload.get("symbol"), payload.get("signature")), []
            )
            api_text = "\n\n".join(
                payloads[position]["text"]
                for position in api_indices
                if payloads[position].get("documentary_role") != "DOCUMENTARY_SIGNATURE"
            )
            if (
                len(context_indices) > MAX_API_CONTEXT_BLOCKS
                or sum(len(payloads[position]["text"]) for position in context_indices)
                > 20000
                or len(payload["signature"]) > 2048
            ):
                extraction.question("api_documentation_context_exceeds_limit", excerpt)
            else:
                extraction.api(
                    {
                        **payload,
                        "text": api_text,
                        "documentary_examples": tuple(
                            payloads[position]["text"] for position in example_indices
                        ),
                    },
                    excerpt,
                    tuple(
                        direct_proposals[position]
                        for position in context_indices
                        if position != index
                    ),
                )
        equation_context_indices = [
            position
            for position in range(max(0, index - 2), min(len(payloads), index + 3))
            if position != index
            and payloads[position]["file"] == payload["file"]
            and payloads[position]["heading_path"] == payload["heading_path"]
        ]
        neighbors = [
            position for position in equation_context_indices
            if not payloads[position].get("quotation")
            and payloads[position].get("documentary_role") != "LITERAL_EXAMPLE"
        ]
        if equation_eligible[index]:
            # Preserve the existing raw-line lane and its existing context
            # boundary, but never use literal/reported parents as equations.
            if all(equation_eligible[position] for position in equation_context_indices):
                extraction.equation(
                    text,
                    excerpt,
                    tuple(direct_proposals[position] for position in neighbors),
                    "\n".join(payloads[position]["text"] for position in neighbors),
                )
            else:
                # Refuse the entire legacy context; filtering denied parents
                # could silently erase an exception or source qualification.
                extraction.question("raw_equation_context_unqualified", excerpt)
            captured = (
                capture_original(text)
                if payload.get("documentary_role") == "PROSE"
                else {"status": "NO_CAPTURE"}
            )
            adjacent_veto = any(
                _equation_context_refuses(normalize_symbols(payloads[position]["text"]))
                for position in equation_context_indices
            )
            if captured["status"] == "CAPTURED" and adjacent_veto:
                extraction.question("inline_equation_adjacent_qualification", excerpt)
            elif captured["status"] == "CAPTURED":
                validate_capture(text, captured)
                scalar_witness = None
                from ai_brain.stage3.acquisition.documentary_scalar_policy import ROLE, derive
                same_original = [p for p in payloads if p.get("file") == payload["file"]
                                 and p.get("original_bytes_hash") == payload.get("original_bytes_hash")]
                if len(same_original) == 1:
                    try:
                        body = derive(payload)
                        if any(p["kind"] != "LITERAL" for p in body["wire"]["proofs"]):
                            witness_id = extraction.add(
                                InterpretationContent(canonical_json(body), ROLE, (excerpt.proposal_id,)),
                                KnowledgeKind.INTERPRETATION, EpistemicCharacter.INTERPRETIVE, excerpt,
                            )
                            scalar_witness = (witness_id, body["wire"])
                    except ValueError:
                        extraction.question("scalar_unit_witness_not_supported", excerpt)
                for formula in captured["formulas"]:
                    # Introduced formula authority is qualified only by its
                    # complete original parent, never widened neighbor units.
                    extraction.equation(
                        formula["expression"], excerpt, context_text=text, scalar_witness=scalar_witness
                    )
            elif captured["status"] == "REFUSED":
                extraction.question("inline_equation_capture_refused", excerpt)
        if not payload.get("signature"):
            extraction.captions(text, excerpt)
            for description in naming_contexts(text, _MODAL):
                extraction.description(description, excerpt)
        procedure_indices = procedure_groups.get(
            (payload["file"], tuple(payload["heading_path"]), payload["title"]), []
        )
        if procedure_indices and index == procedure_indices[0]:
            procedure_text = "\n".join(
                payloads[position]["text"] for position in procedure_indices
            )
            if len(procedure_indices) > 16 or len(procedure_text) > 20000:
                if re.search(r"(?m)^\s*\d+[.)] ", procedure_text):
                    extraction.question("procedure_context_exceeds_limit", excerpt)
            else:
                extraction.procedure(
                    procedure_text,
                    payload,
                    excerpt,
                    tuple(
                        direct_proposals[position]
                        for position in procedure_indices
                        if position != index
                    ),
                )
        # PDF line wraps must not truncate definitions or hide a following 'not'.
        # A sentence crossing a chunk boundary cites both original passages.
        if not payload.get("signature"):
            next_index = index + 1
            continuation = (
                next_index < len(payloads)
                and not payloads[next_index].get("quotation")
                and payloads[next_index].get("documentary_role") != "LITERAL_EXAMPLE"
                and payloads[next_index]["file"] == payload["file"]
                and payloads[next_index]["heading_path"] == payload["heading_path"]
                and payload["chunk_index"] + 1 < payload["chunk_count"]
                and payloads[next_index]["chunk_index"] == payload["chunk_index"] + 1
            )
            combined = text + (
                "\n" + payloads[next_index]["text"] if continuation else ""
            )
            # Replace numbered citation markers with same-width whitespace so
            # sentence boundaries and original chunk offsets remain aligned.
            combined = re.sub(
                r"\[\d{1,4}\]", lambda match: " " * len(match[0]), combined
            )
            previous_continues = (
                index > 0
                and not payloads[index - 1].get("quotation")
                and payloads[index - 1].get("documentary_role") != "LITERAL_EXAMPLE"
                and payloads[index - 1]["file"] == payload["file"]
                and payloads[index - 1]["heading_path"] == payload["heading_path"]
                and payload["chunk_index"] > 0
                and payloads[index - 1]["chunk_index"] == payload["chunk_index"] - 1
                and not payloads[index - 1]["text"].rstrip().endswith((".", "!", "?"))
            )
            for ordinal, sentence_match in enumerate(
                re.finditer(
                    r"[\s\S]+?(?:[.!?](?=\s|$|(?:They|The|This|These|Those|It|We)\b)|$)",
                    combined,
                )
            ):
                if sentence_match.start() >= len(text):
                    break
                if ordinal == 0 and previous_continues:
                    continue
                sentence = sentence_match[0].strip()
                terminal = (
                    payloads[next_index]
                    if continuation and sentence_match.end() > len(text)
                    else payload
                )
                if (
                    not sentence.endswith((".", "!", "?"))
                    and terminal["chunk_index"] + 1 < terminal["chunk_count"]
                ):
                    continue
                sentence = re.sub(r"(?<=\w)-\n(?=\w)", "", sentence)
                sentence = " ".join(sentence.split())
                # A full stop is not permission to discard a following exception.
                # Associate only a bounded adjacent referring/exception clause;
                # ambiguous context becomes a description/review, not a rule.
                following_match = re.match(
                    r"\s*([^\n]*?(?:[.!?](?=\s|$)|$))",
                    combined[sentence_match.end() :],
                )
                following = (
                    " ".join(following_match[1].split()) if following_match else ""
                )
                if trailing_qualification(following, _MODAL):
                    sentence += " " + following
                extraction.current_context = (
                    (direct_proposals[next_index],)
                    if continuation
                    and (
                        sentence_match.end() > len(text)
                        or trailing_qualification(following, _MODAL)
                        and sentence_match.end() + len(following_match[0]) > len(text)
                    )
                    else ()
                )
                extraction.sentence(sentence, excerpt)
            extraction.current_context = ()
        if extraction.semantic_count == before and not (
            api_indices and index != api_indices[0]
        ):
            extraction.question("no_supported_semantic_pattern_quote_only", excerpt)
    from ai_brain.stage3.acquisition.documentary_api_policy import (
        propose_api_context_policies,
    )

    propose_api_context_policies(extraction)
    return (*direct_proposals, *extraction.proposals), extraction.questions
