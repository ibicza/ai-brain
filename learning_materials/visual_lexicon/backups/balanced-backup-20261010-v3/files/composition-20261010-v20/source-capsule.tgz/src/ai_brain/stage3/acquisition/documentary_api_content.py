"""One pure documentary descriptor recipe shared by extraction and source replay.

Neither a descriptor nor ContentBuild is provenance, approval, an annotation
license or semantic owner authority. The strict context wrapper must supply ALL
actual owned rows and verify their source boundaries before using coherence.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, replace

from ai_brain.stage2.facts.canonical import content_hash
from ai_brain.stage3.acquisition.document_signatures import (
    java_documentary_parameters,
    java_documentary_reference_policy,
    java_documentary_integral_return_policy,
    parse_document_signature,
)
from ai_brain.stage3.domains.documentary_api_scenarios import (
    classify_documented_api_paragraphs,
    documentary_scenario_fingerprint,
    documented_return_clauses_coherent,
)
from ai_brain.stage3.domains.javadoc_clause_view import has_hidden_controls, documentary_tag_clauses
from ai_brain.stage3.knowledge_ir.records import (
    ClaimSchemaContent,
    EntityTypeRef,
    ValueTypeKind,
    ValueTypeRef,
)


@dataclass(frozen=True)
class ContentBuild:
    content: ClaimSchemaContent
    clauses: tuple[str, ...]
    classification: dict
    reference_policy: object | None


def build_documentary_api_content(payload):
    """Retain the legacy incomplete fallback; never use caller values or IO."""
    if type(payload) is not dict:
        raise ValueError("Exact documentary payload required")
    signature, symbol, text = (
        payload.get(key) for key in ("signature", "symbol", "text")
    )
    if (
        type(signature) is not str
        or not 0 < len(signature) <= 2048
        or type(symbol) is not str
        or not symbol
        or type(payload.get("file")) is not str
        or type(text) is not str
        # The caller bounds 32 original rows and their text sum to 20,000.
        # Joining those rows adds at most 31 two-LF separators, not source prose.
        or len(text) > 20000 + 2 * (32 - 1)
    ):
        raise ValueError("unsupported_documentary_signature_not_promoted")
    display = payload.get("signature_display") or signature
    if type(display) is not str or len(display) > 2048:
        raise ValueError("unsupported_documentary_parameters_not_promoted")
    if any(has_hidden_controls(value) for value in (text, signature, symbol, display)):
        raise ValueError("Hidden documentary descriptor characters")
    language = payload.get("signature_language") or {
        "python-docstrings-ast": "python",
        "java-documentation-ast": "java",
    }.get(payload.get("format"), "documentary")
    args = parse_document_signature(signature, language=language, callable_name=symbol)
    if args is None:
        raise ValueError("unsupported_documentary_signature_not_promoted")
    parameters = (
        java_documentary_parameters(display)
        if language == "java"
        else tuple((f"arg{ordinal}", value) for ordinal, value in enumerate(args))
    )
    if parameters is None:
        raise ValueError("unsupported_documentary_parameters_not_promoted")
    clauses = []
    tagged = language == "java" and re.search(r"(?m)^[ \t]*@[A-Za-z]+\b", text)
    for item in documentary_tag_clauses(text) if tagged else re.split(r"\n\s*\n", text):
        clause = item if tagged else " ".join(item.split())
        if not clause or re.fullmatch(
            r"(?:Parameters|Type Parameters|Returns|Throws|Raises|Since|See Also):",
            clause,
            re.IGNORECASE,
        ):
            continue
        clauses.append(
            re.sub(
                r"^((?:Parameters|Returns|Throws|Raises):)(?:\s*\1)+",
                r"\1",
                clause,
                flags=re.IGNORECASE,
            )
        )
    pre = tuple(
        item
        for item in clauses
        if re.search(
            r"^Parameters:|\b(?:must|requires?|provided that|only accepts?|должен|требуется)\b",
            item,
            re.IGNORECASE,
        )
    )
    post = tuple(
        item
        for item in clauses
        if re.search(
            r"\b(?:returns?|adds?|removes?|converts?|computes?|sums?|stores?|copies|maps?|возвращает|добавляет)\b|^Closest\s+",
            item,
            re.IGNORECASE,
        )
    )
    throws = tuple(
        item
        for item in clauses
        if re.search(
            r"^(?:Throws|Raises):\s*(?!no\b|none\b|nothing\b)\S|@throws\s+\S|"
            r"(?:^|[.!?]\s+)(?:Raises?|Throws?)\s+(?!no\b|none\b|nothing\b)\S|"
            r"(?:^|[.!?]\s+)(?:If|When|Unless)\s+[^.!?]{1,512},\s*"
            r"(?:raises?|throws?)\s+(?!no\b|none\b|nothing\b)\S|"
            r"\b(?:method|function|operation|constructor|call)\s+(?:raises?|throws?)\s+\S",
            item,
            re.IGNORECASE,
        )
    )
    content = ClaimSchemaContent(
        EntityTypeRef("documented.api"),
        symbol.rsplit(".", 1)[-1],
        ValueTypeRef(ValueTypeKind.STRING),
        receiver_type="doc." + content_hash((payload["file"], symbol, signature))[:24],
        parameters=parameters,
        return_type="DOCUMENTED_NOT_EXECUTED",
        preconditions=pre,
        postconditions=post,
        declared_exceptions=throws,
        examples=tuple(payload.get("documentary_examples", ())),
    )

    def policy(value):
        fingerprint = documentary_scenario_fingerprint(value)
        return (
            (java_documentary_reference_policy(
                display,
                callable_name=symbol,
                parameters=parameters,
                content_fingerprint=fingerprint,
            ) or java_documentary_integral_return_policy(
                display, callable_name=symbol, parameters=parameters,
                content_fingerprint=fingerprint,
            ))
            if language == "java" and fingerprint is not None
            else None
        )

    reference_policy = policy(content)
    classified = classify_documented_api_paragraphs(
        content, tuple(clauses), reference_policy=reference_policy
    )
    if classified["status"] == "COMPLETE":
        content = replace(
            content,
            **{
                name: classified[name]
                for name in (
                    "preconditions",
                    "postconditions",
                    "declared_exceptions",
                )
            },
        )
        # Opaque-reference tokens bind FINAL rewritten content, not seed buckets.
        reference_policy = policy(content)
        classified = classify_documented_api_paragraphs(
            content, tuple(clauses), reference_policy=reference_policy
        )
    return ContentBuild(content, tuple(clauses), classified, reference_policy)


def api_content_is_coherent(build):
    if type(build) is not ContentBuild or not build.clauses:
        return False
    replay = classify_documented_api_paragraphs(
        build.content, build.clauses, reference_policy=build.reference_policy
    )
    if replay["status"] != "COMPLETE" or replay != build.classification:
        return False
    if any(
        getattr(build.content, name) != replay[name]
        for name in (
            "preconditions",
            "postconditions",
            "declared_exceptions",
        )
    ):
        return False
    return documented_return_clauses_coherent(
        build.content, reference_policy=build.reference_policy
    )
