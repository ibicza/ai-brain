"""Finite complete-original API policy reconstruction, not source authentication.

Inputs must come from preparation's full original inventory or the loader's
fresh same-buffer replay. A caller-created body, context ID or Python object
never proves custody. No source code, example, URL or caller value is executed.
"""

from __future__ import annotations

import re
from itertools import pairwise
from types import SimpleNamespace

from ai_brain.stage2.facts.canonical import canonical_json, content_hash
from ai_brain.stage3.acquisition.documentary_api_content import (
    api_content_is_coherent,
    build_documentary_api_content,
)
from ai_brain.stage3.acquisition.documentary_api_context import (
    API_CONTEXT_SCOPE,
    DOCUMENTARY_API_CONTEXT_POLICY_V1,
    MAX_CONTEXT_BYTES,
    MAX_CONTEXT_NODES,
    classify_api_informational,
    parse_api_context_policy,
)
from ai_brain.stage3.domains.documentary_api_context import scope_observations
from ai_brain.stage3.domains.documentary_api_scenarios import (
    documentary_scenario_fingerprint,
)
from ai_brain.stage3.domains.documentary_custody import ResourceLimitError
from ai_brain.stage3.domains.javadoc_clause_view import has_hidden_controls

_ORIGIN = ("file", "original_bytes_hash", "source_url", "format", "reader_profile")
_OWNER = ("symbol", "signature", "signature_display", "member_anchor", "source_author")
_IDENTIFIER = r"[A-Za-z_$]\w*"
_PACKAGE = re.compile(r"package\s+(?:" + _IDENTIFIER + r"\.)*" + _IDENTIFIER + r"\s*;")


def _plain_declaration(signature, symbol):
    return (
        type(signature) is str
        and re.fullmatch(
            r"(?:(?:public|protected|private|abstract|final|static|strictfp)\s+)*"
            r"(?:class|interface|enum)\s+" + re.escape(symbol.rsplit(".", 1)[-1]),
            signature,
        )
        is not None
    )


def _safe_prose(row):
    return (
        row.get("quotation") is False
        and row.get("documentary_math_presence") is False
        and row.get("documentary_role") in {"PROSE", "DOCUMENTARY_SIGNATURE"}
        and type(row.get("text")) is str
        and not has_hidden_controls(row["text"])
        and bool(row["text"].strip())
    )


def _member(rows):
    # Semantic reasoning imports the extractor; defer the shared anchor helpers
    # until the already-loaded extractor calls reconstruction, avoiding a cycle.
    from ai_brain.stage3.domains.semantic_reasoning import (
        _installed_java_signature_anchor,
        _installed_unqualified_java_signature,
    )

    if (
        not rows
        or len(rows) > 32
        or sum(len(row.get("text", "")) for row in rows) > 20000
        or any(not _safe_prose(row) for row in rows)
    ):
        raise ValueError("Complete plain bounded member context required")
    data = {
        **rows[0],
        "text": "\n\n".join(
            row["text"]
            for row in rows
            if row.get("documentary_role") != "DOCUMENTARY_SIGNATURE"
        ),
        "documentary_examples": (),
    }
    build = build_documentary_api_content(data)
    record = SimpleNamespace(content=build.content)
    anchor = _installed_java_signature_anchor(record, rows)
    if (
        anchor is None
        or not _installed_unqualified_java_signature(record, rows)
        or not api_content_is_coherent(build)
    ):
        raise ValueError("Whole coherent unqualified documentary member required")
    return build, anchor


def _structure(row):
    value = row.get("documentary_structure")
    fields = {
        "schema_version",
        "coordinate_basis",
        "element_path",
        "tag_path",
        "direct_child_ordinal",
        "previous_sibling_path",
        "gap_before_whitespace_only",
        "callable_element_path",
        "well_nested",
        "direct_child_count",
        "skipped_descendant_presence",
        "non_text_token_presence",
    }
    if (
        type(value) is not dict
        or set(value) != fields
        or type(value["schema_version"]) is not int
        or value["schema_version"] != 1
        or value["coordinate_basis"] != "HTML_PARSER_START_EVENTS_NOT_RAW_BYTES"
        or value["well_nested"] is not True
        or value["skipped_descendant_presence"] is not False
        or value["non_text_token_presence"] is not False
        or type(value["element_path"]) is not list
        or not value["element_path"]
        or type(value["tag_path"]) is not list
        or len(value["element_path"]) != len(value["tag_path"])
        or any(type(part) is not int or part < 1 for part in value["element_path"])
        or any(type(tag) is not str or not tag for tag in value["tag_path"])
        or type(value["direct_child_count"]) is not int
        or not 0 <= value["direct_child_count"] <= 65536
        or type(value["direct_child_ordinal"]) is not int
        or not 1 <= value["direct_child_ordinal"] <= 65536
        or type(value["gap_before_whitespace_only"]) is not bool
    ):
        raise ValueError("Complete clean actual HTML structure required")
    if len(value["element_path"]) > 32:
        raise ResourceLimitError("API structural ancestor ceiling exceeded")
    return value


def _html_roles(rows, groups, target_key):
    anchor = groups[target_key][1]
    basis = anchor.get("documentary_context_basis")
    class_metadata = anchor.get("documentary_html_class_structure")
    if (
        type(basis) is not dict
        or basis.get("kind") != "EXPLICIT_JAVADOC_CLASS_STRUCTURE"
    ):
        raise ValueError("Actual Java class owner required")
    owner, name = basis.get("qualified_class"), basis.get("class_name")
    if (
        type(owner) is not str
        or type(name) is not str
        or not owner.endswith("." + name)
    ):
        raise ValueError("Exact qualified class identity required")
    if (
        type(class_metadata) is not dict
        or len(class_metadata.get("class_identities", [])) != 1
    ):
        raise ValueError("One complete HTML class identity required")
    identity = class_metadata["class_identities"][0]
    if (
        identity.get("class_name") != name
        or identity.get("header_text") != "Class " + name
    ):
        raise ValueError("Exact reader class heading required")
    root = _structure({"documentary_structure": class_metadata.get("root_structure")})
    heading_path = identity.get("element_path")
    if (
        type(heading_path) is not list
        or not len(root["element_path"]) < len(heading_path) <= 32
        or any(type(part) is not int or part < 1 for part in heading_path)
        or heading_path[: len(root["element_path"])] != root["element_path"]
    ):
        raise ValueError("Actual class heading must be inside its original root")
    if root["callable_element_path"] is not None:
        raise ValueError("Unowned whole original root required")
    package = owner[: -(len(name) + 1)]
    roles = []
    for index, row in enumerate(rows):
        structure = _structure(row)
        if (
            row.get("documentary_context_basis") != basis
            or row.get("documentary_html_class_structure") != class_metadata
            or structure["element_path"][: len(root["element_path"])]
            != root["element_path"]
            or type(row.get("chunk_index")) is not int
            or row["chunk_index"] != 0
            or type(row.get("chunk_count")) is not int
            or row["chunk_count"] != 1
        ):
            raise ValueError("Whole same-root unchunked HTML ownership required")
        key = tuple(row.get(field) for field in _OWNER)
        if row.get("signature"):
            if key not in groups or row.get("symbol", "").rsplit(".", 1)[0] != owner:
                raise ValueError("Exact same-class callable required")
            callable_path = structure["callable_element_path"]
            if (
                type(callable_path) is not list
                or not callable_path
                or len(callable_path) > 32
            ):
                raise ValueError("Actual bounded callable owner required")
            if any(
                _structure(member)["callable_element_path"] != callable_path
                for member in groups[key][2]
            ):
                raise ValueError("Callable structural ownership differs")
            roles.append("MEMBER_CONTEXT" if key == target_key else "OTHER_CALLABLE")
            continue
        if structure["callable_element_path"] is not None:
            raise ValueError("Unknown callable context cannot be excluded")
        text = " ".join(row["text"].split())
        if _safe_prose(row) and (
            text in {owner, package, "Package " + package}
            or _plain_declaration(text, owner)
        ):
            roles.append("NOMINAL_IDENTITY")
        elif _safe_prose(row) and classify_api_informational(row["text"]):
            roles.append("INFORMATIONAL_PURPOSE")
        elif _safe_prose(row) and text in {"For example:", "Example:", "Examples:"}:
            if index + 1 >= len(rows) or not _literal_pair(row, rows[index + 1]):
                raise ValueError("Complete associated literal example required")
            roles.append("EXAMPLE_INTRODUCTION")
        elif row.get("documentary_role") == "LITERAL_EXAMPLE":
            if (
                not index
                or not _literal_pair(rows[index - 1], row)
                or roles[-1] != "EXAMPLE_INTRODUCTION"
            ):
                raise ValueError(
                    "Literal example has no licensed complete introduction"
                )
            roles.append("INERT_LITERAL_EXAMPLE")
        else:
            raise ValueError("Unlicensed whole-original HTML context")
    return roles


def _literal_pair(intro, literal):
    first, second = _structure(intro), _structure(literal)
    return (
        first["tag_path"][-1] == "p"
        and second["tag_path"][-1] == "pre"
        and first["direct_child_count"] == second["direct_child_count"] == 0
        and first["element_path"][:-1] == second["element_path"][:-1]
        and second["previous_sibling_path"] == first["element_path"]
        and second["direct_child_ordinal"] == first["direct_child_ordinal"] + 1
        and second["gap_before_whitespace_only"] is True
        and literal.get("documentary_role") == "LITERAL_EXAMPLE"
        and literal.get("quotation") is False
        and literal.get("documentary_math_presence") is False
    )


def _span(value, length):
    if (
        type(value) is not list
        or len(value) != length
        or any(type(part) is not int or part < 0 for part in value)
        or any(left >= right for left, right in pairwise(value))
    ):
        raise ValueError("Exact ordered original byte span required")
    return value


def _ast_roles(rows, groups, target_key):
    anchor = groups[target_key][1]
    declarations = anchor.get("documentary_enclosing_java_declarations")
    bindings = anchor.get("documentary_enclosing_java_original_bindings")
    package = anchor.get("documentary_java_package_signature")
    if (
        type(declarations) is not list
        or type(bindings) is not list
        or not 1 <= len(declarations) == len(bindings) <= 32
        or type(package) is not str
        or len(package) > 2048
        or (package and _PACKAGE.fullmatch(package) is None)
    ):
        raise ValueError("Complete plain bounded AST ancestor inventory required")
    ancestors, found_comments = {}, set()
    previous = None
    for declaration, binding in zip(declarations, bindings, strict=True):
        if (
            type(declaration) is not dict
            or set(declaration) != {"symbol", "signature"}
            or type(binding) is not dict
            or set(binding)
            != {
                "symbol",
                "declaration_start_byte",
                "declaration_header_end_byte",
                "declaration_end_byte",
                "documentation_span",
            }
            or type(declaration["symbol"]) is not str
            or binding["symbol"] != declaration["symbol"]
            or declaration["symbol"] in ancestors
            or not _plain_declaration(declaration["signature"], declaration["symbol"])
        ):
            raise ValueError("Exact plain containing declaration required")
        span = _span(
            [
                binding[name]
                for name in (
                    "declaration_start_byte",
                    "declaration_header_end_byte",
                    "declaration_end_byte",
                )
            ],
            3,
        )
        if previous is not None and not previous[1] <= span[0] < span[2] <= previous[2]:
            raise ValueError("AST containing declarations do not nest")
        if binding["documentation_span"] is not None:
            comment = _span(binding["documentation_span"], 2)
            if comment[1] > span[0]:
                raise ValueError("Containing documentation overlaps declaration")
        ancestors[declaration["symbol"]] = (declaration, binding, span)
        previous = span
    owner = declarations[-1]["symbol"]
    if anchor.get("symbol", "").rsplit(".", 1)[0] != owner:
        raise ValueError("Actual target containing owner required")
    roles = []
    expected_documentation = [
        {
            "symbol": declaration["symbol"],
            "comment_start_byte": binding["documentation_span"][0],
            "comment_end_byte": binding["documentation_span"][1],
        }
        for declaration, binding in zip(declarations, bindings, strict=True)
        if binding["documentation_span"] is not None
    ]
    for row in rows:
        if (
            not _safe_prose(row)
            or row.get("documentary_java_package_signature") != package
            or row.get("documentary_context_basis")
            != {
                "kind": "JAVA_AST_DOCUMENTATION",
                "declaration_kind": row.get("declaration_kind"),
            }
        ):
            raise ValueError("Whole plain same-package AST documentation required")
        original = row.get("documentary_java_original_binding")
        if (
            type(original) is not dict
            or set(original)
            != {
                "schema_version",
                "coordinate_basis",
                "comment_span",
                "declaration_span",
            }
            or type(original["schema_version"]) is not int
            or original["schema_version"] != 1
            or original["coordinate_basis"] != "ORIGINAL_UTF8_BYTES"
        ):
            raise ValueError("Actual complete AST original binding required")
        comment = _span(original["comment_span"], 2)
        span = _span(original["declaration_span"], 3)
        if comment[1] > span[0]:
            raise ValueError("AST comment overlaps its declaration")
        symbol = row.get("symbol")
        key = tuple(row.get(field) for field in _OWNER)
        if key in groups:
            if (
                symbol.rsplit(".", 1)[0] != owner
                or row.get("documentary_enclosing_java_declarations") != declarations
                or row.get("documentary_enclosing_java_original_bindings") != bindings
                or row.get("documentary_enclosing_java_documentation")
                != expected_documentation
                or not previous[1] <= comment[0] < span[2] <= previous[2]
                or any(
                    member.get("documentary_java_original_binding") != original
                    for member in groups[key][2]
                )
            ):
                raise ValueError("Complete same-owner member original binding required")
            roles.append("MEMBER_CONTEXT" if key == target_key else "OTHER_CALLABLE")
        elif symbol in ancestors:
            declaration, binding, parent_span = ancestors[symbol]
            ancestor_index = next(
                index
                for index, item in enumerate(declarations)
                if item["symbol"] == symbol
            )
            parent_documentation = [
                {
                    "symbol": item["symbol"],
                    "comment_start_byte": parent["documentation_span"][0],
                    "comment_end_byte": parent["documentation_span"][1],
                }
                for item, parent in zip(
                    declarations[:ancestor_index],
                    bindings[:ancestor_index],
                    strict=True,
                )
                if parent["documentation_span"] is not None
            ]
            if (
                row.get("signature") != declaration["signature"]
                or span != parent_span
                or comment != binding["documentation_span"]
                or row.get("documentary_enclosing_java_declarations")
                != declarations[:ancestor_index]
                or row.get("documentary_enclosing_java_original_bindings")
                != bindings[:ancestor_index]
                or row.get("documentary_enclosing_java_documentation")
                != parent_documentation
                or not classify_api_informational(row["text"])
            ):
                raise ValueError("Whole original-bound informational ancestor required")
            found_comments.add(symbol)
            roles.append("INFORMATIONAL_PURPOSE")
        else:
            raise ValueError("Unknown AST owner cannot be excluded")
    if found_comments != {
        symbol
        for symbol, (_, binding, _) in ancestors.items()
        if binding["documentation_span"] is not None
    }:
        raise ValueError("Containing original documentation is missing")
    return roles


def derive_api_context_policy(context_id, payloads, target_content):
    """Reconstruct one complete body; caller inputs still carry no authority."""
    if (
        type(payloads) is not tuple
        or not payloads
        or any(type(row) is not dict for row in payloads)
    ):
        raise ValueError("Complete ordered original payload tuple required")
    if len(payloads) > MAX_CONTEXT_NODES:
        raise ResourceLimitError("API context node ceiling exceeded")
    if (
        sum(len(canonical_json(row).encode("utf-8")) for row in payloads)
        > MAX_CONTEXT_BYTES
    ):
        raise ResourceLimitError("API context aggregate ceiling exceeded")
    source = {field: payloads[0].get(field) for field in _ORIGIN}
    if any(
        {field: row.get(field) for field in _ORIGIN} != source
        or type(row.get("block")) is not int
        or row["block"] != ordinal
        for ordinal, row in enumerate(payloads, 1)
    ):
        raise ValueError("Complete same-original block order required")
    grouped = {}
    for row in payloads:
        if row.get("signature") and row.get("declaration_kind") not in {
            "class_declaration",
            "interface_declaration",
            "enum_declaration",
            "record_declaration",
        }:
            grouped.setdefault(tuple(row.get(field) for field in _OWNER), []).append(
                row
            )
    groups = {key: (*_member(rows), rows) for key, rows in grouped.items()}
    targets = [
        key for key, (build, _, _) in groups.items() if build.content == target_content
    ]
    if len(targets) != 1:
        raise ValueError("One exactly rebuilt typed target required")
    target_key = targets[0]
    build, anchor, member_rows = groups[target_key]
    if source["format"] == "static-html":
        roles = _html_roles(payloads, groups, target_key)
    elif source["format"] == "java-documentation-ast":
        roles = _ast_roles(payloads, groups, target_key)
    else:
        raise ValueError("Unsupported complete original API format")
    bodies = [
        {
            "original_context_id": context_id,
            "block": row["block"],
            "source_payload_hash": content_hash(row),
        }
        for row in payloads
    ]
    nodes = [
        {"node_id": content_hash(body), "source_payload": row}
        for body, row in zip(bodies, payloads, strict=True)
    ]
    body = {
        "schema_version": 1,
        "policy_kind": DOCUMENTARY_API_CONTEXT_POLICY_V1,
        "context_id": context_id,
        "source_identity": source,
        "target": {
            **{field: anchor.get(field) for field in _OWNER},
            "signature_language": "java",
            "parameters": [list(pair) for pair in build.content.parameters],
            "content_fingerprint": documentary_scenario_fingerprint(build.content),
        },
        "inventory_hash": content_hash(bodies),
        "scope_observations": scope_observations(nodes, member_rows),
        "licenses": [
            {
                "node_id": node["node_id"],
                "source_payload_hash": node_body["source_payload_hash"],
                "role": role,
            }
            for node, node_body, role in zip(nodes, bodies, roles, strict=True)
        ],
        "scope": API_CONTEXT_SCOPE,
    }
    return parse_api_context_policy(canonical_json(body))
