"""Relative candidate reconstruction; authentic source replay is a later gate."""

from dataclasses import asdict

from ai_brain.stage2.facts.canonical import canonical_json, content_hash
from ai_brain.stage3.acquisition.documentary_api_context import (
    DOCUMENTARY_API_CONTEXT_POLICY_V1,
    parse_api_context_policy,
)
from ai_brain.stage3.acquisition.documentary_api_licensing import (
    derive_api_context_policy,
)
from ai_brain.stage3.acquisition.source_review_metadata import source_review_inventory
from ai_brain.stage3.knowledge_ir.records import (
    ClaimSchemaContent,
    EpistemicCharacter,
    InterpretationContent,
    KnowledgeKind,
)


def reserved_api_policy(content):
    """Unknown reserved versions cannot escape as actor-attributed prose."""
    return isinstance(content, InterpretationContent) and (
        (
            type(content.perspective) is str
            and content.perspective.startswith("DOCUMENTARY_API_CONTEXT_POLICY")
        )
        or (
            type(content.claim_text) is str
            and '"policy_kind"' in content.claim_text
            and '"DOCUMENTARY_API_CONTEXT_POLICY' in content.claim_text
        )
    )


def validate_api_policy_candidate(proposal, support):
    content = proposal.proposed_content
    if (
        type(content) is not InterpretationContent
        or content.perspective != DOCUMENTARY_API_CONTEXT_POLICY_V1
        or type(content.supported_record_ids) is not tuple
        or len(content.supported_record_ids) != 1
        or type(content.supported_record_ids[0]) is not str
        or not content.supported_record_ids[0]
        or type(content.contrast_record_ids) is not tuple
        or content.contrast_record_ids != ()
        or proposal.proposed_kind is not KnowledgeKind.INTERPRETATION
        or proposal.proposed_epistemic_character is not EpistemicCharacter.INTERPRETIVE
        or type(proposal.proposed_capabilities) is not tuple
        or proposal.proposed_capabilities != ()
        or type(proposal.proposed_applicability) is not tuple
        or proposal.proposed_applicability != ()
        or type(proposal.proposed_dependencies) is not tuple
        or type(proposal.segment_ids) is not tuple
    ):
        raise ValueError("Exact reviewed typed API policy candidate required")
    inventory = source_review_inventory(support)
    body = parse_api_context_policy(content.claim_text)
    target_id = content.supported_record_ids[0]
    target = support.get(target_id)
    if (
        target is None
        or target.proposal_id != target_id
        or target.source_bundle_id != proposal.source_bundle_id
        or type(target.proposed_content) is not ClaimSchemaContent
        or target.proposed_epistemic_character is not EpistemicCharacter.INTERPRETIVE
    ):
        raise ValueError("Actual typed source-bound target required")
    matching = [
        (context, rows)
        for context, rows in inventory
        if context["context_id"] == body["context_id"]
    ]
    if len(matching) != 1:
        raise ValueError(
            "Policy original context differs from complete review inventory"
        )
    context, rows = matching[0]
    if not rows or any(
        item.source_bundle_id != proposal.source_bundle_id for item, _ in rows
    ):
        raise ValueError("Policy original source bundle differs")
    expected = derive_api_context_policy(
        context["context_id"], tuple(row for _, row in rows), target.proposed_content
    )
    if canonical_json(expected) != content.claim_text:
        raise ValueError("Policy differs from whole captured original reconstruction")
    expected_segments = tuple(
        segment for item, _ in rows for segment in item.segment_ids
    )
    expected_dependencies = (
        rows[0][0].proposal_id,
        target_id,
        *(item.proposal_id for item, _ in rows[1:]),
    )
    if (
        proposal.segment_ids != expected_segments
        or proposal.proposed_dependencies != expected_dependencies
    ):
        raise ValueError(
            "Policy requires complete ordered original source dependency union"
        )
    member_segments = tuple(
        segment
        for (item, _), role in zip(rows, expected["licenses"], strict=True)
        if role["role"] == "MEMBER_CONTEXT"
        for segment in item.segment_ids
    )
    if target.segment_ids != member_segments:
        raise ValueError("Typed target member source lineage differs")
    for item in (proposal, target):
        serialized = asdict(item)
        digest = serialized.pop("proposal_hash")
        if digest != content_hash(serialized):
            raise ValueError("API candidate proposal hash differs")


def propose_api_context_policies(extraction):
    """Only review candidates. No automatic approval or source selection."""
    try:
        inventory = source_review_inventory(extraction.proposals_by_id)
    except ValueError:
        # Optional metadata cannot narrow legacy preparation's original limits.
        return
    targets = tuple(
        item
        for item in extraction.proposals
        if type(item.proposed_content) is ClaimSchemaContent
    )
    extraction.current_context = ()
    for target in targets:
        for context, rows in inventory:
            if not rows or context["format"] not in {
                "static-html",
                "java-documentation-ast",
            }:
                continue
            source_ids = {item.proposal_id for item, _ in rows}
            if not source_ids.intersection(target.proposed_dependencies):
                continue
            try:
                body = derive_api_context_policy(
                    context["context_id"],
                    tuple(row for _, row in rows),
                    target.proposed_content,
                )
            except ValueError:
                extraction.question("complete_api_context_not_licensed", rows[0][0])
                continue
            extraction.add(
                InterpretationContent(
                    canonical_json(body),
                    DOCUMENTARY_API_CONTEXT_POLICY_V1,
                    (target.proposal_id,),
                ),
                KnowledgeKind.INTERPRETATION,
                EpistemicCharacter.INTERPRETIVE,
                rows[0][0],
                dependencies=(target.proposal_id,),
                context=tuple(item for item, _ in rows[1:]),
            )
