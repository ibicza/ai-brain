"""Exact, replayable review and installation of bounded semantic candidates."""

from __future__ import annotations

from dataclasses import asdict

from ai_brain.stage2.education.models import ActorIdentityType
from ai_brain.stage2.facts.canonical import canonical_json, content_hash
from ai_brain.stage3.acquisition.direct_material import (
    _prepare_from_snapshots,
    prepare_direct_material,
)
from ai_brain.stage3.acquisition.material_installation import (
    _compile_reviewed_selection,
)
from ai_brain.stage3.acquisition.persistence import AcquisitionStore
from ai_brain.stage3.acquisition.semantic_extraction import (
    extract_semantic_proposals,
    semantic_profile,
    validate_candidate,
)

SEMANTIC_REVIEW_ROLE = "M33_SOURCE_SEMANTIC_REVIEW_V1"


def prepare_semantic_material(paths, **options):
    """Reading is not approval. The same ordinary-source reader is reused."""
    direct = prepare_direct_material(paths, **options)
    store = AcquisitionStore(options["store_root"])
    return _semantic_review(direct, store)


def _semantic_review(direct, store):
    bundle = store.load_bundle(direct["bundle_object"])
    segments = store.load_segments(direct["segments_object"])
    original = store.load_proposals(direct["proposals_object"])
    proposals, questions = extract_semantic_proposals(
        original, segments, bundle.created_at
    )
    proposal_object = store.save_proposals(direct["segments_object"], proposals)
    body = {
        "schema_version": 1,
        "contract_role": SEMANTIC_REVIEW_ROLE,
        "scope": "BOUNDED_SOURCE_ASSERTIONS_NOT_UNIVERSAL_UNDERSTANDING",
        "domain_id": direct["domain_id"],
        "pack_version": direct["pack_version"],
        "semantic_profile": semantic_profile(),
        "documentary_review": direct,
        "proposals_object": proposal_object,
        "proposals": [asdict(proposal) for proposal in proposals],
        "review_questions": questions,
        "installed": False,
    }
    return {**body, "review_hash": content_hash(body)}


def install_semantic_material(
    review,
    *,
    expected_review_hash,
    approved_proposal_ids,
    reviewer_identity,
    store_root,
    pack_output,
    registry,
    reviewer_type=ActorIdentityType.USER,
    timestamp=None,
):
    if (
        type(review) is not dict
        or review.get("contract_role") != SEMANTIC_REVIEW_ROLE
        or type(review.get("schema_version")) is not int
        or review["schema_version"] != 1
        or review.get("installed") is not False
        or review.get("review_hash") != expected_review_hash
        or content_hash({k: v for k, v in review.items() if k != "review_hash"})
        != expected_review_hash
        or review.get("semantic_profile") != semantic_profile()
    ):
        raise ValueError("semantic review hash/profile changed; prepare a fresh review")
    if (
        type(reviewer_identity) is not str
        or not reviewer_identity.strip()
        or reviewer_type
        not in {ActorIdentityType.USER, ActorIdentityType.TRUSTED_PROCESS}
        or type(approved_proposal_ids) is not tuple
        or not approved_proposal_ids
        or any(type(item) is not str for item in approved_proposal_ids)
        or len(set(approved_proposal_ids)) != len(approved_proposal_ids)
    ):
        raise ValueError(
            "explicit reviewer and unique nonempty semantic selection required"
        )
    if not store_root.is_dir():
        raise FileNotFoundError("source snapshot store is missing")
    if registry.capability_registry is None or registry.provider_registry is None:
        raise ValueError("current capability and provider authority required")
    store = AcquisitionStore(store_root)
    store.verify()
    direct = review["documentary_review"]
    bundle = store.load_bundle(direct["bundle_object"])
    replayed_direct = _prepare_from_snapshots(
        direct["raw_sources"],
        direct["domain_id"],
        direct["pack_version"],
        store,
        bundle.created_at,
    )
    rebuilt = _semantic_review(replayed_direct, store)
    if canonical_json(rebuilt) != canonical_json(review):
        raise ValueError("semantic review differs from original source replay")
    proposals = store.load_proposals(review["proposals_object"])
    by_id = {proposal.proposal_id: proposal for proposal in proposals}
    if not set(approved_proposal_ids) <= set(by_id):
        raise ValueError("unknown semantic selection")
    # A selection must explicitly include its evidence and semantic dependencies.
    # Never silently approve additional candidates to make the compiler succeed.
    selected_ids = set(approved_proposal_ids)
    if any(
        not set(by_id[item].proposed_dependencies) <= selected_ids
        for item in selected_ids
    ):
        raise ValueError(
            "semantic selection lacks explicitly approved dependency closure"
        )
    selected = tuple(by_id[item] for item in approved_proposal_ids)
    selected_by_id = {item.proposal_id: item for item in selected}
    from ai_brain.stage3.acquisition.documentary_api_policy import reserved_api_policy

    for proposal in selected:
        validate_candidate(
            proposal,
            bundle.created_at,
            # Review metadata from the complete freshly replayed map is not
            # approval of its carrier or any omitted evidence dependency.
            supporting_proposals=(
                by_id
                if reserved_api_policy(proposal.proposed_content)
                else selected_by_id
            ),
        )
    from ai_brain.stage3.acquisition.documentary_replay import build_documentary_closure

    closure = build_documentary_closure(direct["raw_sources"], store)
    return _compile_reviewed_selection(
        bundle,
        store.load_segments(direct["segments_object"]),
        selected,
        expected_review_hash=expected_review_hash,
        reviewer_identity=reviewer_identity,
        reviewer_type=reviewer_type,
        pack_output=pack_output,
        pack_version=review["pack_version"],
        registry=registry,
        store=store,
        timestamp=timestamp,
        documentary_closure=closure,
    )
