"""Prospective v2 literal clause witnesses, not discourse or world inference.

The v1 acceptance contract is unchanged. This pure component is not yet an
extraction/install/runtime route. It neither resolves referents nor converts
voice, tense, arguments, or noun phrases into equivalent propositions.
"""

from __future__ import annotations

import re
from dataclasses import dataclass

from ai_brain.stage3.acquisition import documentary_logic as v1

SURFACE_SCHEMA_VERSION = 2
MAX_NOUN_PART_WORDS = 6
MAX_NOUN_WORDS = 12
ARTICLES = frozenset({"a", "an", "the"})
ARGUMENT_PREPOSITIONS = frozenset({"in", "within", "to", "from"})
PASSIVE_PARTICIPLES = frozenset(
    {"stored", "transferred", "released", "absorbed", "collected", "converted"}
)
STATE_WORDS = frozenset(
    {
        "active",
        "inactive",
        "sealed",
        "open",
        "closed",
        "visible",
        "ready",
        "blue",
        "bright",
        "full",
        "empty",
        "present",
        "absent",
        "stable",
        "unstable",
        "high",
        "low",
        "warm",
        "cold",
        # Literal source state only: never inferred from a numerical threshold.
        "saturated",
    }
)
_TOKEN = re.compile(r"[A-Za-z][A-Za-z0-9]*(?:-[A-Za-z0-9]+)*")
_COPULAS = frozenset({"is", "are", "was", "were"})
_AUXILIARIES = frozenset({"will", "do", "does", "did"})
_REPORTING_WORDS = frozenset(
    {
        "claim",
        "claims",
        "claimed",
        "report",
        "reports",
        "reported",
        "say",
        "says",
        "said",
        "believe",
        "believes",
        "believed",
    }
)
_FINITE_WORDS = (
    frozenset(v1._ACTION_BASE)
    | _COPULAS
    | _AUXILIARIES
    | {
        "has",
        "have",
        "becomes",
        "become",
        "remains",
        "remain",
        "occurs",
        "exists",
        "holds",
        "fails",
    }
)


@dataclass(frozen=True)
class SurfaceSpan:
    role: str
    start: int
    end: int


@dataclass(frozen=True)
class LiteralClause:
    """A complete surface parse; spans address exact original character text."""

    text: str
    identity: str
    polarity: str
    form: str
    spans: tuple[SurfaceSpan, ...]
    schema_version: int = SURFACE_SCHEMA_VERSION


def _noun_part(words: list[str]) -> bool:
    if not words:
        return False
    has_article = words[0] in ARTICLES
    content = words[1:] if has_article else words
    if not 1 <= len(content) <= MAX_NOUN_PART_WORDS:
        return False
    # An explicit article+head permits old action-as-noun surfaces, but never
    # an embedded finite predicate: 'the release', not 'the box release cargo'.
    for index, word in enumerate(content):
        # Conservative spelling exclusion, not a POS classifier: e.g. 'family'
        # also refuses here. Unknown nominal/verb homographs still require an
        # independent complete-source meaning audit before inference authority.
        if (
            word in ARTICLES
            or word in v1._PHRASE_RESERVED
            or word in _REPORTING_WORDS
            or word.endswith("ly")
        ):
            return False
        if word in _FINITE_WORDS and not (
            has_article and index == len(content) - 1 and word in v1._ACTION_FORMS
        ):
            return False
    return True


def _noun(words: list[str]) -> bool:
    if not words or len(words) > MAX_NOUN_WORDS or words.count("of") > 1:
        return False
    if "of" not in words:
        return _noun_part(words)
    index = words.index("of")
    return _noun_part(words[:index]) and _noun_part(words[index + 1 :])


def parse_literal_clause_v2(text: str) -> LiteralClause | None:
    """Consume one finite English clause or refuse; no partial-prefix parse.

    NP = article? W{1..6} (of article? W{1..6})?, at most12 total words.
    Actions retain v1 spellings and literal auxiliaries. A single terminal
    in/within/to/from argument is permitted; 'by' only after a closed passive.
    Copular state words and passive participles are explicit finite tables.
    Every modality, reference, instruction and parent guard remains external
    authority-free and unsupported, not removed to make a sentence parse.
    """
    if (
        not v1._safe_string(text, v1.MAX_ATOM_CHARS)
        or v1._FORBIDDEN.search(text)
        or v1._PRONOUN.search(text)
        or v1._CONJUNCTION.search(text)
        or v1.contains_passive_report(text)
        or v1._qualified_parent(text)
    ):
        return None
    tokens = tuple(_TOKEN.finditer(text))
    if not tokens:
        return None
    position = 0
    for token in tokens:
        if text[position : token.start()].strip():
            return None
        position = token.end()
    if text[position:].strip():
        return None
    words = [token[0].casefold() for token in tokens]
    parses: list[tuple[str, tuple[tuple[str, int, int], ...]]] = []

    def argument(start: int, *, agent: bool = False):
        allowed = ARGUMENT_PREPOSITIONS | ({"by"} if agent else set())
        positions = [i for i in range(start, len(words)) if words[i] in allowed]
        if not positions:
            return None, len(words)
        if len(positions) != 1:
            return False, len(words)
        index = positions[0]
        if not _noun(words[index + 1 :]):
            return False, index
        return ("argument", index, len(words)), index

    for verb in range(1, len(words)):
        if not _noun(words[:verb]):
            continue
        head = words[verb]
        tail = verb + 1
        negated = False
        if (
            head in _AUXILIARIES | _COPULAS
            and tail < len(words)
            and words[tail] == "not"
        ):
            negated = True
            tail += 1
        if tail >= len(words) and head not in v1._ACTION_BASE:
            continue
        predicate_end = tail
        action = head
        passive = False
        state = False
        if head in _AUXILIARIES:
            action = words[tail]
            predicate_end = tail + 1
            tail += 1
            if head == "will" and action == "be":
                if tail >= len(words):
                    continue
                action = words[tail]
                predicate_end = tail + 1
                tail += 1
                passive = action in PASSIVE_PARTICIPLES
                state = action in STATE_WORDS
            elif action not in v1._ACTION_FORMS:
                continue
        elif head in _COPULAS:
            action = words[tail]
            predicate_end = tail + 1
            tail += 1
            passive = action in PASSIVE_PARTICIPLES
            state = action in STATE_WORDS
        elif head not in v1._ACTION_BASE:
            continue

        spans = [("subject", 0, verb), ("predicate", verb, predicate_end)]
        if state:
            if tail != len(words):
                continue
            form = "STATE"
        elif passive:
            pp, end = argument(tail, agent=True)
            if pp is False or tail != end:
                continue
            if pp:
                spans.append(pp)
            form = "PASSIVE"
        else:
            if head in _COPULAS or (
                head == "will" and words[verb + 1 + negated] == "be"
            ):
                continue
            pp, end = argument(tail)
            if pp is False:
                continue
            base = v1._ACTION_BASE[action]
            if tail == end:
                if base not in v1._INTRANSITIVE_ACTIONS:
                    continue
            elif not _noun(words[tail:end]):
                continue
            else:
                spans.append(("object", tail, end))
            if pp:
                spans.append(pp)
            form = "ACTIVE"
        parses.append((form, tuple(spans)))

    if len(parses) != 1:
        return None
    form, spans = parses[0]
    return LiteralClause(
        text,
        v1.normalize_atom(text),
        v1._polarity(text),
        form,
        tuple(
            SurfaceSpan(role, tokens[start].start(), tokens[end - 1].end())
            for role, start, end in spans
        ),
    )
