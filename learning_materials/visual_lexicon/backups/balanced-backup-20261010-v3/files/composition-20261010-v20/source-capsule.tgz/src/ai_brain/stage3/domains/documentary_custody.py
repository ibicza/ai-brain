"""Portable documentary raw-byte custody; reader replay is supplemental authority.

Custody and exact reader rendering do not prove source meaning or execution authority.
Static path checks do not close concurrent Windows ancestor-replacement races.
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import stat
import threading
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import ClassVar

MANIFEST_NAME = "documentary_source_closure.json"
CONTAINER_NAME = "documentary_source_bytes.bin"
TOKEN_PREFIX = "documentary-source-closure-v1:sha256:"
CONTRACT_ROLE = "DOCUMENTARY_SOURCE_CUSTODY_PRODUCTION_V1"
SCOPE = "RAW_SOURCE_CUSTODY_AND_READER_REPLAY_NOT_INFERENCE_AUTHORITY"
IMPLEMENTATION_VERSION = 1
REQUIREMENT_NAMESPACE = "documentary-source-custody."
REQUIREMENT_MARKER = REQUIREMENT_NAMESPACE + "required-v1"
EMPTY_HASH = hashlib.sha256(b"").hexdigest()


class ResourceLimitError(Exception):
    """Valid custody request exceeds an explicit availability ceiling."""


_HASH = re.compile(r"[0-9a-f]{64}\Z")
_FORMATS = {
    "plain-document": (".txt", ".md", ".markdown", ".rst"),
    "static-html": (".html", ".htm"),
    "python-docstrings-ast": (".py",),
    "java-documentation-ast": (".java",),
    "c-style-documentation-lexical": (
        ".js",
        ".ts",
        ".c",
        ".h",
        ".cpp",
        ".hpp",
        ".cs",
        ".go",
        ".rs",
        ".kt",
    ),
    "pdf-text-layer": (".pdf",),
}
_DECODERS = (
    "utf-8",
    "utf-8-sig",
    "utf-16",
    "utf-16-le",
    "utf-16-be",
    "cp1251",
    "cp1252",
    "latin-1",
    "reader-specific",
)


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def canonical(value) -> bytes:
    try:
        return json.dumps(
            value,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
            allow_nan=False,
        ).encode("utf-8")
    except (TypeError, ValueError, UnicodeError) as exc:
        raise ValueError("noncanonical closure value") from exc


def _hash(value):
    if type(value) is not str or not _HASH.fullmatch(value):
        raise ValueError("invalid SHA256")


def _integer(value, minimum, maximum):
    if type(value) is not int or not minimum <= value <= maximum:
        raise ValueError("invalid bounded integer")


def _keys(value, keys):
    if type(value) is not dict or set(value) != set(keys):
        raise ValueError("unknown/missing closure keys")


@dataclass(frozen=True)
class Limits:
    container_bytes: int = 64 * 1024 * 1024
    context_work_bytes: int = 64 * 1024 * 1024
    contexts: int = 64
    manifest_bytes: int = 256 * 1024
    io_chunk_bytes: int = 1024 * 1024
    query_raw_io_bytes: int = 256 * 1024 * 1024
    query_metadata_io_bytes: int = 4 * 1024 * 1024
    query_raw_hash_bytes: int = 256 * 1024 * 1024
    query_canonical_hash_bytes: int = 16 * 1024 * 1024
    query_output_bytes: int = 32 * 1024 * 1024
    payload_bytes: int = 512 * 1024 * 1024
    replay_output_bytes: int = 32 * 1024 * 1024

    def __post_init__(self):
        maxima = (
            67108864,
            67108864,
            64,
            262144,
            1048576,
            268435456,
            4194304,
            268435456,
            16777216,
            33554432,
            536870912,
            33554432,
        )
        for value, maximum in zip(asdict(self).values(), maxima, strict=True):
            _size(value, 1, maximum)

    @property
    def profile(self):
        return digest(canonical(_policy(self)))


def _size(value, minimum, maximum):
    if type(value) is not int or value < minimum:
        raise ValueError("invalid resource quantity")
    if value > maximum:
        raise ResourceLimitError("resource ceiling exceeded")


def _policy(limits):
    return {
        "production_version": IMPLEMENTATION_VERSION,
        "format_version": 1,
        "contract_role": CONTRACT_ROLE,
        "limits": asdict(limits),
        "formats": _FORMATS,
        "decoders": _DECODERS,
        "states": ("DERIVED_DOCUMENT", "NO_DOCUMENT_BLOCKS", "UNSUPPORTED_EMPTY_INPUT"),
    }


DEFAULT_LIMITS = Limits()


@dataclass(frozen=True)
class InputContext:
    raw: bytes
    original_name: str
    format: str
    decoder: str
    reader_profile: str
    block_count: int
    view_hash: str
    processing_state: str = "DERIVED_DOCUMENT"
    source_url: str | None = None


@dataclass(frozen=True)
class BuiltClosure:
    manifest_bytes: bytes
    container: bytes
    token: str
    inventory_hash: str


@dataclass(frozen=True)
class Slice:
    raw_hash: str
    byte_start: int
    byte_end: int


@dataclass(frozen=True)
class Context:
    context_id: str
    inventory_index: int
    original_name: str
    format: str
    decoder: str
    reader_profile: str
    raw_hash: str
    block_count: int
    view_hash: str
    source_url: str | None
    processing_state: str


@dataclass(frozen=True)
class Descriptor:
    manifest_hash: str
    container_hash: str
    container_bytes: int
    inventory_hash: str
    sources: tuple[Slice, ...]
    contexts: tuple[Context, ...]
    implementation_profile: str
    scope: str = SCOPE


@dataclass(frozen=True)
class ContextBytes:
    context: Context
    raw: bytes
    scope: str = SCOPE
    inference_authority: bool = False


class QueryBudget:
    """One trusted request ledger; reservations are cumulative and never refunded.

    Counters equal planned actual bytes on success, and conservatively retain
    all reserved work on failure. No process peak-RAM or CPU guarantee.
    """

    __slots__ = ("_limits", "_lock", "_used")
    _FIELDS: ClassVar = {
        "raw_io": "query_raw_io_bytes",
        "metadata_io": "query_metadata_io_bytes",
        "raw_hash": "query_raw_hash_bytes",
        "canonical_hash": "query_canonical_hash_bytes",
        "context": "context_work_bytes",
        "output": "query_output_bytes",
        "payload": "payload_bytes",
        "replay_output": "replay_output_bytes",
    }

    def __init__(self, limits=DEFAULT_LIMITS):
        if type(limits) is not Limits:
            raise ValueError("exact budget policy required")
        self._limits = limits
        self._lock = threading.Lock()
        self._used = dict.fromkeys(self._FIELDS, 0)

    @property
    def limits(self):
        return self._limits

    @property
    def counts(self):
        with self._lock:
            return self._used.copy()

    def reserve(self, **counts):
        with self._lock:
            if set(counts) - set(self._FIELDS):
                raise ValueError("unknown reservation unit")
            for key, value in counts.items():
                if type(value) is not int or value < 0:
                    raise ValueError("invalid reservation quantity")
                used = self._used[key]
                if type(used) is not int or used < 0:
                    raise ValueError("corrupt request ledger")
            for key, value in counts.items():
                if self._used[key] + value > getattr(self._limits, self._FIELDS[key]):
                    raise ResourceLimitError("cumulative request ceiling exceeded")
            for key, value in counts.items():
                self._used[key] += value


def _budget(budget, limits):
    if (
        type(limits) is not Limits
        or type(budget) is not QueryBudget
        or budget.limits != limits
    ):
        raise ValueError("exact request budget/policy required")


def _canonical_size(value, depth=0):
    """Exact encoded length BEFORE constructing a full canonical byte buffer."""
    if depth > 16:
        raise ValueError("canonical value nesting")
    if value is None:
        return 4
    if type(value) is bool:
        return 4 if value else 5
    if type(value) is int:
        return len(str(value))
    if type(value) is str:
        size = 2
        for char in value:
            point = ord(char)
            if 0xD800 <= point <= 0xDFFF:
                raise ValueError("invalid Unicode")
            if char in '"\\\\':
                size += 2
            elif point < 32:
                size += 2 if char in "\b\f\n\r\t" else 6
            else:
                size += (
                    1
                    if point < 128
                    else 2
                    if point < 2048
                    else 3
                    if point < 65536
                    else 4
                )
        return size
    if type(value) in (tuple, list):
        return (
            2
            + max(0, len(value) - 1)
            + sum(_canonical_size(x, depth + 1) for x in value)
        )
    if type(value) is dict and all(type(k) is str for k in value):
        return (
            2
            + max(0, len(value) - 1)
            + sum(
                _canonical_size(k, depth + 1) + 1 + _canonical_size(v, depth + 1)
                for k, v in value.items()
            )
        )
    raise ValueError("unsupported canonical type")


def _encoded(value):
    result = canonical(value)
    if len(result) != _canonical_size(value):
        raise ValueError("canonical length implementation mismatch")
    return result


def expose_output(data, *, budget):
    """Bound and copy caller-supplied bytes; NOT a real renderer clamp."""
    if type(data) is not bytes or type(budget) is not QueryBudget:
        raise ValueError("exact output bytes/request budget required")
    budget.reserve(output=len(data), payload=len(data))
    return memoryview(data).tobytes()


def _profiles(profiles):
    if type(profiles) is not tuple or not profiles:
        raise ValueError("externally pinned reader profiles required")
    _size(len(profiles), 1, 64)
    for value in profiles:
        _hash(value)
    if len(set(profiles)) != len(profiles):
        raise ValueError("duplicate reader profiles")


def _context_shape(value, profiles):
    name = value["original_name"]
    if (
        type(name) is not str
        or not 1 <= len(name) <= 256
        or any(ord(c) < 32 for c in name)
    ):
        raise ValueError("invalid inert original name")
    if (
        name.startswith(("/", "\\"))
        or "\\" in name
        or ":" in name
        or any(part in {"", ".", ".."} for part in name.split("/"))
    ):
        raise ValueError("unsafe inert original name")
    _canonical_size(name)  # Reject invalid Unicode without allocating encoded bytes.
    format_name, decoder = value["format"], value["decoder"]
    if (
        type(format_name) is not str
        or format_name not in _FORMATS
        or Path(name).suffix.casefold() not in _FORMATS[format_name]
    ):
        raise ValueError("unsupported format/name context")
    if type(decoder) is not str or decoder not in _DECODERS:
        raise ValueError("unsupported decoder context")
    for key in ("raw_hash", "reader_profile", "view_hash"):
        _hash(value[key])
    if value["reader_profile"] not in profiles:
        raise ValueError("reader profile not pinned")
    _size(value["block_count"], 0, 8192)
    source_url = value["source_url"]
    if source_url is not None and (
        type(source_url) is not str
        or not 1 <= len(source_url) <= 4096
        or any(ord(char) < 32 for char in source_url)
    ):
        raise ValueError("invalid inert source URL")
    if source_url is not None:
        _canonical_size(source_url)
    state = value["processing_state"]
    if type(state) is not str:
        raise ValueError("invalid processing state")
    empty = value["raw_hash"] == EMPTY_HASH
    if empty:
        if state != "UNSUPPORTED_EMPTY_INPUT" or value["block_count"] != 0:
            raise ValueError("empty custody is not a successful reader document")
    elif state == "NO_DOCUMENT_BLOCKS":
        if value["block_count"] != 0:
            raise ValueError("zero-block processing state differs")
    elif state != "DERIVED_DOCUMENT" or value["block_count"] < 1:
        raise ValueError("unsupported processing state")


def build_closure(
    inputs, *, pinned_reader_profiles, limits=DEFAULT_LIMITS, budget=None
):
    """Supplied complete inventory only; no producer/reader acceptance claim."""
    _profiles(pinned_reader_profiles)
    if type(limits) is not Limits or type(inputs) is not tuple or not inputs:
        raise ValueError("invalid inventory/policy")
    _size(len(inputs), 1, limits.contexts)
    budget = QueryBudget(limits) if budget is None else budget
    _budget(budget, limits)
    blobs, contexts, names = {}, [], set()
    work = 0
    for index, item in enumerate(inputs):
        if type(item) is not InputContext or type(item.raw) is not bytes:
            raise ValueError("exact input context/bytes required")
        _size(len(item.raw), 0, limits.container_bytes)
        work += len(item.raw)
        _size(work, 0, limits.context_work_bytes)
        budget.reserve(raw_hash=len(item.raw))
        raw_hash = digest(item.raw)
        row = {key: value for key, value in asdict(item).items() if key != "raw"}
        row.update(raw_hash=raw_hash, inventory_index=index)
        _context_shape(row, pinned_reader_profiles)
        if row["original_name"].casefold() in names:
            raise ValueError("duplicate source name/context")
        names.add(row["original_name"].casefold())
        if raw_hash in blobs and blobs[raw_hash] != item.raw:
            raise ValueError("digest collision")
        blobs[raw_hash] = item.raw
        size = _canonical_size(row)
        budget.reserve(canonical_hash=size, payload=size)
        row["context_id"] = digest(_encoded(row))
        contexts.append(row)
    total = sum(len(raw) for raw in blobs.values())
    _size(total, 0, limits.container_bytes)
    budget.reserve(payload=total, raw_hash=total)
    sources, parts, offset = [], [], 0
    for raw_hash, raw in sorted(blobs.items()):
        sources.append(
            {"raw_hash": raw_hash, "byte_start": offset, "byte_end": offset + len(raw)}
        )
        parts.append(raw)
        offset += len(raw)
    container = b"".join(parts)
    policy = _policy(limits)
    policy_size = _canonical_size(policy)
    inventory_size = _canonical_size(contexts)
    budget.reserve(
        canonical_hash=policy_size + inventory_size,
        payload=policy_size + inventory_size,
    )
    profile_hash = digest(_encoded(policy))
    inventory_hash = digest(_encoded(contexts))
    body = {
        "schema_version": 1,
        "contract_role": CONTRACT_ROLE,
        "scope": SCOPE,
        "closure_profile": profile_hash,
        "implementation_profile": custody_profile(),
        "container_bytes": total,
        "container_hash": digest(container),
        "inventory_hash": inventory_hash,
        "sources": sources,
        "contexts": contexts,
    }
    body_size = _canonical_size(body)
    budget.reserve(canonical_hash=body_size, payload=body_size)
    manifest_hash = digest(_encoded(body))
    value = {**body, "manifest_hash": manifest_hash}
    manifest_size = _canonical_size(value) + 1
    _size(manifest_size, 1, limits.manifest_bytes)
    budget.reserve(payload=2 * manifest_size)
    manifest = _encoded(value) + b"\n"
    return BuiltClosure(
        manifest, container, TOKEN_PREFIX + manifest_hash, inventory_hash
    )


def binding_token(tokens, *, manifest_present, container_present):
    if (
        type(tokens) is not tuple
        or len(tokens) > 256
        or any(
            type(value) is not str or not value or len(value) > 256 for value in tokens
        )
    ):
        raise ValueError("invalid dependency tokens")
    if (
        type(manifest_present) is not bool
        or type(container_present) is not bool
        or len(set(tokens)) != len(tokens)
    ):
        raise ValueError("invalid/duplicate closure presence tokens")
    selected = [
        value for value in tokens if value.startswith("documentary-source-closure")
    ]
    if any(
        not value.startswith(TOKEN_PREFIX)
        or not _HASH.fullmatch(value[len(TOKEN_PREFIX) :])
        for value in selected
    ):
        raise ValueError("unknown/malformed closure token")
    if not manifest_present and not container_present and not selected:
        return None  # Legacy presence only; no verified-byte claim is returned.
    if not manifest_present or not container_present or len(selected) != 1:
        raise ValueError("closure requires exact artifact pair and token")
    return selected[0]


def _strict_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("duplicate JSON key")
        result[key] = value
    return result


def _reject_constant(_value):
    raise ValueError("nonfinite JSON value")


def parse_descriptor(
    manifest_bytes,
    tokens,
    *,
    pinned_reader_profiles,
    expected_inventory_hash,
    limits=DEFAULT_LIMITS,
    budget,
):
    _profiles(pinned_reader_profiles)
    _hash(expected_inventory_hash)
    _budget(budget, limits)
    if type(manifest_bytes) is not bytes:
        raise ValueError("exact metadata buffer required")
    _size(len(manifest_bytes), 1, limits.manifest_bytes)
    token = binding_token(tokens, manifest_present=True, container_present=True)
    # A conservative known decoded/canonical payload envelope, not JSON object RAM.
    budget.reserve(payload=4 * len(manifest_bytes))
    try:
        value = json.loads(
            manifest_bytes.decode("utf-8"),
            object_pairs_hook=_strict_object,
            parse_constant=_reject_constant,
        )
    except (UnicodeError, json.JSONDecodeError, RecursionError) as exc:
        raise ValueError("invalid closure JSON") from exc
    _keys(
        value,
        (
            "schema_version",
            "contract_role",
            "scope",
            "closure_profile",
            "implementation_profile",
            "container_bytes",
            "container_hash",
            "inventory_hash",
            "sources",
            "contexts",
            "manifest_hash",
        ),
    )
    if type(value["schema_version"]) is not int or value["schema_version"] != 1:
        raise ValueError("unsupported schema")
    if value["contract_role"] != CONTRACT_ROLE:
        raise ValueError("unsupported documentary custody contract")
    if type(value["scope"]) is not str or value["scope"] != SCOPE:
        raise ValueError("unsupported scope")
    for key in (
        "manifest_hash",
        "inventory_hash",
        "container_hash",
        "closure_profile",
        "implementation_profile",
    ):
        _hash(value[key])
    _size(value["container_bytes"], 0, limits.container_bytes)
    sources, contexts = value["sources"], value["contexts"]
    if (
        type(sources) is not list
        or not sources
        or type(contexts) is not list
        or not contexts
    ):
        raise ValueError("invalid source/context lists")
    _size(len(sources), 1, limits.contexts)
    _size(len(contexts), 1, limits.contexts)
    offset, prior_digest, slices = 0, "", []
    for row in sources:
        _keys(row, ("raw_hash", "byte_start", "byte_end"))
        _hash(row["raw_hash"])
        _integer(row["byte_start"], 0, value["container_bytes"])
        _integer(row["byte_end"], 0, value["container_bytes"])
        if row["raw_hash"] <= prior_digest or row["byte_start"] != offset:
            raise ValueError("source ordering/gap/overlap")
        if row["raw_hash"] == EMPTY_HASH:
            if row["byte_end"] != offset:
                raise ValueError("empty digest must have zero slice")
        elif row["byte_end"] <= offset:
            raise ValueError("nonempty digest requires nonempty slice")
        offset, prior_digest = row["byte_end"], row["raw_hash"]
        slices.append(Slice(**row))
    if offset != value["container_bytes"]:
        raise ValueError("container trailing/gap bytes")
    sizes = {source.raw_hash: source.byte_end - source.byte_start for source in slices}
    names, seen_sources, parsed_contexts, context_bodies, work = set(), set(), [], [], 0
    for index, row in enumerate(contexts):
        _keys(
            row,
            (
                "context_id",
                "inventory_index",
                "original_name",
                "format",
                "decoder",
                "reader_profile",
                "raw_hash",
                "block_count",
                "view_hash",
                "processing_state",
                "source_url",
            ),
        )
        _context_shape(row, pinned_reader_profiles)
        _hash(row["context_id"])
        _integer(row["inventory_index"], 0, limits.contexts - 1)
        if (
            row["inventory_index"] != index
            or row["raw_hash"] not in sizes
            or row["original_name"].casefold() in names
        ):
            raise ValueError("incomplete/ambiguous context inventory")
        work += sizes[row["raw_hash"]]
        _size(work, 0, limits.context_work_bytes)
        names.add(row["original_name"].casefold())
        seen_sources.add(row["raw_hash"])
        parsed_contexts.append(Context(**row))
        context_bodies.append(
            {key: item for key, item in row.items() if key != "context_id"}
        )
    if seen_sources != set(sizes):
        raise ValueError("unused source")
    body = {key: item for key, item in value.items() if key != "manifest_hash"}
    policy = _policy(limits)
    hashed_values = (policy, body, contexts, *context_bodies)
    hash_work = sum(_canonical_size(item) for item in hashed_values)
    canonical_value_size = _canonical_size(value)
    # Exact all-canonical-hash reservation BEFORE any canonical buffer/hash.
    budget.reserve(
        canonical_hash=hash_work, payload=hash_work + 2 * (canonical_value_size + 1)
    )
    policy_hash, body_hash, inventory_hash, *context_hashes = (
        digest(_encoded(item)) for item in hashed_values
    )
    if value["implementation_profile"] != custody_profile():
        raise ValueError("documentary custody implementation profile changed")
    if value["closure_profile"] != policy_hash:
        raise ValueError("unsupported closure profile")
    if (
        body_hash != value["manifest_hash"]
        or token != TOKEN_PREFIX + value["manifest_hash"]
        or manifest_bytes != _encoded(value) + b"\n"
    ):
        raise ValueError("metadata buffer/hash/token differs")
    if (
        inventory_hash != value["inventory_hash"]
        or inventory_hash != expected_inventory_hash
    ):
        raise ValueError("external complete inventory differs")
    if any(
        row["context_id"] != result
        for row, result in zip(contexts, context_hashes, strict=True)
    ):
        raise ValueError("context identity differs")
    return Descriptor(
        value["manifest_hash"],
        value["container_hash"],
        value["container_bytes"],
        value["inventory_hash"],
        tuple(slices),
        tuple(parsed_contexts),
        value["implementation_profile"],
    )


def verify_closure(
    manifest_bytes,
    container,
    tokens,
    *,
    pinned_reader_profiles,
    expected_inventory_hash,
    limits=DEFAULT_LIMITS,
    budget,
):
    descriptor = parse_descriptor(
        manifest_bytes,
        tokens,
        pinned_reader_profiles=pinned_reader_profiles,
        expected_inventory_hash=expected_inventory_hash,
        limits=limits,
        budget=budget,
    )
    if type(container) is not bytes or len(container) != descriptor.container_bytes:
        raise ValueError("exact immutable container length differs")
    # Full digest plus EVERY distinct slice: exactly 2*C on successful pass.
    budget.reserve(raw_hash=2 * len(container))
    if digest(container) != descriptor.container_hash:
        raise ValueError("container hash differs")
    view = memoryview(container)
    for source in descriptor.sources:
        if (
            hashlib.sha256(view[source.byte_start : source.byte_end]).hexdigest()
            != source.raw_hash
        ):
            raise ValueError("raw slice membership differs")
    return descriptor


def verified_context_bytes(
    manifest_bytes,
    container,
    tokens,
    context_id,
    *,
    pinned_reader_profiles,
    expected_inventory_hash,
    limits=DEFAULT_LIMITS,
    budget,
):
    _hash(context_id)
    _budget(budget, limits)
    descriptor = verify_closure(
        manifest_bytes,
        container,
        tokens,
        pinned_reader_profiles=pinned_reader_profiles,
        expected_inventory_hash=expected_inventory_hash,
        limits=limits,
        budget=budget,
    )
    context = next(
        (item for item in descriptor.contexts if item.context_id == context_id), None
    )
    if context is None:
        raise ValueError("unknown context identity")
    source = next(
        item for item in descriptor.sources if item.raw_hash == context.raw_hash
    )
    size = source.byte_end - source.byte_start
    budget.reserve(context=size, payload=size)
    raw = memoryview(container)[source.byte_start : source.byte_end].tobytes()
    return ContextBytes(context, raw)


def _not_reparse(info):
    if stat.S_ISLNK(info.st_mode) or getattr(info, "st_file_attributes", 0) & getattr(
        stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400
    ):
        raise ValueError("reparse/symlink path forbidden")


def _checked_directory(path):
    # Check before resolve so a junction/symlink cannot disappear from evidence.
    path = Path(os.path.abspath(path))
    for ancestor in reversed((path, *path.parents)):
        info = ancestor.lstat()
        _not_reparse(info)
        if not stat.S_ISDIR(info.st_mode):
            raise ValueError("directory ancestor is not a directory")
    return path


def _stamp(info):
    # Windows lstat/fstat can expose different historical ctime semantics.
    # Use the same explicit birth-time field when available, not that alias.
    created_or_changed = getattr(info, "st_birthtime_ns", info.st_ctime_ns)
    return (
        info.st_dev,
        info.st_ino,
        info.st_size,
        info.st_mtime_ns,
        created_or_changed,
    )


def _read_checked(path, expected, chunk):
    before = path.lstat()
    _not_reparse(before)
    if not stat.S_ISREG(before.st_mode) or before.st_size != expected:
        raise ValueError("file identity/size changed before open")
    flags = os.O_RDONLY | getattr(os, "O_BINARY", 0) | getattr(os, "O_NOFOLLOW", 0)
    fd = os.open(path, flags)
    try:
        opened = os.fstat(fd)
        _not_reparse(opened)
        if not stat.S_ISREG(opened.st_mode) or _stamp(opened) != _stamp(before):
            raise ValueError("file identity changed before read")
        parts, used = [], 0
        while used < expected:
            part = os.read(fd, min(chunk, expected - used))
            if not part:
                raise ValueError("file truncated during read")
            used += len(part)
            parts.append(part)
        after = os.fstat(fd)
    finally:
        os.close(fd)
    final = path.lstat()
    _not_reparse(final)
    if _stamp(before) != _stamp(after) or _stamp(before) != _stamp(final):
        raise ValueError("file changed during read")
    return b"".join(parts)


BASE_PACK_FILES = frozenset(
    {
        "manifest.json",
        "knowledge.jsonl",
        "concept_graph.json",
        "exercise_families.json",
        "capability_requirements.json",
        "adapter_bindings.json",
        "evaluation_manifest.json",
        "source_bindings.json",
        "pack_manifest.json",
    }
)
OPTIONAL_PACK_FILES = frozenset(
    {
        "approval.json",
        "java_evidence_closure.json",
        "java_production_closure.json",
        "alias_semantics.json",
        MANIFEST_NAME,
        CONTAINER_NAME,
    }
)
PACK_FILES = BASE_PACK_FILES | OPTIONAL_PACK_FILES


def read_regular_bytes(path, *, maximum, budget, io_category="raw_io"):
    """Bound one explicit regular path; static checks are not a path-race sandbox."""
    _budget(budget, budget.limits if type(budget) is QueryBudget else None)
    path = Path(path)
    _checked_directory(path.parent)
    info = path.lstat()
    _not_reparse(info)
    if not stat.S_ISREG(info.st_mode):
        raise ValueError("nonregular source blob")
    _size(info.st_size, 0, maximum)
    if io_category not in {"raw_io", "metadata_io"}:
        raise ValueError("unsupported IO category")
    budget.reserve(**{io_category: info.st_size, "payload": 2 * info.st_size})
    result = _read_checked(path, info.st_size, budget.limits.io_chunk_bytes)
    _checked_directory(path.parent)
    return result


def read_fixed_pair(
    root, *, workspace_root, limits=DEFAULT_LIMITS, budget, pack_mode=False
):
    """Checked held pair; allows only explicitly known flat pack entries in pack mode.

    Reserve stat lengths before reads/materialization; no unreserved EOF probe.
    Windows ancestor replacement TOCTOU remains OPEN.
    """
    _budget(budget, limits)
    if type(pack_mode) is not bool:
        raise ValueError("invalid pair mode")
    boundary, target = _checked_directory(workspace_root), _checked_directory(root)
    if not target.is_relative_to(boundary) or target == boundary:
        raise ValueError("directory outside explicit workspace")
    entries = []
    maximum_entries = len(PACK_FILES) if pack_mode else 2
    for entry in target.iterdir():
        entries.append(entry)
        if len(entries) > maximum_entries:
            raise ValueError("unexpected fixed pack entries")
        info = entry.lstat()
        _not_reparse(info)
        if not stat.S_ISREG(info.st_mode):
            raise ValueError("nonregular pack entry")
    names = {entry.name for entry in entries}
    if pack_mode:
        if not BASE_PACK_FILES <= names or names - PACK_FILES:
            raise ValueError("incomplete or unexpected pack entries")
    elif names != {MANIFEST_NAME, CONTAINER_NAME}:
        raise ValueError("exact fixed pair required")
    if not {MANIFEST_NAME, CONTAINER_NAME} <= names:
        raise ValueError("documentary custody pair missing")
    sizes = {}
    for name, minimum, maximum in (
        (MANIFEST_NAME, 1, limits.manifest_bytes),
        (CONTAINER_NAME, 0, limits.container_bytes),
    ):
        info = (target / name).lstat()
        _not_reparse(info)
        _size(info.st_size, minimum, maximum)
        sizes[name] = info.st_size
    metadata_size, raw_size = sizes[MANIFEST_NAME], sizes[CONTAINER_NAME]
    budget.reserve(
        metadata_io=metadata_size,
        raw_io=raw_size,
        payload=2 * (metadata_size + raw_size),
    )
    manifest = _read_checked(
        target / MANIFEST_NAME, metadata_size, limits.io_chunk_bytes
    )
    container = _read_checked(target / CONTAINER_NAME, raw_size, limits.io_chunk_bytes)
    _checked_directory(target)
    _checked_directory(boundary)
    return manifest, container


def custody_profile():
    """Actual trusted code/profile verification, distinct from documentary-byte budget.

    This does not authenticate source authors or turn reader rendering into raw
    verbatim spans. No source-selected paths or runtime network are involved.
    """
    from ai_brain.stage3.acquisition.document_readers import reader_profile

    stage3 = Path(__file__).parent.parent
    hooks = (
        "domains/documentary_custody.py",
        "domains/documentary_api_scenarios.py",
        "domains/javadoc_clause_view.py",
        "domains/knowledge_service.py",
        "domains/semantic_reasoning.py",
        "domains/documentary_conditionals_v2.py",
        "domains/documentary_context_inventory.py",
        "domains/documentary_api_context.py",
        "domains/documentary_api_policy.py",
        "acquisition/documentary_api_context.py",
        "acquisition/documentary_api_content.py",
        "acquisition/documentary_api_licensing.py",
        "acquisition/documentary_api_policy.py",
        "acquisition/source_review_metadata.py",
        "domains/pack.py",
        "acquisition/documentary_surface_logic.py",
        "acquisition/documentary_surface_payload.py",
        "acquisition/documentary_conditional_v2.py",
        "acquisition/documentary_conditional_context_v2.py",
        "acquisition/documentary_conditional_bridge_v2.py",
        "acquisition/documentary_reader_conditionals_v2.py",
        "acquisition/documentary_logic.py",
        "acquisition/documentary_clauses.py",
        "acquisition/documentary_replay.py",
        "domains/pack_io.py",
        "domains/request_verification.py",
        "domains/loader.py",
        "domains/registry.py",
        "acquisition/compiler.py",
        "acquisition/direct_material.py",
        "acquisition/semantic_material.py",
    )
    # Acquisition-only implementation dependencies are additionally byte-bound
    # by semantic_profile at preparation/review. This selected reader/runtime
    # profile is not a full-core freeze; an external black-box gate must bind
    # ALL core files separately, rather than reading arbitrary acquisition paths.
    return digest(
        canonical(
            {
                "contract_role": CONTRACT_ROLE,
                "production_version": IMPLEMENTATION_VERSION,
                "policy": DEFAULT_LIMITS.profile,
                "reader_profile": reader_profile(),
                "hooks": {name: digest((stage3 / name).read_bytes()) for name in hooks},
            }
        )
    )


def _captured_inventory_hash(metadata, budget):
    """Extract ONLY from the same held buffer; full validation follows before replay."""
    if type(metadata) is not bytes:
        raise ValueError("exact metadata buffer required")
    _size(len(metadata), 1, budget.limits.manifest_bytes)
    budget.reserve(payload=4 * len(metadata))
    try:
        value = json.loads(
            metadata.decode("utf-8"),
            object_pairs_hook=_strict_object,
            parse_constant=_reject_constant,
        )
    except (UnicodeError, json.JSONDecodeError, RecursionError) as exc:
        raise ValueError("invalid documentary custody JSON") from exc
    if type(value) is not dict:
        raise ValueError("invalid documentary custody descriptor")
    result = value.get("inventory_hash")
    _hash(result)
    return result


def verify_pack_custody(pack, *, budget=None, pack_files=None, retain_context=False):
    """Supplemental raw+fresh-reader admission, never semantic truth validation."""
    from types import MappingProxyType

    from ai_brain.stage3.acquisition.document_readers import reader_profile
    from ai_brain.stage3.domains.pack import DomainPack

    if type(retain_context) is not bool:
        raise ValueError("context retention must be an exact boolean")
    if type(pack) is not DomainPack or type(pack.evaluation_manifest) is not dict:
        raise ValueError("exact domain pack required")
    budget = QueryBudget() if budget is None else budget
    _budget(budget, budget.limits if type(budget) is QueryBudget else None)
    if "documentary_source_custody" in pack.evaluation_manifest:
        raise ValueError("unsupported evaluation custody field")
    tests = pack.evaluation_manifest.get("test_cases")
    if type(tests) is not list or any(type(test) is not str for test in tests):
        raise ValueError("exact evaluation test-case declarations required")
    declarations = [test for test in tests if test.startswith(REQUIREMENT_NAMESPACE)]
    if declarations and declarations != [REQUIREMENT_MARKER]:
        raise ValueError("unknown documentary custody requirement")
    marker_present = bool(declarations)
    if pack_files is not None:
        if type(pack_files) not in (dict, MappingProxyType):
            raise ValueError("exact captured pack mapping required")
        if len(pack_files) > len(PACK_FILES):
            raise ValueError("unexpected captured pack entries")
        if any(
            type(name) is not str or type(data) is not bytes
            for name, data in pack_files.items()
        ):
            raise ValueError("captured pack requires exact names/immutable bytes")
        names = set(pack_files)
        if not BASE_PACK_FILES <= names or names - PACK_FILES:
            raise ValueError("incomplete or unexpected captured pack entries")
    else:
        root = _checked_directory(Path(pack.root))
        names = set()
        for entry in root.iterdir():
            names.add(entry.name)
            if len(names) > len(PACK_FILES):
                raise ValueError("unexpected pack entries")
    token = binding_token(
        pack.manifest.dependency_packs,
        manifest_present=MANIFEST_NAME in names,
        container_present=CONTAINER_NAME in names,
    )
    if not marker_present:
        if token is not None:
            raise ValueError("custody files/token without explicit requirement")
        return (None, ()) if retain_context else None
    if token is None:
        raise ValueError("required documentary custody missing")
    if {"java_evidence_closure.json", "java_production_closure.json"} & names:
        raise ValueError("documentary custody cannot replace Java authority closure")
    if pack_files is None:
        metadata, container = read_fixed_pair(
            root,
            workspace_root=root.parent,
            limits=budget.limits,
            budget=budget,
            pack_mode=True,
        )
    else:
        metadata, container = pack_files[MANIFEST_NAME], pack_files[CONTAINER_NAME]
    inventory_hash = _captured_inventory_hash(metadata, budget)
    profile = reader_profile()
    descriptor = verify_closure(
        metadata,
        container,
        pack.manifest.dependency_packs,
        pinned_reader_profiles=(profile,),
        expected_inventory_hash=inventory_hash,
        limits=budget.limits,
        budget=budget,
    )
    from ai_brain.stage3.acquisition.documentary_replay import (
        replay_documentary_closure,
    )

    contexts = replay_documentary_closure(
        pack, descriptor, container, budget=budget, retain_context=retain_context
    )
    return (descriptor, contexts) if retain_context else descriptor
