"""Complete source-only API context, not optional policy or Java authority.

Only the installed loader's fresh same-buffer replay is consumed. Structural
IDs identify observed regions, not approved records or independently verified
semantic owners. No source IO, examples, code or URLs are executed here.
"""

from __future__ import annotations

from dataclasses import asdict

from ai_brain.stage2.facts.canonical import canonical_json, content_hash
from ai_brain.stage3.acquisition.documentary_api_context import (
    API_SCOPES,
    MAX_CONTEXT_BYTES,
    MAX_CONTEXT_NODES,
)
from ai_brain.stage3.domains.documentary_context_inventory import (
    UnsupportedDocumentaryContext,
    original_context_index,
)
from ai_brain.stage3.domains.documentary_custody import ResourceLimitError


def _region(context_id, payload, path):
    if path is None:
        return None
    return content_hash(
        {
            "original_context_id": context_id,
            "coordinate_basis": "HTML_PARSER_START_EVENTS_NOT_RAW_BYTES",
            "outer_original_binding": payload.get("documentary_java_original_binding"),
            "element_path": path,
        }
    )


def context_nodes(pack):
    """All originals, all rows, exact order; refuse rather than return a prefix."""
    if type(pack.documentary_context) is not tuple:
        raise UnsupportedDocumentaryContext("Exact fresh context tuple required")
    if any(
        type(row) is not tuple
        or len(row) != 2
        or any(type(value) is not str for value in row)
        for row in pack.documentary_context
    ):
        raise ValueError("Exact canonical context rows required")
    if len(pack.documentary_context) > MAX_CONTEXT_NODES:
        raise ResourceLimitError("API context node ceiling exceeded")
    size = sum(len(encoded.encode("utf-8")) for _, encoded in pack.documentary_context)
    if size > MAX_CONTEXT_BYTES:
        raise ResourceLimitError("API context aggregate ceiling exceeded")
    originals, _ = original_context_index(pack)
    nodes, bodies = [], []
    for context_id, payload in originals:
        for key in (
            "documentary_enclosing_java_declarations",
            "documentary_enclosing_java_original_bindings",
        ):
            ancestors = payload.get(key)
            if type(ancestors) is list and len(ancestors) > 32:
                raise ResourceLimitError("API structural ancestor ceiling exceeded")
        body = {
            "original_context_id": context_id,
            "block": payload["block"],
            "source_payload_hash": content_hash(payload),
        }
        node_id = content_hash(body)
        bodies.append(body)
        structure = payload.get("documentary_structure")
        parent_id = owner_id = None
        if type(structure) is dict:
            path = structure.get("element_path")
            for structural_path in (path, structure.get("callable_element_path")):
                if type(structural_path) is list and len(structural_path) > 32:
                    raise ResourceLimitError("API structural ancestor ceiling exceeded")
            if type(path) is list and path:
                parent_id = (
                    _region(context_id, payload, path[:-1]) if len(path) > 1 else None
                )
            owner_id = _region(
                context_id, payload, structure.get("callable_element_path")
            )
        elif type(payload.get("documentary_java_original_binding")) is dict:
            binding = payload["documentary_java_original_binding"]
            if binding.get("declaration_span") is not None:
                owner_id = content_hash(
                    {
                        "original_context_id": context_id,
                        "coordinate_basis": "ORIGINAL_UTF8_BYTES",
                        "declaration_span": binding["declaration_span"],
                    }
                )
        nodes.append(
            {
                "node_id": node_id,
                "original_context_id": context_id,
                "source_payload": payload,
                "parent_id": parent_id,
                "owner_id": owner_id,
                "source_only": True,
                "inference_authority": False,
                "assessed": False,
            }
        )
    return nodes, content_hash(bodies)


def scope_observations(nodes, target_payloads):
    """Presence witnesses only. Missing metadata never establishes absence."""
    observations = {
        name: {
            "artifact_status": "UNAVAILABLE_NOT_ABSENT",
            "witness_node_ids": [],
            "external_semantics": "UNAVAILABLE_NOT_ABSENT",
        }
        for name in API_SCOPES
    }
    target_origins = {
        canonical_json(
            {
                key: payload.get(key)
                for key in (
                    "file",
                    "original_bytes_hash",
                    "source_url",
                    "format",
                    "reader_profile",
                )
            }
        )
        for payload in target_payloads
    }
    target_rows = {canonical_json(payload) for payload in target_payloads}
    for node in nodes:
        payload = node["source_payload"]
        identity = canonical_json(
            {
                key: payload.get(key)
                for key in (
                    "file",
                    "original_bytes_hash",
                    "source_url",
                    "format",
                    "reader_profile",
                )
            }
        )
        if identity not in target_origins:
            continue
        slots = ["FILE"]
        if canonical_json(payload) in target_rows:
            slots.append("MEMBER")
        html = payload.get("documentary_html_class_structure")
        if (type(html) is dict and html.get("class_identities")) or payload.get(
            "documentary_enclosing_java_declarations"
        ):
            slots.append("CLASS")
        basis = payload.get("documentary_context_basis") or {}
        package = payload.get("documentary_java_package_signature")
        owner = basis.get("qualified_class") if type(basis) is dict else None
        if package or (
            type(owner) is str
            and "." in owner
            and " ".join(payload["text"].split())
            in {
                owner.rsplit(".", 1)[0],
                "Package " + owner.rsplit(".", 1)[0],
            }
        ):
            slots.append("PACKAGE")
        for slot in slots:
            observation = observations[slot]
            observation["artifact_status"] = "PRESENT_IN_THIS_SOURCE"
            observation["witness_node_ids"].append(node["node_id"])
    return observations


def describe_api_context(pack, reference, arguments):
    if (
        type(reference) is not str
        or not reference
        or type(arguments) is not dict
        or arguments
    ):
        return {"status": "INVALID_REQUEST"}
    from ai_brain.stage3.domains.semantic_reasoning import _source_payloads, _structured

    contract = _structured(pack, "contract", reference, None)
    if contract is None:
        return {"status": "INSUFFICIENT_EVIDENCE", "domain_id": pack.manifest.domain_id}
    if contract["status"] != "DOCUMENTED_CONTRACT":
        return contract
    identities = {
        item["knowledge_id"]
        for item in contract["evidence"]
        if item["kind"] == "CLAIM_SCHEMA"
    }
    selected = [
        record for record in pack.knowledge_records if record.knowledge_id in identities
    ]
    if len(selected) != 1:
        return {"status": "AMBIGUOUS_REFERENCE", "domain_id": pack.manifest.domain_id}
    try:
        nodes, inventory_hash = context_nodes(pack)
    except UnsupportedDocumentaryContext:
        return {
            "status": "NEEDS_NEW_CAPABILITY",
            "reason": "Fresh complete original context required",
        }
    payloads = _source_payloads(pack, selected[0])
    return {
        "status": "DOCUMENTED_API_CONTEXT",
        "domain_id": pack.manifest.domain_id,
        "pack_hash": pack.manifest.pack_content_hash,
        "target_record_id": selected[0].knowledge_id,
        "contexts": nodes,
        "inventory_hash": inventory_hash,
        "inventory_scope": "ALL_HELD_ORIGINALS_ALL_RENDERED_ROWS_IN_ORDER",
        "originals": [asdict(context) for context in pack.documentary_custody.contexts],
        "scope_observations": scope_observations(nodes, payloads),
        "source_only": True,
        "inference_authority": False,
        "assessed": False,
        "source_code_executed": False,
        "scope": "SOURCE_CONTEXT_DESCRIPTION_NOT_JAVA_BEHAVIOR",
    }
