"""Conservative documentary descriptions, deliberately not inference authority.

Preserve entire qualified assertions and local naming contexts. Neither pattern
resolves general anaphora, proves facts, or creates executable rules/relations.
"""

from __future__ import annotations

import re

QUALIFIED_DESCRIPTION = "DOCUMENTARY_QUALIFIED_DESCRIPTION_V1"
NAMING_CONTEXT = "DOCUMENTARY_NAMING_CONTEXT_V1"
DEFINITION_CONTEXT = "DOCUMENTARY_DEFINITION_CONTEXT_V1"
PARAGRAPH_CONTEXT = "DOCUMENTARY_PARAGRAPH_CONTEXT_V1"
REPORTED_PARAGRAPH_CONTEXT = "DOCUMENTARY_REPORTED_PARAGRAPH_CONTEXT_V1"
DESCRIPTION_PERSPECTIVES = frozenset(
    {
        QUALIFIED_DESCRIPTION,
        NAMING_CONTEXT,
        DEFINITION_CONTEXT,
        PARAGRAPH_CONTEXT,
        REPORTED_PARAGRAPH_CONTEXT,
    }
)
_NAME = r"[\w][\w /()'’–-]{0,100}?"
_REPORTING = re.compile(
    r"\b(?:according to|believed?|argued?|claimed?|wrote|writes|reported?|"
    r"по мнению|считал|утверждал)\b",
    re.IGNORECASE,
)
_REFERENCE = re.compile(
    r"^(?:this|that|these|those|it|they|we|you|he|she|there|это|он|она)\b",
    re.IGNORECASE,
)


def description_context_flags(perspective):
    """Machine category flags, never instructions or attribution read from prose."""
    if perspective not in {PARAGRAPH_CONTEXT, REPORTED_PARAGRAPH_CONTEXT}:
        return {}
    flags = {
        "unresolved_paragraph_context": True,
        "context_relation": "UNRESOLVED_SOURCE_PARAGRAPH",
    }
    if perspective == REPORTED_PARAGRAPH_CONTEXT:
        flags.update(
            reported_context=True,
            attribution_resolution="UNRESOLVED",
            same_subject_ownership=False,
            scope="SOURCE_DESCRIPTION_ONLY",
            inference_authority=False,
        )
    return flags


def _safe(text):
    return (
        len(text) <= 2000
        and not any(mark in text for mark in ("?", '"', "“", "«", ">", "="))
        and "[UNSUPPORTED_MATH_NOTATION]" not in text
        and not _REPORTING.search(text)
    )


def qualified_description(sentence, modal):
    """Only an explicit positive subject/description with a retained qualifier."""
    if not _safe(sentence):
        return None
    match = re.fullmatch(
        rf"({_NAME})\s+(is defined as|are defined as|means|refers to|"
        rf"означает|это|is|are|was|were)\s+(.+)",
        sentence,
        re.IGNORECASE,
    )
    if not match:
        return None
    name, predicate, body = match.groups()
    if (
        _REFERENCE.search(name)
        or modal.search(name)
        or not (
            modal.search(body)
            or re.search(
                r"\bonly\s+(?:during|after|before|for|under)\b", body, re.IGNORECASE
            )
        )
    ):
        return None
    # A negated/modal predicate is not a positive term description. A trailing
    # exception is retained verbatim, never split into a stronger assertion.
    if re.match(
        r"(?:not|never|may|might|could|не|никогда|может)\b", body, re.IGNORECASE
    ):
        return None
    if predicate.casefold() in {"is", "are", "was", "were"} and not re.match(
        r"(?:(?:now|currently|today)\s+)?(?:a|an|the)\s+", body, re.IGNORECASE
    ):
        return None
    if re.match(
        r"(?:a|an|the)\s+(?:part|component|constituent|kind|type)\s+of\b",
        body,
        re.IGNORECASE,
    ):
        return None
    return name.strip(), sentence, QUALIFIED_DESCRIPTION


def naming_contexts(text, modal):
    """Return full same-paragraph context, not an inferred antecedent definition."""
    result = []
    for paragraph in re.split(r"\n\s*\n", text):
        paragraph = " ".join(paragraph.split())
        if not _safe(paragraph):
            continue
        # Explicit local event naming retains the complete conditional clause.
        # It does not infer a general definition or resolve remote antecedents.
        event_name = re.fullmatch(
            rf"When\s+(.{{10,1200}}),\s+this\s+is\s+called\s+({_NAME})[.!]?$",
            paragraph,
            re.IGNORECASE,
        )
        if (
            event_name
            and not modal.search(event_name[1])
            and not _REFERENCE.search(event_name[2])
        ):
            result.append((event_name[2].strip(" .!"), paragraph, NAMING_CONTEXT))
        if modal.search(paragraph):
            continue
        naming = re.search(
            rf"\b(?:This|That|Such)\s+(?:approach|process|method|system|"
            rf"line of thought)\s+(?:(?:also|later|eventually)\s+)?"
            rf"(?:became known as|is known as|was called)\s+"
            rf"({_NAME})[.!]?$",
            paragraph,
            re.IGNORECASE,
        )
        if naming:
            # No isolated pronoun resolution and no crossing paragraph, heading,
            # source or quotation boundaries. Keep the ambiguous context intact.
            preceding = paragraph[: naming.start()].strip()
            if len(preceding) >= 20 and preceding.endswith((".", "!")):
                result.append((naming[1].strip(" .!"), paragraph, NAMING_CONTEXT))
        event = re.fullmatch(
            rf"({_NAME})\s+became\s+((?:a|an|the)\s+.+)", paragraph, re.IGNORECASE
        )
        if event and not _REFERENCE.search(event[1]):
            result.append((event[1].strip(), paragraph, NAMING_CONTEXT))
    return result


def trailing_qualification(following, modal):
    """An adjacent exception/referring qualifier must not be lost at a full stop."""
    return bool(
        (
            modal.search(following)
            or re.search(
                r"\bonly\s+(?:during|after|before|for|under)\b",
                following,
                re.IGNORECASE,
            )
        )
        and re.match(
            r"(?:except|unless|only if|but|however|кроме|если|однако)\b|"
            r"(?:it|this|these|they)(?:\s+(?:definition|rule|statement|claim|property))?\s+"
            r"(?:(?:is|are)\s+(?:(?:not|only)\s+)?(?:valid|true|correct|applicable)|"
            r"(?:applies|holds|changes)\s+(?:only\s+)?(?:when|unless|during|after|before|under)|"
            r"(?:may|might|does|do)\s+(?:not\s+)?(?:apply|hold|change))\b",
            following,
            re.IGNORECASE,
        )
    )
