"""Bounded typed reasoning from installed IR, never from acquisition or prompts.

Documented causal chains are explanations of source assertions, not proofs of
transitive causation. Mathematical results are conditional on reviewed rules
and explicitly supplied units/assumptions. Unknown relations are not false.
"""

from __future__ import annotations

import json
import re
from collections import deque
from dataclasses import asdict
from fractions import Fraction
from itertools import pairwise

from ai_brain.stage2.facts.canonical import canonical_json, content_hash
from ai_brain.stage3.acquisition.document_signatures import (
    java_documentary_parameter_types,
    java_documentary_parameters,
    parse_document_signature,
    parse_documentary_type_reference,
)
from ai_brain.stage3.acquisition.documentary_api_policy import reserved_api_policy
from ai_brain.stage3.acquisition.documentary_logic import (
    DOCUMENTARY_CONDITIONAL_V1,
    MAX_RULES,
    bind_scope,
    derive_conditionals,
    documentary_scope,
    extract_documentary_conditionals,
    parse_conditional_payload,
    parse_conditional_query,
)
from ai_brain.stage3.acquisition.math_notation import normalize_symbols
from ai_brain.stage3.acquisition.semantic_extraction import (
    STEP_PREFIX,
    parse_unit,
    term_key,
)
from ai_brain.stage3.acquisition.source_descriptions import (
    DESCRIPTION_PERSPECTIVES,
    description_context_flags,
)
from ai_brain.stage3.domains.document_limits import (
    MAX_DOCUMENTARY_PACK_RECORDS,
    MAX_DOCUMENTARY_QUERY_RECORDS,
)
from ai_brain.stage3.domains.document_retrieval import excerpt_payload
from ai_brain.stage3.domains.request_verification import (
    custody_evidence,
    verified_request,
)
from ai_brain.stage3.knowledge_ir.records import (
    CausalClaimContent,
    ClaimSchemaContent,
    ConceptContent,
    DefinitionContent,
    EpistemicCharacter,
    InterpretationContent,
    ProcedureContent,
    ProcedureStepKind,
    RelationContent,
    RuleContent,
)


def _documentary_java_signature_matches(payload, requested_types):
    if payload.get("signature_language") != "java":
        return False

    def descriptor(types):
        # Java varargs declarations and Javadoc array method identifiers denote
        # the same last parameter descriptor. Preserve the raw T... in the
        # contract; no widening, generic erasure or import resolution occurs.
        return tuple(
            value[:-3] + "[]" if value.endswith("...") else value for value in types
        )

    requested = descriptor(requested_types)
    variants = []
    for field in ("signature", "signature_display"):
        declared = java_documentary_parameter_types(payload.get(field))
        if declared is not None:
            variants.append(descriptor(declared))
    if not variants:
        return False
    # Javadoc explicitly publishes a method identifier as well as its display
    # declaration. Accept that exact source-provided alias, not an inferred
    # generic erasure. Its callable name/arity must agree with the declaration.
    anchor = parse_documentary_type_reference(payload.get("member_anchor"))
    if (
        anchor is not None
        and anchor[0] == (payload.get("symbol") or "").rsplit(".", 1)[-1]
        and len(anchor[1]) == len(variants[0])
    ):
        variants.append(descriptor(anchor[1]))
    # Qualification may be explicit for just some parameters. Alternatives
    # always belong to this same reviewed declaration and parameter position.
    variants = [variant for variant in variants if len(variant) == len(requested)]
    return bool(variants) and all(
        value in {variant[position] for variant in variants}
        for position, value in enumerate(requested)
    )


def _packs(service, domain_id):
    registry = service.registry
    if registry.capability_registry is None or registry.provider_registry is None:
        raise ValueError("missing runtime authority")
    registry.capability_registry.verify(registry.provider_registry)
    domains = {item.domain_id for item in registry.list()}
    if domain_id is not None:
        if domain_id not in domains:
            raise KeyError("domain not installed")
        domains = {domain_id}
    if len(domains) > 64:
        raise OverflowError("domain limit")
    packs = []
    count = 0
    for identity in sorted(domains):
        current = registry.show(identity)
        if current.status.value == "DEPRECATED":
            continue
        if not registry.verify_currentness(identity, current.pack_version)["current"]:
            raise ValueError("stale authority")
        pack = registry.load_installed_pack(identity, current.pack_version)
        count += len(pack.knowledge_records)
        if (
            len(pack.knowledge_records) > MAX_DOCUMENTARY_PACK_RECORDS
            or count > MAX_DOCUMENTARY_QUERY_RECORDS
        ):
            raise OverflowError("record limit")
        packs.append(pack)
    return packs


def _evidence(pack, records):
    """Include original documentary dependencies of every intermediate step."""
    by_id = {record.knowledge_id: record for record in pack.knowledge_records}
    bindings = {source.binding_id: source for source in pack.source_bindings}
    result, visited = [], set()
    pending = list(records)
    while pending:
        record = pending.pop()
        if record.knowledge_id in visited:
            continue
        visited.add(record.knowledge_id)
        if len(visited) > 128:
            raise OverflowError("evidence closure exceeds limit")
        payload = excerpt_payload(record)
        result.append(
            {
                "knowledge_id": record.knowledge_id,
                "kind": record.kind.value,
                "record_hash": record.content_hash,
                "epistemic_character": record.epistemic_character.value,
                "origin": payload if payload else None,
                **custody_evidence(pack),
                "sources": [
                    asdict(bindings[identity]) for identity in record.provenance_refs
                ],
            }
        )
        pending.extend(by_id[identity] for identity in record.dependencies)
    return sorted(result, key=lambda item: item["knowledge_id"])


def _answer(pack, records, status, value, steps=()):
    evidence = _evidence(pack, records)
    if (
        len(records) == 1
        and isinstance(records[0].content, ClaimSchemaContent)
        and records[0].content.return_type == "DOCUMENTED_NOT_EXECUTED"
        and isinstance(value, dict)
    ):
        # Unclassified API prose (performance, allocation, wrapping, warnings)
        # must remain usable without inventing a formal postcondition. These
        # installed source descriptions are explicitly non-inference authority;
        # every passage references the same original evidence closure below.
        passages = [
            {
                "knowledge_id": item["knowledge_id"],
                "text": item["origin"]["text"],
                **{
                    key: item["origin"][key]
                    for key in (
                        "documentary_original_text",
                        "documentary_rendering_basis",
                        "documentary_note_label",
                        "documentary_note_label_origin",
                    )
                    if key in item["origin"]
                },
            }
            for item in evidence
            if item["origin"]
            and item["origin"].get("documentary_role") == "PROSE"
            and not item["origin"].get("quotation")
        ]
        value = {
            **value,
            "documented_description": {
                "scope": "SOURCE_DESCRIPTION_ONLY",
                "description_is_inference_authority": False,
                "passages": passages,
            },
        }
    return {
        "status": status,
        "domain_id": pack.manifest.domain_id,
        "pack_hash": pack.manifest.pack_content_hash,
        "value": value,
        "proof_steps": list(steps),
        "evidence": evidence,
        "truth_status": "REVIEWED_SOURCE_ASSERTIONS_NOT_INDEPENDENT_FACT_VERIFICATION",
        "answer_mode": "TYPED_INSTALLED_KNOWLEDGE",
        **({"source_code_executed": False} if status == "DOCUMENTED_CONTRACT" else {}),
    }


def _named(pack, reference):
    target = term_key(reference)
    return tuple(
        record
        for record in pack.knowledge_records
        if isinstance(record.content, ConceptContent)
        and target
        in {
            term_key(record.content.canonical_name_en),
            term_key(record.content.canonical_name_ru),
        }
    )


def _source_payloads(pack, record):
    by_id = {item.knowledge_id: item for item in pack.knowledge_records}
    return [
        payload
        for identity in record.dependencies
        if (payload := excerpt_payload(by_id[identity])) is not None
    ]


def _unique(records):
    return tuple({record.knowledge_id: record for record in records}.values())


def _conditional(pack, task):
    """Derive only from reviewed source clauses, never from a perspective flag alone."""
    if any(
        isinstance(record.content, InterpretationContent)
        and record.content.perspective == "DOCUMENTARY_CONDITIONAL_V2"
        for record in pack.knowledge_records
    ):
        from ai_brain.stage3.acquisition.documentary_conditional_bridge_v2 import (
            convert_v1_query_v2,
        )
        from ai_brain.stage3.domains.documentary_conditionals_v2 import assess_task_v2

        try:
            converted = convert_v1_query_v2(task)
        except ValueError:
            return {
                "status": "NEEDS_NEW_CAPABILITY",
                "domain_id": pack.manifest.domain_id,
                "reason": "Whole mixed-version task cannot be converted exactly",
            }
        return assess_task_v2(pack, converted)
    by_id = {item.knowledge_id: item for item in pack.knowledge_records}
    origins = [
        origin
        for item in pack.knowledge_records
        if (origin := excerpt_payload(item)) is not None
    ]
    # Reader blocks/chunks are original documentary order, not pack record order.
    ordered_origins = sorted(
        origins,
        key=lambda origin: (
            origin["original_bytes_hash"],
            origin["file"],
            origin["block"],
            origin["chunk_index"],
        ),
    )
    following_by_position = {
        (
            origin["original_bytes_hash"],
            origin["file"],
            origin["block"],
            origin["chunk_index"],
        ): following
        for origin, following in pairwise(ordered_origins)
        if origin["original_bytes_hash"] == following["original_bytes_hash"]
        and origin["file"] == following["file"]
    }
    preceding_by_position = {
        (
            following["original_bytes_hash"],
            following["file"],
            following["block"],
            following["chunk_index"],
        ): origin
        for origin, following in pairwise(ordered_origins)
        if origin["original_bytes_hash"] == following["original_bytes_hash"]
        and origin["file"] == following["file"]
    }
    groups = {}
    for record in pack.knowledge_records:
        content = record.content
        if not isinstance(content, InterpretationContent) or (
            content.perspective != DOCUMENTARY_CONDITIONAL_V1
        ):
            continue
        if (
            len(content.supported_record_ids) != 1
            or content.supported_record_ids != record.dependencies
            or content.contrast_record_ids
            or record.epistemic_character is not EpistemicCharacter.INTERPRETIVE
            or record.required_capability_ids
            or record.applicability_refs
        ):
            raise ValueError("invalid conditional authority")
        source = by_id[content.supported_record_ids[0]]
        origin = excerpt_payload(source)
        if origin is None:
            raise ValueError("conditional requires original documentary evidence")
        scope = documentary_scope(origin)
        parsed = parse_conditional_payload(content.claim_text)
        # Compare with a freshly parsed, source-bound candidate. Even approved
        # arbitrary JSON/perspective text cannot impersonate an original clause.
        following = following_by_position.get(
            (
                origin["original_bytes_hash"],
                origin["file"],
                origin["block"],
                origin["chunk_index"],
            )
        )
        preceding = preceding_by_position.get(
            (
                origin["original_bytes_hash"],
                origin["file"],
                origin["block"],
                origin["chunk_index"],
            )
        )
        candidates = tuple(
            bind_scope(candidate, scope)
            for candidate in extract_documentary_conditionals(
                origin, following, preceding
            )
        )
        if canonical_json(parsed.to_dict()) not in {
            canonical_json(candidate) for candidate in candidates
        }:
            raise ValueError("conditional differs from its original source/scope")
        groups.setdefault(scope, []).append((record.knowledge_id, parsed.to_dict()))

    # A contradictory hypothetical query is contested even when this pack has
    # no licensed rules. Use the same pure engine, not a second negation parser.
    premise_check = derive_conditionals((), task)
    if premise_check["status"] == "CONTESTED":
        return {
            "status": "CONTESTED_CONDITIONAL_DERIVATION",
            "domain_id": pack.manifest.domain_id,
            "conflicts": premise_check["conflicts"],
            "reason": "Contradictory hypothetical premises; no conclusion asserted",
        }
    productive = []
    for scope, rules in sorted(groups.items()):
        if len(rules) > MAX_RULES:
            raise OverflowError("conditional rule budget exceeded")
        result = derive_conditionals(tuple(rules), task)
        status = result["status"]
        if status in {"INVALID_CONDITIONAL_INPUT", "SCOPE_CONFLICT"}:
            raise ValueError("invalid conditional source/query binding")
        if status == "BOUND_EXCEEDED":
            return {"status": "RESOURCE_LIMIT", "domain_id": pack.manifest.domain_id}
        if status == "CONTESTED":
            return {
                "status": "CONTESTED_CONDITIONAL_DERIVATION",
                "domain_id": pack.manifest.domain_id,
                "conflicts": result["conflicts"],
                "reason": "Contradictory hypothetical premises or source consequences; no conclusion asserted",
            }
        if status == "DERIVED" and (
            task["goal"] is None or result["goal_follows"] is True
        ):
            productive.append((scope, result))
    if len(productive) > 1:
        return {
            "status": "AMBIGUOUS_SOURCE_SCOPE",
            "domain_id": pack.manifest.domain_id,
            "source_scope_candidates": [content_hash(scope) for scope, _ in productive],
            "reason": "Select an attributed source; independent scopes are not silently composed",
        }
    if not productive:
        return None
    scope, result = productive[0]
    selected = tuple(by_id[identity] for identity in result["used_rule_ids"])
    if not selected:
        return None
    value = {
        "scope": "DOCUMENTARY_CONDITIONAL_DERIVATION",
        "source_scope": list(scope),
        "assumptions": result["assumptions"],
        "assumptions_are_hypothetical": True,
        "conclusions": result["conclusions"],
        "source_assertions_independently_verified": False,
        "source_code_executed": False,
        "inference_kind": "BOUNDED_FORWARD_CHAINING",
        "query_hash": content_hash(task),
    }
    if task["goal"] is not None:
        value.update(goal=task["goal"]["text"], goal_follows=True)
    answer = _answer(
        pack,
        selected,
        "DOCUMENTED_CONDITIONAL_CONCLUSIONS",
        value,
        result["proof_steps"],
    )
    answer["truth_status"] = (
        "CONDITIONAL_ON_ASSUMPTIONS_AND_REVIEWED_SOURCE_ASSERTIONS_NOT_INDEPENDENT_FACT_VERIFICATION"
    )
    answer["derivation_hash"] = content_hash(
        {
            "pack_hash": answer["pack_hash"],
            "query_hash": value["query_hash"],
            "source_scope": scope,
            "conclusions": value["conclusions"],
            "proof_steps": answer["proof_steps"],
            "evidence_hashes": [item["record_hash"] for item in answer["evidence"]],
        }
    )
    return answer


def _structured(pack, intent, left, right):
    records = pack.knowledge_records
    if intent in {"definition", "taxonomy", "part", "causal", "interpretations"}:
        starts = _named(pack, left)
        if len(starts) > 1:
            return {
                "status": "AMBIGUOUS_REFERENCE",
                "domain_id": pack.manifest.domain_id,
            }
        if not starts:
            return None
        start = starts[0]
    if intent == "definition":
        definitions = tuple(
            record
            for record in records
            if isinstance(record.content, DefinitionContent)
            and start.knowledge_id in record.dependencies
        )
        descriptions = tuple(
            record
            for record in records
            if isinstance(record.content, InterpretationContent)
            and record.content.perspective in DESCRIPTION_PERSPECTIVES
            and start.knowledge_id in record.content.supported_record_ids
        )
        if right is not None:

            def authored(record):
                return any(
                    term_key(payload.get("source_author") or "") == term_key(right)
                    for payload in _source_payloads(pack, record)
                )

            definitions = tuple(record for record in definitions if authored(record))
            descriptions = tuple(record for record in descriptions if authored(record))
        if not definitions and not descriptions:
            return None
        claims = sorted({record.content.definition_en for record in definitions})
        return _answer(
            pack,
            (start, *definitions, *descriptions),
            "SOURCE_DESCRIPTION_ONLY"
            if not definitions
            else "MULTIPLE_SOURCE_DEFINITIONS"
            if len(claims) > 1
            else "SOURCE_SUPPORTED_DEFINITION",
            {
                "term": left,
                **(
                    {
                        "source_author": right,
                        "attribution_kind": "DOCUMENTARY_DECLARED_SOURCE_AUTHOR",
                    }
                    if right is not None
                    else {}
                ),
                "definitions": claims,
                "source_descriptions": [
                    {
                        "text": record.content.claim_text,
                        "kind": record.content.perspective,
                        "knowledge_id": record.knowledge_id,
                        **description_context_flags(record.content.perspective),
                    }
                    for record in descriptions
                ],
                "description_is_inference_authority": False,
                "conflict_silently_resolved": False,
                "consistency": "NOT_ESTABLISHED"
                if len(claims) > 1
                else "SINGLE_DESCRIPTION"
                if definitions
                else "NOT_ESTABLISHED",
                "logical_contradiction_proven": False,
            },
        )
    if intent in {"taxonomy", "part", "causal"}:
        ends = _named(pack, right)
        if len(ends) > 1:
            return {
                "status": "AMBIGUOUS_REFERENCE",
                "domain_id": pack.manifest.domain_id,
            }
        if not ends:
            return None
        end = ends[0]
        edges = []
        for record in records:
            content = record.content
            if intent == "causal" and isinstance(content, CausalClaimContent):
                edges.append((content.cause_id, content.effect_id, record))
            elif (
                isinstance(content, RelationContent)
                and content.predicate_id
                == ("is_a" if intent == "taxonomy" else "part_of")
                and intent != "causal"
            ):
                edges.append((content.subject_id, content.object_id, record))
        adjacency = {}
        for subject, target, record in edges:
            # Qualified assertions are not silently composed into unconditional facts.
            if (
                record.applicability_refs
                or intent != "causal"
                and record.epistemic_character
                not in {EpistemicCharacter.EMPIRICAL, EpistemicCharacter.DETERMINISTIC}
            ):
                continue
            adjacency.setdefault(subject, []).append((target, record))
        pending, visited = deque([(start.knowledge_id, ())]), {start.knowledge_id}
        while pending:
            node, path = pending.popleft()
            for target, record in adjacency.get(node, ()):
                expanded = (*path, record)
                if target == end.knowledge_id:
                    return _answer(
                        pack,
                        _unique((start, end, *expanded)),
                        "CONTESTED_CAUSAL_CHAIN"
                        if intent == "causal"
                        and any(
                            item.epistemic_character is EpistemicCharacter.CONTESTED
                            for item in expanded
                        )
                        else "DOCUMENTED_CAUSAL_CHAIN"
                        if intent == "causal"
                        else "SOURCE_SUPPORTED_RELATION",
                        {
                            "subject": left,
                            "object": right,
                            "relation": intent,
                            "step_count": len(expanded),
                            "transitive_causal_fact_asserted": False,
                        },
                        [
                            {
                                "rule_id": item.knowledge_id,
                                "content": asdict(item.content),
                            }
                            for item in expanded
                        ],
                    )
                if intent == "part" or len(expanded) >= 8 or target in visited:
                    continue
                visited.add(target)
                pending.append((target, expanded))
        return {
            "status": "INSUFFICIENT_EVIDENCE",
            "domain_id": pack.manifest.domain_id,
            "reason": "No installed source relation proves the request; unknown is not false.",
        }
    if intent == "interpretations":
        interpretations = tuple(
            record
            for record in records
            if isinstance(record.content, InterpretationContent)
            and record.content.perspective not in DESCRIPTION_PERSPECTIVES
            and record.content.perspective != "DOCUMENTARY_CONDITIONAL_V2"
            and not reserved_api_policy(record.content)
            and start.knowledge_id in record.content.supported_record_ids
            and (
                right is None or term_key(record.content.perspective) == term_key(right)
            )
        )
        if not interpretations:
            return None
        return _answer(
            pack,
            (start, *interpretations),
            "CONTESTED"
            if len({item.content.perspective for item in interpretations}) > 1
            else "ATTRIBUTED_INTERPRETATION",
            [
                {
                    "perspective": item.content.perspective,
                    "claim": item.content.claim_text,
                }
                for item in interpretations
            ],
        )
    if intent in {"contract", "procedure"}:
        callable_reference, requested_types = left, None
        if intent == "contract" and ("(" in left or ")" in left):
            parsed = parse_documentary_type_reference(left)
            if parsed is None:
                return {
                    "status": "INVALID_REQUEST",
                    "reason": "A callable type reference requires bounded exact documentary Java types",
                }
            callable_reference, requested_types = parsed
        selected, exact = [], []
        for record in records:
            if not isinstance(
                record.content,
                ClaimSchemaContent if intent == "contract" else ProcedureContent,
            ):
                continue
            payloads = _source_payloads(pack, record)
            labels = (
                [payload.get("symbol") or "" for payload in payloads]
                if intent == "contract"
                else [payload.get("title") or "" for payload in payloads]
            )
            aliases = list(labels)
            if intent == "contract":
                # Class.member is a source-derived spelling, not an import
                # guess. Same short owners in different packages remain
                # ambiguous; arbitrary partial namespaces are not accepted.
                aliases.extend(
                    ".".join((payload.get("symbol") or "").split(".")[-2:])
                    for payload in payloads
                    if payload.get("signature_language") == "java"
                )
            if requested_types is not None and not any(
                _documentary_java_signature_matches(payload, requested_types)
                for payload in payloads
            ):
                continue
            if any(
                term_key(callable_reference)
                in {term_key(label), term_key(label.rsplit(".", 1)[-1])}
                for label in aliases
            ):
                selected.append(record)
                if any(
                    term_key(callable_reference) == term_key(label) for label in labels
                ):
                    exact.append(record)
        # A qualified name wins over another callable's coincidental short name.
        # Multiple exact declarations/overloads remain ambiguous, not merged.
        selected = (
            (exact or selected)
            if intent == "contract" and "." in callable_reference
            else selected
        )
        if len(selected) > 1:
            return {
                "status": "AMBIGUOUS_REFERENCE",
                "domain_id": pack.manifest.domain_id,
                "candidates": [item.knowledge_id for item in selected],
            }
        if not selected:
            return None
        record = selected[0]
        if intent == "contract":
            return _answer(
                pack,
                (record,),
                "DOCUMENTED_CONTRACT",
                asdict(record.content),
                ({"operation": "read documented restrictions; do not execute"},),
            )
        by_id = {item.knowledge_id: item for item in records}
        steps = []
        for step in record.content.steps:
            if step.kind is ProcedureStepKind.READ_FACT:
                content = by_id[step.authority_ref].content
                if not isinstance(
                    content, ConceptContent
                ) or not content.description_en.startswith(STEP_PREFIX):
                    return {
                        "status": "NEEDS_NEW_CAPABILITY",
                        "reason": "Undocumented procedure step",
                    }
                steps.append(json.loads(content.description_en[len(STEP_PREFIX) :]))
            elif step.kind is not ProcedureStepKind.PRODUCE_TYPED_OUTPUT:
                return {
                    "status": "NEEDS_NEW_CAPABILITY",
                    "reason": "Procedure execution is not authorized",
                }
        return _answer(
            pack, (record,), "DOCUMENTED_PROCEDURE", {"steps": steps, "executed": False}
        )
    return None


def assess_installed_scenario(pack, reference, arguments):
    """Apply complete reviewed documentary obligations under hypothetical inputs.

    This is not source execution or full Java semantics. Unclassified associated
    prose cannot be discarded as irrelevant to a scenario application.
    """
    from ai_brain.stage3.domains.documentary_api_scenarios import (
        assess_documented_scenario,
        classify_documented_api_paragraphs,
    )

    if (
        type(reference) is not str
        or not reference
        or len(reference) > 512
        or type(arguments) is not dict
        or set(arguments) != {"values"}
        or type(arguments["values"]) is not dict
    ):
        return {
            "status": "INVALID_REQUEST",
            "reason": "Explicit scenario values required",
        }
    contract = _structured(pack, "contract", reference, None)
    if contract is None:
        return {"status": "INSUFFICIENT_EVIDENCE", "domain_id": pack.manifest.domain_id}
    if contract["status"] != "DOCUMENTED_CONTRACT":
        return contract
    identities = {
        row["knowledge_id"]
        for row in contract["evidence"]
        if row["kind"] == "CLAIM_SCHEMA"
    }
    selected = [
        record for record in pack.knowledge_records if record.knowledge_id in identities
    ]
    if len(selected) != 1:
        return {"status": "AMBIGUOUS_REFERENCE", "domain_id": pack.manifest.domain_id}
    record = selected[0]
    payloads = _source_payloads(pack, record)
    if not _installed_java_enclosing_context_is_nominal(pack, payloads):
        return {
            "status": "NEEDS_NEW_CAPABILITY",
            "value": None,
            "proof_steps": [],
            "reason": "Installed enclosing Java documentary context has unassessed obligations or qualifiers",
        }
    if any(
        payload.get("signature_language") == "java" for payload in payloads
    ) and not (_installed_unqualified_java_signature(record, payloads)):
        return {
            "status": "NEEDS_NEW_CAPABILITY",
            "value": None,
            "proof_steps": [],
            "reason": "Complete unqualified same-callable documentary signature required; annotation semantics are not licensed",
        }
    reference_policy = _installed_reference_policy(record, payloads)
    paragraphs = []
    for payload in payloads:
        if payload.get("documentary_role") in {
            "DOCUMENTARY_SIGNATURE",
            "LITERAL_EXAMPLE",
        }:
            continue
        if (
            payload.get("documentary_role") != "PROSE"
            or payload.get("quotation") is not False
            or payload.get("documentary_math_presence") is not False
        ):
            return {
                "status": "NEEDS_NEW_CAPABILITY",
                "reason": "Scenario source context is not licensed plain documentary prose",
            }
        from ai_brain.stage3.domains.javadoc_clause_view import documentary_tag_clauses
        tagged = payload.get("signature_language") == "java" and re.search(
            r"(?m)^[ \t]*@[A-Za-z]+\b", payload["text"]
        )
        for paragraph in documentary_tag_clauses(payload["text"]) if tagged else re.split(r"\n\s*\n", payload["text"]):
            clause = paragraph if tagged else " ".join(paragraph.split())
            if not clause or re.fullmatch(
                r"(?:Parameters|Type Parameters|Returns|Throws|Raises|Since|See Also):",
                clause,
                re.IGNORECASE,
            ):
                continue
            clause = re.sub(
                r"^((?:Parameters|Returns|Throws|Raises):)(?:\s*\1)+",
                r"\1",
                clause,
                flags=re.IGNORECASE,
            )
            paragraphs.append(clause)
    classified = classify_documented_api_paragraphs(
        record.content, tuple(paragraphs), reference_policy=reference_policy
    )
    if classified["status"] != "COMPLETE":
        return {
            **classified,
            "domain_id": pack.manifest.domain_id,
            "pack_hash": pack.manifest.pack_content_hash,
        }
    if any(
        getattr(record.content, name) != classified[name]
        for name in ("preconditions", "postconditions", "declared_exceptions")
    ):
        return {
            "status": "NEEDS_NEW_CAPABILITY",
            "reason": "Reviewed obligations differ from complete original paragraph classification",
        }
    assessment = assess_documented_scenario(
        record.content, arguments["values"], reference_policy=reference_policy
    )
    if assessment["status"] != "DOCUMENTED_API_SCENARIO":
        return {
            **assessment,
            "domain_id": pack.manifest.domain_id,
            "pack_hash": pack.manifest.pack_content_hash,
        }
    steps = [
        {**step, "rule_id": record.knowledge_id} for step in assessment["proof_steps"]
    ]
    return {
        **_answer(pack, (record,), assessment["status"], assessment["value"], steps),
        "source_context_is_not_assessed": True,
        "source_context_classification": classified["classifications"],
        "source_code_executed": False,
        "independently_verified": False,
        "scope": "HYPOTHETICAL_DOCUMENTED_API_OBLIGATIONS_ONLY",
    }


def _installed_java_enclosing_context_is_nominal(pack, payloads):
    """Do not mistake a dependency-local contract for the entire class scope.

    Only verified installed excerpts participate. In particular an unassociated
    class-wide obligation must not disappear merely because extraction kept it
    as an overview rather than a callable dependency. Unknown enclosing meaning
    is refused, never inferred from annotation names or relevance keywords.
    """
    java = [p for p in payloads if p.get("signature_language") == "java"]
    if not java:
        return True
    if len(pack.knowledge_records) > MAX_DOCUMENTARY_PACK_RECORDS:
        return False
    identity_fields = (
        "file",
        "original_bytes_hash",
        "source_url",
        "format",
        "reader_profile",
    )
    identity = {name: java[0].get(name) for name in identity_fields}
    basis = java[0].get("documentary_context_basis")
    if any(
        {name: p.get(name) for name in identity_fields} != identity
        or p.get("documentary_context_basis") != basis
        for p in java
    ):
        return False
    if type(basis) is not dict:
        return False
    kind = basis.get("kind")
    if kind == "EXPLICIT_JAVADOC_CLASS_STRUCTURE":
        owner, name = basis.get("qualified_class"), basis.get("class_name")
        if (
            type(owner) is not str
            or type(name) is not str
            or not owner.endswith("." + name)
            or any(
                type(p.get("symbol")) is not str
                or p["symbol"].rsplit(".", 1)[0] != owner
                for p in java
            )
        ):
            return False
        package = owner[: -(len(name) + 1)]
        nominal = {owner, package, "Package " + package}
        plain_declaration = re.compile(
            r"(?:(?:public|protected|private|abstract|final|static|strictfp)\s+)*"
            r"(?:class|interface|enum)\s+" + re.escape(name)
        )
        required = java[0].get("documentary_enclosing_context_blocks")
        if (
            type(required) is not list
            or len(required) > 8192
            or any(type(n) is not int or not 1 <= n <= 8192 for n in required)
            or required != sorted(set(required))
            or any(
                p.get("documentary_enclosing_context_blocks") != required for p in java
            )
        ):
            return False
        found = set()
    elif kind == "JAVA_AST_DOCUMENTATION":
        # Source AST comments on a containing declaration are not automatically
        # part of a method's dependency list either. Their meaning is unassessed.
        owner = java[0].get("symbol")
        if type(owner) is not str:
            return False
        declarations = java[0].get("documentary_enclosing_java_declarations")
        enclosing_documentation = java[0].get(
            "documentary_enclosing_java_documentation"
        )
        package_signature = java[0].get("documentary_java_package_signature")
        if (
            type(declarations) is not list
            or not 1 <= len(declarations) <= 32
            # Any associated enclosing documentation remains unassessed even
            # when review rejected its separate excerpt. Missing metadata is
            # not evidence of absence. Only an explicit empty list is clean.
            or type(enclosing_documentation) is not list
            or enclosing_documentation
            or type(package_signature) is not str
            or len(package_signature) > 2048
            or any(
                p.get("documentary_enclosing_java_declarations") != declarations
                or p.get("documentary_enclosing_java_documentation")
                != enclosing_documentation
                or p.get("documentary_java_package_signature") != package_signature
                for p in java
            )
            or (
                package_signature
                and re.fullmatch(
                    r"package\s+(?:[A-Za-z_$]\w*\.)*[A-Za-z_$]\w*\s*;",
                    package_signature,
                )
                is None
            )
        ):
            return False
        ancestors = []
        for declaration in declarations:
            if type(declaration) is not dict or set(declaration) != {
                "symbol",
                "signature",
            }:
                return False
            symbol, signature = declaration["symbol"], declaration["signature"]
            if (
                type(symbol) is not str
                or not owner.startswith(symbol + ".")
                or symbol in ancestors
                or type(signature) is not str
                or re.fullmatch(
                    r"(?:(?:public|protected|private|abstract|final|static|strictfp)\s+)*"
                    r"(?:class|interface|enum)\s+"
                    + re.escape(symbol.rsplit(".", 1)[-1]),
                    signature,
                )
                is None
            ):
                return False
            ancestors.append(symbol)
        if ancestors[-1] != owner.rsplit(".", 1)[0]:
            return False
    else:
        return False
    for item in pack.knowledge_records:
        p = excerpt_payload(item)
        if p is None or (
            p.get("file") != identity["file"]
            or p.get("original_bytes_hash") != identity["original_bytes_hash"]
            or p.get("documentary_context") != "JAVA_API_DOCUMENTATION"
        ):
            continue
        if kind == "JAVA_AST_DOCUMENTATION":
            symbol = p.get("symbol")
            if (
                p.get("declaration_kind")
                in {
                    "class_declaration",
                    "interface_declaration",
                    "enum_declaration",
                    "record_declaration",
                }
                and type(symbol) is str
                and owner.startswith(symbol + ".")
            ):
                return False
            continue
        if p.get("signature") or p.get("symbol"):
            continue  # Other callables do not confer enclosing authority.
        ordinal = p.get("block")
        if type(ordinal) is not int or ordinal not in required or ordinal in found:
            return False
        found.add(ordinal)
        if (
            {field: p.get(field) for field in identity_fields} != identity
            or p.get("documentary_context_basis") != basis
            or p.get("documentary_role") != "PROSE"
            or p.get("quotation") is not False
            or p.get("documentary_math_presence") is not False
            or type(p.get("text")) is not str
        ):
            return False
        text = " ".join(p["text"].split())
        if text not in nominal and plain_declaration.fullmatch(text) is None:
            return False
    return kind == "JAVA_AST_DOCUMENTATION" or found == set(required)


def _installed_java_signature_anchor(record, payloads):
    """One complete same-callable declaration in either reader-owned format."""
    if not payloads or any(
        payload.get("signature_language") != "java" for payload in payloads
    ):
        return None
    fields = (
        "file",
        "original_bytes_hash",
        "source_url",
        "format",
        "reader_profile",
        "signature",
        "signature_display",
        "signature_language",
        "symbol",
        "member_anchor",
        "source_author",
        "heading_path",
    )
    scopes = {
        canonical_json({name: payload.get(name) for name in fields})
        for payload in payloads
    }
    signatures = [
        payload
        for payload in payloads
        if payload.get("documentary_role") == "DOCUMENTARY_SIGNATURE"
        and payload.get("quotation") is False
        and payload.get("documentary_math_presence") is False
    ]
    if len(scopes) != 1:
        return None
    if all(
        payload.get("format") == "java-documentation-ast"
        and payload.get("declaration_kind")
        in {"method_declaration", "constructor_declaration"}
        and payload.get("documentary_context_basis")
        == {
            "kind": "JAVA_AST_DOCUMENTATION",
            "declaration_kind": payload.get("declaration_kind"),
        }
        for payload in payloads
    ):
        # AST documentation repeats the same captured declaration on its prose
        # blocks; it does not invent an HTML-style standalone signature block.
        if signatures:
            return None
        candidates = [
            p
            for p in payloads
            if p.get("documentary_role") == "PROSE"
            and p.get("quotation") is False
            and p.get("documentary_math_presence") is False
        ]
        if not candidates:
            return None
        payload = candidates[0]
        # Preserve the reader's original 800-character scenario admission
        # budget without ever replacing a longer declaration by its prefix.
        # The full bounded literal may still serve an unassessed descriptor.
        raw_signature = payload.get("signature")
        if type(raw_signature) is not str or len(raw_signature) > 800:
            return None
    else:
        if len(signatures) != 1:
            return None
        payload = signatures[0]
    symbol = payload.get("symbol")
    signature = payload.get("signature_display") or payload.get("signature")
    if (
        type(symbol) is not str
        or symbol.rsplit(".", 1)[-1] != record.content.predicate_id
        or type(signature) is not str
        or parse_document_signature(signature, language="java", callable_name=symbol)
        is None
        or java_documentary_parameters(signature) != record.content.parameters
    ):
        return None
    return payload


def _installed_unqualified_java_signature(record, payloads):
    """Base parameter spellings cannot erase unknown declaration annotations."""
    payload = _installed_java_signature_anchor(record, payloads)
    if payload is None:
        return False
    # Neither short nor qualified annotation names carry semantic authority.
    # Both retained spellings are inspected; never silently strip a display marker.
    return not any(
        type(payload.get(field)) is str and "@" in payload[field]
        for field in ("signature", "signature_display")
    )


def _installed_reference_policy(record, payloads):
    """Rebuild ephemeral token authority from one verified installed source scope.

    The public router has already admitted pack custody/currentness. No caller
    value, path or supplied policy participates here. A signature from another
    member/file/author or an ambiguous display never supplies reference roles.
    This is documentary syntax, not Java assignability or source execution.
    """
    from ai_brain.stage3.acquisition.document_signatures import (
        java_documentary_reference_policy,
        java_documentary_integral_return_policy,
    )
    from ai_brain.stage3.domains.documentary_api_scenarios import (
        documentary_scenario_fingerprint,
    )

    payload = _installed_java_signature_anchor(record, payloads)
    if payload is None:
        return None
    signature = payload.get("signature_display") or payload.get("signature")
    fingerprint = documentary_scenario_fingerprint(record.content)
    if (
        type(payload.get("symbol")) is not str
        or payload["symbol"].rsplit(".", 1)[-1] != record.content.predicate_id
        or fingerprint is None
    ):
        return None
    return java_documentary_reference_policy(
        signature,
        callable_name=payload["symbol"],
        parameters=record.content.parameters,
        content_fingerprint=fingerprint,
    ) or java_documentary_integral_return_policy(
        signature, callable_name=payload["symbol"], parameters=record.content.parameters,
        content_fingerprint=fingerprint,
    )


def _intent(question):
    speaker = re.fullmatch(
        r"what did\s+([^?]{1,100}?)\s+(?:argue|claim|contend|assert|write)\s+"
        r"about\s+([^?]{1,100})[?]?",
        question.strip(),
        re.IGNORECASE,
    )
    if speaker:
        return "interpretations", speaker[2].strip(), speaker[1].strip()
    authored = re.fullmatch(
        r"(?:what is|define|что такое|определи)\s+(.+?)\s+"
        r"(?:according to|по мнению)\s+([^?]{1,100})[?]?",
        question.strip(),
        re.IGNORECASE,
    )
    if authored:
        return "definition", authored[1].strip(), authored[2].strip()
    patterns = (
        ("definition", r"(?:what is|define|что такое|определи)\s+(.+)"),
        (
            "taxonomy",
            r"(?:is|является ли)\s+(.+?)\s+(?:a type of|a kind of|видом)\s+(.+)",
        ),
        ("part", r"(?:is|является ли)\s+(.+?)\s+(?:part of|частью)\s+(.+)"),
        (
            "causal",
            r"explain (?:the\s+)?(?:documented\s+)?causal chain from\s+(.+?)\s+to\s+(.+)",
        ),
        (
            "causal",
            r"(?:why does|how does|почему)\s+(.+?)\s+(?:cause|lead to|вызывает|приводит к)\s+(.+)",
        ),
        (
            "interpretations",
            r"(?:compare (?:the\s+)?(?:interpretations|accounts|views) of|сравни трактовки)\s+(.+)",
        ),
        (
            "contract",
            (
                r"(?:(?:show|describe|give|provide)(?: me)?\s+(?:the\s+)?)?"
                r"(?:documented\s+)?(?:contract (?:for|of)|constraints for)\s+(.+)"
                r"|what (?:exceptions are documented for|constraints apply to|"
                r"are the documented (?:preconditions|postconditions) for)\s+(.+)"
                r"|what does the documentation say\s+(.+?)\s+returns"
                r"|(?:(?:покажи|опиши|дай)\s+)?"
                r"(?:документированный\s+)?(?:контракт для|ограничения для)\s+(.+)"
            ),
        ),
        ("procedure", r"(?:steps for|how to|шаги для)\s+(.+)"),
    )
    for intent, pattern in patterns:
        match = re.fullmatch(
            pattern + r"[?]?", question.strip().rstrip("?"), re.IGNORECASE
        )
        if match:
            if intent == "contract":
                return (
                    intent,
                    next(value for value in match.groups() if value is not None),
                    None,
                )
            return (
                intent,
                *match.groups(),
                *(() if len(match.groups()) == 2 else (None,)),
            )
    return None


def _numeric_request(question, arguments):
    if arguments is not None:
        if type(arguments) is not dict or set(arguments) != {
            "unknown",
            "known",
            "conditions",
        }:
            raise ValueError("numeric arguments require unknown, known, conditions")
        if (
            type(arguments["unknown"]) is not str
            or type(arguments["known"]) is not dict
            or any(type(name) is not str for name in arguments["known"])
        ):
            raise ValueError("numeric symbols must be named strings")
        known = {
            normalize_symbols(name): value for name, value in arguments["known"].items()
        }
        if len(known) != len(arguments["known"]):
            raise ValueError("colliding source symbol aliases")
        return {
            **arguments,
            "unknown": normalize_symbols(arguments["unknown"]),
            "known": known,
        }
    match = re.fullmatch(
        r"(?:find|calculate|compute|solve|вычисли|найди|реши)\s+([A-Za-z]\w{0,15})\s+"
        r"(?:when|given|при)\s+(.+?)(?:;\s*(?:assuming|при условии)\s+(.+))?",
        normalize_symbols(question.strip()),
        re.IGNORECASE,
    )
    if not match:
        return None
    known = {}
    for item in match[2].split(","):
        assignment = re.fullmatch(
            r"\s*([A-Za-z]\w{0,15})\s*=\s*"
            r"([+-]?(?:\d+/\d+|\d+(?:\.\d+)?|\.\d+))"
            r"(?:\s+(\S+)|([A-Za-z][^\s,]*))\s*",
            item,
        )
        if not assignment or assignment[1] in known:
            raise ValueError("known values need unique variables and explicit units")
        known[assignment[1]] = {
            "value": assignment[2],
            "unit": assignment[3] or assignment[4],
        }
    return {
        "unknown": match[1],
        "known": known,
        "conditions": [match[3]] if match[3] else [],
    }


def _solve(service, packs, request):
    from ai_brain.stage3.domains.knowledge_service import _bounded_number
    from ai_brain.stage3.acquisition.documentary_scalar_policy import validate_installed as validate_scalar_units
    for pack in packs:
        validate_scalar_units(pack)

    if (
        type(request["unknown"]) is not str
        or not re.fullmatch(r"[A-Za-z]\w{0,15}", request["unknown"])
        or type(request["known"]) is not dict
        or request["unknown"] in request["known"]
        or len(request["known"]) > 64
        or type(request["conditions"]) is not list
        or len(request["conditions"]) > 32
        or any(
            type(condition) is not str or not 0 < len(condition) <= 512
            for condition in request["conditions"]
        )
    ):
        return {
            "status": "INVALID_REQUEST",
            "reason": "invalid bounded numeric request",
        }
    candidates = [
        (pack, record)
        for pack in packs
        for record in pack.knowledge_records
        if isinstance(record.content, RuleContent)
        and {v.variable_id for v in record.content.variables}
        == {*request["known"], request["unknown"]}
    ]
    if not candidates:
        return {
            "status": "NEEDS_NEW_CAPABILITY",
            "reason": "No installed equation matches the supplied variables",
        }
    if len(candidates) > 1:
        # Select by explicit reviewed applicability and quantity dimensions,
        # never by familiarity, ranking, or guessed physical circumstances.
        if any(
            variable.value_type.quantity_type is None
            for _, record in candidates
            for variable in record.content.variables
        ):
            return {
                "status": "NEEDS_NEW_CAPABILITY",
                "reason": "Competing rule has no reviewed quantity types; incompatibility is not proven",
            }
        supplied_dimensions = {}
        for name, supplied in request["known"].items():
            if (
                type(supplied) is not dict
                or set(supplied) != {"value", "unit"}
                or not _bounded_number(supplied["value"])
            ):
                return {
                    "status": "INVALID_REQUEST",
                    "reason": "Every known value requires a number and explicit unit",
                }
            try:
                supplied_dimensions[name] = parse_unit(supplied["unit"])[0]
            except ValueError:
                return {"status": "UNSUPPORTED_UNIT", "variable": name}
        dimensional = [
            (pack, record)
            for pack, record in candidates
            if all(
                variable.value_type.quantity_type is not None
                and (
                    variable.variable_id == request["unknown"]
                    or variable.value_type.quantity_type.dimension
                    == supplied_dimensions[variable.variable_id]
                )
                for variable in record.content.variables
            )
        ]
        if not dimensional:
            return {
                "status": "UNIT_MISMATCH",
                "reason": "No matching rule has the supplied quantity dimensions",
            }
        explicit = {term_key(value) for value in request["conditions"]}
        applicable = [
            (pack, record)
            for pack, record in dimensional
            if {
                term_key(value)
                for value in (
                    *record.content.applicability.preconditions,
                    *record.content.applicability.assumptions,
                )
            }
            <= explicit
        ]
        if not applicable:
            return {
                "status": "APPLICABILITY_REQUIRED",
                "candidate_conditions": {
                    record.knowledge_id: [
                        *record.content.applicability.preconditions,
                        *record.content.applicability.assumptions,
                    ]
                    for _, record in dimensional
                },
                "reason": "No rule's complete explicit assumptions were supplied",
            }
        candidates = applicable
    if len(candidates) != 1:
        return {
            "status": "AMBIGUOUS_RULE",
            "candidates": [record.knowledge_id for _, record in candidates],
        }
    pack, record = candidates[0]
    converted = {}
    for variable in record.content.variables:
        quantity = variable.value_type.quantity_type
        if quantity is None:
            return {
                "status": "NEEDS_NEW_CAPABILITY",
                "reason": "Rule has no reviewed quantity types",
            }
        canonical_unit = quantity.canonical_unit
        if canonical_unit is None or (
            canonical_unit.scale_numerator,
            canonical_unit.scale_denominator,
        ) != (1, 1):
            return {
                "status": "NEEDS_NEW_CAPABILITY",
                "reason": "Canonical SI rule required",
            }
        if variable.variable_id == request["unknown"]:
            continue
        supplied = request["known"][variable.variable_id]
        if (
            type(supplied) is not dict
            or set(supplied) != {"value", "unit"}
            or not _bounded_number(supplied["value"])
        ):
            return {
                "status": "INVALID_REQUEST",
                "reason": "Every known value requires a number and explicit unit",
            }
        try:
            dimension, scale = parse_unit(supplied["unit"])
        except ValueError:
            return {"status": "UNSUPPORTED_UNIT", "variable": variable.variable_id}
        if dimension != variable.value_type.quantity_type.dimension:
            return {"status": "UNIT_MISMATCH", "variable": variable.variable_id}
        value = Fraction(str(supplied["value"])) * scale
        converted[variable.variable_id] = str(value)
    conditions = {term_key(value) for value in request["conditions"]}
    required = tuple(
        dict.fromkeys(
            (
                *record.content.applicability.preconditions,
                *record.content.applicability.assumptions,
            )
        )
    )
    if not {term_key(value) for value in required} <= conditions:
        return {
            "status": "APPLICABILITY_REQUIRED",
            "required_conditions": list(required),
        }
    result = service._solve(
        pack,
        record,
        {
            "known": converted,
            "unknown": request["unknown"],
            "conditions": list(required),
        },
    )
    if result["status"] != "SOLVED_EXACT":
        return result
    answer = _answer(
        pack,
        (record,),
        "SOLVED_EXACT",
        result["value"],
        (
            {
                "operation": "validate units and convert inputs to canonical SI",
                "known": converted,
            },
            {
                "operation": "apply installed reviewed equation",
                "rule_id": record.knowledge_id,
            },
            {"operation": "verify exact solution under explicit assumptions"},
        ),
    )
    answer["assumptions"] = list(required)
    dimensions = result["value"]["dimension"]
    if dimensions is not None:
        base_symbols = ("m", "kg", "s", "A", "K", "mol", "cd")
        positive = [
            symbol + (f"^{power}" if power != 1 else "")
            for symbol, power in zip(base_symbols, dimensions, strict=True)
            if power > 0
        ]
        negative = [
            symbol + (f"^{-power}" if power != -1 else "")
            for symbol, power in zip(base_symbols, dimensions, strict=True)
            if power < 0
        ]
        answer["value"]["unit"] = ("*".join(positive) or "1") + "".join(
            "/" + value for value in negative
        )
    answer["answer_mode"] = "EXACT_CONDITIONAL_CALCULATION"
    return answer


@verified_request
def reason_installed(service, question, *, domain_id=None, arguments=None):
    if (
        type(question) is not str
        or not question.strip()
        or len(question) > 1024
        or domain_id is not None
        and (type(domain_id) is not str or not domain_id or len(domain_id) > 512)
    ):
        return {"status": "INVALID_REQUEST"}
    if re.match(
        r"\s*(?:execute|run|выполни|запусти)\b", question, re.IGNORECASE
    ) or re.match(
        r"\s*(?:compute|evaluate|calculate|вычисли)\s+"
        r"[A-Za-z_$][\w$]*(?:\.[A-Za-z_$][\w$]*)+\s*\(",
        question,
        re.IGNORECASE,
    ):
        return {
            "status": "NEEDS_NEW_CAPABILITY",
            "reason": "Source or procedure execution is not authorized",
        }
    if re.fullmatch(
        r"(?:determine\s+)?which\s+(?:interpretation|account)"
        r"(?:\s+of\s+[^?]{1,100})?\s+is independently true[?]?",
        question.strip(),
        re.IGNORECASE,
    ):
        return {
            "status": "NEEDS_NEW_CAPABILITY",
            "reason": "Installed attributed positions do not supply an independent truth verifier",
        }
    scenario = re.fullmatch(
        r"assess documented scenario for\s+([^?]{1,512})[?]?",
        question.strip(),
        re.IGNORECASE,
    )
    if scenario:
        try:
            packs = _packs(service, domain_id)
            answers = [
                assess_installed_scenario(pack, scenario[1].strip(), arguments)
                for pack in packs
            ]
            supported = [
                answer
                for answer in answers
                if answer["status"] != "INSUFFICIENT_EVIDENCE"
            ]
            if len(supported) > 1:
                return {"status": "AMBIGUOUS_DOMAIN"}
            return supported[0] if supported else {"status": "INSUFFICIENT_EVIDENCE"}
        except KeyError:
            return {"status": "DOMAIN_NOT_INSTALLED"}
        except OverflowError:
            return {"status": "RESOURCE_LIMIT"}
        except (ValueError, OSError):
            return {"status": "STALE_AUTHORITY"}
    try:
        conditional = parse_conditional_query(question)
        if conditional is None and re.match(
            r"\s*(?:what follows\b|if\b|given\b|does\b.*\bfollow\b|"
            r"что следует\b|если\b|дано\b|следует ли\b)",
            question,
            re.IGNORECASE,
        ):
            return {
                "status": "INVALID_REQUEST",
                "reason": "Unsupported conditional query; use complete explicit bounded clauses",
            }
        numeric = _numeric_request(question, arguments)
        intent = _intent(question)
        if conditional is not None and arguments is not None:
            return {
                "status": "INVALID_REQUEST",
                "reason": "Conditional and numeric arguments cannot be mixed",
            }
        if numeric is None and intent is None and conditional is None:
            return None
    except (ValueError, TypeError):
        return {
            "status": "INVALID_REQUEST",
            "reason": "Invalid numeric request or units",
        }
    try:
        packs = _packs(service, domain_id)
    except KeyError:
        return {"status": "DOMAIN_NOT_INSTALLED"}
    except OverflowError:
        return {"status": "RESOURCE_LIMIT"}
    except (ValueError, OSError):
        return {"status": "STALE_AUTHORITY"}
    try:
        if numeric is not None:
            return _solve(service, packs, numeric)
        answers = [
            answer
            for pack in packs
            if (
                answer := _conditional(pack, conditional)
                if conditional is not None
                else _structured(pack, *intent)
            )
            is not None
        ]
        if len(answers) > 1:
            return {
                "status": "AMBIGUOUS_DOMAIN",
                "domain_candidates": [answer["domain_id"] for answer in answers],
            }
        return (
            answers[0]
            if answers
            else (
                {
                    "status": "INSUFFICIENT_EVIDENCE",
                    "reason": "No reviewed source derivation; unknown is not false",
                }
                if conditional is not None
                else None
            )
        )
    except OverflowError:
        return {"status": "RESOURCE_LIMIT"}
    except (ValueError, KeyError, TypeError, ZeroDivisionError):
        # Malformed requests must not turn into successful source retrieval.
        return {
            "status": "INVALID_REQUEST",
            "reason": "Invalid request, units, or unsupported typed content",
        }
