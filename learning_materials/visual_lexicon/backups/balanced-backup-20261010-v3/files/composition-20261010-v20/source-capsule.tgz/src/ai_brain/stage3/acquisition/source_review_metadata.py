"""M33 relative source-review inventory, authenticated only by fresh replay.

No source IO, registry, global cache or hidden ambiguity-field authority. The
base M32 proposal representation is unchanged. Exactly one explicit extension
carries the whole ordered inventory, including originals with no reader rows.
"""

from __future__ import annotations

import json
from dataclasses import asdict

from ai_brain.stage2.facts.canonical import bytes_hash, canonical_json, content_hash
from ai_brain.stage3.acquisition.documentary_api_context import _json_work
from ai_brain.stage3.acquisition.models import (
    ExtractionMethod,
    KnowledgeProposal,
    M33SourceReviewProposal,
)
from ai_brain.stage3.domains import documentary_custody as custody
from ai_brain.stage3.knowledge_ir.records import (
    ConceptContent,
    EpistemicCharacter,
    KnowledgeKind,
)

ROLE = "M33_SOURCE_CONTEXT_REVIEW_V1"
MAX_METADATA_BYTES = 256 * 1024
MAX_VIEW_BYTES = 8 * 1024 * 1024
MAX_TOTAL_VIEW_BYTES = 32 * 1024 * 1024
CONTEXT_BODY_FIELDS = frozenset(
    {
        "inventory_index",
        "original_name",
        "raw_hash",
        "source_url",
        "format",
        "reader_profile",
        "decoder",
        "block_count",
        "view_hash",
        "processing_state",
    }
)
CONTEXT_FIELDS = CONTEXT_BODY_FIELDS | {"context_id"}
PREFIX = "DIRECT_SOURCE_EXCERPT_V1\n"


def _pairs(rows):
    result = {}
    for key, value in rows:
        if key in result:
            raise ValueError("Duplicate source-review JSON key")
        result[key] = value
    return result


def _number(value):
    raise ValueError("Noninteger source-review JSON number")


def parse_source_review_metadata(encoded):
    """Strict relative witness only; no caller metadata authenticates originals."""
    if type(encoded) is not str or not 0 < len(encoded) <= MAX_METADATA_BYTES:
        raise ValueError("Bounded exact source-review metadata string required")
    try:
        if len(encoded.encode("utf-8")) > MAX_METADATA_BYTES:
            raise ValueError("Source-review metadata UTF8 ceiling exceeded")
        _json_work(encoded)
        body = json.loads(
            encoded,
            object_pairs_hook=_pairs,
            parse_float=_number,
            parse_constant=_number,
        )
    except (UnicodeError, RecursionError, json.JSONDecodeError) as error:
        raise ValueError("Invalid source-review metadata JSON") from error
    if type(body) is not dict or set(body) != {
        "schema_version",
        "contract_role",
        "source_bundle_id",
        "inventory_hash",
        "contexts",
    }:
        raise ValueError("Exact source-review metadata fields required")
    if (
        type(body["schema_version"]) is not int
        or body["schema_version"] != 1
        or body["contract_role"] != ROLE
        or type(body["source_bundle_id"]) is not str
        or not 0 < len(body["source_bundle_id"]) <= 512
        or any(ord(char) < 32 for char in body["source_bundle_id"])
        or type(body["contexts"]) is not list
        or not 1 <= len(body["contexts"]) <= 64
    ):
        raise ValueError("Bounded source-review version/bundle/inventory required")
    names = set()
    for index, context in enumerate(body["contexts"]):
        if type(context) is not dict or set(context) != CONTEXT_FIELDS:
            raise ValueError("Exact eleven-field source-review context required")
        custody._integer(context["inventory_index"], 0, 63)
        if context["inventory_index"] != index:
            raise ValueError("Source-review original inventory order differs")
        # This only validates a declared profile's shape, never its authenticity.
        custody._context_shape(context, (context["reader_profile"],))
        if context["decoder"] != "reader-specific":
            raise ValueError("Source-review actual reader decoder required")
        name = context["original_name"].casefold()
        if name in names:
            raise ValueError("Duplicate source-review original name")
        names.add(name)
        actual = {key: value for key, value in context.items() if key != "context_id"}
        if context["context_id"] != content_hash(actual):
            raise ValueError("Source-review context identity differs")
    if (
        body["inventory_hash"] != content_hash(body["contexts"])
        or canonical_json(body) != encoded
    ):
        raise ValueError("Source-review canonical inventory differs")
    return body


def build_source_review_metadata(bundle_id, contexts):
    """Called with actual complete preparation reports/views, not selected rows."""
    if type(contexts) is not tuple or not 1 <= len(contexts) <= 64:
        raise ValueError("Optional source-review inventory ceiling exceeded")
    rows = []
    for context in contexts:
        if type(context) is not dict or set(context) != CONTEXT_BODY_FIELDS:
            raise ValueError("Exact source-review context identity body required")
        custody._context_shape(context, (context["reader_profile"],))
        rows.append({**context, "context_id": content_hash(context)})
    encoded = canonical_json(
        {
            "schema_version": 1,
            "contract_role": ROLE,
            "source_bundle_id": bundle_id,
            "inventory_hash": content_hash(rows),
            "contexts": rows,
        }
    )
    parse_source_review_metadata(encoded)
    return encoded


def validate_source_review_carrier(proposal):
    if (
        type(proposal) is not M33SourceReviewProposal
        or proposal.proposed_kind is not KnowledgeKind.CONCEPT
        or proposal.proposed_epistemic_character is not EpistemicCharacter.INTERPRETIVE
        or proposal.extraction_method is not ExtractionMethod.REVIEWED_MAPPING
        or type(proposal.proposed_content) is not ConceptContent
        or type(proposal.proposed_content.description_en) is not str
        or type(proposal.proposed_content.description_ru) is not str
        or not proposal.proposed_content.description_en.startswith(PREFIX)
        or proposal.proposed_content.description_ru
        != proposal.proposed_content.description_en
        or type(proposal.proposed_dependencies) is not tuple
        or proposal.proposed_dependencies != ()
        or type(proposal.proposed_applicability) is not tuple
        or proposal.proposed_applicability != ()
        or type(proposal.proposed_capabilities) is not tuple
        or proposal.proposed_capabilities != ()
    ):
        raise ValueError("Exact M33 direct-source review carrier required")
    body = parse_source_review_metadata(proposal.producer_review_metadata)
    if body["source_bundle_id"] != proposal.source_bundle_id:
        raise ValueError("Source-review carrier bundle differs")
    return body


def source_review_inventory(support):
    """Whole-map relative reconstruction; fresh compiler replay is mandatory."""
    if type(support) is not dict or not support or len(support) > 16384:
        raise ValueError("Complete bounded captured proposal map required")
    carriers = [
        proposal
        for proposal in support.values()
        if type(proposal) is M33SourceReviewProposal
    ]
    if len(carriers) != 1:
        raise ValueError("Exactly one source-review metadata carrier required")
    carrier = carriers[0]
    metadata = validate_source_review_carrier(carrier)
    direct = []
    total_bytes = 0
    for identity, proposal in support.items():
        if (
            type(proposal) not in {KnowledgeProposal, M33SourceReviewProposal}
            or identity != proposal.proposal_id
            or proposal.source_bundle_id != metadata["source_bundle_id"]
        ):
            raise ValueError("Captured proposal map identity/bundle differs")
        content = proposal.proposed_content
        if type(content) is not ConceptContent:
            continue
        if (
            type(content.description_en) is not str
            or type(content.description_ru) is not str
        ):
            raise ValueError("Captured concept descriptions require exact strings")
        if not content.description_en.startswith(PREFIX):
            continue
        if content.description_ru != content.description_en:
            raise ValueError("Captured direct-source language views differ")
        encoded = content.description_en[len(PREFIX) :]
        if len(encoded) >= MAX_VIEW_BYTES:
            raise ValueError("Captured source row exceeds original view ceiling")
        try:
            row_bytes = len(encoded.encode("utf-8")) + 1
            if row_bytes > MAX_VIEW_BYTES:
                raise ValueError(
                    "Captured source row exceeds original UTF8 view ceiling"
                )
            total_bytes += row_bytes
            if total_bytes > MAX_TOTAL_VIEW_BYTES:
                raise ValueError("Captured source inventory exceeds total view ceiling")
            _json_work(encoded)
        except UnicodeError as error:
            raise ValueError("Invalid captured source UTF8") from error
        body = asdict(proposal)
        digest = body.pop("proposal_hash")
        if (
            digest != content_hash(body)
            or type(proposal.segment_ids) is not tuple
            or len(proposal.segment_ids) != 1
        ):
            raise ValueError("Captured direct-source hash/segment differs")
        try:
            payload = json.loads(
                encoded,
                object_pairs_hook=_pairs,
                parse_float=_number,
                parse_constant=_number,
            )
        except (ValueError, RecursionError) as error:
            raise ValueError("Invalid captured documentary source payload") from error
        if type(payload) is not dict or canonical_json(payload) != encoded:
            raise ValueError("Exact canonical direct source payload required")
        direct.append((proposal, payload))
    if not direct or direct[0][0] is not carrier:
        raise ValueError("Carrier must be the first actual rendered original row")
    cursor, inventory = 0, []
    for context in metadata["contexts"]:
        rows = []
        view_bytes = 0
        for block in range(1, context["block_count"] + 1):
            if cursor >= len(direct):
                raise ValueError("Captured whole-original rows are missing")
            proposal, payload = direct[cursor]
            expected = {
                "file": context["original_name"],
                "original_bytes_hash": context["raw_hash"],
                "source_url": context["source_url"],
                "format": context["format"],
                "reader_profile": context["reader_profile"],
            }
            if (
                {key: payload.get(key) for key in expected} != expected
                or type(payload.get("block")) is not int
                or payload["block"] != block
                or proposal.segment_ids
                != (f"{metadata['source_bundle_id']}.segment.{cursor + 1:05d}",)
            ):
                raise ValueError("Captured ordered original row identity differs")
            rows.append((proposal, payload))
            view_bytes += len(canonical_json(payload).encode("utf-8")) + 1
            if view_bytes > MAX_VIEW_BYTES:
                raise ValueError("Captured original exceeds view ceiling")
            cursor += 1
        view = "".join(canonical_json(row) + "\n" for _, row in rows).encode("utf-8")
        if bytes_hash(view) != context["view_hash"]:
            raise ValueError("Captured complete original view differs")
        inventory.append((context, tuple(rows)))
    if cursor != len(direct):
        raise ValueError("Captured extra original rows differ")
    return tuple(inventory)
