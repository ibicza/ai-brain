"""Practical, explicit-review installation using the existing M-31/M-32 core.

Preparing material never installs it. The caller must approve the exact review
hash and a nonempty explicit proposal selection. Java source still requires its
specialized trust closure; documentation can use the structured-note pipeline.
"""

from __future__ import annotations

import re
from dataclasses import asdict
from pathlib import Path

from ai_brain.stage2.education.models import ActorIdentityType
from ai_brain.stage2.facts.canonical import canonical_json, content_hash, utc_now
from ai_brain.stage3.acquisition.compiler import compile_provisional_pack
from ai_brain.stage3.acquisition.models import (
    ProposalStatus,
    ReviewDecision,
    SegmentKind,
    SourceMediaType,
)
from ai_brain.stage3.acquisition.persistence import AcquisitionStore
from ai_brain.stage3.acquisition.proposals import propose_knowledge
from ai_brain.stage3.acquisition.review import review_proposal
from ai_brain.stage3.acquisition.segmentation import segment_bundle
from ai_brain.stage3.acquisition.sources import ingest_bundle
from ai_brain.stage3.acquisition.verification import verify_proposals
from ai_brain.stage3.capabilities.resolution import resolve_capability
from ai_brain.stage3.capabilities.scalar_equation_solver import NeedsNewCapability
from ai_brain.stage3.domains.approval import PackApprovalDecision, approve_pack
from ai_brain.stage3.domains.registry import InstalledDomainRegistry
from ai_brain.stage3.domains.validation import validate_pack
from ai_brain.stage3.knowledge_ir.version import UNIVERSAL_KNOWLEDGE_IR_SCHEMA_VERSION

_DOMAIN_ID = re.compile(r"[a-z][a-z0-9_.-]{2,95}\Z")
_REVIEW_ROLE = "M33_PRACTICAL_MATERIAL_REVIEW_V1"


def prepare_material(
    paths: tuple[Path, ...],
    *,
    domain_id: str,
    store_root: Path,
    pack_version: str = "0.1.0-provisional",
    timestamp: str | None = None,
) -> dict:
    if type(domain_id) is not str or not _DOMAIN_ID.fullmatch(domain_id):
        raise ValueError("invalid domain identity")
    store = AcquisitionStore.open_or_initialize(store_root)
    bundle = ingest_bundle(
        paths,
        bundle_id=domain_id,
        domain_tags=(domain_id,),
        imported_at=timestamp or utc_now(),
        store=store,
    )
    store.save_bundle(bundle)
    if any(
        document.media_type is SourceMediaType.JAVA_SOURCE
        for document in bundle.documents
    ):
        raise NeedsNewCapability(
            "NEEDS_NEW_CAPABILITY: raw Java requires the specialized semantic trust pipeline"
        )
    segments = segment_bundle(bundle, store)
    segment_set = store.save_segments(bundle.bundle_hash, segments)
    proposals = _material_proposals(bundle, segments, store)
    proposal_set = store.save_proposals(segment_set, proposals)
    body = _review_body(
        domain_id, pack_version, bundle, segment_set, proposal_set, proposals
    )
    return {**body, "review_hash": content_hash(body)}


def _material_proposals(bundle, segments, store):
    # The whole-document overview is not a second occurrence of its first
    # directive. Keep it in provenance, but extract from physical child spans.
    children = tuple(item for item in segments if item.kind is not SegmentKind.DOCUMENT)
    return verify_proposals(
        bundle, segments, propose_knowledge(bundle, children), store
    )


def _review_body(domain_id, pack_version, bundle, segment_set, proposal_set, proposals):
    return {
        "schema_version": 1,
        "contract_role": _REVIEW_ROLE,
        "domain_id": domain_id,
        "pack_version": pack_version,
        "bundle_object": content_hash(asdict(bundle)),
        "segments_object": segment_set,
        "proposals_object": proposal_set,
        "documents": [asdict(item) for item in bundle.documents],
        "proposals": [asdict(item) for item in proposals],
        "installed": False,
    }


def install_reviewed_material(
    review: dict,
    *,
    expected_review_hash: str,
    approved_proposal_ids: tuple[str, ...],
    reviewer_identity: str,
    store_root: Path,
    pack_output: Path,
    registry: InstalledDomainRegistry,
    reviewer_type: ActorIdentityType = ActorIdentityType.USER,
    timestamp: str | None = None,
) -> dict:
    """Install an explicitly selected, exact review; never approve by default."""
    if type(review) is not dict or set(review) != {
        "schema_version",
        "contract_role",
        "domain_id",
        "pack_version",
        "bundle_object",
        "segments_object",
        "proposals_object",
        "documents",
        "proposals",
        "installed",
        "review_hash",
    }:
        raise ValueError("material review fields changed")
    if (
        type(review["schema_version"]) is not int
        or review["schema_version"] != 1
        or review["contract_role"] != _REVIEW_ROLE
        or review["installed"] is not False
        or any(
            type(review[name]) is not str
            for name in (
                "domain_id",
                "pack_version",
                "bundle_object",
                "segments_object",
                "proposals_object",
                "review_hash",
            )
        )
        or review["review_hash"] != expected_review_hash
        or content_hash(
            {key: value for key, value in review.items() if key != "review_hash"}
        )
        != expected_review_hash
    ):
        raise ValueError("material review hash or authority changed")
    if (
        type(reviewer_identity) is not str
        or not reviewer_identity.strip()
        or reviewer_type
        not in {ActorIdentityType.USER, ActorIdentityType.TRUSTED_PROCESS}
        or type(approved_proposal_ids) is not tuple
        or not approved_proposal_ids
        or any(type(item) is not str for item in approved_proposal_ids)
        or len(set(approved_proposal_ids)) != len(approved_proposal_ids)
    ):
        raise ValueError("explicit reviewer and unique nonempty selection required")
    if registry.capability_registry is None or registry.provider_registry is None:
        raise ValueError("current capability and provider authority required")
    # Loading must not create a new store or replace missing evidence.
    if not store_root.is_dir():
        raise FileNotFoundError("material evidence store is missing")
    store = AcquisitionStore(store_root)
    store.verify()
    bundle = store.load_bundle(review["bundle_object"])
    segments = store.load_segments(review["segments_object"])
    saved = store.load_proposals(review["proposals_object"])
    # Regenerate from immutable snapshots, not a caller-edited proposal display.
    proposals = _material_proposals(bundle, segments, store)
    if proposals != saved or bundle.bundle_id != review["domain_id"]:
        raise ValueError("material proposals differ from immutable source")
    expected_body = _review_body(
        review["domain_id"],
        review["pack_version"],
        bundle,
        review["segments_object"],
        review["proposals_object"],
        proposals,
    )
    if canonical_json(expected_body) != canonical_json(
        {key: value for key, value in review.items() if key != "review_hash"}
    ):
        raise ValueError("material review differs from immutable source")
    by_id = {item.proposal_id: item for item in proposals}
    if not set(approved_proposal_ids) <= set(by_id) or any(
        by_id[identity].status is not ProposalStatus.VERIFIED
        for identity in approved_proposal_ids
    ):
        raise ValueError(
            "only structurally verified proposals can use this review path"
        )
    return _compile_reviewed_selection(
        bundle,
        segments,
        tuple(by_id[identity] for identity in approved_proposal_ids),
        expected_review_hash=expected_review_hash,
        reviewer_identity=reviewer_identity,
        reviewer_type=reviewer_type,
        pack_output=pack_output,
        pack_version=review["pack_version"],
        registry=registry,
        store=store,
        timestamp=timestamp,
    )


def _compile_reviewed_selection(
    bundle,
    segments,
    proposals,
    *,
    expected_review_hash,
    reviewer_identity,
    reviewer_type,
    pack_output,
    pack_version,
    registry,
    store,
    timestamp=None,
    documentary_closure=None,
):
    """Shared compiler/approval/install path after exact source-bound review."""
    if registry.capability_registry is None or registry.provider_registry is None:
        raise ValueError("current capability and provider authority required")
    stamp = timestamp or utc_now()
    updated, approvals = [], []
    for selected_proposal in proposals:
        proposal, _, approval = review_proposal(
            selected_proposal,
            reviewer_identity=reviewer_identity,
            reviewer_type=reviewer_type,
            decision=ReviewDecision.APPROVE,
            rationale=f"Explicit material review {expected_review_hash}",
            timestamp=stamp,
        )
        updated.append(proposal)
        approvals.append(approval)
    pack = compile_provisional_pack(
        bundle,
        segments,
        tuple(updated),
        tuple(approvals),
        pack_output,
        domain_id=bundle.bundle_id,
        pack_version=pack_version,
        store=store,
        documentary_closure=documentary_closure,
    )
    resolutions = {}
    for requirement in pack.manifest.required_capabilities:
        resolution = resolve_capability(
            registry.capability_registry,
            requirement,
            requesting_domain_id=pack.manifest.domain_id,
            requesting_pack_hash=pack.manifest.pack_content_hash,
            provider_registry=registry.provider_registry,
            resolved_at=stamp,
        )
        if resolution.receipt is None:
            raise ValueError(f"NEEDS_NEW_CAPABILITY: {requirement.capability_id}")
        for receipt in resolution.closure_receipts:
            resolutions[receipt.receipt_hash] = receipt
    receipts = tuple(resolutions.values())
    approval = approve_pack(
        pack_hash=pack.manifest.pack_content_hash,
        knowledge_ir_schema=UNIVERSAL_KNOWLEDGE_IR_SCHEMA_VERSION,
        concept_graph_hash=pack.manifest.concept_graph_hash,
        source_binding_hashes=pack.manifest.source_binding_hashes,
        capability_resolution_receipt_hashes=tuple(
            item.receipt_hash for item in receipts
        ),
        validation_report_hash=content_hash(validate_pack(pack)),
        evaluation_manifest_hash=pack.manifest.evaluation_manifest_hash,
        reviewer_identity=reviewer_identity,
        reviewer_type=reviewer_type,
        decision=PackApprovalDecision.APPROVE,
        policy_version="m33-practical-explicit-review-v1",
        timestamp=stamp,
    )
    installed = registry.install(pack, approval, receipts, installed_at=stamp)
    return {
        "status": "INSTALLED",
        "domain_id": installed.domain_id,
        "pack_version": installed.pack_version,
        "pack_hash": installed.pack_hash,
        "installation_receipt_hash": installed.installation_receipt_hash,
        "review_hash": expected_review_hash,
        "approved_record_count": len(pack.knowledge_records),
    }
