"""Fresh original-byte reader replay and exact compiled documentary lineage.

This reconstructs documentary rendering, not semantic proposal meaning. It never
reads acquisition storage at runtime, executes source, or follows source URLs.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass

from ai_brain.stage2.facts.canonical import canonicalize
from ai_brain.stage3.domains import documentary_custody as custody

EXCERPT_PREFIX = "DIRECT_SOURCE_EXCERPT_V1\n"
EXCERPT_SCOPE = "DOCUMENTARY_EVIDENCE_NOT_EXECUTION_AUTHORITY"
MAX_VIEW_BYTES = 8 * 1024 * 1024


def custody_profile():
    """Shared production contract fingerprint; no semantic-profile recursion."""
    return custody.custody_profile()


def _source(source):
    if type(source) is not dict or set(source) != {
        "name",
        "original_bytes_hash",
        "source_url",
    }:
        raise ValueError("exact original source identity required")
    custody._hash(source["original_bytes_hash"])
    name, url = source["name"], source["source_url"]
    if (
        type(name) is not str
        or not 1 <= len(name) <= 256
        or name.startswith(("/", "\\"))
        or "\\" in name
        or ":" in name
        or any(part in {"", ".", ".."} for part in name.split("/"))
        or any(ord(char) < 32 for char in name)
    ):
        raise ValueError("invalid inert source name")
    if url is not None and (
        type(url) is not str
        or not 1 <= len(url) <= 4096
        or any(ord(char) < 32 for char in url)
    ):
        raise ValueError("invalid inert source URL")
    custody._canonical_size(name)
    custody._canonical_size(url)


def documentary_payload(source, report, ordinal, profile):
    """Exactly the historical payload builder: no field omission/normalization."""
    _source(source)
    custody._hash(profile)
    if (
        type(report) is not dict
        or set(report) != {"format", "blocks", "issues"}
        or type(report["format"]) is not str
        or report["format"] not in custody._FORMATS
        or type(report["blocks"]) is not list
        or type(report["issues"]) is not list
        or type(ordinal) is not int
        or not 1 <= ordinal <= len(report["blocks"])
    ):
        raise ValueError("invalid exact reader report/block ordinal")
    block = report["blocks"][ordinal - 1]
    base = {
        "schema_version": 1,
        "scope": EXCERPT_SCOPE,
        "file": source["name"],
        "original_bytes_hash": source["original_bytes_hash"],
        "source_url": source["source_url"],
        "format": report["format"],
        "reader_profile": profile,
        "block": ordinal,
    }
    if (
        type(block) is not dict
        or set(block) & set(base)
        or type(block.get("text")) is not str
    ):
        raise ValueError("reader block cannot override source identity")
    return {**base, **block}


def _canonical_hash(value, budget):
    value = canonicalize(value)
    size = custody._canonical_size(value)
    budget.reserve(canonical_hash=size, payload=size)
    return custody.digest(custody._encoded(value))


def _view(source, report, profile, budget):
    if type(report) is not dict or type(report.get("blocks")) is not list:
        raise ValueError("invalid current reader report")
    custody._size(len(report["blocks"]), 0, 8192)
    values = tuple(
        documentary_payload(source, report, ordinal, profile)
        for ordinal in range(1, len(report["blocks"]) + 1)
    )
    total = sum(custody._canonical_size(value) + 1 for value in values)
    custody._size(total, 0, MAX_VIEW_BYTES)
    # Existing reader has already allocated its internally bounded blocks. This
    # reservation precedes full canonical view materialization, NOT reader internals.
    budget.reserve(replay_output=total, payload=3 * total, raw_hash=total)
    lines = tuple(custody._encoded(value) + b"\n" for value in values)
    view = b"".join(lines)
    return view, lines, custody.digest(view)


def _reader(raw, name, budget):
    from ai_brain.stage3.acquisition.document_readers import read_document

    budget.reserve(context=len(raw))
    # In particular empty raw retains the actual reader's ValueError refusal.
    return read_document(raw, name)


def build_documentary_closure(raw_sources, store, *, budget=None):
    """Build after original review replay, before selection; no source omission."""
    from ai_brain.stage3.acquisition.document_readers import reader_profile
    from ai_brain.stage3.acquisition.persistence import AcquisitionStore

    if (
        type(raw_sources) not in (list, tuple)
        or not raw_sources
        or type(store) is not AcquisitionStore
    ):
        raise ValueError("complete original inventory/acquisition store required")
    budget = custody.QueryBudget() if budget is None else budget
    custody._budget(
        budget, budget.limits if type(budget) is custody.QueryBudget else None
    )
    custody._size(len(raw_sources), 1, budget.limits.contexts)
    names, paths, work = set(), {}, 0
    # Preflight ALL source lengths before allocating any raw source buffer.
    for source in raw_sources:
        _source(source)
        if source["name"].casefold() in names:
            raise ValueError("duplicate original source context")
        names.add(source["name"].casefold())
        path = (
            store.blob_root
            / source["original_bytes_hash"][:2]
            / source["original_bytes_hash"]
        )
        custody._checked_directory(path.parent)
        info = path.lstat()
        custody._not_reparse(info)
        import stat

        if not stat.S_ISREG(info.st_mode):
            raise ValueError("nonregular acquisition source blob")
        custody._size(info.st_size, 0, budget.limits.container_bytes)
        work += info.st_size
        custody._size(work, 0, budget.limits.context_work_bytes)
        paths[source["original_bytes_hash"]] = path
    blobs = {}
    for raw_hash, path in paths.items():
        raw = custody.read_regular_bytes(
            path, maximum=budget.limits.container_bytes, budget=budget
        )
        budget.reserve(raw_hash=len(raw))
        if custody.digest(raw) != raw_hash:
            raise ValueError("original source CAS digest changed")
        blobs[raw_hash] = raw
    profile = reader_profile()
    inputs = []
    for source in raw_sources:
        raw = blobs[source["original_bytes_hash"]]
        report = _reader(raw, source["name"], budget)
        _, _, view_hash = _view(source, report, profile, budget)
        inputs.append(
            custody.InputContext(
                raw,
                source["name"],
                report["format"],
                "reader-specific",
                profile,
                len(report["blocks"]),
                view_hash,
                "DERIVED_DOCUMENT" if report["blocks"] else "NO_DOCUMENT_BLOCKS",
                source["source_url"],
            )
        )
    return custody.build_closure(
        tuple(inputs),
        pinned_reader_profiles=(profile,),
        limits=budget.limits,
        budget=budget,
    )


@dataclass(frozen=True)
class ReplayedSegment:
    segment: object
    document_hash: str
    view_hash: str
    canonical_payload: str
    context_id: str


def _reconstruct(pack, descriptor, container, budget):
    from ai_brain.stage3.acquisition.document_readers import reader_profile
    from ai_brain.stage3.acquisition.models import (
        DocumentStructure,
        SegmentKind,
        SourceDocument,
        SourceLocation,
        SourceMediaType,
        SourceSegment,
    )

    profile = reader_profile()
    slices = {source.raw_hash: source for source in descriptor.sources}
    result, segment_ordinal = [], 0
    for context in descriptor.contexts:
        if context.reader_profile != profile or context.decoder != "reader-specific":
            raise ValueError("current reader profile/context differs")
        source_slice = slices.get(context.raw_hash)
        if source_slice is None:
            raise ValueError("context source membership missing")
        size = source_slice.byte_end - source_slice.byte_start
        budget.reserve(payload=size)
        raw = memoryview(container)[
            source_slice.byte_start : source_slice.byte_end
        ].tobytes()
        source = {
            "name": context.original_name,
            "original_bytes_hash": context.raw_hash,
            "source_url": context.source_url,
        }
        report = _reader(raw, context.original_name, budget)
        view, lines, view_hash = _view(source, report, profile, budget)
        state = "DERIVED_DOCUMENT" if report["blocks"] else "NO_DOCUMENT_BLOCKS"
        if (
            report["format"] != context.format
            or len(report["blocks"]) != context.block_count
            or view_hash != context.view_hash
            or state != context.processing_state
        ):
            raise ValueError("fresh reader whole-view/context mismatch")
        if not lines:
            continue
        structure_body = {
            "heading_count": 0,
            "table_count": 0,
            "code_block_count": 0,
            "page_count": None,
        }
        structure = DocumentStructure(
            **structure_body, structure_hash=_canonical_hash(structure_body, budget)
        )
        document_body = {
            "document_id": f"{pack.manifest.domain_id}.document.{context.inventory_index + 1:03d}",
            "media_type": SourceMediaType.TEXT,
            "language": "mixed",
            "relative_path": context.original_name + ".documentation-view.txt",
            "bytes_hash": view_hash,
            "canonical_text_hash": view_hash,
            "source_metadata": (
                ("original_name", context.original_name),
                ("original_bytes_hash", context.raw_hash),
                ("scope", "DOCUMENTATION_VIEW_ONLY"),
                ("reader_profile", profile),
            ),
            "imported_at": pack.manifest.created_at,
            "version": pack.manifest.pack_version,
            "parent_bundle_id": pack.manifest.domain_id,
            "structure": structure,
        }
        document = SourceDocument(
            **document_body, document_hash=_canonical_hash(document_body, budget)
        )
        # Canonical text decode has a conservative known payload envelope; not
        # a promise about Python object/allocator process peak memory.
        budget.reserve(payload=4 * len(view), raw_hash=len(view))
        offset = 0
        for ordinal, line in enumerate(lines, 1):
            text = line.decode("utf-8").rstrip("\n")
            segment_body = {
                "segment_id": f"{pack.manifest.domain_id}.segment.{segment_ordinal + 1:05d}",
                "bundle_id": pack.manifest.domain_id,
                "document_id": document.document_id,
                "kind": SegmentKind.PARAGRAPH,
                "ordinal": segment_ordinal,
                "canonical_text": text,
                "source_location": SourceLocation(
                    offset, offset + len(line), ordinal, ordinal, ()
                ),
                "source_span_hash": custody.digest(line),
            }
            segment = SourceSegment(
                **segment_body, segment_hash=_canonical_hash(segment_body, budget)
            )
            result.append(
                ReplayedSegment(
                    segment, document.document_hash, view_hash, text, context.context_id
                )
            )
            segment_ordinal += 1
            offset += len(line)
    return tuple(result)


def _hash_tuple(value):
    if type(value) is not tuple or not value:
        raise ValueError("nonempty exact lineage hash tuple required")
    for item in value:
        custody._hash(item)


def replay_documentary_closure(
    pack, descriptor, container, *, budget, retain_context=False
):
    """Match all compiled lineage and retained payloads after held-byte verification.

    Called by verify_pack_custody after descriptor/container checks. This does
    NOT replay semantic extraction or prove content propositions/definitions.
    """
    from ai_brain.stage3.domains.manifest import SourceBinding
    from ai_brain.stage3.knowledge_ir.records import ConceptContent, KnowledgeRecord

    if type(retain_context) is not bool:
        raise ValueError("context retention must be an exact boolean")
    custody._budget(
        budget, budget.limits if type(budget) is custody.QueryBudget else None
    )
    if type(descriptor) is not custody.Descriptor or type(container) is not bytes:
        raise ValueError("validated immutable closure buffers required")
    replayed = _reconstruct(pack, descriptor, container, budget)
    segments = {item.segment.segment_hash: item for item in replayed}
    payloads = {}
    for item in replayed:
        payloads.setdefault(item.canonical_payload, []).append(item)
    if len(segments) != len(replayed):
        raise ValueError("ambiguous replayed segment identity")
    if (
        type(pack.source_bindings) is not tuple
        or type(pack.knowledge_records) is not tuple
    ):
        raise ValueError("exact pack records/source bindings required")
    bindings = {}
    for binding in pack.source_bindings:
        if (
            type(binding) is not SourceBinding
            or type(binding.binding_id) is not str
            or not binding.binding_id
        ):
            raise ValueError("exact documentary source binding required")
        if binding.binding_id in bindings:
            raise ValueError("duplicate source binding identity")
        bindings[binding.binding_id] = binding
    used, record_ids = set(), set()
    for record in pack.knowledge_records:
        if (
            type(record) is not KnowledgeRecord
            or type(record.knowledge_id) is not str
            or not record.knowledge_id
            or record.knowledge_id in record_ids
            or type(record.provenance_refs) is not tuple
            or len(record.provenance_refs) != 1
            or type(record.provenance_refs[0]) is not str
            or not record.provenance_refs[0]
        ):
            raise ValueError("exact one-binding compiled record required")
        record_ids.add(record.knowledge_id)
        binding = bindings.get(record.provenance_refs[0])
        if binding is None:
            raise ValueError("record source binding missing")
        used.add(binding.binding_id)
        for values in (
            binding.segment_hashes,
            binding.document_hashes,
            binding.evidence_hashes,
            binding.source_hashes,
        ):
            _hash_tuple(values)
        if (
            type(binding.fact_memory_refs) is not tuple
            or binding.fact_memory_refs
            or type(binding.claim_refs) is not tuple
            or binding.claim_refs
            or type(binding.derivation_hashes) is not tuple
            or binding.derivation_hashes
        ):
            raise ValueError("specialized authority is not documentary lineage")
        bound = tuple(segments.get(value) for value in binding.segment_hashes)
        if not bound or any(item is None for item in bound):
            raise ValueError(
                "binding segment is not from full fresh original inventory"
            )
        fields = sorted(asdict(record.content))
        expected_docs = tuple(sorted({item.document_hash for item in bound}))
        expected_evidence = tuple(item.segment.source_span_hash for item in bound)
        expected_sources = tuple(item.view_hash for item in bound)
        expected_fields = tuple(
            (f"content.{field}", item.segment.source_span_hash)
            for item in bound
            for field in fields
        )
        if (
            binding.document_hashes != expected_docs
            or binding.evidence_hashes != expected_evidence
            or binding.source_hashes != expected_sources
            or type(binding.field_evidence) is not tuple
            or binding.field_evidence != expected_fields
            or binding.source_chain_hash
            != _canonical_hash(
                (expected_docs, binding.segment_hashes, expected_fields), budget
            )
            or binding.binding_hash
            != _canonical_hash(
                {
                    key: value
                    for key, value in asdict(binding).items()
                    if key != "binding_hash"
                },
                budget,
            )
        ):
            raise ValueError("compiled documentary source/field chain differs")
        content = record.content
        if type(content) is ConceptContent:
            descriptions = (content.description_ru, content.description_en)
            if any(type(value) is not str for value in descriptions):
                raise ValueError("exact concept descriptions required")
            marked = tuple(value.startswith(EXCERPT_PREFIX) for value in descriptions)
            if any(marked):
                if not all(marked) or descriptions[0] != descriptions[1]:
                    raise ValueError("retained excerpt languages/payload differ")
                text = descriptions[0][len(EXCERPT_PREFIX) :]
                matches = payloads.get(text, ())
                if len(matches) != 1 or len(bound) != 1 or matches[0] != bound[0]:
                    raise ValueError(
                        "retained excerpt is not exact unambiguous fresh source payload"
                    )
                # Payload is already exact fresh JSON. This label is likewise a
                # documentary locator, never an extracted semantic term identity.
                import json

                payload = json.loads(text)
                label = f"source {payload['file']} block {payload['block']} {payload['original_bytes_hash'][:12]}"
                if (
                    content.canonical_name_ru != label
                    or content.canonical_name_en != label
                ):
                    raise ValueError("retained excerpt documentary locator differs")
    if used != set(bindings):
        raise ValueError("unused source bindings outside documentary record closure")
    if retain_context:
        # Retain references to ALREADY replayed strings, including unselected
        # blocks. Context IDs distinguish original inventories, not just hashes.
        # This is derived request-local evidence, never serialized authority.
        # Reservation bounds planned reference/tuple storage, not process peak.
        budget.reserve(payload=128 * len(replayed))
        return tuple((item.context_id, item.canonical_payload) for item in replayed)
    return None
