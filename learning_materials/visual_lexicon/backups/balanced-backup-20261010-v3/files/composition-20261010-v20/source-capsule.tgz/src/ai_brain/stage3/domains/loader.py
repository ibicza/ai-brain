from __future__ import annotations

import json
from pathlib import Path

from ai_brain.stage3.capabilities.models import CapabilityRequirement
from ai_brain.stage3.domains.aliases import (
    ALIAS_SEMANTICS_DEPENDENCY_PREFIX,
    ALIAS_SEMANTICS_FILENAME,
    AliasSemantics,
    AuthoritativeIdentity,
    ExactReferenceAlias,
    SearchAliasEntry,
    verify_alias_semantics,
)
from ai_brain.stage3.domains.manifest import *
from ai_brain.stage3.domains.pack import *
from ai_brain.stage3.domains.pack_io import capture_pack
from ai_brain.stage3.domains.request_verification import current_request
from ai_brain.stage3.domains.validation import validate_pack
from ai_brain.stage3.knowledge_ir.serialization import load_record

_FILES = {
    "manifest.json",
    "knowledge.jsonl",
    "concept_graph.json",
    "exercise_families.json",
    "capability_requirements.json",
    "adapter_bindings.json",
    "evaluation_manifest.json",
    "source_bindings.json",
    "pack_manifest.json",
}


def load_pack(root: Path, *, _snapshot=None, budget=None) -> DomainPack:
    from ai_brain.stage3.domains.documentary_custody import QueryBudget

    scope = current_request()
    budget = budget or (scope.budget if scope is not None else QueryBudget())
    snapshot = capture_pack(root, budget=budget) if _snapshot is None else _snapshot
    snapshot.assert_current()
    root, files = snapshot.root, snapshot.files
    names = set(files)
    missing = _FILES - names
    if missing:
        raise ValueError(f"domain pack files missing: {sorted(missing)}")
    unexpected = names - (
        _FILES
        | {
            "approval.json",
            "java_evidence_closure.json",
            "java_production_closure.json",
            ALIAS_SEMANTICS_FILENAME,
            "documentary_source_closure.json",
            "documentary_source_bytes.bin",
        }
    )
    if unexpected:
        raise ValueError(f"unexpected domain pack files: {sorted(unexpected)}")

    def read(name):
        raw = files[name]
        budget.reserve(payload=4 * len(raw))
        return _read_bytes(raw)

    manifest_row = read("manifest.json")
    requirements = tuple(
        CapabilityRequirement(**x) for x in read("capability_requirements.json")
    )
    manifest = DomainPackManifest(
        **{
            **manifest_row,
            "supported_languages": tuple(manifest_row["supported_languages"]),
            "subject_tags": tuple(manifest_row["subject_tags"]),
            "knowledge_record_hashes": tuple(manifest_row["knowledge_record_hashes"]),
            "exercise_family_hashes": tuple(manifest_row["exercise_family_hashes"]),
            "source_binding_hashes": tuple(manifest_row["source_binding_hashes"]),
            "required_capabilities": requirements,
            "adapter_binding_hashes": tuple(manifest_row["adapter_binding_hashes"]),
            "dependency_packs": tuple(manifest_row["dependency_packs"]),
        }
    )
    java_dependencies = tuple(
        item
        for item in manifest.dependency_packs
        if item.startswith(("java-evidence-closure.", "java-production-closure."))
    )
    java_artifacts = sum(
        name in files
        for name in ("java_evidence_closure.json", "java_production_closure.json")
    )
    if java_artifacts != len(java_dependencies) or len(java_dependencies) > 1:
        raise ValueError("Java evidence closure dependency mismatch")
    alias_dependencies = tuple(
        item
        for item in manifest.dependency_packs
        if item.startswith(ALIAS_SEMANTICS_DEPENDENCY_PREFIX)
    )
    if (
        len(alias_dependencies) != int(ALIAS_SEMANTICS_FILENAME in files)
        or len(alias_dependencies) > 1
    ):
        raise ValueError("pack alias-semantics dependency mismatch")
    budget.reserve(payload=4 * len(files["knowledge.jsonl"]))
    lines = files["knowledge.jsonl"].decode("utf-8").splitlines()
    if len(lines) > 100_000 or any(
        len(line.encode("utf-8")) > 4 * 1024 * 1024 for line in lines
    ):
        raise ValueError("knowledge JSONL exceeds resource policy")
    records = tuple(load_record(line) for line in lines if line.strip())
    graph_row = read("concept_graph.json")
    graph = ConceptGraph(
        tuple(ConceptNode(**x) for x in graph_row["nodes"]),
        tuple(
            ConceptEdge(**{**x, "kind": ConceptEdgeKind(x["kind"])})
            for x in graph_row["edges"]
        ),
        graph_row["schema_version"],
        graph_row["graph_hash"],
    )
    families = tuple(
        ExerciseFamilyBinding(
            **{
                **x,
                "concept_ids": tuple(x["concept_ids"]),
                "required_capabilities": tuple(x["required_capabilities"]),
                "difficulty_structure": tuple(x["difficulty_structure"]),
            }
        )
        for x in read("exercise_families.json")
    )
    adapters = tuple(
        AdapterBinding(
            **{
                **x,
                "capability_ids": tuple(x["capability_ids"]),
                "allowed_contexts": tuple(x["allowed_contexts"]),
                "compatible_pack_versions": tuple(x["compatible_pack_versions"]),
            }
        )
        for x in read("adapter_bindings.json")
    )
    sources = tuple(
        SourceBinding(
            **{
                **x,
                "fact_memory_refs": tuple(x["fact_memory_refs"]),
                "claim_refs": tuple(x["claim_refs"]),
                "evidence_hashes": tuple(x["evidence_hashes"]),
                "source_hashes": tuple(x["source_hashes"]),
                "derivation_hashes": tuple(x["derivation_hashes"]),
                "document_hashes": tuple(x["document_hashes"]),
                "segment_hashes": tuple(x["segment_hashes"]),
                "field_evidence": tuple(tuple(item) for item in x["field_evidence"]),
            }
        )
        for x in read("source_bindings.json")
    )
    alias_semantics = None
    if ALIAS_SEMANTICS_FILENAME in files:
        alias_row = read(ALIAS_SEMANTICS_FILENAME)
        alias_semantics = AliasSemantics(
            schema_version=alias_row["schema_version"],
            authoritative_identities=tuple(
                AuthoritativeIdentity(**item)
                for item in alias_row["authoritative_identities"]
            ),
            exact_references=tuple(
                ExactReferenceAlias(**item) for item in alias_row["exact_references"]
            ),
            search_aliases=tuple(
                SearchAliasEntry(
                    alias=item["alias"], record_ids=tuple(item["record_ids"])
                )
                for item in alias_row["search_aliases"]
            ),
            index_hash=alias_row["index_hash"],
        )
        if alias_dependencies != (
            ALIAS_SEMANTICS_DEPENDENCY_PREFIX + alias_semantics.index_hash,
        ):
            raise ValueError("pack binds another alias-semantics index")
        verify_alias_semantics(
            alias_semantics, tuple(item.knowledge_id for item in records)
        )
    value = DomainPack(
        str(root),
        manifest,
        records,
        graph,
        families,
        adapters,
        sources,
        read("evaluation_manifest.json"),
        alias_semantics,
    )
    validate_pack(value)
    # Supplemental M33 source-only classification replay, not a change to the
    # generic/pinned IR or provider validator. Import after package initialization.
    from ai_brain.stage3.acquisition.reported_context import (
        validate_reported_context_records,
    )

    validate_reported_context_records(
        value.knowledge_records, source_bindings=value.source_bindings
    )
    from dataclasses import replace

    from ai_brain.stage3.domains.documentary_custody import verify_pack_custody

    descriptor, contexts = verify_pack_custody(
        value, budget=budget, pack_files=files, retain_context=True
    )
    snapshot.assert_current()
    if descriptor is not None:
        value = replace(
            value, documentary_custody=descriptor, documentary_context=contexts
        )
    from ai_brain.stage3.domains.documentary_conditionals_v2 import (
        validate_installed_conditionals_v2,
    )

    validate_installed_conditionals_v2(value)
    from ai_brain.stage3.domains.documentary_api_policy import validated_api_policies

    validated_api_policies(value)
    from ai_brain.stage3.acquisition.documentary_scalar_policy import validate_installed as validate_scalar_units
    validate_scalar_units(value)
    pack_manifest = read("pack_manifest.json")
    if pack_manifest != {
        "domain_id": manifest.domain_id,
        "pack_content_hash": manifest.pack_content_hash,
        "pack_version": manifest.pack_version,
        "schema_version": manifest.schema_version,
    }:
        raise ValueError("outer pack manifest mismatch")
    return value


def _read(path: Path):
    return _read_bytes(path.read_bytes())


def _read_bytes(raw):
    def strict_object(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise ValueError("duplicate JSON key in domain pack")
            result[key] = value
        return result

    return json.loads(raw.decode("utf-8"), object_pairs_hook=strict_object)
