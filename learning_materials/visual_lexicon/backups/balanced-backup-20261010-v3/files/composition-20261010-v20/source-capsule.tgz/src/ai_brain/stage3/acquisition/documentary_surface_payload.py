"""Strict original-text replay for prospective literal v2 clause payloads.

This is a pure codec, not installation, source authority or a runtime route.
Caller-constructed frozen dataclasses never substitute for reparsing text.
"""

from __future__ import annotations

import json
from typing import Any

from ai_brain.stage3.acquisition import documentary_logic as v1
from ai_brain.stage3.acquisition.documentary_surface_logic import (
    LiteralClause,
    SurfaceSpan,
    parse_literal_clause_v2,
)

MAX_CLAUSE_PAYLOAD_CHARS = 8192


def _exact(left: Any, right: Any) -> bool:
    """Exact primitive tree equality; Python bool/int equality is not sufficient."""
    if type(left) is not type(right):
        return False
    if type(left) is dict:
        return left.keys() == right.keys() and all(
            _exact(left[key], right[key]) for key in left
        )
    if type(left) in {list, tuple}:
        return len(left) == len(right) and all(
            _exact(a, b) for a, b in zip(left, right, strict=True)
        )
    return type(left) in {str, int, bool, type(None)} and left == right


def _fields(clause: LiteralClause) -> dict[str, Any]:
    return {
        "schema_version": clause.schema_version,
        "text": clause.text,
        "identity": clause.identity,
        "polarity": clause.polarity,
        "form": clause.form,
        "spans": [
            {"role": span.role, "start": span.start, "end": span.end}
            for span in clause.spans
        ],
    }


def clause_payload(clause: LiteralClause) -> dict[str, Any]:
    """Serialize only an exactly reparsed component result, never arbitrary IR."""
    if (
        type(clause) is not LiteralClause
        or type(clause.spans) is not tuple
        or any(type(span) is not SurfaceSpan for span in clause.spans)
    ):
        raise ValueError("invalid literal clause container")
    parsed = parse_literal_clause_v2(clause.text)
    if parsed is None or not _exact(_fields(clause), _fields(parsed)):
        raise ValueError("literal clause does not match complete original text")
    return _fields(parsed)


def parse_clause_payload(payload: Any) -> LiteralClause:
    """Strict typed keys, witnesses and complete original text must all agree."""
    if type(payload) is str:
        if not 0 < len(payload) <= MAX_CLAUSE_PAYLOAD_CHARS:
            raise ValueError("literal clause payload exceeds bounds")
        try:
            payload = json.loads(payload, object_pairs_hook=v1._json_object)
        except (ValueError, RecursionError) as error:
            raise ValueError("invalid literal clause JSON") from error
    if type(payload) is not dict or set(payload) != {
        "schema_version",
        "text",
        "identity",
        "polarity",
        "form",
        "spans",
    }:
        raise ValueError("invalid literal clause payload fields")
    parsed = parse_literal_clause_v2(payload["text"])
    if parsed is None or not _exact(payload, _fields(parsed)):
        raise ValueError("literal clause fields differ from complete original text")
    return parsed


def canonical_clause_json(payload: Any) -> str:
    parsed = parse_clause_payload(payload)
    result = json.dumps(
        _fields(parsed), ensure_ascii=False, sort_keys=True, separators=(",", ":")
    )
    if len(result) > MAX_CLAUSE_PAYLOAD_CHARS:
        raise ValueError("canonical literal clause exceeds bounds")
    return result
