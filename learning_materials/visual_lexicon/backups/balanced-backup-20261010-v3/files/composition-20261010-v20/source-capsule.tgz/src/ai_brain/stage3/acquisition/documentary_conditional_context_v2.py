"""Prospective v2 parent/adjacent eligibility; no raw-custody authentication.

The same original/file/author/heading/member boundaries as v1 are retained.
Reader provenance and all original bytes still need trusted installed replay.
"""

from __future__ import annotations

import re
import unicodedata

from ai_brain.stage3.acquisition import documentary_logic as v1
from ai_brain.stage3.acquisition.documentary_conditional_v2 import (
    extract_conditionals_v2,
)


def _text(origin: dict) -> str:
    # A present but empty/malformed original field is not a reason to fall back
    # to a more convenient display. Absence is separate legacy reader metadata.
    text = origin.get("documentary_original_text", origin.get("text"))
    if type(text) is not str or len(text) > v1.MAX_SOURCE_CHARS:
        raise ValueError("invalid complete v2 original context")
    return text


def _file(origin: dict) -> str:
    value = origin.get("file")
    if (
        type(value) is not str
        or not value.strip()
        or len(value) > 4096
        or any(unicodedata.category(char) in {"Cc", "Cf", "Cs"} for char in value)
    ):
        raise ValueError("invalid v2 original file identity")
    return value


def extract_documentary_conditionals_v2(
    origin: dict,
    following_origin: dict | None = None,
    preceding_origin: dict | None = None,
) -> tuple[dict, ...]:
    scope = v1.documentary_scope(origin)
    file = _file(origin)
    text = _text(origin)
    for preceding, adjacent in ((False, following_origin), (True, preceding_origin)):
        if adjacent is None:
            continue
        if type(adjacent) is not dict:
            raise ValueError("unknown v2 adjacent context shape")
        # Unknown provenance is a failure, not an excuse to label a potentially
        # attached qualifier unrelated. Valid different scopes remain isolated.
        adjacent_scope = v1._documentary_provenance_scope(adjacent)
        adjacent_file = _file(adjacent)
        if adjacent_scope != scope or adjacent_file != file:
            continue
        if (
            adjacent.get("documentary_math_presence") is not False
            or adjacent.get("quotation") is not False
            or adjacent.get("documentary_role") != "PROSE"
        ):
            return ()
        adjacent_text = _text(adjacent)
        if (
            v1._qualified_parent(adjacent_text)
            or v1._INSTRUCTION.search(adjacent_text)
            or v1._QUOTED_DOCUMENT.search(adjacent_text)
        ):
            return ()
        sentences = re.findall(r"[^.!?]+[.!?]|[^.!?]+$", adjacent_text)
        guards = [sentences[-1] if sentences else ""] if preceding else [adjacent_text]
        if any(v1._QUALIFIER_START.search(guard.strip()) for guard in guards):
            return ()
    return extract_conditionals_v2(text, origin.get("source_author"))
