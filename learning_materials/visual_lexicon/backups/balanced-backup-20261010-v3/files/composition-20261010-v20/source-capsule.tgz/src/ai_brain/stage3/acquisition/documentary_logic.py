"""Bounded documentary conditionals, with exact clauses and hypothetical proofs.

This is deliberately a small grammar, not natural-language entailment. A source
rule is an assertion to review; its forward consequences are conditional on the
query assumptions, not empirical evidence. No program, synonym, converse,
contraposition, or closed-world negation is evaluated here.
"""

from __future__ import annotations

import hashlib
import json
import re
import unicodedata
from dataclasses import dataclass, replace
from typing import Any

from ai_brain.stage3.acquisition.documentary_clauses import contains_passive_report

DOCUMENTARY_CONDITIONAL_V1 = "DOCUMENTARY_CONDITIONAL_V1"
CONDITIONAL_PERSPECTIVE = DOCUMENTARY_CONDITIONAL_V1
SCHEMA_VERSION = 1
MAX_ASSUMPTIONS = 16
MAX_RULES = 128
MAX_CLOSURE = 64
MAX_DEPTH = 8
MAX_ATOM_CHARS = 512
MAX_SENTENCE_CHARS = 2048
MAX_QUERY_CHARS = 512
MAX_PAYLOAD_CHARS = 65536
MAX_SOURCE_CHARS = MAX_RULES * MAX_SENTENCE_CHARS

_FORBIDDEN = re.compile(
    r"\b(?:or|only|unless|except|may|might|could|can|must|should|would|shall|"
    r"sometimes|possibly|probably|approximately|every|all|any|some|none|never|"
    r"each|no|both|most|few|several|"
    r"either|neither|if|when|then|according|believed|claimed|reportedly|"
    r"because|since|although|though|whereas|while|until|before|after|"
    r"therefore|hence|provided|providing|assuming|whenever|wherever|whether|"
    r"likely|unlikely|perhaps|apparently|presumably|conceivably|necessarily|"
    r"или|либо|только|кроме|если|когда|то|может|могут|возможно|должен|"
    r"иногда|всегда|каждый|все|любой|некоторые|никогда|якобы|"
    r"поскольку|потому|поэтому|хотя|пока|прежде|после)\b",
    re.IGNORECASE,
)
_PRONOUN = re.compile(
    r"\b(?:it|its|they|them|their|he|him|his|she|her|we|our|you|your|"
    r"this|that|these|those|which|who|он|она|оно|они|его|ее|её|их|"
    r"это|этот|эта|эти|мы|вы|который|которая|которые)\b",
    re.IGNORECASE,
)
_INSTRUCTION = re.compile(
    r"\b(?:ignore|disregard|execute|eval|exec|import|__\w+__|system|assistant|"
    r"developer|prompt|instruction|instructions|override|pretend|return|"
    r"answer|respond|print|delete|run|sudo|powershell|"
    r"игнорируй|выполни|инструкции|инструкцию|системный|запусти)\b|"
    r"(?:https?://|javascript:|\$\(|</?script|```)",
    re.IGNORECASE,
)
_ILLEGAL = re.compile(
    r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f<>\[\]{}=\\`\"'“”‘’«»‹›]"
    r"|[^\S \t\r\n\u00a0]"
)
_CONJUNCTION = re.compile(r"\s+(and|и)\s+", re.IGNORECASE)
_PREDICATE = re.compile(
    r"\b(?:is|are|was|were|has|have|becomes|become|remains|remain|"
    r"opens|closes|glows|flashes|rings|activates|deactivates|starts|stops|"
    r"occurs|moves|rises|falls|exists|appears|disappears|holds|fails|"
    r"является|являются|имеет|имеют|становится|становятся|остается|остаётся|"
    r"открывается|закрывается|светится|горит|звенит|работает|существует)\b",
    re.IGNORECASE,
)
_NEGATION = re.compile(
    r"\b(?:is|are|was|were|has|have|will|do|does|did)\s+(not)\s+|\b(не)\s+",
    re.IGNORECASE,
)
# A finite surface grammar, not a guess about a verb's scientific meaning.
# Each form stays literal in Atom.text/identity; this table never lemmatizes a
# premise, predicts a program action, or equates present and future clauses.
_ACTION_FORMS = {
    "absorb": "absorbs",
    "activate": "activates",
    "appear": "appears",
    "close": "closes",
    "collect": "collects",
    "consume": "consumes",
    "contain": "contains",
    "convert": "converts",
    "create": "creates",
    "deactivate": "deactivates",
    "decrease": "decreases",
    "disappear": "disappears",
    "emit": "emits",
    "expand": "expands",
    "fall": "falls",
    "flash": "flashes",
    "gain": "gains",
    "generate": "generates",
    "glow": "glows",
    "increase": "increases",
    "lose": "loses",
    "maintain": "maintains",
    "move": "moves",
    "open": "opens",
    "produce": "produces",
    "receive": "receives",
    "reduce": "reduces",
    "release": "releases",
    "retain": "retains",
    "ring": "rings",
    "rise": "rises",
    "rotate": "rotates",
    "send": "sends",
    "start": "starts",
    "stop": "stops",
    "store": "stores",
    "transfer": "transfers",
    "transmit": "transmits",
    "travel": "travels",
    "turn": "turns",
    "use": "uses",
}
_INTRANSITIVE_ACTIONS = frozenset(
    {
        "activate",
        "appear",
        "close",
        "deactivate",
        "decrease",
        "disappear",
        "expand",
        "fall",
        "flash",
        "glow",
        "increase",
        "move",
        "open",
        "ring",
        "rise",
        "rotate",
        "start",
        "stop",
        "travel",
        "turn",
    }
)
_ACTION_BASE = {
    form: base for base, third in _ACTION_FORMS.items() for form in (base, third)
}
_PHRASE_WORD = re.compile(r"[A-Za-z][A-Za-z0-9]*(?:-[A-Za-z0-9]+)*\Z")
_PHRASE_RESERVED = frozenset(
    [
        "will",
        "do",
        "does",
        "did",
        "be",
        "is",
        "are",
        "was",
        "were",
        "has",
        "have",
        "not",
        "nor",
        "to",
        "for",
        "by",
        "as",
        "than",
        "so",
        "but",
        "with",
        "without",
        "in",
        "on",
        "at",
        "under",
        "within",
        "about",
        "from",
        "into",
        "over",
        "upon",
        "during",
        "through",
        "per",
        "of",
        "please",
        "kindly",
        "certainly",
        "actually",
        "really",
        "also",
        "just",
        "already",
        "still",
        "am",
        "been",
        "being",
        "having",
        "going",
        "saying",
        "says",
        "said",
        "claim",
        "claims",
        "report",
        "reports",
    ]
)
# Any uncertainty/reporting/restrictor in the same complete reader parent is
# unresolved context, not a fragment to discard while retaining a positive
# rule. Structural if/when/then and literal negation are intentionally absent.
_CONTEXT_LIMITER = re.compile(
    r"\b(?:only|unless|except|may|might|could|can|must|should|would|shall|"
    r"sometimes|possibly|probably|approximately|every|all|any|some|none|never|"
    r"each|both|most|few|several|either|neither|according|reportedly|"
    r"because|since|although|though|whereas|while|until|before|after|"
    r"provided|providing|assuming|whenever|wherever|whether|likely|unlikely|"
    r"perhaps|apparently|presumably|conceivably|necessarily|rarely|"
    r"только|кроме|может|могут|возможно|должен|иногда|всегда|каждый|все|"
    r"любой|некоторые|никогда|якобы|поскольку|потому|хотя|пока|прежде|после)\b",
    re.IGNORECASE,
)
_REPORTING_CONTEXT = re.compile(
    r"(?:^|[.!?]\s+)(?:[A-Za-z][A-Za-z0-9-]*[ \t]+){1,8}"
    r"(?:claims|claimed|reports|reported|says|said|believes|believed)\b"
    r"|\b(?:is|are|was|were|be|been)\s+(?:claimed|believed|reported|said)\b",
    re.IGNORECASE | re.MULTILINE,
)
_QUALIFIER_START = re.compile(
    r"^(?:unless|except|only|but|however|otherwise|кроме|только|однако|иначе)\b"
    r"|^(?:this|it|that|these|those|это|этот|эта|эти|"
    r"(?:the\s+)?(?:(?:following|preceding|previous|above)\s+)?"
    r"(?:rule|statement|claim|condition|conclusion|implication))\b.{0,2048}?\b"
    r"(?:not|no|only|unless|except|may|might|could|can|must|should|would|"
    r"never|sometimes|always|rarely|invalid|untrue|false|не|нет|только|лишь|кроме|может|иногда)\b",
    re.IGNORECASE | re.DOTALL,
)
_QUOTED_DOCUMENT = re.compile(r"[\"'“”‘’«»‹›`]|^\s*>", re.MULTILINE)


def normalize_atom(text: str) -> str:
    """The only identity normalization is whitespace and case."""
    return " ".join(text.split()).casefold()


def _safe_string(value: Any, maximum: int, *, nullable: bool = False) -> bool:
    if nullable and value is None:
        return True
    return (
        type(value) is str
        and 0 < len(value) <= maximum
        and bool(value.strip())
        and not _ILLEGAL.search(value)
        and not _INSTRUCTION.search(value)
        and not any(unicodedata.category(char) in {"Cf", "Cs"} for char in value)
    )


def _action_phrase(words: list[str], *, state: bool = False) -> bool:
    """Explicit bounded noun-like surface, without claiming noun resolution."""
    return (
        0 < len(words) <= 8
        and (words[0].casefold() not in {"a", "an", "the"} or len(words) > 1)
        and not any(word.casefold() in {"a", "an", "the"} for word in words[1:])
        and all(_PHRASE_WORD.fullmatch(word) for word in words)
        and not any(word.casefold() in _PHRASE_RESERVED for word in words)
        and not any(
            word.casefold() in _ACTION_BASE
            and not (state and word.casefold() == "open")
            for word in words
        )
    )


def _action_clause_safe(text: str) -> bool | None:
    """Recognize a whole action clause; None delegates unchanged legacy states."""
    words = text.split()
    lowered = [word.casefold() for word in words]
    auxiliaries = [
        i for i, word in enumerate(lowered) if word in {"will", "do", "does", "did"}
    ]
    if auxiliaries:
        if len(auxiliaries) != 1:
            return False
        index = auxiliaries[0]
        tail = lowered[index + 1 :]
        if tail and tail[0] == "not":
            tail = tail[1:]
        if not tail or not _action_phrase(words[:index]):
            return False
        verb = tail[0]
        object_words = words[len(words) - len(tail) + 1 :]
        if lowered[index] == "will" and verb in {"be", "have"}:
            return _action_phrase(object_words, state=verb == "be")
        if verb not in _ACTION_FORMS:
            return False
        return (
            _action_phrase(object_words)
            if object_words
            else verb in _INTRANSITIVE_ACTIONS
        )
    verbs = [i for i, word in enumerate(lowered) if word in _ACTION_BASE]
    if not verbs:
        return None
    index = verbs[0]
    legacy = _PREDICATE.search(" ".join(words))
    if legacy and legacy.start() < len(" ".join(words[:index])):
        return None if all(lowered[i] == "open" for i in verbs) else False
    # An action spelling can be a noun in an existing explicit copula clause
    # ("the release is visible"); do not replace that old state grammar.
    if index + 1 < len(words) and lowered[index + 1] in {"is", "are", "was", "were"}:
        return None
    if len(verbs) != 1 or not _action_phrase(words[:index]):
        return False
    object_words = words[index + 1 :]
    base = _ACTION_BASE[lowered[index]]
    return (
        _action_phrase(object_words) if object_words else base in _INTRANSITIVE_ACTIONS
    )


def _clause_safe(text: str) -> bool:
    if not _safe_string(text, MAX_ATOM_CHARS):
        return False
    if any(mark in text for mark in ",;.!?:()"):
        return False
    if (
        _FORBIDDEN.search(text)
        or _PRONOUN.search(text)
        or _CONJUNCTION.search(text)
        or contains_passive_report(text)
    ):
        return False
    negations = re.findall(r"\b(?:not|не)\b", text, re.IGNORECASE)
    if len(negations) > 1 or (negations and _NEGATION.search(text) is None):
        return False
    action = _action_clause_safe(text)
    if action is not None:
        return action
    predicates = tuple(_PREDICATE.finditer(text))
    # Legacy states must still be one complete finite clause. A nonempty tail
    # is not permission to hide another copula/predicate in the complement.
    # Plain adjective "open" and action-as-noun "the release" are not finite
    # spellings in this table, so their existing single-copula forms survive.
    if len(predicates) > 1:
        return False
    predicate = predicates[0] if predicates else None
    if predicate:
        subject = text[: predicate.start()].strip()
        complement = text[predicate.end() :].strip()
        # Copulas/transitive auxiliaries require a complement; other supported
        # finite predicates may stand alone. Neither a keyword nor imperative
        # is an assumption.
        return bool(subject) and (
            bool(complement)
            or predicate[0].casefold()
            not in {
                "is",
                "are",
                "was",
                "were",
                "has",
                "have",
                "becomes",
                "become",
                "remains",
                "remain",
                "является",
                "являются",
                "имеет",
                "имеют",
                "становится",
                "становятся",
                "остается",
                "остаётся",
            }
        )
    # Russian documentary clauses can omit the present-tense copula. Accept
    # only a named subject followed by one explicit adjectival state.
    return bool(
        re.fullmatch(
            r"[А-ЯЁ][а-яё\w-]*\s+(?:не\s+)?[а-яё]+(?:на|ен|ён|енна|ённа|ый|ая|ое|ые)",
            text,
        )
    )


def _polarity(text: str) -> str:
    return "NEGATIVE" if _NEGATION.search(text) else "POSITIVE"


@dataclass(frozen=True)
class Atom:
    text: str
    identity: str
    polarity: str

    def __post_init__(self) -> None:
        if (
            not _clause_safe(self.text)
            or type(self.identity) is not str
            or self.identity != normalize_atom(self.text)
            or type(self.polarity) is not str
            or self.polarity != _polarity(self.text)
        ):
            raise ValueError("invalid documentary atom")

    @classmethod
    def from_text(cls, text: str) -> Atom:
        if type(text) is not str:
            raise ValueError("atom text must be a string")
        return cls(text, normalize_atom(text), _polarity(text))

    def to_dict(self) -> dict[str, str]:
        return {"text": self.text, "identity": self.identity, "polarity": self.polarity}


def _atom_list(value: Any, maximum: int) -> tuple[Atom, ...]:
    if type(value) is not list or not 0 < len(value) <= maximum:
        raise ValueError("invalid atom list")
    result = []
    for item in value:
        if type(item) is not dict or set(item) != {"text", "identity", "polarity"}:
            raise ValueError("invalid atom fields")
        result.append(Atom(**item))
    if len({item.identity for item in result}) != len(result):
        raise ValueError("duplicate atom")
    return tuple(result)


def _validate_atoms(value: Any, maximum: int) -> None:
    if (
        type(value) is not tuple
        or not 0 < len(value) <= maximum
        or any(type(item) is not Atom for item in value)
        or len({item.identity for item in value}) != len(value)
    ):
        raise ValueError("invalid atom tuple")


def _split_clauses(text: str) -> tuple[Atom, ...]:
    parts = _CONJUNCTION.split(text)
    connectors = {part.casefold() for part in parts[1::2]}
    if len(connectors) > 1:
        raise ValueError("mixed conjunction grammar")
    values = tuple(Atom.from_text(part.strip()) for part in parts[::2])
    _validate_atoms(values, MAX_ASSUMPTIONS)
    return values


def _parse_sentence(sentence: str) -> tuple[tuple[Atom, ...], tuple[Atom, ...]]:
    if not _safe_string(sentence, MAX_SENTENCE_CHARS):
        raise ValueError("invalid conditional sentence")
    match = re.fullmatch(
        r"\s*(?:If|When)\s+(.+?),\s*(?:then\s+)?(.+?)\.\s*",
        sentence,
        re.IGNORECASE | re.DOTALL,
    )
    if match is None:
        match = re.fullmatch(
            r"\s*Если\s+(.+?),\s*то\s+(.+?)\.\s*",
            sentence,
            re.IGNORECASE | re.DOTALL,
        )
    if match is None:
        raise ValueError("unsupported conditional sentence")
    return _split_clauses(match[1]), _split_clauses(match[2])


def _validate_scope(scope: Any) -> None:
    if (
        type(scope) is not tuple
        or len(scope) > 8
        or any(
            type(part) is not str
            or len(part) > 4096
            or any(unicodedata.category(char) in {"Cc", "Cf", "Cs"} for char in part)
            for part in scope
        )
        or (bool(scope) and not scope[0].strip())
    ):
        raise ValueError("invalid provenance scope")


@dataclass(frozen=True)
class ConditionalRule:
    antecedents: tuple[Atom, ...]
    consequents: tuple[Atom, ...]
    sentence: str
    source_author: str | None = None
    scope: tuple[str, ...] = ()
    schema_version: int = SCHEMA_VERSION

    def __post_init__(self) -> None:
        if (
            type(self.schema_version) is not int
            or self.schema_version != SCHEMA_VERSION
        ):
            raise ValueError("unsupported conditional schema")
        _validate_atoms(self.antecedents, MAX_ASSUMPTIONS)
        _validate_atoms(self.consequents, MAX_ASSUMPTIONS)
        if not _safe_string(self.source_author, 128, nullable=True):
            raise ValueError("invalid source author")
        _validate_scope(self.scope)
        if _parse_sentence(self.sentence) != (self.antecedents, self.consequents):
            raise ValueError("conditional does not match its complete source sentence")

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "antecedents": [item.to_dict() for item in self.antecedents],
            "consequents": [item.to_dict() for item in self.consequents],
            "sentence": self.sentence,
            "sentence_sha256": hashlib.sha256(
                self.sentence.encode("utf-8")
            ).hexdigest(),
            "source_author": self.source_author,
            "scope": list(self.scope),
        }


@dataclass(frozen=True)
class QueryTask:
    assumptions: tuple[Atom, ...]
    goal: Atom | None = None
    author: str | None = None
    schema_version: int = SCHEMA_VERSION

    def __post_init__(self) -> None:
        if (
            type(self.schema_version) is not int
            or self.schema_version != SCHEMA_VERSION
        ):
            raise ValueError("unsupported query schema")
        _validate_atoms(self.assumptions, MAX_ASSUMPTIONS)
        if self.goal is not None and type(self.goal) is not Atom:
            raise ValueError("invalid query goal")
        if not _safe_string(self.author, 128, nullable=True):
            raise ValueError("invalid query author")

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "assumptions": [item.to_dict() for item in self.assumptions],
            "goal": self.goal.to_dict() if self.goal is not None else None,
            "author": self.author,
        }


def canonical_json(payload: dict[str, Any]) -> str:
    """Stable JSON for InterpretationContent.claim_text; no executable content."""
    parse_conditional_payload(payload)
    return json.dumps(
        payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")
    )


def _json_object(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("duplicate JSON key")
        result[key] = value
    return result


def parse_conditional_payload(payload: Any) -> ConditionalRule:
    """Strictly validate complete v1 JSON or a v1 dictionary, without coercion."""
    if type(payload) is str:
        if not 0 < len(payload) <= MAX_PAYLOAD_CHARS:
            raise ValueError("conditional JSON exceeds bounds")
        try:
            payload = json.loads(payload, object_pairs_hook=_json_object)
        except (ValueError, RecursionError) as error:
            raise ValueError("invalid conditional JSON") from error
    fields = {
        "schema_version",
        "antecedents",
        "consequents",
        "sentence",
        "sentence_sha256",
        "source_author",
        "scope",
    }
    if type(payload) is not dict or set(payload) != fields:
        raise ValueError("invalid conditional payload fields")
    if not _safe_string(payload["sentence"], MAX_SENTENCE_CHARS):
        raise ValueError("invalid source sentence")
    digest = payload["sentence_sha256"]
    if (
        type(digest) is not str
        or re.fullmatch(r"[0-9a-f]{64}", digest) is None
        or digest != hashlib.sha256(payload["sentence"].encode("utf-8")).hexdigest()
    ):
        raise ValueError("invalid sentence digest")
    if type(payload["scope"]) is not list:
        raise ValueError("scope must be a JSON list")
    rule = ConditionalRule(
        _atom_list(payload["antecedents"], MAX_ASSUMPTIONS),
        _atom_list(payload["consequents"], MAX_ASSUMPTIONS),
        payload["sentence"],
        payload["source_author"],
        tuple(payload["scope"]),
        payload["schema_version"],
    )
    if (
        len(
            json.dumps(
                rule.to_dict(),
                ensure_ascii=False,
                sort_keys=True,
                separators=(",", ":"),
            )
        )
        > MAX_PAYLOAD_CHARS
    ):
        raise ValueError("canonical conditional JSON exceeds bounds")
    return rule


def bind_scope(payload: Any, scope: tuple[str, ...]) -> dict[str, Any]:
    """Bind trusted installation provenance, never a scope supplied by source prose."""
    _validate_scope(scope)
    if not scope:
        raise ValueError("installed rules require provenance scope")
    return replace(parse_conditional_payload(payload), scope=scope).to_dict()


def _documentary_provenance_scope(origin: Any) -> tuple[str, ...]:
    """Derive a provenance boundary from an installed documentary excerpt.

    A title is presentation, not authority or identity. The original byte hash,
    author, heading path, and exact member/signature delimit allowed composition.
    This helper validates provenance shape; callers still verify actual source
    bytes and excerpt dependencies against their installation records.
    """
    if (
        type(origin) is not dict
        or origin.get("scope") != "DOCUMENTARY_EVIDENCE_NOT_EXECUTION_AUTHORITY"
    ):
        raise ValueError("origin lacks documentary provenance")
    digest = origin.get("original_bytes_hash")
    if type(digest) is not str or re.fullmatch(r"[0-9a-f]{64}", digest) is None:
        raise ValueError("origin requires an original byte digest")
    author = origin.get("source_author")
    if not _safe_string(author, 128, nullable=True):
        raise ValueError("invalid origin author")
    headings = origin.get("heading_path")

    def metadata(value, maximum):
        return (
            type(value) is str
            and len(value) <= maximum
            and bool(value.strip())
            and not any(
                unicodedata.category(char) in {"Cc", "Cf", "Cs"} for char in value
            )
        )

    if (
        type(headings) is not list
        or len(headings) > 16
        or any(not metadata(item, 256) for item in headings)
    ):
        raise ValueError("invalid heading provenance")
    members = []
    for key in ("symbol", "signature", "member_anchor"):
        value = origin.get(key)
        if value is not None and not metadata(value, 2048):
            raise ValueError("invalid member provenance")
        members.append(value or "")
    scope = (
        digest,
        normalize_atom(author) if author is not None else "",
        json.dumps(headings, ensure_ascii=False, separators=(",", ":")),
        *members,
    )
    _validate_scope(scope)
    return scope


def documentary_scope(origin: Any) -> tuple[str, ...]:
    """Require explicitly reader-classified math-free prose for conditionals.

    Missing legacy metadata is unknown, not an assertion of math absence. This
    flag is conservative classification, not an exact raw-byte source witness.
    """
    scope = _documentary_provenance_scope(origin)
    if (
        origin.get("quotation", False) is not False
        or type(origin.get("documentary_role")) is not str
        or origin["documentary_role"] != "PROSE"
    ):
        raise ValueError("origin is not eligible documentary prose")
    if origin.get("documentary_math_presence") is not False:
        raise ValueError("conditional origin requires explicit math-free prose")
    return scope


def _qualified_parent(text: str) -> bool:
    return bool(
        _CONTEXT_LIMITER.search(text)
        or _REPORTING_CONTEXT.search(text)
        or any(
            _QUALIFIER_START.search(sentence.strip())
            for sentence in re.findall(r"[^.!?]+[.!?]|[^.!?]+$", text)
        )
    )


def extract_conditionals(
    text: str, source_author: str | None = None
) -> tuple[dict, ...]:
    """Propose complete supported sentences for review, retaining original text."""
    if (
        type(text) is not str
        or len(text) > MAX_SOURCE_CHARS
        or _INSTRUCTION.search(text)
        or _QUOTED_DOCUMENT.search(text)
        or _qualified_parent(text)
        or not _safe_string(source_author, 128, nullable=True)
    ):
        return ()
    # Use explicit sentence boundaries; never discover a rule inside quotation,
    # code, another conditional, heading, or a larger unparsed sentence.
    sentences = re.findall(r"[^.!?]+[.!?]|[^.!?]+$", text)
    result: list[dict] = []
    seen: set[str] = set()
    for index, raw in enumerate(sentences):
        sentence = raw.strip()
        if index and _QUALIFIER_START.search(sentences[index - 1].strip()):
            continue
        if index + 1 < len(sentences) and _QUALIFIER_START.search(
            sentences[index + 1].strip()
        ):
            continue
        try:
            antecedents, consequents = _parse_sentence(sentence)
            rule = ConditionalRule(antecedents, consequents, sentence, source_author)
        except ValueError:
            continue
        payload = rule.to_dict()
        encoded = canonical_json(payload)
        if encoded not in seen:
            result.append(payload)
            seen.add(encoded)
        if len(result) > MAX_RULES:
            return ()
    return tuple(result)


def extract_documentary_conditionals(
    origin: dict,
    following_origin: dict | None = None,
    preceding_origin: dict | None = None,
) -> tuple[dict, ...]:
    """Preserve attached same-scope qualifiers across reader block splits.

    This is conservative: a qualifier suppresses every proposed rule in the
    adjacent block, rather than guessing which sentence the author qualified.
    Acquisition replay must use the full original, not a selected excerpt list.
    """
    scope = documentary_scope(origin)
    for is_preceding, adjacent_origin in (
        (False, following_origin),
        (True, preceding_origin),
    ):
        if adjacent_origin is None:
            continue
        try:
            # A math/unknown neighbor can still contain an attached restrictor.
            # Guard provenance is separate from positive rule eligibility.
            adjacent_scope = _documentary_provenance_scope(adjacent_origin)
        except ValueError:
            adjacent_scope = None
        if type(adjacent_origin) is not dict:
            continue
        adjacent_text = adjacent_origin.get(
            "documentary_original_text"
        ) or adjacent_origin.get("text", "")
        if adjacent_scope != scope or adjacent_origin.get("file") != origin.get("file"):
            continue
        # A freshly replayed empty quote/math parent is coverage, not a premise.
        # Its absent rendered text must not let a V1-only query bypass V2's guard.
        if adjacent_origin.get("documentary_role") == "SOURCE_CONTEXT_MARKER":
            return ()
        # A flag/display cannot replay a guard hidden or transformed by math.
        # Refuse this whole same-scope adjacent context, even without a visible
        # qualifier. Missing/malformed metadata is likewise unknown, not safe.
        if adjacent_origin.get("documentary_math_presence") is not False:
            return ()
        if type(adjacent_text) is not str or len(adjacent_text) > MAX_SOURCE_CHARS:
            return ()
        if _qualified_parent(adjacent_text):
            return ()
        sentences = re.findall(r"[^.!?]+[.!?]|[^.!?]+$", adjacent_text)
        guard_contexts = (
            [sentences[-1] if sentences else ""] if is_preceding else [adjacent_text]
        )
        if any(_QUALIFIER_START.search(context.strip()) for context in guard_contexts):
            return ()
    text = origin.get("documentary_original_text") or origin["text"]
    return extract_conditionals(text, origin.get("source_author"))


def parse_conditional_query(question: str) -> dict | None:
    """Parse a bounded explicit hypothetical task; ordinary keywords are not tasks."""
    if not _safe_string(question, MAX_QUERY_CHARS):
        return None
    text = question.strip()
    author = None
    attributed = re.fullmatch(
        r"(.+?)(?:,\s*|\s+)(?:according to|по мнению|согласно)\s+([^?]+)\??",
        text,
        re.IGNORECASE,
    )
    if attributed:
        text, author = attributed[1].strip(), attributed[2].strip()
    if not text.endswith("?"):
        text += "?" if attributed else ""
    assumptions = None
    goal = None
    for pattern in (
        r"What follows if (.+)\?",
        r"If (.+), what follows\?",
        r"Given (.+), what follows\?",
        r"Что следует, если (.+)\?",
        r"Если (.+), что следует\?",
        r"Дано (.+), что следует\?",
    ):
        match = re.fullmatch(pattern, text, re.IGNORECASE)
        if match:
            assumptions = match[1]
            break
    if assumptions is None:
        match = re.fullmatch(
            r"Does it follow that (.+?)(?: if |, given )(.+)\?", text, re.IGNORECASE
        )
        if match is None:
            match = re.fullmatch(r"Does (.+) follow if (.+)\?", text, re.IGNORECASE)
        if match is None:
            match = re.fullmatch(r"Следует ли (.+), если (.+)\?", text, re.IGNORECASE)
        if match:
            goal, assumptions = match.groups()
    if assumptions is None:
        return None
    try:
        # Semicolons delimit explicit assumptions; conjunctions use exactly the
        # same grammar as the source and cannot create incomplete fragments.
        atoms = tuple(
            atom
            for clause in assumptions.split(";")
            for atom in _split_clauses(clause.strip())
        )
        query = QueryTask(atoms, Atom.from_text(goal.strip()) if goal else None, author)
    except ValueError:
        return None
    return query.to_dict()


def _parse_query(payload: Any) -> QueryTask:
    if type(payload) is QueryTask:
        return payload
    if type(payload) is not dict or set(payload) != {
        "schema_version",
        "assumptions",
        "goal",
        "author",
    }:
        raise ValueError("invalid query fields")
    goal = payload["goal"]
    if goal is not None:
        goal = _atom_list([goal], 1)[0]
    return QueryTask(
        _atom_list(payload["assumptions"], MAX_ASSUMPTIONS),
        goal,
        payload["author"],
        payload["schema_version"],
    )


def _opposite(identity: str) -> str | None:
    # Only explicit syntactic complements count. No synonym or semantic
    # rewriting (including does-not -> positive-verb morphology) is attempted.
    match = _NEGATION.search(identity)
    if match is None:
        return None
    group = 1 if match[1] is not None else 2
    start, end = match.span(group)
    return normalize_atom(identity[:start] + identity[end:])


def _conflicts(atoms: dict[str, Atom]) -> list[dict[str, str]]:
    result = []
    for identity, atom in sorted(atoms.items()):
        positive = _opposite(identity)
        if positive is not None and positive in atoms:
            result.append({"positive": atoms[positive].text, "negative": atom.text})
    return result


def derive_conditionals(rules: Any, query: Any) -> dict[str, Any]:
    """Pure bounded forward chaining inside one trusted source/author scope.

    Rules are (knowledge_id, payload) tuples. Invalid input, scope mixing,
    contradictions, or exceeded bounds fail closed without positive conclusions.
    Assumptions are returned as hypothetical input, never as derived evidence.
    """
    result: dict[str, Any] = {
        "status": "NO_DERIVATION",
        "conclusions": [],
        "proof_steps": [],
        "used_rule_ids": [],
        "conflicts": [],
        "assumptions": [],
        "goal_follows": None,
        "assumptions_are_hypothetical": True,
        "goal_assumed": False,
        "source_assertions_are_empirical_proof": False,
    }
    try:
        task = _parse_query(query)
        result["assumptions"] = [item.text for item in task.assumptions]
        result["goal_assumed"] = bool(
            task.goal is not None
            and any(item.identity == task.goal.identity for item in task.assumptions)
        )
        if type(rules) not in {tuple, list}:
            raise ValueError("invalid rule collection")
        if len(rules) > MAX_RULES:
            result["status"] = "BOUND_EXCEEDED"
            return result
        parsed: list[tuple[str, ConditionalRule]] = []
        identifiers: set[str] = set()
        for entry in rules:
            if type(entry) is not tuple or len(entry) != 2:
                raise ValueError("invalid rule entry")
            identifier, payload = entry
            if (
                type(identifier) is not str
                or not identifier.strip()
                or len(identifier) > 256
                or any(
                    char.isspace() or unicodedata.category(char) in {"Cc", "Cf", "Cs"}
                    for char in identifier
                )
                or identifier in identifiers
            ):
                raise ValueError("invalid or duplicate rule identifier")
            identifiers.add(identifier)
            rule = parse_conditional_payload(payload)
            if task.author is None or (
                rule.source_author is not None
                and normalize_atom(rule.source_author) == normalize_atom(task.author)
            ):
                parsed.append((identifier, rule))
    except (ValueError, TypeError, RecursionError):
        result["status"] = "INVALID_CONDITIONAL_INPUT"
        return result
    if parsed and (
        any(not rule.scope for _, rule in parsed)
        or len({rule.scope for _, rule in parsed}) != 1
        or len(
            {
                normalize_atom(rule.source_author)
                if rule.source_author is not None
                else None
                for _, rule in parsed
            }
        )
        != 1
    ):
        result["status"] = "SCOPE_CONFLICT"
        return result
    known = {atom.identity: atom for atom in task.assumptions}
    depths = {identity: 0 for identity in known}
    steps: list[dict[str, Any]] = []
    used: list[str] = []
    fired: set[str] = set()
    initial = set(known)
    while True:
        conflicts = _conflicts(known)
        if conflicts:
            result.update(
                status="CONTESTED",
                conflicts=conflicts,
                proof_steps=steps,
                used_rule_ids=used,
            )
            return result
        changed = False
        # Stable sorting gives deterministic proofs regardless of database row
        # order. Each round uses a snapshot so unrelated ordering cannot alter
        # depth, firing eligibility, or the discovery of contradictions.
        snapshot = set(known)
        for identifier, rule in sorted(parsed, key=lambda item: item[0]):
            if identifier in fired or not all(
                item.identity in snapshot for item in rule.antecedents
            ):
                continue
            novel = [item for item in rule.consequents if item.identity not in known]
            if not novel:
                fired.add(identifier)
                continue
            depth = 1 + max(depths[item.identity] for item in rule.antecedents)
            if depth > MAX_DEPTH or len(known) + len(novel) > MAX_CLOSURE:
                result.update(
                    status="BOUND_EXCEEDED", proof_steps=steps, used_rule_ids=used
                )
                return result
            for atom in novel:
                known[atom.identity] = atom
                depths[atom.identity] = depth
            fired.add(identifier)
            used.append(identifier)
            steps.append(
                {
                    "rule_id": identifier,
                    "antecedents": [item.text for item in rule.antecedents],
                    "consequents": [item.text for item in rule.consequents],
                    "depth": depth,
                }
            )
            changed = True
        if not changed:
            break
    conclusions = [known[identity].text for identity in sorted(set(known) - initial)]
    result.update(
        status="DERIVED" if conclusions else "NO_DERIVATION",
        conclusions=conclusions,
        proof_steps=steps,
        used_rule_ids=used,
        goal_follows=task.goal.identity in (set(known) - initial)
        if task.goal is not None
        else None,
    )
    return result
