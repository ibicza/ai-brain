"""Contracts for an experimental source-grounded reader, not a truth oracle.

Span validation proves transport/anchoring, NOT semantic entailment. Gold decisions
still require independently reviewed annotation before textbook training.
"""

from __future__ import annotations

import hashlib
import math
from collections import Counter
from collections.abc import Sequence
from dataclasses import dataclass
from typing import Literal

Decision = Literal["YES", "NO", "UNKNOWN"]
DECISIONS: tuple[Decision, ...] = ("YES", "NO", "UNKNOWN")


def text_hash(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


@dataclass(frozen=True)
class EvidenceSpan:
    start: int
    end: int
    quote: str

    def validate(self, source: str) -> None:
        if type(self.start) is not int or type(self.end) is not int:
            raise ValueError("span offsets must be integers, not booleans")
        if not 0 <= self.start < self.end <= len(source):
            raise ValueError("span is outside source")
        if source[self.start : self.end] != self.quote:
            raise ValueError("evidence quote does not match source")


@dataclass(frozen=True)
class GroundedExample:
    sample_id: str
    source_family: str
    source_text: str
    source_sha256: str
    language: str
    claim: str
    decision: Decision
    evidence: tuple[EvidenceSpan, ...]
    unknown_reason: str = ""

    def validate(self) -> None:
        for value in (self.sample_id, self.source_family, self.source_text, self.claim):
            if not isinstance(value, str) or not value.strip():
                raise ValueError("example identity, source and claim must be nonempty")
        if self.language not in {"ru", "en"} or self.decision not in DECISIONS:
            raise ValueError("unsupported language or decision")
        if text_hash(self.source_text) != self.source_sha256:
            raise ValueError("source hash mismatch")
        if self.decision != "UNKNOWN" and not self.evidence:
            raise ValueError("YES/NO require source evidence; absence is not NO")
        if self.decision == "UNKNOWN" and not self.unknown_reason.strip():
            raise ValueError("UNKNOWN requires an annotated reason")
        if self.decision != "UNKNOWN" and self.unknown_reason:
            raise ValueError("affirmative/negative example has an unknown reason")
        for span in self.evidence:
            span.validate(self.source_text)

    def prompt(self) -> str:
        # Labels, gold spans, source-family/split IDs never enter model input.
        return (
            "Decide using only SOURCE: YES = supported; NO = explicitly contradicted; "
            "UNKNOWN = insufficient, conditional or conflicting evidence.\n"
            f"SOURCE:\n{self.source_text}\nCLAIM:\n{self.claim}\nDECISION:"
        )

    def lm_record(self) -> dict[str, str]:
        self.validate()
        return {"prompt": self.prompt(), "answer": self.decision}


def audit_splits(splits: dict[str, Sequence[GroundedExample]]) -> dict[str, object]:
    """Reject exact leakage; this does not detect paraphrases or prove blindness."""
    if set(splits) != {"train", "dev", "test"}:
        raise ValueError("require separate train/dev/test splits")
    owners: dict[tuple[str, str], str] = {}
    ids: set[str] = set()
    report: dict[str, object] = {}
    for name, rows in splits.items():
        if not rows:
            raise ValueError("empty split")
        for row in rows:
            row.validate()
            if row.sample_id in ids:
                raise ValueError("duplicate sample ID")
            ids.add(row.sample_id)
            for kind, key in (
                ("source family", row.source_family),
                ("source bytes", row.source_sha256),
                ("prompt", text_hash(row.prompt())),
            ):
                previous = owners.setdefault((kind, key), name)
                if previous != name:
                    raise ValueError(f"cross-split {kind} leakage")
        counts = Counter((r.language, r.decision) for r in rows)
        if any(
            not counts[(lang, label)] for lang in ("ru", "en") for label in DECISIONS
        ):
            raise ValueError("each split requires all decisions in both languages")
        report[name] = {
            "count": len(rows),
            "counts": {f"{a}/{b}": n for (a, b), n in sorted(counts.items())},
        }
    return report


def selective_decision(probabilities: Sequence[float], threshold: float) -> Decision:
    if len(probabilities) != 3 or any(
        not math.isfinite(p) or p < 0 for p in probabilities
    ):
        raise ValueError("invalid decision probabilities")
    if not math.isclose(sum(probabilities), 1.0, abs_tol=1e-6):
        raise ValueError("decision probabilities must sum to one")
    if not math.isfinite(threshold) or not 0 <= threshold <= 1:
        raise ValueError("invalid threshold")
    best = max(probabilities)
    if best < threshold or sum(p == best for p in probabilities) != 1:
        return "UNKNOWN"
    return DECISIONS[probabilities.index(best)]


def decision_metrics(
    gold: Sequence[Decision], predicted: Sequence[Decision]
) -> dict[str, object]:
    if not gold or len(gold) != len(predicted):
        raise ValueError("nonempty paired decisions required")
    if any(x not in DECISIONS for x in (*gold, *predicted)):
        raise ValueError("invalid decision")
    accepted = sum(p != "UNKNOWN" for p in predicted)
    false_assertions = sum(
        p != "UNKNOWN" and p != g for g, p in zip(gold, predicted, strict=True)
    )
    answerable = sum(g != "UNKNOWN" for g in gold)
    correct_assertions = sum(
        g == p and p != "UNKNOWN" for g, p in zip(gold, predicted, strict=True)
    )
    return {
        "count": len(gold),
        "accuracy": sum(g == p for g, p in zip(gold, predicted, strict=True))
        / len(gold),
        "accepted": accepted,
        "false_assertions": false_assertions,
        "assertion_error_rate": false_assertions / accepted if accepted else None,
        "coverage": accepted / len(gold),
        "answerable_recall": correct_assertions / answerable if answerable else None,
        "confusion": {
            f"{g}/{p}": sum(
                a == g and b == p for a, b in zip(gold, predicted, strict=True)
            )
            for g in DECISIONS
            for p in DECISIONS
        },
    }


def choose_dev_threshold(
    gold: Sequence[Decision],
    probabilities: Sequence[Sequence[float]],
    *,
    min_accepted: int = 30,
) -> float | None:
    """Fixed grid, empirical dev criterion only; no statistical safety guarantee."""
    if (
        len(gold) != len(probabilities)
        or type(min_accepted) is not int
        or min_accepted <= 0
    ):
        raise ValueError("invalid calibration inputs")
    choices: list[tuple[int, float]] = []
    for threshold in (0.50, 0.60, 0.70, 0.80, 0.90, 0.95, 0.98, 0.99):
        predicted = [selective_decision(p, threshold) for p in probabilities]
        metrics = decision_metrics(gold, predicted)
        accepted = int(metrics["accepted"])
        if not metrics["false_assertions"] and accepted >= min_accepted:
            choices.append((accepted, threshold))
    return max(choices, key=lambda pair: (pair[0], pair[1]))[1] if choices else None
