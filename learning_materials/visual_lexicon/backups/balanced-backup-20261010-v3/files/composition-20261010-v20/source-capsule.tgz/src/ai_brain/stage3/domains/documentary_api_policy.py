"""Reviewed optional API policies re-derived from fresh complete originals."""

from dataclasses import asdict

from ai_brain.stage2.facts.canonical import canonical_json, content_hash
from ai_brain.stage3.acquisition.documentary_api_context import (
    DOCUMENTARY_API_CONTEXT_POLICY_V1,
    parse_api_context_policy,
)
from ai_brain.stage3.acquisition.documentary_api_licensing import (
    derive_api_context_policy,
)
from ai_brain.stage3.acquisition.documentary_api_policy import reserved_api_policy
from ai_brain.stage3.domains.document_retrieval import excerpt_payload
from ai_brain.stage3.domains.documentary_api_scenarios import assess_documented_scenario
from ai_brain.stage3.domains.documentary_context_inventory import original_context_index
from ai_brain.stage3.knowledge_ir.records import ClaimSchemaContent, EpistemicCharacter


def _source_union(record, sources, bindings):
    """Same original segments, exact order, full field evidence, no label trust."""
    if (
        type(record.provenance_refs) is not tuple
        or len(record.provenance_refs) != 1
        or type(record.provenance_refs[0]) is not str
        or not record.provenance_refs[0]
    ):
        raise ValueError("API source requires one exact ordered source binding")
    own = bindings.get(record.provenance_refs[0])
    if own is None:
        raise ValueError("API source binding missing")
    direct = []
    for source in sources:
        if (
            type(source.provenance_refs) is not tuple
            or len(source.provenance_refs) != 1
            or type(source.provenance_refs[0]) is not str
            or not source.provenance_refs[0]
        ):
            raise ValueError("API direct excerpt binding differs")
        binding = bindings.get(source.provenance_refs[0])
        if (
            binding is None
            or len(binding.segment_hashes) != 1
            or len(binding.evidence_hashes) != 1
            or len(binding.source_hashes) != 1
        ):
            raise ValueError("API excerpt must bind exactly one original segment")
        direct.append(binding)
    document_hashes = tuple(
        sorted({value for item in direct for value in item.document_hashes})
    )
    segment_hashes = tuple(value for item in direct for value in item.segment_hashes)
    evidence_hashes = tuple(value for item in direct for value in item.evidence_hashes)
    source_hashes = tuple(value for item in direct for value in item.source_hashes)
    field_evidence = tuple(
        (f"content.{field}", digest)
        for digest in evidence_hashes
        for field in sorted(asdict(record.content))
    )
    if (
        own.document_hashes != document_hashes
        or own.segment_hashes != segment_hashes
        or own.evidence_hashes != evidence_hashes
        or own.source_hashes != source_hashes
        or own.field_evidence != field_evidence
        or own.source_chain_hash
        != content_hash((document_hashes, segment_hashes, field_evidence))
        or own.claim_refs
        or own.fact_memory_refs
        or own.derivation_hashes
    ):
        raise ValueError("API whole-original ordered source lineage differs")


def validated_api_policies(pack):
    """All reserved records before selection; unknown versions never actor prose."""
    policies = tuple(
        record
        for record in pack.knowledge_records
        if reserved_api_policy(record.content)
    )
    if not policies:
        return ()
    rows, _ = original_context_index(pack)
    by_id = {record.knowledge_id: record for record in pack.knowledge_records}
    bindings = {binding.binding_id: binding for binding in pack.source_bindings}
    if len(by_id) != len(pack.knowledge_records) or len(bindings) != len(
        pack.source_bindings
    ):
        raise ValueError("Duplicate API record/source identity")
    excerpts = {}
    for record in pack.knowledge_records:
        payload = excerpt_payload(record)
        if payload is not None:
            excerpts.setdefault(canonical_json(payload), []).append(record)
    admitted = []
    for policy in policies:
        content = policy.content
        if (
            content.perspective != DOCUMENTARY_API_CONTEXT_POLICY_V1
            or type(content.supported_record_ids) is not tuple
            or len(content.supported_record_ids) != 1
            or type(content.supported_record_ids[0]) is not str
            or not content.supported_record_ids[0]
            or type(content.contrast_record_ids) is not tuple
            or content.contrast_record_ids != ()
            or type(policy.required_capability_ids) is not tuple
            or policy.required_capability_ids != ()
            or type(policy.applicability_refs) is not tuple
            or policy.applicability_refs != ()
            or policy.epistemic_character is not EpistemicCharacter.INTERPRETIVE
            or type(policy.dependencies) is not tuple
        ):
            raise ValueError("Invalid installed reserved API policy authority")
        target = by_id.get(content.supported_record_ids[0])
        if (
            target is None
            or type(target.content) is not ClaimSchemaContent
            or target.epistemic_character is not EpistemicCharacter.INTERPRETIVE
        ):
            raise ValueError("Installed API typed target missing")
        body = parse_api_context_policy(content.claim_text)
        original = tuple(
            payload for context_id, payload in rows if context_id == body["context_id"]
        )
        expected = derive_api_context_policy(
            body["context_id"], original, target.content
        )
        if canonical_json(expected) != content.claim_text:
            raise ValueError(
                "Installed API policy differs from complete fresh original"
            )
        source_records = []
        for payload in original:
            matching = excerpts.get(canonical_json(payload), ())
            if (
                len(matching) != 1
                or matching[0].epistemic_character
                is not EpistemicCharacter.INTERPRETIVE
            ):
                raise ValueError(
                    "API policy requires explicitly reviewed complete source excerpts"
                )
            source_records.append(matching[0])
        expected_dependencies = (
            source_records[0].knowledge_id,
            target.knowledge_id,
            *(record.knowledge_id for record in source_records[1:]),
        )
        if policy.dependencies != expected_dependencies:
            raise ValueError("Installed API complete source dependency union differs")
        members = tuple(
            record
            for record, role in zip(source_records, expected["licenses"], strict=True)
            if role["role"] == "MEMBER_CONTEXT"
        )
        if target.dependencies != tuple(record.knowledge_id for record in members):
            raise ValueError("Installed API typed member dependency union differs")
        _source_union(policy, source_records, bindings)
        _source_union(target, members, bindings)
        admitted.append((policy, target, expected))
    return tuple(admitted)


def assess_api_scenario_v2(pack, reference, arguments):
    if (
        type(reference) is not str
        or not reference
        or type(arguments) is not dict
        or set(arguments) != {"values"}
        or type(arguments["values"]) is not dict
    ):
        return {"status": "INVALID_REQUEST"}
    from ai_brain.stage3.domains.semantic_reasoning import (
        _answer,
        _installed_reference_policy,
        _source_payloads,
        _structured,
    )

    policies = validated_api_policies(pack)
    contract = _structured(pack, "contract", reference, None)
    if contract is None:
        return {"status": "INSUFFICIENT_EVIDENCE", "domain_id": pack.manifest.domain_id}
    if contract["status"] != "DOCUMENTED_CONTRACT":
        return contract
    identities = {
        item["knowledge_id"]
        for item in contract["evidence"]
        if item["kind"] == "CLAIM_SCHEMA"
    }
    selected = [
        (policy, target, body)
        for policy, target, body in policies
        if target.knowledge_id in identities
    ]
    if not selected:
        return {
            "status": "NEEDS_NEW_CAPABILITY",
            "value": None,
            "proof_steps": [],
            "reason": "Reviewed complete fresh API context policy required",
        }
    if len(selected) != 1:
        return {"status": "AMBIGUOUS_REFERENCE", "value": None, "proof_steps": []}
    policy, target, body = selected[0]
    reference_policy = _installed_reference_policy(
        target, _source_payloads(pack, target)
    )
    assessment = assess_documented_scenario(
        target.content, arguments["values"], reference_policy=reference_policy
    )
    if assessment["status"] != "DOCUMENTED_API_SCENARIO":
        return {
            **assessment,
            "domain_id": pack.manifest.domain_id,
            "pack_hash": pack.manifest.pack_content_hash,
        }
    steps = [
        {**step, "rule_id": target.knowledge_id} for step in assessment["proof_steps"]
    ]
    return {
        **_answer(
            pack, (policy, target), assessment["status"], assessment["value"], steps
        ),
        "context_admission": {
            "policy_record_id": policy.knowledge_id,
            "source_context_id": body["context_id"],
            "inventory_hash": body["inventory_hash"],
            "scope": body["scope"],
            "scope_observations": body["scope_observations"],
        },
        "source_code_executed": False,
        "independently_verified": False,
        "source_context_is_not_assessed": True,
        "scope": "HYPOTHETICAL_DOCUMENTED_API_OBLIGATIONS_ONLY",
    }
