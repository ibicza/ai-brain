"""Shared complete fresh original-context index, never caller authentication.

The installed loader supplies the already same-buffer replayed Descriptor and
canonical rows. Constructing these Python objects does not confer custody.
"""

from __future__ import annotations

import json
from dataclasses import asdict

from ai_brain.stage2.facts.canonical import canonical_json, content_hash
from ai_brain.stage3.acquisition.documentary_logic import _json_object
from ai_brain.stage3.domains.document_limits import MAX_DOCUMENTARY_PACK_RECORDS
from ai_brain.stage3.domains.documentary_custody import Descriptor, QueryBudget
from ai_brain.stage3.domains.request_verification import current_request


class UnsupportedDocumentaryContext(ValueError):
    """Fresh complete reader context is required by this capability."""


def original_context_index(pack):
    descriptor = pack.documentary_custody
    rows = pack.documentary_context
    if type(descriptor) is not Descriptor or type(rows) is not tuple:
        raise UnsupportedDocumentaryContext(
            "complete freshly replayed source context required"
        )
    if len(rows) > MAX_DOCUMENTARY_PACK_RECORDS:
        raise OverflowError("conditional context block ceiling exceeded")
    contexts = {item.context_id: item for item in descriptor.contexts}
    if len(contexts) != len(descriptor.contexts):
        raise ValueError("duplicate original context identity")
    counts = dict.fromkeys(contexts, 0)
    order = {key: index for index, key in enumerate(contexts)}
    last_context = -1
    result, lookup = [], {}
    request = current_request()
    budget = request.budget if request is not None else QueryBudget()
    for row in rows:
        if (
            type(row) is not tuple
            or len(row) != 2
            or any(type(value) is not str for value in row)
            or row[0] not in contexts
        ):
            raise ValueError("unknown exact reader context row")
        context_id, encoded = row
        if order[context_id] < last_context:
            raise ValueError("original context order differs")
        last_context = order[context_id]
        budget.reserve(payload=4 * len(encoded), context=len(encoded))
        origin = json.loads(encoded, object_pairs_hook=_json_object)
        context = contexts[context_id]
        counts[context_id] += 1
        if (
            type(origin) is not dict
            or origin.get("original_bytes_hash") != context.raw_hash
            or origin.get("file") != context.original_name
            or origin.get("source_url") != context.source_url
            or origin.get("format") != context.format
            or origin.get("reader_profile") != context.reader_profile
            or type(origin.get("block")) is not int
            or origin["block"] != counts[context_id]
            or canonical_json(origin) != encoded
            or encoded in lookup
        ):
            raise ValueError("complete original context identity/order differs")
        lookup[encoded] = len(result)
        result.append((context_id, origin))
    if any(counts[key] != context.block_count for key, context in contexts.items()):
        raise ValueError("complete original rendered block inventory missing")
    return tuple(result), lookup


def describe_original_context(pack):
    """Opaque ALL-row projection, independent of selected semantic admission.

    Unknown, quoted, qualified and contradictory material stays unchanged.
    This is not a license to omit a parent from any inference audit. Only the
    installed loader's freshly replayed rows may supply custody; constructing
    a descriptor or calling this helper directly does not authenticate a pack.
    Public use is through the verified installed-service request boundary.
    """
    originals, _ = original_context_index(pack)
    rows, identities = [], []
    for context_id, payload in originals:
        identity = {
            "original_context_id": context_id,
            "block": payload["block"],
            "source_payload_hash": content_hash(payload),
        }
        identities.append(identity)
        rows.append({
            **identity,
            "node_id": content_hash(identity),
            "source_payload": payload,
            "semantic_admission": "NOT_ASSESSED",
            "inference_authority": False,
        })
    return {
        "status": "DOCUMENTARY_SOURCE_CONTEXT",
        "domain_id": pack.manifest.domain_id,
        "pack_hash": pack.manifest.pack_content_hash,
        "contexts": rows,
        "originals": [asdict(context) for context in pack.documentary_custody.contexts],
        "inventory_hash": content_hash(identities),
        "inventory_scope": "ALL_HELD_ORIGINALS_ALL_RENDERED_ROWS_IN_ORDER",
        "source_only": True,
        "inference_authority": False,
        "semantic_admission": "NOT_ASSESSED",
        "source_code_executed": False,
        "scope": "OPAQUE_SOURCE_RETENTION_NOT_SELECTED_SEMANTIC_ADMISSION",
    }
