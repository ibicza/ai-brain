"""Bounded source-labelled relation and named-attribution proposals.

This is a surface grammar, not POS tagging, world knowledge or entailment.
Every output requires source/semantic review and original-context custody in
the caller. Exact labels are never singularized, synonymized or made transitive.
Quoted examples, arbitrary pronouns, nested reports and qualified direct edges
are not assertion authority. Attributed qualification remains literal claim text.
"""

from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass, field

from ai_brain.stage3.acquisition.documentary_clauses import (
    SourceSpan,
    split_documentary_sentences,
)

MAX_RELATION_INPUT = 16_000
MAX_RELATION_SENTENCE = 2048
MAX_RELATION_LABEL = 160
MAX_RELATION_LIST = 16
MAX_RELATION_ASSERTIONS = 64
_WORD = r"[^\W\d_][\w'’–-]*"
_LABEL = rf"{_WORD}(?:\s+{_WORD}){{0,15}}"
_PRONOUN = re.compile(
    r"\b(?:it|its|they|them|their|he|him|his|she|her|we|our|you|your|"
    r"this|that|these|those|someone|somebody|which|who|whose|there|"
    r"он|она|оно|они|его|ее|её|их|это|этот|эта|эти)\b",
    re.IGNORECASE,
)
_REPORT = re.compile(
    r"\b(?:according\s+to|argues?|argued|claims?|claimed|contends?|contended|"
    r"asserts?|asserted|writes?|wrote|thinks?|thought|believes?|believed|"
    r"says?|said|reports?|reported|reportedly|allegedly)\b",
    re.IGNORECASE,
)
_QUALIFIED = re.compile(
    r"\b(?:not|no|never|only|unless|except|may|might|could|can|must|should|"
    r"would|shall|sometimes|possibly|probably|approximately|usually|often|"
    r"generally|typically|always|rarely|frequently|likely|unlikely|mainly|primarily|largely|nearly|almost|some|any|"
    r"every|all|each|most|few|several|both|either|neither|if|when|then|"
    r"because|since|although|though|whereas|while|until|before|after|"
    r"however|but|rather|otherwise|currently|formerly|now|today|"
    r"не|нет|если|когда|может|только|кроме|иногда|обычно)\b|"
    r"\b\w+n't\b",
    re.IGNORECASE,
)
_UNSAFE = re.compile(
    r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f<>\[\]{}=\\`]|"
    r"https?://|javascript:|\$\(|\b(?:ignore|disregard|execute|eval|exec|"
    r"import|__\w+__|sudo|powershell|override|instructions?)\b",
    re.IGNORECASE,
)
_QUOTED = re.compile(r'["“”«»‹›]|(?:^|\n)\s*>|(?<!\w)[\'‘’]|[\'‘’](?!\w)')
_RELATIVE_OR_VERB = re.compile(
    r"\b(?:that|which|who|whose|where|when|is|are|was|were|has|have|"
    r"be|been|being|becomes?|became|does?|did|to|with|without|for|"
    r"as|by|at|in|on|from|through|than|and|or)\b",
    re.IGNORECASE,
)
_ATTRIBUTE_ACTION = r"argues?|argued|claims?|claimed|contends?|contended|asserts?|asserted|writes?|wrote|thinks?|thought|believes?|believed|says?|said|reports?|reported"
_ATTRIBUTION = re.compile(
    rf"(?P<speaker>{_LABEL})\s+(?:{_ATTRIBUTE_ACTION})\s+that\s+(?P<claim>.+)",
    re.IGNORECASE,
)
_ACCORDING = re.compile(
    rf"According\s+to\s+(?P<speaker>{_LABEL}),\s*(?P<claim>.+)",
    re.IGNORECASE,
)
_CLAIM = re.compile(
    rf"(?P<topic>{_LABEL})\s+(?:is|are|was|were|has|have|causes?|leads?\s+to)\s+.+",
    re.IGNORECASE,
)


@dataclass(frozen=True)
class DocumentaryRelation:
    subject: str
    predicate: str
    object: str
    source: SourceSpan
    subject_span: SourceSpan
    object_span: SourceSpan
    review_required: bool = field(default=True, init=False)
    inference_authority: bool = field(default=False, init=False)
    epistemic_scope: str = field(default="SOURCE_ASSERTION_ONLY", init=False)


@dataclass(frozen=True)
class NamedAttribution:
    speaker: str
    topic: str
    claim: SourceSpan
    source: SourceSpan
    speaker_span: SourceSpan
    topic_span: SourceSpan
    context: SourceSpan
    review_required: bool = field(default=True, init=False)
    inference_authority: bool = field(default=False, init=False)
    epistemic_scope: str = field(default="SOURCE_ATTRIBUTED_INTERPRETATION", init=False)


@dataclass(frozen=True)
class RelationReview:
    reason: str
    source: SourceSpan


@dataclass(frozen=True)
class RelationExtraction:
    assertions: tuple[DocumentaryRelation, ...] = ()
    attributed_claims: tuple[NamedAttribution, ...] = ()
    review_reasons: tuple[RelationReview, ...] = ()


@dataclass(frozen=True)
class RelativeSurfaceBinding:
    """A local syntactic attachment, never a resolved empirical proposition."""

    reference: SourceSpan
    antecedent: SourceSpan
    binding_kind: str = field(default="IMMEDIATE_RELATIVE_SURFACE", init=False)
    inference_authority: bool = field(default=False, init=False)


@dataclass(frozen=True)
class DocumentaryParentInventory:
    """Exact complete-parent retrieval anchors, without logical conversion.

    Qualification spans are an inventory, not a complete scope AST. Pronouns
    remain unresolved except a narrow immediate relative surface attachment.
    Subjects are explicit clause labels, not taxonomic entities or aliases.
    """

    parent: SourceSpan
    subjects: tuple[SourceSpan, ...]
    qualifications: tuple[SourceSpan, ...]
    references: tuple[SourceSpan, ...]
    bindings: tuple[RelativeSurfaceBinding, ...]
    epistemic_scope: str = field(default="SOURCE_ASSERTION_NOT_EMPIRICAL", init=False)
    inference_authority: bool = field(default=False, init=False)
    review_required: bool = field(default=True, init=False)


_INVENTORY_QUALIFIER = re.compile(
    r"\b(?:can|cannot|may|might|could|must|should|would|shall|will|not|no|"
    r"all|some|most|every|each|many|few|several|both|either|neither|only|"
    r"unless|except|if|when|until|before|after|while|because|as|however|"
    r"but|so|usually|often|rarely|always|never|sometimes|possibly|probably)\b",
    re.IGNORECASE,
)
_INVENTORY_SUBJECT = re.compile(
    r"(?P<subject>[A-Za-z][A-Za-z -]{0,159}?)\s+"
    r"(?:is|are|was|were|has|have|can|cannot|may|might|could|must|should|"
    r"would|will|use|uses|prevent|prevents|expand|expands|contain|contains)\b",
    re.IGNORECASE,
)
_IMMEDIATE_RELATIVE = re.compile(
    r"\b(?:has|have)\s+(?P<antecedent>(?:a|an|the)\s+"
    r"[A-Za-z][A-Za-z-]*(?:\s+[A-Za-z][A-Za-z-]*){0,3})\s+"
    r"(?P<reference>which|that)\s+(?:prevents|contains|has|is)\b",
    re.IGNORECASE,
)


def inventory_documentary_parent(
    text: str, *, origin: str = "PROSE"
) -> DocumentaryParentInventory | None:
    """Inventory one complete original parent for reviewed source retrieval.

    No qualifier is removed and no antecedent/consequence is fabricated. This
    parser does not authorize empirical relations, deterministic conditionals,
    quantifier instantiation, or remote/coreferent subject substitution.
    """
    if type(text) is not str:
        raise TypeError("documentary text must be an exact string")
    if (
        type(origin) is not str
        or origin != "PROSE"
        or not text.strip()
        or len(text) > MAX_RELATION_INPUT
        or re.search(r"\r?\n[ \t]*\r?\n", text)
        or _UNSAFE.search(text)
        or _QUOTED.search(text)
        or _REPORT.search(text)
        or any(
            unicodedata.category(char) in {"Cc", "Cf", "Cs", "Zl", "Zp"}
            and char not in "\t\r\n"
            for char in text
        )
    ):
        return None
    sentences = split_documentary_sentences(text)
    if not sentences or any(
        len(sentence.text) > MAX_RELATION_SENTENCE for sentence in sentences
    ):
        return None
    subjects = []
    for sentence in sentences:
        if sentence.text.endswith("?"):
            continue
        match = _INVENTORY_SUBJECT.match(sentence.text)
        if match is None:
            continue
        label = match["subject"]
        # Preserve quantified labels, but do not treat deictic references,
        # conditional antecedents or multiple coordinated clauses as subjects.
        if (
            _PRONOUN.search(label)
            or re.search(r"\b(?:if|when|unless|and|or|because|while)\b", label, re.I)
        ):
            continue
        span = _span(
            text,
            sentence.start + match.start("subject"),
            sentence.start + match.end("subject"),
        )
        if span.text not in {item.text for item in subjects}:
            subjects.append(span)
    if not subjects or len(subjects) > MAX_RELATION_ASSERTIONS:
        return None
    qualifications = tuple(
        SourceSpan(match[0], match.start(), match.end())
        for match in _INVENTORY_QUALIFIER.finditer(text)
    )
    references = tuple(
        SourceSpan(match[0], match.start(), match.end())
        for match in _PRONOUN.finditer(text)
    )
    if len(qualifications) + len(references) > 256:
        return None
    bindings = []
    for match in _IMMEDIATE_RELATIVE.finditer(text):
        antecedent = match["antecedent"]
        if _PRONOUN.search(antecedent) or _QUALIFIED.search(antecedent):
            continue
        if re.search(r"\b(?:and|or|which|that)\b", antecedent, re.I):
            continue
        bindings.append(
            RelativeSurfaceBinding(
                SourceSpan(match["reference"], match.start("reference"), match.end("reference")),
                SourceSpan(antecedent, match.start("antecedent"), match.end("antecedent")),
            )
        )
    return DocumentaryParentInventory(
        SourceSpan(text, 0, len(text)),
        tuple(subjects), qualifications, references, tuple(bindings),
    )


def _span(text: str, start: int, end: int) -> SourceSpan:
    while start < end and text[start].isspace():
        start += 1
    while end > start and text[end - 1].isspace():
        end -= 1
    return SourceSpan(text[start:end], start, end)


def _label(text: str, *, plural: bool = False) -> bool:
    """Narrow noun-shaped surface, not an independently established noun POS."""
    if (
        not text
        or len(text) > MAX_RELATION_LABEL
        or re.fullmatch(_LABEL, text) is None
        or _PRONOUN.search(text)
        or _RELATIVE_OR_VERB.search(text)
        or _QUALIFIED.search(text)
        or _REPORT.search(text)
    ):
        return False
    words = text.split()
    # Avoid silently treating action/degree modifiers as a simple noun class.
    if any(word.casefold().endswith(("ly", "ing", "ed")) for word in words):
        return False
    if plural:
        head = words[-1].casefold()
        return head.endswith("s") and not head.endswith(("ous", "ss", "us", "is"))
    return True


def _named_speaker(text: str) -> bool:
    # Explicit source label, not guessed from a section, job, or earlier sentence.
    return (
        _label(text)
        and text[0].isupper()
        and not re.match(r"(?:the|a|an)\s+", text, re.IGNORECASE)
    )


def _attribution(text: str, sentence: SourceSpan) -> NamedAttribution | None:
    match = _ATTRIBUTION.fullmatch(sentence.text.rstrip(".!")) or _ACCORDING.fullmatch(
        sentence.text.rstrip(".!")
    )
    if match is None or not _named_speaker(match["speaker"]):
        return None
    claim = match["claim"]
    topic = _CLAIM.fullmatch(claim)
    if topic is None or _PRONOUN.search(claim) or _REPORT.search(claim):
        return None
    if not _label(topic["topic"]):
        return None
    # A conditional/reported antecedent is not a self-contained named claim.
    if re.search(r"\b(?:if|when|unless|provided|assuming)\b", claim, re.IGNORECASE):
        return None
    offset = sentence.start
    claim_span = _span(text, offset + match.start("claim"), offset + match.end("claim"))
    return NamedAttribution(
        match["speaker"],
        topic["topic"],
        claim_span,
        sentence,
        _span(text, offset + match.start("speaker"), offset + match.end("speaker")),
        _span(
            text,
            claim_span.start + topic.start("topic"),
            claim_span.start + topic.end("topic"),
        ),
        SourceSpan(text, 0, len(text)),
    )


def _list(text: str, start: int, end: int) -> tuple[SourceSpan, ...]:
    raw = text[start:end]
    # An explicit final conjunction is required for a multi-item enumeration.
    if "," in raw and re.search(r",?\s+and\s+", raw, re.IGNORECASE) is None:
        return ()
    boundaries = list(re.finditer(r",\s*(?:and\s+)?|\s+and\s+", raw, re.IGNORECASE))
    parts, cursor = [], 0
    for boundary in boundaries:
        parts.append(_span(text, start + cursor, start + boundary.start()))
        cursor = boundary.end()
    parts.append(_span(text, start + cursor, end))
    if len(parts) > MAX_RELATION_LIST:
        return ()
    if any(not _label(item.text) for item in parts):
        return ()
    if len({item.text.casefold() for item in parts}) != len(parts):
        return ()
    return tuple(parts)


def _relations(text: str, sentence: SourceSpan) -> tuple[DocumentaryRelation, ...]:
    raw = sentence.text.rstrip(".!")
    patterns = (
        (
            r"(?P<left>.+?)\s+(?:is|are)\s+(?:a kind of|a type of|types of|kinds of)\s+(?P<right>.+)",
            "is_a",
            "left",
            "right",
            True,
        ),
        (
            r"(?P<left>.+?)\s+(?:is|are)\s+(?:a part of|part of|parts of|a component of|components of|a constituent of|constituents of)\s+(?P<right>.+)",
            "part_of",
            "left",
            "right",
            True,
        ),
        (
            r"(?P<left>.+?)\s+(?:consists of|has a component called|has a part called)\s+(?P<right>.+)",
            "part_of",
            "right",
            "left",
            True,
        ),
        (
            r"(?P<left>.+?)\s+(?:is|are|was|were)\s+caused by\s+(?P<right>.+)",
            "causes",
            "right",
            "left",
            False,
        ),
        (
            r"(?P<left>.+?)\s+(?:causes?|leads? to)\s+(?P<right>.+)",
            "causes",
            "left",
            "right",
            False,
        ),
        (
            r"(?P<left>.+?)\s+is\s+(?:a|an)\s+(?P<right>.+)",
            "is_a",
            "left",
            "right",
            False,
        ),
        (r"(?P<left>.+?)\s+are\s+(?P<right>.+)", "is_a", "left", "right", False),
    )
    for index, (pattern, predicate, subject_group, object_group, lists) in enumerate(
        patterns
    ):
        match = re.fullmatch(pattern, raw, re.IGNORECASE)
        if match is None:
            continue
        spans = {
            name: _span(
                text,
                sentence.start + match.start(name),
                sentence.start + match.end(name),
            )
            for name in ("left", "right")
        }
        subject, target = spans[subject_group], spans[object_group]
        # Enumeration belongs to exactly one side; never distribute both sides
        # into an invented Cartesian product or split causal conjunctions.
        subjects = _list(text, subject.start, subject.end) if lists else (subject,)
        objects = _list(text, target.start, target.end) if lists else (target,)
        if not subjects or not objects or (len(subjects) > 1 and len(objects) > 1):
            return ()
        if any(not _label(item.text, plural=index == 6) for item in objects):
            return ()
        if any(not _label(item.text) for item in subjects):
            return ()
        return tuple(
            DocumentaryRelation(left.text, predicate, right.text, sentence, left, right)
            for left in subjects
            for right in objects
        )
    return ()


def parse_documentary_relations(
    text: str, *, origin: str = "PROSE"
) -> RelationExtraction:
    """Parse a complete bounded original passage; return review-only candidates.

    ``origin`` is a caller-supplied classification, not authenticated provenance.
    A caller must verify original scope and adjacent guard context before use.
    Qualifications/reporting anywhere suppress all *direct* edges in the passage;
    they are never deleted to recover a convenient subclause. Named attribution
    is preserved separately with its qualified claim, without direct edges.
    """
    if type(text) is not str:
        raise TypeError("documentary text must be an exact string")
    whole = SourceSpan(text, 0, len(text))
    if type(origin) is not str or origin != "PROSE":
        return RelationExtraction(
            review_reasons=(RelationReview("non_assertion_origin", whole),)
        )
    if not text.strip() or len(text) > MAX_RELATION_INPUT:
        return RelationExtraction(
            review_reasons=(RelationReview("invalid_or_oversized_passage", whole),)
        )
    if _UNSAFE.search(text) or _QUOTED.search(text):
        return RelationExtraction(
            review_reasons=(RelationReview("unsafe_or_quoted_passage", whole),)
        )
    sentences = split_documentary_sentences(text)
    if not sentences or any(
        len(item.text) > MAX_RELATION_SENTENCE for item in sentences
    ):
        return RelationExtraction(
            review_reasons=(RelationReview("incomplete_or_oversized_sentence", whole),)
        )
    assertions, attributed, reviews = [], [], []
    guarded = bool(_QUALIFIED.search(text) or _REPORT.search(text))
    for sentence in sentences:
        if sentence.text.endswith("?"):
            reviews.append(RelationReview("question_not_assertion", sentence))
            continue
        claim = _attribution(text, sentence)
        if claim is not None:
            attributed.append(claim)
            if len(assertions) + len(attributed) > MAX_RELATION_ASSERTIONS:
                return RelationExtraction(
                    review_reasons=(RelationReview("assertion_limit_exceeded", whole),)
                )
            continue
        if guarded:
            reviews.append(
                RelationReview("qualified_conditional_or_unresolved_report", sentence)
            )
            continue
        candidates = _relations(text, sentence)
        if candidates:
            assertions.extend(candidates)
        else:
            reviews.append(
                RelationReview("unsupported_or_ambiguous_relation", sentence)
            )
        if len(assertions) + len(attributed) > MAX_RELATION_ASSERTIONS:
            return RelationExtraction(
                review_reasons=(RelationReview("assertion_limit_exceeded", whole),)
            )
    return RelationExtraction(tuple(assertions), tuple(attributed), tuple(reviews))
