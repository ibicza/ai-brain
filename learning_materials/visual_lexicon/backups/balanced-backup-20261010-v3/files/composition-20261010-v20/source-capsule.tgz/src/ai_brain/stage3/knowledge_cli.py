"""Practical M-33 CLI. Run: python -m ai_brain.stage3.knowledge_cli --help."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from ai_brain.stage2.facts.canonical import canonical_json
from ai_brain.stage3.acquisition.direct_material import (
    DIRECT_REVIEW_ROLE,
    install_direct_material,
    prepare_direct_material,
)
from ai_brain.stage3.acquisition.material_installation import (
    install_reviewed_material,
    prepare_material,
)
from ai_brain.stage3.acquisition.semantic_material import (
    SEMANTIC_REVIEW_ROLE,
    install_semantic_material,
    prepare_semantic_material,
)
from ai_brain.stage3.capabilities.persistence import load_registry
from ai_brain.stage3.capabilities.scalar_equation_solver import NeedsNewCapability
from ai_brain.stage3.domains.knowledge_service import InstalledKnowledgeService
from ai_brain.stage3.domains.registry import InstalledDomainRegistry
from ai_brain.stage3.providers.persistence import load_provider_registry


def build_parser():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path("artifacts/m33-practical"))
    repository = Path(__file__).resolve().parents[3]
    parser.add_argument(
        "--providers",
        type=Path,
        default=repository / "artifacts/stage3/providers/registry_v2.json",
    )
    parser.add_argument(
        "--capabilities",
        type=Path,
        default=repository / "artifacts/stage3/capabilities/registry_v2.json",
    )
    commands = parser.add_subparsers(dest="command", required=True)
    prepare = commands.add_parser(
        "prepare", help="snapshot material and emit a review; never install"
    )
    prepare.add_argument("paths", nargs="+", type=Path)
    prepare.add_argument("--domain-id", required=True)
    prepare.add_argument("--pack-version", default="0.1.0-provisional")
    prepare.add_argument("--output", required=True, type=Path)
    read = commands.add_parser(
        "read",
        help="read books/articles/docs/source documentation directly; emit review only",
    )
    read.add_argument("paths", nargs="*", type=Path)
    read.add_argument("--url", action="append", default=[])
    read.add_argument("--source-root", type=Path)
    read.add_argument("--domain-id", required=True)
    read.add_argument("--pack-version", default="0.1.0-documentary")
    read.add_argument("--output", required=True, type=Path)
    learn = commands.add_parser(
        "learn",
        help="propose source-bound typed knowledge from ordinary material; never auto-approve",
    )
    learn.add_argument("paths", nargs="*", type=Path)
    learn.add_argument("--url", action="append", default=[])
    learn.add_argument("--source-root", type=Path)
    learn.add_argument("--domain-id", required=True)
    learn.add_argument("--pack-version", default="0.1.0-semantic")
    learn.add_argument("--output", required=True, type=Path)
    approve = commands.add_parser(
        "approve", help="explicitly review, compile and install"
    )
    approve.add_argument("review", type=Path)
    approve.add_argument("--review-hash", required=True)
    approve.add_argument("--reviewer", required=True)
    selection = approve.add_mutually_exclusive_group(required=True)
    selection.add_argument("--proposal-id", action="append")
    selection.add_argument(
        "--all-verified",
        action="store_true",
        help="explicit selection of every structurally verified proposal in this exact review",
    )
    selection.add_argument(
        "--all-reviewed-excerpts",
        action="store_true",
        help="explicitly approve all documentary excerpts after inspecting their exact review",
    )
    selection.add_argument(
        "--all-reviewed-knowledge",
        action="store_true",
        help="explicit approval of the exact semantic review including evidence dependency closure",
    )
    approve.add_argument("--pack-output", type=Path, required=True)
    query = commands.add_parser("query")
    query.add_argument("--domain-id", required=True)
    query.add_argument(
        "--operation",
        required=True,
        help="list, lookup, taxonomy, temporal, interpretations, contract, solve; other operations abstain",
    )
    query.add_argument("--reference")
    query.add_argument("--arguments", default="{}", help="JSON object")
    query.add_argument("--pack-version")
    for name in ("search", "ask", "reason"):
        retrieval = commands.add_parser(
            name,
            help="retrieve quoted evidence by ordinary question; no source execution",
        )
        retrieval.add_argument("question")
        retrieval.add_argument("--domain-id")
        retrieval.add_argument("--limit", type=int, default=5)
        if name in {"ask", "reason"}:
            retrieval.add_argument(
                "--arguments",
                help="optional explicit numeric request: unknown, known values with units, conditions",
            )
    commands.add_parser("list")
    commands.add_parser("verify")
    return parser


def _registry(args, *, create=False):
    providers = load_provider_registry(args.providers)
    capabilities = load_registry(args.capabilities, providers)
    method = (
        InstalledDomainRegistry.open_or_initialize
        if create
        else InstalledDomainRegistry.open
    )
    return method(
        args.root / "installed",
        capability_registry=capabilities,
        provider_registry=providers,
    )


def main(argv=None):
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    args = build_parser().parse_args(argv)
    try:
        if args.command in {"prepare", "read", "learn"}:
            # Check the output collision before making any acquisition writes.
            if args.output.exists():
                raise FileExistsError("review output exists; choose a fresh file")
            options = {
                "domain_id": args.domain_id,
                "pack_version": args.pack_version,
                "store_root": args.root / "acquisition",
            }
            if args.command in {"read", "learn"}:
                reader = (
                    prepare_semantic_material
                    if args.command == "learn"
                    else prepare_direct_material
                )
                review = reader(
                    tuple(args.paths),
                    source_root=args.source_root,
                    urls=tuple(args.url),
                    **options,
                )
            else:
                review = prepare_material(tuple(args.paths), **options)
            args.output.parent.mkdir(parents=True, exist_ok=True)
            with args.output.open("x", encoding="utf-8", newline="\n") as stream:
                stream.write(canonical_json(review) + "\n")
            result = {
                "status": "REVIEW_REQUIRED",
                "review_hash": review["review_hash"],
                "proposal_count": len(review["proposals"]),
                "installed": False,
                "review_file": str(args.output),
                "extraction_report": review.get("extraction_report", []),
                "review_questions": review.get("review_questions", []),
            }
        elif args.command == "approve":
            review = json.loads(args.review.read_text(encoding="utf-8"))
            selection = (
                tuple(
                    item["proposal_id"]
                    for item in review["proposals"]
                    if item["status"] == "VERIFIED"
                )
                if args.all_verified
                else tuple(item["proposal_id"] for item in review["proposals"])
                if args.all_reviewed_excerpts or args.all_reviewed_knowledge
                else tuple(args.proposal_id)
            )
            direct = review.get("contract_role") == DIRECT_REVIEW_ROLE
            semantic = review.get("contract_role") == SEMANTIC_REVIEW_ROLE
            if args.all_reviewed_excerpts and not direct:
                raise ValueError(
                    "--all-reviewed-excerpts is only for direct documentary reviews"
                )
            if args.all_reviewed_knowledge and not semantic:
                raise ValueError("--all-reviewed-knowledge requires a semantic review")
            installer = (
                install_semantic_material
                if semantic
                else install_direct_material
                if direct
                else install_reviewed_material
            )
            result = installer(
                review,
                expected_review_hash=args.review_hash,
                approved_proposal_ids=selection,
                reviewer_identity=args.reviewer,
                store_root=args.root / "acquisition",
                pack_output=args.pack_output,
                registry=_registry(args, create=True),
            )
        else:
            registry = _registry(args)
            if args.command in {"search", "ask", "reason"}:
                service = InstalledKnowledgeService(registry)
                if args.command == "search":
                    result = service.search(
                        args.question, domain_id=args.domain_id, limit=args.limit
                    )
                else:
                    method = service.reason if args.command == "reason" else service.ask
                    options = {
                        "domain_id": args.domain_id,
                        "arguments": json.loads(args.arguments)
                        if args.arguments
                        else None,
                    }
                    if args.command == "ask":
                        options["limit"] = args.limit
                    result = method(args.question, **options)
            elif args.command == "query":
                result = InstalledKnowledgeService(registry).query(
                    args.domain_id,
                    args.operation,
                    reference=args.reference,
                    arguments=json.loads(args.arguments),
                    pack_version=args.pack_version,
                )
            elif args.command == "verify":
                result = registry.verify()
            else:
                result = {
                    "status": "OK",
                    "domains": [
                        {
                            "domain_id": item.domain_id,
                            "pack_version": item.pack_version,
                            "pack_hash": item.pack_hash,
                            "status": item.status.value,
                        }
                        for item in registry.list()
                    ],
                }
        print(canonical_json(result))
        return (
            0
            if result["status"]
            not in {"INVALID_REQUEST", "STALE_AUTHORITY", "RESOURCE_LIMIT"}
            else 2
        )
    except NeedsNewCapability as error:
        print(canonical_json({"status": "NEEDS_NEW_CAPABILITY", "reason": str(error)}))
        return 0
    except (ValueError, KeyError, OSError) as error:
        print(canonical_json({"status": "BLOCKED", "reason": str(error)}))
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
