"""Source-bound documentary import without manually authored @directives.

Original bytes -> replayable documentary text view -> INTERPRETIVE concepts ->
explicit review -> the existing M32 compiler and installed-domain registry.
No rule, executable API authority or Java trust authorization is synthesized.
"""

from __future__ import annotations

import os
import re
from dataclasses import asdict
from pathlib import Path

from ai_brain.stage2.education.models import ActorIdentityType
from ai_brain.stage2.facts.canonical import (
    bytes_hash,
    canonical_json,
    content_hash,
    utc_now,
)
from ai_brain.stage3.acquisition.document_readers import (
    MAX_BLOCKS,
    MAX_INPUT_BYTES,
    read_document,
    reader_profile,
)
from ai_brain.stage3.acquisition.material_installation import (
    _compile_reviewed_selection,
)
from ai_brain.stage3.acquisition.models import (
    AcquisitionManifest,
    DocumentStructure,
    ExtractionMethod,
    KnowledgeProposal,
    M33SourceReviewProposal,
    ProposalStatus,
    SegmentKind,
    SourceBundle,
    SourceDocument,
    SourceLocation,
    SourceMediaType,
    SourceSegment,
)
from ai_brain.stage3.acquisition.persistence import AcquisitionStore
from ai_brain.stage3.acquisition.sources import _RESOURCE_POLICY, verify_bundle
from ai_brain.stage3.acquisition.verification import verify_proposals
from ai_brain.stage3.acquisition.version import (
    KNOWLEDGE_PROPOSAL_SCHEMA_VERSION,
    SOURCE_COMPILER_VERSION,
)
from ai_brain.stage3.capabilities.scalar_equation_solver import NeedsNewCapability
from ai_brain.stage3.knowledge_ir.records import (
    ConceptContent,
    EpistemicCharacter,
    KnowledgeKind,
)

DIRECT_REVIEW_ROLE = "M33_DIRECT_DOCUMENTARY_REVIEW_V1"
EXCERPT_PREFIX = "DIRECT_SOURCE_EXCERPT_V1\n"
MAX_RAW_SELECTION_BYTES = 256 * 1024 * 1024
_SUFFIXES = {
    ".txt",
    ".md",
    ".markdown",
    ".rst",
    ".html",
    ".htm",
    ".pdf",
    ".py",
    ".java",
    ".js",
    ".ts",
    ".c",
    ".h",
    ".cpp",
    ".hpp",
    ".cs",
    ".go",
    ".rs",
    ".kt",
}
_IGNORE = {
    ".git",
    ".venv",
    "node_modules",
    "__pycache__",
    "artifacts",
    "tmp",
    ".code-review-graph",
}


def discover_material(paths):
    found = []
    visited = 0
    for supplied in paths:
        if supplied.is_symlink() or supplied.is_junction():
            raise ValueError("document symlinks/junctions are forbidden")
        if supplied.is_dir():
            for directory, folders, files in os.walk(supplied, followlinks=False):
                visited += 1
                if visited > 10000:
                    raise ValueError("source directory discovery exceeds limit")
                folders[:] = sorted(
                    name
                    for name in folders
                    if name not in _IGNORE
                    and not (Path(directory) / name).is_symlink()
                    and not (Path(directory) / name).is_junction()
                )
                found.extend(
                    Path(directory) / name
                    for name in sorted(files)
                    if Path(name).suffix.casefold() in _SUFFIXES
                )
                if len(found) > 256:
                    raise ValueError(
                        "source selection exceeds 256 documents; select a chapter/subdirectory"
                    )
        else:
            found.append(supplied)
    if not found or len(found) > 256:
        raise ValueError("select between 1 and 256 supported documents")
    if any(
        path.is_symlink() or path.is_junction() or not path.is_file() for path in found
    ):
        raise ValueError("source must be a regular file")
    resolved = tuple(path.resolve(strict=True) for path in found)
    if len(set(resolved)) != len(resolved):
        raise ValueError("duplicate document selection")
    return resolved


def prepare_direct_material(
    paths,
    *,
    domain_id,
    store_root,
    pack_version="0.1.0-documentary",
    source_root=None,
    urls=(),
    timestamp=None,
):
    if type(domain_id) is not str or not re.fullmatch(
        r"[a-z][a-z0-9_.-]{2,95}", domain_id
    ):
        raise ValueError("invalid domain identity")
    files = discover_material(paths) if paths else ()
    if (
        type(urls) is not tuple
        or not files
        and not urls
        or len(files) + len(urls) > 256
    ):
        raise ValueError("select 1..256 files or explicit source URLs")
    root = source_root.resolve(strict=True) if source_root else None
    if root and (
        not root.is_dir() or any(not path.is_relative_to(root) for path in files)
    ):
        raise ValueError("source root must contain all selected files")
    names = [path.relative_to(root).as_posix() if root else path.name for path in files]
    if len({name.casefold() for name in names}) != len(names):
        raise ValueError(
            "duplicate source names; supply --source-root to preserve relative paths"
        )
    sizes = [path.stat().st_size for path in files]
    if (
        any(size > MAX_INPUT_BYTES for size in sizes)
        or sum(sizes) > MAX_RAW_SELECTION_BYTES
    ):
        raise ValueError("source selection exceeds raw input limits")
    store = AcquisitionStore.open_or_initialize(store_root)
    raw_sources, total = [], 0
    for path, name in zip(files, names, strict=True):
        # Stat is an early rejection only, not the size of the captured bytes.
        # Read at most the remaining allowance plus one byte to detect overflow
        # before allocating or persisting an unbounded, concurrently grown file.
        allowance = min(MAX_INPUT_BYTES, MAX_RAW_SELECTION_BYTES - total)
        with path.open("rb") as stream:
            raw = stream.read(allowance + 1)
        if len(raw) > MAX_INPUT_BYTES:
            raise ValueError("source size changed beyond input limit")
        total += len(raw)
        if total > MAX_RAW_SELECTION_BYTES:
            raise ValueError("source selection exceeds total input limit")
        raw_sources.append(
            {
                "name": name,
                "original_bytes_hash": store.put_blob(raw),
                "source_url": None,
            }
        )
    from ai_brain.stage3.acquisition.document_fetch import fetch_document

    for url in urls:
        raw, name, final_url = fetch_document(url)
        total += len(raw)
        if total > MAX_RAW_SELECTION_BYTES:
            raise ValueError("source selection exceeds total input limit")
        raw_sources.append(
            {
                "name": name,
                "original_bytes_hash": store.put_blob(raw),
                "source_url": final_url,
            }
        )
    if len({source["name"].casefold() for source in raw_sources}) != len(raw_sources):
        raise ValueError("source identities collide")
    return _prepare_from_snapshots(
        raw_sources, domain_id, pack_version, store, timestamp or utc_now()
    )


def _prepare_from_snapshots(raw_sources, domain_id, pack_version, store, stamp):
    from ai_brain.stage3.acquisition.documentary_replay import (
        custody_profile,
        documentary_payload,
    )

    profile = reader_profile()
    documents, segments, proposals, reports, review_contexts = [], [], [], [], []
    derived_total = 0
    for document_index, source in enumerate(raw_sources, 1):
        raw = store.get_blob(source["original_bytes_hash"])
        report = read_document(raw, source["name"])
        reports.append(
            {
                **source,
                "format": report["format"],
                "block_count": len(report["blocks"]),
                "issues": report["issues"],
            }
        )
        if not report["blocks"]:
            review_contexts.append(
                {
                    "inventory_index": document_index - 1,
                    "original_name": source["name"],
                    "raw_hash": source["original_bytes_hash"],
                    "source_url": source["source_url"],
                    "format": report["format"],
                    "reader_profile": profile,
                    "decoder": "reader-specific",
                    "block_count": 0,
                    "view_hash": bytes_hash(b""),
                    "processing_state": "NO_DOCUMENT_BLOCKS",
                }
            )
            continue
        lines = []
        for ordinal, block in enumerate(report["blocks"], 1):
            payload = documentary_payload(source, report, ordinal, profile)
            lines.append(canonical_json(payload) + "\n")
        view = "".join(lines).encode("utf-8")
        derived_total += len(view)
        if len(view) > 8 * 1024 * 1024 or derived_total > 32 * 1024 * 1024:
            raise ValueError(
                "documentary views exceed compiler resource limits; split the input"
            )
        view_hash = store.put_blob(view)
        review_contexts.append(
            {
                "inventory_index": document_index - 1,
                "original_name": source["name"],
                "raw_hash": source["original_bytes_hash"],
                "source_url": source["source_url"],
                "format": report["format"],
                "reader_profile": profile,
                "decoder": "reader-specific",
                "block_count": len(report["blocks"]),
                "view_hash": view_hash,
                "processing_state": "DERIVED_DOCUMENT",
            }
        )
        structure_body = {
            "heading_count": 0,
            "table_count": 0,
            "code_block_count": 0,
            "page_count": None,
        }
        structure = DocumentStructure(
            **structure_body, structure_hash=content_hash(structure_body)
        )
        document_body = {
            "document_id": f"{domain_id}.document.{document_index:03d}",
            "media_type": SourceMediaType.TEXT,
            "language": "mixed",
            "relative_path": source["name"] + ".documentation-view.txt",
            "bytes_hash": view_hash,
            "canonical_text_hash": view_hash,
            "source_metadata": (
                ("original_name", source["name"]),
                ("original_bytes_hash", source["original_bytes_hash"]),
                ("scope", "DOCUMENTATION_VIEW_ONLY"),
                ("reader_profile", profile),
            ),
            "imported_at": stamp,
            "version": pack_version,
            "parent_bundle_id": domain_id,
            "structure": structure,
        }
        document = SourceDocument(
            **document_body, document_hash=content_hash(document_body)
        )
        documents.append(document)
        offset = 0
        for ordinal, line in enumerate(lines, 1):
            length = len(line.encode("utf-8"))
            segment_body = {
                "segment_id": f"{domain_id}.segment.{len(segments) + 1:05d}",
                "bundle_id": domain_id,
                "document_id": document.document_id,
                "kind": SegmentKind.PARAGRAPH,
                "ordinal": len(segments),
                "canonical_text": line.rstrip("\n"),
                "source_location": SourceLocation(
                    offset, offset + length, ordinal, ordinal, ()
                ),
                "source_span_hash": bytes_hash(view[offset : offset + length]),
            }
            segment = SourceSegment(
                **segment_body, segment_hash=content_hash(segment_body)
            )
            segments.append(segment)
            offset += length
            # Names are documentary identities, not extracted term identities.
            label = f"source {source['name']} block {ordinal} {source['original_bytes_hash'][:12]}"
            content = ConceptContent(
                label,
                label,
                EXCERPT_PREFIX + segment.canonical_text,
                EXCERPT_PREFIX + segment.canonical_text,
            )
            proposal_body = {
                "proposal_id": "",
                "source_bundle_id": domain_id,
                "segment_ids": (segment.segment_id,),
                "proposed_kind": KnowledgeKind.CONCEPT,
                "proposed_epistemic_character": EpistemicCharacter.INTERPRETIVE,
                "proposed_content": content,
                "proposed_dependencies": (),
                "proposed_applicability": (),
                "proposed_capabilities": (),
                "extraction_method": ExtractionMethod.REVIEWED_MAPPING,
                "status": ProposalStatus.REVIEW_REQUIRED,
                "ambiguity_fields": ("documentary_truth_and_context_require_review",),
                "compiler_version": SOURCE_COMPILER_VERSION,
                "schema_version": KNOWLEDGE_PROPOSAL_SCHEMA_VERSION,
            }
            proposal_body["proposal_id"] = (
                "proposal." + content_hash(proposal_body)[:32]
            )
            proposals.append(
                KnowledgeProposal(
                    **proposal_body, proposal_hash=content_hash(proposal_body)
                )
            )
            if len(proposals) > MAX_BLOCKS:
                raise ValueError(
                    f"source selection exceeds {MAX_BLOCKS} documentary passages"
                )
    if not proposals:
        raise NeedsNewCapability(
            "NEEDS_NEW_CAPABILITY: selection contains no readable documentary material"
        )
    from ai_brain.stage3.acquisition.source_review_metadata import (
        build_source_review_metadata,
    )

    # This optional witness must not narrow legacy preparation's 256-original
    # limit. Unsupported review metadata means no optional API license, not a
    # fabricated empty carrier or failure of the ordinary base review path.
    try:
        metadata = build_source_review_metadata(domain_id, tuple(review_contexts))
    except ValueError:
        metadata = None
    if metadata is not None:
        body = asdict(proposals[0])
        body.pop("proposal_hash")
        body.update(proposal_id="", producer_review_metadata=metadata)
        body["proposal_id"] = "proposal." + content_hash(body)[:32]
        proposals[0] = M33SourceReviewProposal(**body, proposal_hash=content_hash(body))
    manifest_body = {
        "compiler_version": SOURCE_COMPILER_VERSION,
        "resource_policy_hash": content_hash(_RESOURCE_POLICY),
        "runtime_network": False,
        "document_hashes": tuple(d.document_hash for d in documents),
        "schema_version": 1,
    }
    manifest = AcquisitionManifest(
        **manifest_body, manifest_hash=content_hash(manifest_body)
    )
    bundle_body = {
        "bundle_id": domain_id,
        "domain_tags": (domain_id, "documentary-evidence"),
        "documents": tuple(documents),
        "manifest": manifest,
        "created_at": stamp,
    }
    bundle = SourceBundle(**bundle_body, bundle_hash=content_hash(bundle_body))
    verify_bundle(bundle, store=store)
    segments = tuple(segments)
    proposals = verify_proposals(bundle, segments, tuple(proposals), store)
    store.save_bundle(bundle)
    segment_set = store.save_segments(bundle.bundle_hash, segments)
    proposal_set = store.save_proposals(segment_set, proposals)
    body = {
        "schema_version": 1,
        "contract_role": DIRECT_REVIEW_ROLE,
        "domain_id": domain_id,
        "pack_version": pack_version,
        "reader_profile": profile,
        "custody_profile": custody_profile(),
        "raw_sources": raw_sources,
        "extraction_report": reports,
        "bundle_object": content_hash(asdict(bundle)),
        "segments_object": segment_set,
        "proposals_object": proposal_set,
        "documents": [asdict(d) for d in documents],
        "proposals": [asdict(p) for p in proposals],
        "installed": False,
    }
    return {**body, "review_hash": content_hash(body)}


def install_direct_material(
    review,
    *,
    expected_review_hash,
    approved_proposal_ids,
    reviewer_identity,
    store_root,
    pack_output,
    registry,
    reviewer_type=ActorIdentityType.USER,
    timestamp=None,
):
    if (
        type(review) is not dict
        or review.get("contract_role") != DIRECT_REVIEW_ROLE
        or review.get("installed") is not False
        or type(review.get("schema_version")) is not int
        or review["schema_version"] != 1
    ):
        raise ValueError("invalid direct material review")
    body = {key: value for key, value in review.items() if key != "review_hash"}
    if (
        review.get("review_hash") != expected_review_hash
        or content_hash(body) != expected_review_hash
        or review.get("reader_profile") != reader_profile()
    ):
        raise ValueError(
            "direct review hash or reader profile changed; prepare a fresh review"
        )
    if (
        type(reviewer_identity) is not str
        or not reviewer_identity.strip()
        or reviewer_type
        not in {ActorIdentityType.USER, ActorIdentityType.TRUSTED_PROCESS}
        or type(approved_proposal_ids) is not tuple
        or not approved_proposal_ids
        or any(type(x) is not str for x in approved_proposal_ids)
        or len(set(approved_proposal_ids)) != len(approved_proposal_ids)
    ):
        raise ValueError("explicit reviewer and nonempty unique selection required")
    if not store_root.is_dir():
        raise FileNotFoundError("source snapshot store is missing")
    store = AcquisitionStore(store_root)
    store.verify()
    bundle = store.load_bundle(review["bundle_object"])
    # Replay from original bytes. An edited display, locator or quote cannot be
    # legitimized by merely recomputing its outward review hash.
    rebuilt = _prepare_from_snapshots(
        review["raw_sources"],
        review["domain_id"],
        review["pack_version"],
        store,
        bundle.created_at,
    )
    if canonical_json(rebuilt) != canonical_json(review):
        raise ValueError("direct review differs from replayed original snapshots")
    proposals = store.load_proposals(review["proposals_object"])
    by_id = {p.proposal_id: p for p in proposals}
    if not set(approved_proposal_ids) <= set(by_id):
        raise ValueError("unknown documentary selection")
    selected = tuple(by_id[identity] for identity in approved_proposal_ids)
    if any(
        p.status is not ProposalStatus.REVIEW_REQUIRED
        or p.proposed_kind is not KnowledgeKind.CONCEPT
        or p.proposed_epistemic_character is not EpistemicCharacter.INTERPRETIVE
        for p in selected
    ):
        raise ValueError("direct import permits documentary evidence only")
    from ai_brain.stage3.acquisition.documentary_replay import build_documentary_closure

    closure = build_documentary_closure(review["raw_sources"], store)
    return _compile_reviewed_selection(
        bundle,
        store.load_segments(review["segments_object"]),
        selected,
        expected_review_hash=expected_review_hash,
        reviewer_identity=reviewer_identity,
        reviewer_type=reviewer_type,
        pack_output=pack_output,
        pack_version=review["pack_version"],
        registry=registry,
        store=store,
        timestamp=timestamp,
        documentary_closure=closure,
    )
