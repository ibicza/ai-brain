"""Bounded documentary signature parsing; descriptors are not execution authority.

The scanner preserves parameter spelling instead of inferring types or defaults.
Python syntax is inspected as AST only. Java signatures use structural checks,
not Java type resolution. Unsupported or ambiguous declarations return ``None``.
"""

from __future__ import annotations

import ast
import hashlib
import json
import re
import unicodedata
from dataclasses import dataclass

MAX_SIGNATURE_CHARS = 8192
MAX_SIGNATURE_DEPTH = 24
MAX_SIGNATURE_PARAMETERS = 64
_CALLABLE = re.compile(r"([A-Za-z_$][\w$]*(?:\.[A-Za-z_$][\w$]*)*)\s*$")
_PAIRS = {"(": ")", "[": "]", "{": "}", "<": ">"}
REFERENCE_POLICY_VERSION = 1
REFERENCE_POLICY_ROLE = "OPAQUE_DOCUMENTARY_REFERENCE"


@dataclass(frozen=True)
class DocumentaryReferencePolicy:
    """Syntactic, parent-bound token policy; never self-authenticating evidence."""

    version: int
    role: str
    signature: str
    callable_name: str
    parameters: tuple[tuple[str, str], ...]
    declared_type_variables: tuple[str, ...]
    reference_parameters: tuple[tuple[str, str, str], ...]
    return_spelling: str
    content_fingerprint: str
    policy_hash: str


@dataclass(frozen=True)
class DocumentaryIntegralReturnPolicy:
    """Exact source declaration spelling, not Java execution/type resolution."""

    version: int
    role: str
    signature: str
    callable_name: str
    parameters: tuple[tuple[str, str], ...]
    return_spelling: str
    content_fingerprint: str
    policy_hash: str


def java_documentary_integral_return_policy(
    signature, *, callable_name, parameters, content_fingerprint
):
    """Reconstruct a bounded primitive integral declaration without inference.

    Parent custody must establish original source identity. A supplied spelling,
    digest or this token alone cannot confer provenance or installation authority.
    Annotated, generic, throwing, array and unfamiliar declarations refuse.
    """
    if (
        type(signature) is not str or len(signature) > MAX_SIGNATURE_CHARS
        or type(callable_name) is not str
        or not re.fullmatch(r"[A-Za-z_$][\w$]*(?:\.[A-Za-z_$][\w$]*){0,15}", callable_name)
        or len(callable_name) > 512
        or type(parameters) is not tuple or not 1 <= len(parameters) <= 16
        or type(content_fingerprint) is not str
        or not re.fullmatch(r"[0-9a-f]{64}", content_fingerprint)
    ):
        return None
    try:
        if len(signature.encode("utf-8")) > MAX_SIGNATURE_CHARS:
            return None
    except UnicodeError:
        return None
    if any(char not in "\t\r\n" and unicodedata.category(char) in {"Cc", "Cf", "Cs"}
           for char in signature):
        return None
    if (parse_document_signature(signature, language="java", callable_name=callable_name) is None
            or java_documentary_parameters(signature) != parameters):
        return None
    parsed = _java_documentary_node(signature.strip(), "DocumentaryOwner")
    if parsed is None or not parsed[1]:
        return None
    raw, nodes = parsed
    declaration = nodes[0].parent.parent
    if (declaration.type != "method_declaration"
            or declaration.child_by_field_name("type_parameters") is not None
            or declaration.child_by_field_name("dimensions") is not None):
        return None
    pending, visited = [declaration], 0
    while pending:
        node = pending.pop()
        visited += 1
        if visited > 256 or node.type in {
            "annotation", "marker_annotation", "line_comment", "block_comment", "throws",
        }:
            return None
        pending.extend(node.named_children)
    result_node = declaration.child_by_field_name("type")
    if result_node is None:
        return None
    spelling = raw[result_node.start_byte:result_node.end_byte].decode()
    if spelling not in {"byte", "short", "int", "long"}:
        return None
    body = dict(version=1, role="EXACT_DOCUMENTARY_INTEGRAL_RETURN", signature=signature,
                callable_name=callable_name, parameters=parameters, return_spelling=spelling,
                content_fingerprint=content_fingerprint)
    digest = hashlib.sha256(json.dumps(body, ensure_ascii=False, sort_keys=True,
                                      separators=(",", ":"), allow_nan=False).encode()).hexdigest()
    return DocumentaryIntegralReturnPolicy(**body, policy_hash=digest)


def java_documentary_reference_policy(
    signature, *, callable_name, parameters, content_fingerprint
):
    """Build a bounded syntax policy from one exact method declaration.

    This pure API does not establish that a signature belongs to installed
    evidence. The trusted caller must bind the exact same callable/source scope
    and rederive it; neither caller arguments nor a digest confer provenance.
    Unbounded *method-declared* variables and exact Object spellings alone have
    opaque roles. Bounds, annotations, arrays, varargs and unfamiliar types refuse.
    """
    if (
        type(signature) is not str
        or type(callable_name) is not str
        or type(content_fingerprint) is not str
        or not re.fullmatch(r"[0-9a-f]{64}", content_fingerprint)
        or not re.fullmatch(
            r"[A-Za-z_$][\w$]*(?:\.[A-Za-z_$][\w$]*){0,15}", callable_name
        )
        or len(callable_name) > 512
        or type(parameters) is not tuple
        or not 1 <= len(parameters) <= 16
        or len(signature) > MAX_SIGNATURE_CHARS
    ):
        return None
    try:
        if len(signature.encode("utf-8")) > MAX_SIGNATURE_CHARS:
            return None
    except UnicodeError:
        return None
    if any(
        type(row) is not tuple
        or len(row) != 2
        or any(type(item) is not str or len(item) > 512 for item in row)
        for row in parameters
    ):
        return None
    if (
        parse_document_signature(
            signature, language="java", callable_name=callable_name
        )
        is None
        or java_documentary_parameters(signature) != parameters
    ):
        return None
    parsed = _java_documentary_node(signature.strip(), "DocumentaryOwner")
    if parsed is None or not parsed[1]:
        return None
    raw, nodes = parsed
    declaration = nodes[0].parent.parent
    if declaration.type != "method_declaration":
        return None
    # An unknown annotation may itself add an obligation. No short-name guesses.
    pending = [declaration]
    visited = 0
    while pending:
        node = pending.pop()
        visited += 1
        if visited > 256:
            return None
        if node.type in {
            "annotation",
            "marker_annotation",
            "line_comment",
            "block_comment",
            "throws",
        }:
            return None
        pending.extend(node.named_children)
    variables = []
    type_parameters = declaration.child_by_field_name("type_parameters")
    if type_parameters is not None:
        if not 1 <= len(type_parameters.named_children) <= 16:
            return None
        for node in type_parameters.named_children:
            if (
                node.type != "type_parameter"
                or len(node.named_children) != 1
                or node.named_children[0].type != "type_identifier"
            ):
                return None
            identity = raw[node.start_byte : node.end_byte].decode()
            if not re.fullmatch(r"[A-Za-z_$][A-Za-z0-9_$]{0,63}", identity):
                return None
            variables.append(identity)
        if len(set(variables)) != len(variables):
            return None
    known = {
        "byte",
        "short",
        "int",
        "long",
        "boolean",
        "String",
        "java.lang.String",
        "Byte",
        "Short",
        "Integer",
        "Long",
        "Boolean",
        "java.lang.Byte",
        "java.lang.Short",
        "java.lang.Integer",
        "java.lang.Long",
        "java.lang.Boolean",
    }
    references = []
    for name, spelling in parameters:
        if spelling in variables:
            references.append((name, spelling, "METHOD_TYPE_VARIABLE"))
        elif spelling in {"Object", "java.lang.Object"}:
            references.append((name, spelling, "NOMINAL_OBJECT_SPELLING"))
        elif spelling not in known:
            return None
    result_node = declaration.child_by_field_name("type")
    if result_node is None or declaration.child_by_field_name("dimensions") is not None:
        return None
    result = _canonical_java_type(
        raw[result_node.start_byte : result_node.end_byte].decode()
    )
    if result not in known | set(variables) | {"Object", "java.lang.Object", "void"}:
        return None
    used = {spelling for _, spelling in parameters}
    if not references or any(name not in used for name in variables):
        return None
    body = {
        "version": REFERENCE_POLICY_VERSION,
        "role": REFERENCE_POLICY_ROLE,
        "signature": signature,
        "callable_name": callable_name,
        "parameters": parameters,
        "declared_type_variables": tuple(variables),
        "reference_parameters": tuple(references),
        "return_spelling": result,
        "content_fingerprint": content_fingerprint,
    }
    digest = hashlib.sha256(
        json.dumps(
            body,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
            allow_nan=False,
        ).encode("utf-8")
    ).hexdigest()
    return DocumentaryReferencePolicy(**body, policy_hash=digest)


def _python_shape(name, body, suffix, parameters):
    if suffix.endswith(":"):
        suffix = suffix[:-1].rstrip()
    if suffix and not suffix.startswith("->"):
        return False
    try:
        tree = ast.parse(f"def {name}({body}) {suffix}:\n    pass\n")
    except (SyntaxError, ValueError, RecursionError):
        return False
    if sum(1 for _ in ast.walk(tree)) > 256:
        return False
    args = tree.body[0].args
    names = [item.arg for item in (*args.posonlyargs, *args.args, *args.kwonlyargs)]
    names.extend(item.arg for item in (args.vararg, args.kwarg) if item is not None)
    return len(names) == len(set(names)) and len(names) == sum(
        value not in {"/", "*"} for value in parameters
    )


def _java_documentary_node(signature, name):
    """Return a bounded syntactic declaration's raw bytes/parameters, or None."""
    import tree_sitter_java
    from tree_sitter import Language, Parser

    ending = "" if signature.endswith(";") else " {}"
    raw = f"class {name} {{ {signature}{ending} }}".encode()
    root = Parser(Language(tree_sitter_java.language())).parse(raw).root_node
    if root.has_error:
        return None
    body = root.named_children[0].child_by_field_name("body")
    if (
        body is None
        or len(body.named_children) != 1
        or body.named_children[0].type
        not in {"method_declaration", "constructor_declaration"}
    ):
        return None
    parameters = body.named_children[0].child_by_field_name("parameters")
    if parameters is None:
        return None
    if any(
        parameter.type == "spread_parameter"
        for parameter in parameters.named_children[:-1]
    ):
        return None
    names = []
    for parameter in parameters.named_children:
        identity = parameter.child_by_field_name("name")
        if identity is None:
            declarator = next(
                (
                    child
                    for child in parameter.named_children
                    if child.type == "variable_declarator"
                ),
                None,
            )
            identity = declarator.child_by_field_name("name") if declarator else None
        if identity is None and parameter.type == "receiver_parameter":
            names.append("this")
        elif identity is None:
            return None
        else:
            names.append(raw[identity.start_byte : identity.end_byte].decode())
    return (
        (raw, tuple(parameters.named_children))
        if len(names) == len(set(names))
        else None
    )


def _java_shape(signature, name):
    """Validate syntax only; no imports, erasure, linkage or assignability."""
    return _java_documentary_node(signature, name) is not None


def _callable_matches(rendered, declared):
    # A short name constrains only the basename. With an explicit owner, permit
    # source-rendered suffixes (Type.f vs package.Type.f), not a different owner.
    if "." not in declared:
        return rendered.rsplit(".", 1)[-1] == declared
    return declared == rendered or declared.endswith("." + rendered)


def parse_document_signature(signature, *, language=None, callable_name=None):
    """Return exact raw parameter descriptors, ``()`` for no args, or ``None``.

    ``language`` is ``python``, ``java``, ``documentary`` or ``None``. Passing the
    documented callable name (qualified or short) prevents annotation calls from
    being selected as a method. Generic angle brackets are recognized outside
    defaults and annotation expressions in Java/documentary mode. Lambda headers
    and quoted commas do not split parameters. No expression is evaluated.
    """
    if (
        type(signature) is not str
        or not signature.strip()
        or len(signature) > MAX_SIGNATURE_CHARS
        or language not in (None, "python", "java", "documentary")
        or callable_name is not None
        and (
            type(callable_name) is not str
            or not re.fullmatch(_CALLABLE.pattern, callable_name)
        )
    ):
        return None
    text = signature.strip()
    stack, candidates, parts = [], [], []
    quote, escaped, opening, start = None, False, None, None
    default, lambda_headers = False, 0
    position = 0
    while position < len(text):
        char = text[position]
        if quote is not None:
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif text.startswith(quote, position):
                position += len(quote)
                quote = None
                continue
            position += 1
            continue
        if char in {"'", '"'}:
            quote = char * 3 if text.startswith(char * 3, position) else char
            position += len(quote)
            continue
        top_parameter = opening is not None and len(stack) == 1
        if (
            top_parameter
            and default
            and re.match(r"lambda\b", text[position:])
            and (
                position == 0
                or not (text[position - 1].isalnum() or text[position - 1] == "_")
            )
        ):
            lambda_headers += 1
        if top_parameter and char == ":" and lambda_headers:
            lambda_headers -= 1
        if top_parameter and char == "=":
            if language == "java":
                return None
            default = True
        if top_parameter and char == "," and not lambda_headers:
            value = text[start:position].strip()
            if not value or len(parts) >= MAX_SIGNATURE_PARAMETERS:
                return None
            parts.append(value)
            start, default = position + 1, False
        generic = (
            char == "<"
            and language != "python"
            and (not stack or stack[-1] == "<" or top_parameter and not default)
        )
        if generic and re.match(r"\s*[>,]", text[position + 1 :]):
            return None
        if char in "([{" or generic:
            if not stack and char == "(":
                match = _CALLABLE.search(text[:position])
                annotation = (
                    match is not None
                    and match.start() > 0
                    and text[match.start() - 1] == "@"
                )
                if match and not annotation:
                    name = match[1]
                    if callable_name is not None and not _callable_matches(
                        name, callable_name
                    ):
                        return None
                    if candidates or opening is not None:
                        return None
                    opening, start = position, position + 1
                    selected_name = name.rsplit(".", 1)[-1]
            stack.append(char)
            if len(stack) > MAX_SIGNATURE_DEPTH:
                return None
        elif char in ")]}":
            if not stack or _PAIRS[stack[-1]] != char:
                return None
            if top_parameter and char == ")":
                value = text[start:position].strip()
                if value:
                    parts.append(value)
                elif parts and language == "java":
                    return None
                if lambda_headers or len(parts) > MAX_SIGNATURE_PARAMETERS:
                    return None
                candidates.append((opening, position, selected_name, tuple(parts)))
                opening, start = None, None
            stack.pop()
        elif char == ">" and stack and stack[-1] == "<":
            stack.pop()
        elif (
            (
                char == ">"
                and language != "python"
                and not default
                and len(stack) <= 1
                and (position == 0 or text[position - 1] != "-")
            )
            or char == ";"
            and (stack or position != len(text) - 1)
        ):
            return None
        position += 1
    if stack or quote is not None or len(candidates) != 1:
        return None
    begin, end, name, parameters = candidates[0]
    suffix = text[end + 1 :].strip()
    if language == "python" and not _python_shape(
        name, text[begin + 1 : end], suffix, parameters
    ):
        return None
    if language == "java":
        if not _java_shape(text, name):
            return None
        if suffix and not re.fullmatch(r"(?:throws\s+[\w$.,\s]+)?\s*;?", suffix):
            return None
        parameter_names = set()
        for value in parameters:
            # Require a type/name descriptor, not an untyped Python argument.
            match = re.search(r"\b[A-Za-z_$][\w$]*(?:\s*\[\s*\])*\s*$", value)
            if not match or not value[: match.start()].strip():
                return None
            parameter_name = re.match(r"[A-Za-z_$][\w$]*", match[0])[0]
            if parameter_name in parameter_names:
                return None
            parameter_names.add(parameter_name)
    elif language != "python":
        if suffix and not suffix.startswith("->"):
            return None
        # A documentary spelling must fit at least one supported declaration
        # grammar, not merely balance its punctuation. A mixed/unknown dialect
        # remains an excerpt rather than a guessed structured contract.
        body = text[begin + 1 : end]
        if not _python_shape(name, body, suffix, parameters) and (
            suffix or not _java_shape(f"void {name}({body})", name)
        ):
            return None
    return parameters


def java_documentary_parameter_types(signature):
    """Return exact documented Java type spellings, or ``None`` if unsupported.

    Insignificant whitespace is normalized for syntactic comparison; keyword
    and identifier boundaries and quoted annotation values are preserved. Arrays and
    varargs remain spelled as documented: ``T`` is not erased, a short type is
    not resolved against imports, and ``T...`` is not equated to ``T[]``. This
    helper grants no callable execution or Java semantic trust authorization.
    """
    descriptors = java_documentary_parameters(signature)
    return None if descriptors is None else tuple(value for _, value in descriptors)


def _java_identifier_part(char):
    return (
        char.isalnum()
        or char in {"_", "$"}
        or unicodedata.category(char)
        in {
            "Mn",
            "Mc",
            "Pc",
            "Sc",
            "Cf",
        }
    )


def _canonical_java_type(value):
    """Compact punctuation, preserving lexical boundaries and literal bytes."""
    result, position, quote, escaped = [], 0, None, False
    while position < len(value):
        char = value[position]
        if quote is not None:
            if not escaped and value.startswith(quote, position):
                result.append(quote)
                position += len(quote)
                quote = None
                continue
            result.append(char)
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            position += 1
            continue
        if char in {'"', "'"}:
            quote = char * 3 if value.startswith(char * 3, position) else char
            result.append(quote)
            position += len(quote)
            continue
        if char.isspace():
            while position < len(value) and value[position].isspace():
                position += 1
            if result and position < len(value):
                previous, following = result[-1][-1], value[position]
                if (
                    _java_identifier_part(previous)
                    and _java_identifier_part(following)
                    or previous == "?"
                    and re.match(r"(?:extends|super)\b", value[position:])
                ):
                    result.append(" ")
            continue
        if char == "?" and re.match(r"(?:extends|super)\b", value[position + 1 :]):
            result.append("? ")
        else:
            result.append(char)
        position += 1
    return None if quote is not None else "".join(result)


def java_documentary_parameters(signature):
    """Return ``((source_name, canonical_documented_type), ...)`` or ``None``.

    Names come from the declaration AST, never positional guesses. Types preserve
    syntactic generic/array/varargs spelling, normalizing only insignificant
    whitespace and preserving keyword/identifier boundaries and literals. This
    documentary mapping neither resolves Java types nor supplies executable or
    return-type authority: the contract remains documented-not-executed.
    """
    if parse_document_signature(signature, language="java") is None:
        return None
    parsed = _java_documentary_node(signature.strip(), "DocumentaryOwner")
    if parsed is None:
        return None
    raw, parameters = parsed
    result = []
    for parameter in parameters:
        dimensions = parameter.child_by_field_name("dimensions")
        if parameter.type == "formal_parameter":
            type_node = parameter.child_by_field_name("type")
            identity = parameter.child_by_field_name("name")
            varargs = False
        elif parameter.type == "spread_parameter":
            types = [
                child
                for child in parameter.named_children
                if child.type not in {"modifiers", "variable_declarator"}
            ]
            if len(types) != 1:
                return None
            type_node, varargs = types[0], True
            declarator = next(
                (
                    child
                    for child in parameter.named_children
                    if child.type == "variable_declarator"
                ),
                None,
            )
            if (
                declarator is None
                or declarator.child_by_field_name("dimensions") is not None
            ):
                return None
            identity = declarator.child_by_field_name("name")
        else:
            # Receiver parameters and undocumented grammar need another policy.
            return None
        if type_node is None or type_node.type == "void_type" or identity is None:
            return None
        value = raw[type_node.start_byte : type_node.end_byte].decode()
        if dimensions is not None:
            value += raw[dimensions.start_byte : dimensions.end_byte].decode()
        if varargs:
            value += "..."
        if "/*" in value or "//" in value:
            return None
        name = raw[identity.start_byte : identity.end_byte].decode()
        canonical = _canonical_java_type(value)
        if canonical is None:
            return None
        result.append((name, canonical))
    # The normalized representation must still be a valid bounded declaration,
    # rather than merely a string that looks suitable for equality comparison.
    roundtrip = (
        "void documentaryRoundtrip("
        + ", ".join(f"{value} {name}" for name, value in result)
        + ")"
    )
    if (
        len(roundtrip) > MAX_SIGNATURE_CHARS
        or _java_documentary_node(roundtrip, "DocumentaryOwner") is None
    ):
        return None
    return tuple(result)


def parse_documentary_type_reference(reference):
    """Parse ``qualified.callable(Type, OtherType...)`` without inferring types.

    Only a bounded Java type spelling is accepted, without argument names,
    expressions, annotations, or code. Types are validated as documentary syntax
    by a fabricated declaration; no source is compiled or executed. Returns the
    original callable name and canonical exact type spellings, or ``None``.
    """
    if (
        type(reference) is not str
        or not reference.strip()
        or len(reference) > MAX_SIGNATURE_CHARS
    ):
        return None
    text = reference.strip()
    match = re.fullmatch(
        r"([A-Za-z_$][\w$]*(?:\.[A-Za-z_$][\w$]*)*)\s*\((.*)\)", text, re.DOTALL
    )
    if match is None:
        return None
    name, body = match.groups()
    if not body.strip():
        return name, ()
    if re.search(r"[^\w$.,<>\[\]?\s]", body):
        return None
    types, stack, start = [], [], 0
    for position, char in enumerate(body):
        if char in "<[":
            stack.append(char)
            if len(stack) > MAX_SIGNATURE_DEPTH:
                return None
        elif char in ">]":
            if not stack or _PAIRS[stack[-1]] != char:
                return None
            stack.pop()
        elif char == "," and not stack:
            value = body[start:position].strip()
            if not value or len(types) >= MAX_SIGNATURE_PARAMETERS:
                return None
            types.append(value)
            start = position + 1
    value = body[start:].strip()
    if stack or not value or len(types) >= MAX_SIGNATURE_PARAMETERS:
        return None
    types.append(value)
    declaration = (
        "void documentaryCallable("
        + ", ".join(f"{value} argument{ordinal}" for ordinal, value in enumerate(types))
        + ")"
    )
    if len(declaration) > MAX_SIGNATURE_CHARS:
        return None
    canonical = java_documentary_parameter_types(declaration)
    return None if canonical is None else (name, canonical)
