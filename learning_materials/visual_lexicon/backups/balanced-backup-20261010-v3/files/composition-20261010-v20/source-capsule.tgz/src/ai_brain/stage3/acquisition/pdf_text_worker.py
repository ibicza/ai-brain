"""Isolated, bounded PDF text reader. Never executes document actions or OCR."""

from __future__ import annotations

import io
import json
import sys

MAX_BYTES = 64 * 1024 * 1024
MAX_TEXT = 8 * 1024 * 1024
MAX_PAGES = 2000


def _memory_limit():
    if sys.platform != "win32":
        import resource

        resource.setrlimit(resource.RLIMIT_AS, (1024**3, 1024**3))
        return None
    # A private nested job constrains only this reader process, not the host.
    import ctypes
    from ctypes import wintypes

    class Basic(ctypes.Structure):
        _fields_ = [
            ("process_time", ctypes.c_longlong),
            ("job_time", ctypes.c_longlong),
            ("flags", wintypes.DWORD),
            ("min_working", ctypes.c_size_t),
            ("max_working", ctypes.c_size_t),
            ("active", wintypes.DWORD),
            ("affinity", ctypes.c_size_t),
            ("priority", wintypes.DWORD),
            ("scheduling", wintypes.DWORD),
        ]

    class Limits(ctypes.Structure):
        _fields_ = [
            ("basic", Basic),
            ("io", ctypes.c_ulonglong * 6),
            ("process_memory", ctypes.c_size_t),
            ("job_memory", ctypes.c_size_t),
            ("peak_process", ctypes.c_size_t),
            ("peak_job", ctypes.c_size_t),
        ]

    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel.CreateJobObjectW.argtypes = [ctypes.c_void_p, wintypes.LPCWSTR]
    kernel.CreateJobObjectW.restype = wintypes.HANDLE
    kernel.GetCurrentProcess.restype = wintypes.HANDLE
    kernel.SetInformationJobObject.argtypes = [
        wintypes.HANDLE,
        ctypes.c_int,
        ctypes.c_void_p,
        wintypes.DWORD,
    ]
    kernel.AssignProcessToJobObject.argtypes = [wintypes.HANDLE, wintypes.HANDLE]
    handle = kernel.CreateJobObjectW(None, None)
    limits = Limits()
    limits.basic.flags = 0x100  # JOB_OBJECT_LIMIT_PROCESS_MEMORY
    limits.process_memory = 512 * 1024 * 1024
    if (
        not handle
        or not kernel.SetInformationJobObject(
            handle, 9, ctypes.byref(limits), ctypes.sizeof(limits)
        )
        or not kernel.AssignProcessToJobObject(handle, kernel.GetCurrentProcess())
    ):
        raise RuntimeError("PDF worker could not establish its memory limit")
    return handle  # Keep it alive until the process exits.


def main():
    job_handle = _memory_limit()
    from pypdf import PdfReader

    raw = sys.stdin.buffer.read(MAX_BYTES + 1)
    if len(raw) > MAX_BYTES:
        raise ValueError("PDF exceeds input limit")
    reader = PdfReader(io.BytesIO(raw), strict=True)
    if reader.is_encrypted:
        raise ValueError("encrypted PDF requires an explicitly decrypted input")
    if len(reader.pages) > MAX_PAGES:
        raise ValueError("PDF exceeds page limit")
    result, total = [], 0
    for ordinal, page in enumerate(reader.pages, 1):
        contents = page.get_contents()
        if contents is not None and len(contents.get_data()) > 4 * 1024 * 1024:
            raise ValueError("PDF page content stream exceeds limit")
        text = page.extract_text() or ""
        total += len(text.encode("utf-8"))
        if total > MAX_TEXT:
            raise ValueError("PDF extracted text exceeds limit")
        resources = page.get("/Resources", {})
        if hasattr(resources, "get_object"):
            resources = resources.get_object()
        objects = resources.get("/XObject", {})
        if hasattr(objects, "get_object"):
            objects = objects.get_object()
        has_image = any(
            item.get_object().get("/Subtype") == "/Image" for item in objects.values()
        )
        result.append({"page": ordinal, "text": text, "has_image": has_image})
    # ASCII JSON escaping is lossless and independent of the Windows locale.
    sys.stdout.write(json.dumps({"pages": result}, ensure_ascii=True))
    sys.stdout.flush()
    return job_handle


if __name__ == "__main__":
    try:
        main()
    except Exception as error:  # noqa: BLE001 -- isolated worker reports every failure, never success
        sys.stdout.write(
            json.dumps({"error": type(error).__name__, "reason": str(error)})
        )
        sys.stdout.flush()
        raise SystemExit(2)
