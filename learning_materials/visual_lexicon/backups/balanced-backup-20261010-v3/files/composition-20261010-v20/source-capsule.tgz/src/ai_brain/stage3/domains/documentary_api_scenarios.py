"""Bounded hypothetical documentary API obligations, never Java execution.

Nominal primitive/reference spellings are an input policy, not the Java type
system or evidence of runtime acceptance. Source clauses must parse completely;
unknown qualifications never disappear into a partial successful assessment.
"""

from __future__ import annotations

import hashlib
import json
import re
from dataclasses import dataclass

from ai_brain.stage3.domains.javadoc_clause_view import documentary_clause_view
from ai_brain.stage3.knowledge_ir.records import (
    ClaimSchemaContent,
    EntityTypeRef,
    ValueTypeKind,
    ValueTypeRef,
)

MAX_PARAMETERS = 16
MAX_CLAUSES = 16
MAX_CLAUSE_BYTES = 4096
MAX_TOTAL_CLAUSE_BYTES = 32768
MAX_ARGUMENT_STRING_BYTES = 4096
MAX_TOTAL_ARGUMENT_BYTES = 16384
MAX_INTEGER_BITS = 128
MAX_PREDICATE_NODES = 32
MAX_SOURCE_PARAGRAPHS = 48
MAX_REPEAT_COUNT = 4096
MAX_REPEAT_OUTPUT_BYTES = 65536
SCOPE = "HYPOTHETICAL_DOCUMENTED_API_OBLIGATIONS_ONLY"
_NAME = r"[A-Za-z_$][A-Za-z0-9_$]{0,63}"
_EXCEPTION = rf"{_NAME}(?:\.{_NAME}){{0,3}}"
_LITERAL = r"null|true|false|-?(?:0|[1-9][0-9]{0,39})"
_INTEGRAL = {"byte", "short", "int", "long"}
_BOXED_INTEGRAL = {"Byte", "Short", "Integer", "Long"}
_INTEGER_WIDTHS = {
    "byte": 8,
    "Byte": 8,
    "short": 16,
    "Short": 16,
    "int": 32,
    "Integer": 32,
    "long": 64,
    "Long": 64,
}


class _Invalid(Exception):
    pass


class _Unsupported(Exception):
    pass


class _Limit(Exception):
    pass


class _OpaqueReference:
    """Internal token kind, never a modeled Java object or inferred String."""


def _bytes(text, ceiling):
    if type(text) is not str:
        raise _Invalid("Exact source strings required")
    if len(text) > ceiling:
        raise _Limit("Documentary scenario string ceiling")
    try:
        size = len(text.encode("utf-8"))
    except UnicodeError as error:
        raise _Invalid("Invalid Unicode") from error
    if size > ceiling:
        raise _Limit("Documentary scenario byte ceiling")
    return size


def _literal(text):
    if text == "null":
        return None
    if text == "true":
        return True
    if text == "false":
        return False
    if not re.fullmatch(r"-?(?:0|[1-9][0-9]{0,39})", text):
        raise _Unsupported("Unsupported source literal")
    number = int(text)
    if abs(number).bit_length() > MAX_INTEGER_BITS:
        raise _Limit("Integer literal representation ceiling")
    return number


def _parameter_types(content, reference_policy=None):
    if type(content.parameters) is not tuple:
        raise _Invalid("Exact parameter tuples required")
    if len(content.parameters) > MAX_PARAMETERS:
        raise _Limit("Parameter ceiling")
    references = _validated_reference_policy(content, reference_policy)
    types = {}
    for row in content.parameters:
        if type(row) is not tuple or len(row) != 2:
            raise _Invalid("Exact parameter descriptor required")
        name, spelling = row
        if (
            type(name) is not str
            or not re.fullmatch(_NAME, name)
            or name in {"null", "true", "false"}
            or name in types
        ):
            raise _Invalid("Unique exact documentary parameter names required")
        if type(spelling) is not str:
            raise _Invalid("Exact documentary type spelling required")
        if name in references:
            kind, nullable = _OpaqueReference, True
        elif spelling in {"String", "java.lang.String"}:
            kind, nullable = str, True
        elif spelling in _INTEGRAL:
            kind, nullable = int, False
        elif spelling in _BOXED_INTEGRAL or spelling in {
            "java.lang." + item for item in _BOXED_INTEGRAL
        }:
            kind, nullable = int, True
        elif spelling == "boolean":
            kind, nullable = bool, False
        elif spelling in {"Boolean", "java.lang.Boolean"}:
            kind, nullable = bool, True
        else:
            raise _Unsupported("Unsupported documentary input type")
        types[name] = (kind, nullable)
    return types


def _parameters(content, values, reference_policy=None):
    if type(values) is not dict:
        raise _Invalid("Exact argument object required")
    if len(values) > MAX_PARAMETERS:
        raise _Limit("Parameter ceiling")
    types = _parameter_types(content, reference_policy)
    if any(type(name) is not str for name in values) or set(values) != set(types):
        raise _Invalid("Missing, extra or differently spelled parameter")
    size = 0
    for name, value in values.items():
        size += len(name)
        kind, nullable = types[name]
        if value is None:
            if not nullable:
                raise _Invalid("Null is not an admitted primitive argument")
            size += 4
        elif kind is _OpaqueReference:
            size += _bytes(value, MAX_ARGUMENT_STRING_BYTES)
        elif type(value) is not kind:
            raise _Invalid("Argument type differs; no coercion or bool-as-int")
        elif kind is str:
            size += _bytes(value, MAX_ARGUMENT_STRING_BYTES)
        elif kind is int:
            if abs(value).bit_length() > MAX_INTEGER_BITS:
                raise _Limit("Integer argument representation ceiling")
            spelling = dict(content.parameters)[name].removeprefix("java.lang.")
            width = _INTEGER_WIDTHS[spelling]
            if not -(1 << (width - 1)) <= value < (1 << (width - 1)):
                raise _Invalid("Argument exceeds its declared Java integral range")
            size += 40
        else:
            size += 5
    if size > MAX_TOTAL_ARGUMENT_BYTES:
        raise _Limit("Aggregate hypothetical argument ceiling")
    return types


@dataclass(frozen=True)
class _Predicate:
    parameter: str
    operator: str
    literal: object
    right_parameter: str | None = None

    def payload(self):
        result = {
            "parameter": self.parameter,
            "operator": self.operator,
            "literal": self.literal,
        }
        if self.right_parameter is not None:
            result.pop("literal")
            result["right_parameter"] = self.right_parameter
        return result

    def names(self):
        return (self.parameter,) + (
            (self.right_parameter,) if self.right_parameter is not None else ()
        )


@dataclass(frozen=True)
class _Compound:
    operator: str
    operands: tuple[_Predicate, ...]

    def payload(self):
        return {
            "operator": self.operator,
            "operands": [item.payload() for item in self.operands],
        }

    def names(self):
        return tuple(sorted({name for item in self.operands for name in item.names()}))


def _atom(text, types):
    right_parameter = None
    match = re.fullmatch(
        rf"({_NAME})\s+is\s+(not\s+)?(null|true|false)", text, re.IGNORECASE
    )
    if match:
        parameter, operator, literal = (
            match[1],
            "!=" if match[2] else "==",
            _literal(match[3]),
        )
    else:
        match = re.fullmatch(
            rf"({_NAME})\s+is\s+(negative|nonnegative)", text, re.IGNORECASE
        )
        if match:
            parameter, operator, literal = (
                match[1],
                "<" if match[2].lower() == "negative" else ">=",
                0,
            )
        else:
            match = re.fullmatch(
                rf"({_NAME})\s+is\s+(not\s+)?(less than or equal to|greater than or equal to|less than|greater than|equal to)\s+({_LITERAL}|{_NAME})",
                text,
                re.IGNORECASE,
            )
            if match:
                parameter = match[1]
                operator = {
                    "less than": "<",
                    "greater than": ">",
                    "equal to": "==",
                    "less than or equal to": "<=",
                    "greater than or equal to": ">=",
                }[match[3].lower()]
                if match[2]:
                    operator = {"<": ">=", ">": "<=", "==": "!=", "<=": ">", ">=": "<"}[
                        operator
                    ]
                operand = match[4]
            else:
                match = re.fullmatch(
                    rf"({_NAME})\s*(==|!=|<=|>=|=|<|>)\s*({_LITERAL}|{_NAME})",
                    text,
                    re.IGNORECASE,
                )
                if not match:
                    raise _Unsupported("Complete anchored condition required")
                parameter = match[1]
                operator = "==" if match[2] == "=" else match[2]
                operand = match[3]
            if operand in types:
                right_parameter, literal = operand, None
            else:
                literal = _literal(operand)
    if parameter not in types:
        raise _Unsupported("Condition names an undocumented parameter")
    kind = types[parameter][0]
    if right_parameter is not None:
        # No Java object equality, type resolution, coercion or unboxing claim.
        if kind is not int or types[right_parameter][0] is not int:
            raise _Unsupported("Only integral parameter comparisons supported")
    elif literal is not None and (type(literal) is not kind or kind is str):
        raise _Unsupported("Condition literal/type policy mismatch")
    if operator not in {"==", "!="} and (
        kind is not int or right_parameter is None and type(literal) is not int
    ):
        raise _Unsupported("Only integral ordered conditions are supported")
    return _Predicate(parameter, operator, literal, right_parameter)


def _condition(text, types):
    """Flat homogeneous conjunctions only; mixed precedence/nesting is unknown.

    An omitted subject is recoverable only in an immediately following ``is``
    clause. It never licenses pronoun, noun-category or arbitrary co-reference.
    """
    # ``or equal to`` belongs to one complete ordered comparison, not a branch.
    pieces = re.split(r"\s+(and|or(?!\s+equal\s+to\b))\s+", text, flags=re.IGNORECASE)
    if len(pieces) == 1:
        return _atom(text, types)
    if len(pieces) // 2 + 2 > MAX_PREDICATE_NODES:
        raise _Limit("Predicate node ceiling")
    operators = {item.lower() for item in pieces[1::2]}
    if len(operators) != 1:
        raise _Unsupported("Mixed compound precedence unsupported")
    operands = []
    for piece in pieces[::2]:
        if re.match(r"is\s+", piece, re.IGNORECASE):
            if not operands:
                raise _Unsupported("Elided condition has no explicit subject")
            piece = operands[-1].parameter + " " + piece
        operands.append(_atom(piece, types))
    return _Compound(operators.pop().upper(), tuple(operands))


def _met(predicate, values):
    if type(predicate) is _Compound:
        # Evaluate every leaf; a true OR branch cannot hide an unknown null order.
        results = tuple(_met(item, values) for item in predicate.operands)
        return all(results) if predicate.operator == "AND" else any(results)
    left = values[predicate.parameter]
    right = (
        values[predicate.right_parameter]
        if predicate.right_parameter is not None
        else predicate.literal
    )
    if predicate.right_parameter is not None and (
        type(left) is not int or type(right) is not int
    ):
        raise _Unsupported("Nullable parameter comparison has no integral values")
    if predicate.operator in {"==", "!="}:
        # Exact primitive identity: False never equals numeric zero.
        equal = type(left) is type(right) and left == right
        return equal if predicate.operator == "==" else not equal
    if type(left) is not int:
        raise _Unsupported("Ordered nullable condition has no integral value")
    if predicate.operator == "<":
        return left < right
    if predicate.operator == "<=":
        return left <= right
    if predicate.operator == ">":
        return left > right
    return left >= right


def _precondition(text, types):
    match = re.fullmatch(
        rf"Requires\s+({_NAME})\s+(?:to be nonnull|not null)", text, re.IGNORECASE
    )
    if match:
        return _condition(match[1] + " is not null", types)
    match = re.fullmatch(rf"({_NAME})\s+must\s+(not\s+)?be\s+null", text, re.IGNORECASE)
    if match:
        return _condition(
            match[1] + (" is not null" if match[2] else " is null"), types
        )
    match = re.fullmatch(r"Requires\s+(.+)", text, re.IGNORECASE)
    if not match:
        raise _Unsupported("Complete required precondition unsupported")
    return _condition(match[1], types)


def _exception(text, types):
    match = re.fullmatch(
        rf"(?:Throws|Raises):\s*({_EXCEPTION})\s+-\s+(?:if|when)\s+(.+)",
        text,
        re.IGNORECASE,
    )
    if match:
        return match[1], _condition(match[2], types)
    match = re.fullmatch(
        rf"(?:Throws|Raises)\s+({_EXCEPTION})\s+(?:if|when)\s+(.+)", text, re.IGNORECASE
    )
    if match:
        return match[1], _condition(match[2], types)
    match = re.fullmatch(
        rf"If\s+(.+),\s*(?:throws|raises)\s+({_EXCEPTION})", text, re.IGNORECASE
    )
    if not match:
        raise _Unsupported("Complete guarded documented exception unsupported")
    return match[2], _condition(match[1], types)


def _return_leaf(text, types):
    text = re.sub(r"^Returns:\s*", "Returns ", text, flags=re.IGNORECASE)
    match = re.fullmatch(
        rf"Returns\s+(?:the (?:same|value of)\s+({_NAME})|({_NAME})\s+unchanged)",
        text,
        re.IGNORECASE,
    )
    if match:
        parameter = match[1] or match[2]
        if parameter not in types:
            raise _Unsupported("Return names an undocumented parameter")
        return {"kind": "ARGUMENT_VALUE", "parameter": parameter}
    match = re.fullmatch(
        rf"Returns\s+the non-null\s+({_NAME})\s+that was validated",
        text,
        re.IGNORECASE,
    )
    if match:
        guard = _condition(match[1] + " is not null", types)
        if types[match[1]][0] not in {str, _OpaqueReference}:
            raise _Unsupported("Non-null reference return requires reference policy")
        return {
            "kind": "ARGUMENT_VALUE",
            "parameter": match[1],
            "_guard": guard,
        }
    match = re.fullmatch(rf"Returns\s+({_LITERAL})", text, re.IGNORECASE)
    if not match:
        raise _Unsupported("Complete explicit documented return unsupported")
    return {"kind": "SOURCE_LITERAL", "value": _literal(match[1])}


@dataclass(frozen=True)
class _Choice:
    guard: _Predicate | _Compound
    if_leaf: dict
    otherwise_leaf: dict


@dataclass(frozen=True)
class _Partition:
    branches: tuple


def _partition(text, types, return_spelling):
    if return_spelling not in _INTEGRAL:
        raise _Unsupported("Partition requires exact declared primitive integral return")
    parts = text.removeprefix("Returns ").split(";")
    if len(parts) != 3:
        raise _Unsupported("Only a complete three-way integral partition is supported")
    branches, pair, operators = [], None, set()
    for part in parts:
        part = re.sub(r"^and\s+", "", part.strip(), flags=re.IGNORECASE)
        match = re.fullmatch(rf"(.+?)\s+if\s+({_NAME})\s*(==|<|>)\s*({_NAME})", part)
        if not match:
            raise _Unsupported("Complete finite partition branch required")
        leaf_text, left, operator, right = match.groups()
        leaf_text = re.sub(r"^the value\s+", "", leaf_text, flags=re.IGNORECASE)
        if (left == right or left not in types or right not in types
                or types[left][0] is not int or types[right][0] is not int):
            raise _Unsupported("Partition requires two distinct documentary integral parameters")
        if pair is not None and pair != (left, right) or operator in operators:
            raise _Unsupported("Partition must be disjoint over the same ordered pair")
        pair = (left, right)
        operators.add(operator)
        if leaf_text in {"a negative integer", "a positive integer", "< 0", "> 0", "<0", ">0"}:
            leaf = {"kind":"DOCUMENTED_SIGN_REGION",
                    "operator":"<" if leaf_text == "a negative integer" or leaf_text.startswith("<") else ">",
                    "boundary":0,"exact_value_known":False}
        else:
            leaf = _return_leaf("Returns " + leaf_text, types)
            if leaf["kind"] != "SOURCE_LITERAL" or type(leaf["value"]) is not int:
                raise _Unsupported("Partition requires exact integral literal or sign region")
            width = _INTEGER_WIDTHS[return_spelling]
            if not -(1 << (width-1)) <= leaf["value"] < (1 << (width-1)):
                raise _Unsupported("Literal exceeds declared documentary return range")
        branches.append((_condition(f"{left} {operator} {right}", types), leaf))
    if operators != {"==", "<", ">"}:
        raise _Unsupported("Partition does not cover integral equality and both orderings")
    return _Partition(tuple(branches))


@dataclass(frozen=True)
class _RepeatText:
    string_parameter: str
    count_parameter: str


def _leaf_class(leaf, types, spellings):
    if "_guard" in leaf:
        raise _Unsupported("Nested guarded return leaf unsupported")
    if leaf["kind"] == "SOURCE_LITERAL":
        return (type(leaf["value"]),), False
    name = leaf["parameter"]
    kind, nullable = types[name]
    if kind is _OpaqueReference:
        return (kind, spellings[name]), nullable
    return (kind,), nullable


def _return(text, types, spellings=None, return_spelling=None):
    spellings = {} if spellings is None else spellings
    text = re.sub(r"^Returns:\s*", "Returns ", text, flags=re.IGNORECASE)
    if text.startswith("Returns ") and text.count(";") >= 2:
        return _partition(text, types, return_spelling)
    match = re.fullmatch(
        r"Returns\s+(.+?)\s+if\s+(.+?);\s*otherwise\s+returns\s+(.+)",
        text,
        re.IGNORECASE,
    )
    if match:
        first, condition, second = match.groups()
    else:
        match = re.fullmatch(
            r"If\s+(.+?),\s*returns\s+(.+?);\s*otherwise\s+returns\s+(.+)",
            text,
            re.IGNORECASE,
        )
        if match:
            condition, first, second = match.groups()
    if match:
        guard = _condition(condition, types)
        leaves = tuple(
            _return_leaf("Returns " + leaf, types) for leaf in (first, second)
        )
        classes = tuple(_leaf_class(leaf, types, spellings) for leaf in leaves)
        null_class = (type(None),)
        if classes[0][0] != classes[1][0] and not (
            classes[0][0] == null_class
            and classes[1][1]
            or classes[1][0] == null_class
            and classes[0][1]
        ):
            raise _Unsupported("Choice leaf classes differ; no Java assignability")
        return _Choice(guard, *leaves)
    match = re.fullmatch(
        rf"Returns\s+(?:a string consisting of\s+)?({_NAME})\s+repeated\s+({_NAME})\s+times",
        text,
        re.IGNORECASE,
    )
    if match:
        string, count = match.groups()
        if (
            spellings.get(string) not in {"String", "java.lang.String"}
            or types[string][0] is not str
            or spellings.get(count) != "int"
        ):
            raise _Unsupported("Repetition requires exact documentary String/int")
        return _RepeatText(string, count)
    return _return_leaf(text, types)


def _effect_result(item, values, allowed):
    """Evaluate only finite documented effects; suppressed text is not encoded."""
    if type(item) is _Partition:
        # Evaluate every guard, including nonselected nullable orderings.
        outcomes = [_met(guard, values) for guard, _ in item.branches]
        if sum(outcomes) != 1:
            raise _Unsupported("No unique documentary partition branch")
        index = outcomes.index(True)
        leaf = item.branches[index][1]
        return dict(leaf) if allowed else None, {
            "rule_kind":"DOCUMENTED_INTEGRAL_PARTITION",
            "predicate":{"operator":"UNORDERED_EXHAUSTIVE_INTEGRAL_PARTITION",
                         "branches":[{"guard":guard.payload(),"leaf":dict(value)}
                                     for guard,value in item.branches]},
            "branch_conditions_met":outcomes,"selected_branch":index,
            "selected_leaf":dict(leaf),
        }
    if type(item) is _Choice:
        met = _met(item.guard, values)
        leaf = item.if_leaf if met else item.otherwise_leaf
        result = dict(leaf) if allowed else None
        if result is not None and result["kind"] == "ARGUMENT_VALUE":
            result["value"] = values[result["parameter"]]
        return result, {
            "rule_kind": "DOCUMENTED_RETURN_CHOICE",
            "predicate": {
                "operator": "DOCUMENTED_BINARY_CHOICE",
                "guard": item.guard.payload(),
                "if_leaf": dict(item.if_leaf),
                "otherwise_leaf": dict(item.otherwise_leaf),
            },
            "guard_condition_met": met,
            "selected_branch": "IF" if met else "OTHERWISE",
            "selected_leaf": dict(leaf),
        }
    effect = {
        "operator": "REPEAT_TEXT",
        "string_parameter": item.string_parameter,
        "count_parameter": item.count_parameter,
    }
    proof = {
        "rule_kind": "DOCUMENTED_RETURN_TEXT_REPETITION",
        "predicate": effect,
        "evaluator_domain": None,
        "count": None,
        "input_utf8_bytes": None,
        "output_utf8_bytes": None,
    }
    if not allowed:
        return None, proof
    string, count = values[item.string_parameter], values[item.count_parameter]
    if type(string) is not str or type(count) is not int or count < 0:
        raise _Unsupported("Outside hypothetical text operator domain")
    if count > MAX_REPEAT_COUNT:
        raise _Limit("Repetition count ceiling")
    input_size = _bytes(string, MAX_ARGUMENT_STRING_BYTES)
    output_size = input_size * count
    if output_size > MAX_REPEAT_OUTPUT_BYTES:
        raise _Limit("Repetition output byte ceiling")
    proof.update(
        evaluator_domain={
            "kind": "HYPOTHETICAL_TEXT_OPERATOR_DOMAIN",
            "string_nonnull": True,
            "count_nonnegative": True,
            "source_precondition_inferred": False,
        },
        count=count,
        input_utf8_bytes=input_size,
        output_utf8_bytes=output_size,
    )
    return {
        "kind": "DOCUMENTED_STRING_REPETITION",
        "string_parameter": item.string_parameter,
        "count_parameter": item.count_parameter,
        "value": string * count,
    }, proof


def _schema(content):
    if type(content) is not ClaimSchemaContent:
        raise _Invalid("Exact documentary claim schema required")
    if (
        type(content.return_type) is not str
        or content.return_type != "DOCUMENTED_NOT_EXECUTED"
    ):
        raise _Unsupported("Only non-executed documentary schemas supported")
    if (
        type(content.subject_type) is not EntityTypeRef
        or type(content.subject_type.entity_type_id) is not str
        or content.subject_type.entity_type_id != "documented.api"
    ):
        raise _Unsupported("Only documentary API subject supported")
    for field in (
        "qualifier_ids",
        "generic_constraints",
        "resolved_parameter_types",
        "parameter_array_dimensions",
        "parameter_varargs",
        "method_type_parameters",
        "intersection_bounds",
        "first_bound_erasures",
        "resolved_declared_exceptions",
        "modifiers",
    ):
        value = getattr(content, field)
        if type(value) is not tuple:
            raise _Invalid("Exact schema metadata tuple required")
        if value:
            raise _Unsupported("Unhandled additional schema obligation/Java authority")
    for field in (
        "java_callable_kind",
        "resolved_return_type",
        "accessibility",
        "enclosing_type_accessibility",
        "module_name",
        "package_exported",
        "deprecated_since",
    ):
        if getattr(content, field) is not None:
            raise _Unsupported("Specialized/temporal metadata unsupported")
    if type(content.return_array_dimensions) is not int:
        raise _Invalid("Exact dimension integer required")
    if content.return_array_dimensions != 0:
        raise _Unsupported("Array obligations unsupported")


def _scenario_fingerprint(content):
    _schema(content)
    if (
        type(content.object_type) is not ValueTypeRef
        or type(content.object_type.kind) is not ValueTypeKind
        or content.object_type.quantity_type is not None
        or content.object_type.entity_type is not None
    ):
        raise _Unsupported(
            "Opaque policy fingerprint requires nominal value descriptor"
        )
    if (
        type(content.parameters) is not tuple
        or len(content.parameters) > MAX_PARAMETERS
    ):
        raise _Invalid("Exact bounded parameter rows required")
    rows, total = [], 0
    for row in content.parameters:
        if type(row) is not tuple or len(row) != 2:
            raise _Invalid("Exact parameter rows required")
        total += sum(_bytes(item, 512) for item in row)
        rows.append(row)
    body = {
        "version": 1,
        "scope": SCOPE,
        "subject_type": content.subject_type.entity_type_id,
        "object_kind": content.object_type.kind.value,
        "parameters": rows,
        "return_type": content.return_type,
    }
    for name in ("predicate_id", "receiver_type"):
        value = getattr(content, name)
        if value is not None:
            total += _bytes(value, 512)
        body[name] = value
    for name in ("preconditions", "postconditions", "declared_exceptions", "examples"):
        values = getattr(content, name)
        if type(values) is not tuple:
            raise _Invalid("Exact documentary string tuple required")
        if len(values) > MAX_CLAUSES:
            raise _Limit("Fingerprint clause ceiling")
        total += sum(_bytes(value, MAX_CLAUSE_BYTES) for value in values)
        body[name] = values
    if total > MAX_TOTAL_CLAUSE_BYTES:
        raise _Limit("Fingerprint source aggregate ceiling")
    # Specialized fields are absent by _schema, and no user object is traversed.
    return hashlib.sha256(
        json.dumps(
            body,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
            allow_nan=False,
        ).encode("utf-8")
    ).hexdigest()


def documentary_scenario_fingerprint(content: ClaimSchemaContent) -> str | None:
    """Bounded contract projection, NOT a knowledge record/provenance hash.

    Every used source field and nominal object descriptor is included; all Java
    authority/qualifier fields must be absent. A trusted parent must recompute
    after classification rewrites any clause, and bind record/source identity.
    """
    try:
        return _scenario_fingerprint(content)
    except (_Invalid, _Unsupported, _Limit):
        return None


def _validated_reference_policy(content, policy):
    if policy is None:
        return {}
    from ai_brain.stage3.acquisition.document_signatures import (
        DocumentaryIntegralReturnPolicy,
        DocumentaryReferencePolicy,
        java_documentary_reference_policy,
    )

    if type(policy) is DocumentaryIntegralReturnPolicy:
        _validated_integral_return(content, policy)
        return {}
    if type(policy) is not DocumentaryReferencePolicy:
        raise _Invalid("Exact internal documentary reference policy required")
    if type(policy.version) is not int:
        raise _Invalid("Exact reference policy version integer required")
    for field in (
        "role",
        "signature",
        "callable_name",
        "return_spelling",
        "content_fingerprint",
        "policy_hash",
    ):
        _bytes(getattr(policy, field), 8192)
    for field, width in (("parameters", 2), ("reference_parameters", 3)):
        value = getattr(policy, field)
        if type(value) is not tuple:
            raise _Invalid("Exact immutable reference policy rows required")
        if len(value) > MAX_PARAMETERS:
            raise _Limit("Reference policy parameter ceiling")
        for row in value:
            if type(row) is not tuple or len(row) != width:
                raise _Invalid("Exact immutable reference policy descriptor required")
            for item in row:
                _bytes(item, 512)
    if type(policy.declared_type_variables) is not tuple:
        raise _Invalid("Exact declared variable tuple required")
    if len(policy.declared_type_variables) > MAX_PARAMETERS:
        raise _Limit("Declared variable ceiling")
    for variable in policy.declared_type_variables:
        _bytes(variable, 64)
    fingerprint = _scenario_fingerprint(content)
    if (
        content.parameters != policy.parameters
        or content.predicate_id != policy.callable_name.rsplit(".", 1)[-1]
        or fingerprint != policy.content_fingerprint
    ):
        raise _Unsupported(
            "Reference policy does not bind this exact documentary contract"
        )
    expected = java_documentary_reference_policy(
        policy.signature,
        callable_name=policy.callable_name,
        parameters=content.parameters,
        content_fingerprint=fingerprint,
    )
    if expected is None or expected != policy:
        raise _Unsupported(
            "Reference policy differs from complete signature syntax replay"
        )
    return {name: spelling for name, spelling, _ in policy.reference_parameters}


def _validated_integral_return(content, policy):
    from ai_brain.stage3.acquisition.document_signatures import (
        DocumentaryIntegralReturnPolicy, java_documentary_integral_return_policy,
    )
    if type(policy) is not DocumentaryIntegralReturnPolicy:
        return None
    if type(policy.version) is not int or policy.version != 1:
        raise _Invalid("Exact integral return policy version required")
    for field in ("role", "signature", "callable_name", "return_spelling",
                  "content_fingerprint", "policy_hash"):
        _bytes(getattr(policy, field), 8192)
    if type(policy.parameters) is not tuple or len(policy.parameters) > MAX_PARAMETERS:
        raise _Invalid("Exact bounded integral policy parameter tuple required")
    for row in policy.parameters:
        if type(row) is not tuple or len(row) != 2:
            raise _Invalid("Exact integral policy parameter row required")
        for item in row:
            _bytes(item, 512)
    fingerprint = _scenario_fingerprint(content)
    if (content.parameters != policy.parameters
            or content.predicate_id != policy.callable_name.rsplit(".",1)[-1]
            or fingerprint != policy.content_fingerprint):
        raise _Unsupported("Integral return policy differs from exact contract")
    expected = java_documentary_integral_return_policy(
        policy.signature, callable_name=policy.callable_name, parameters=content.parameters,
        content_fingerprint=fingerprint,
    )
    if expected is None or expected != policy:
        raise _Unsupported("Integral return declaration differs from complete syntax replay")
    return policy.return_spelling


def _source_text(source):
    # A normalized parsing view never replaces the retained source_clause.
    try:
        text = documentary_clause_view(source).removesuffix(".")
    except ValueError as error:
        raise _Unsupported(str(error)) from error
    if not text:
        raise _Unsupported("Empty required clause")
    return text


def _return_identity(item):
    if type(item) is _Partition:
        # Unordered partition identity includes every original guard and leaf.
        return "PARTITION", tuple(sorted(
            ((json.dumps(guard.payload(), sort_keys=True), json.dumps(leaf,sort_keys=True))
             for guard,leaf in item.branches)
        ))
    if type(item) is _Choice:
        return (
            "CHOICE",
            item.guard.payload(),
            _return_identity(item.if_leaf),
            _return_identity(item.otherwise_leaf),
        )
    if type(item) is _RepeatText:
        return "REPEAT_TEXT", item.string_parameter, item.count_parameter
    identity = (
        (item["kind"], item["parameter"])
        if item["kind"] == "ARGUMENT_VALUE"
        else (item["kind"], type(item["value"]), item["value"])
    )
    return identity, item["_guard"].payload() if "_guard" in item else None


def documented_return_clauses_coherent(content, *, reference_policy=None):
    """Static finite return consistency only; no invented hypothetical arguments."""
    try:
        _schema(content)
        types = _parameter_types(content, reference_policy)
        return_spelling = _validated_integral_return(content, reference_policy)
        if (
            type(content.postconditions) is not tuple
            or len(content.postconditions) > MAX_CLAUSES
        ):
            return False
        returns, total = [], 0
        for source in content.postconditions:
            total += _bytes(source, MAX_CLAUSE_BYTES)
            if total > MAX_TOTAL_CLAUSE_BYTES:
                return False
            returns.append(
                _return_identity(
                    _return(_source_text(source), types, dict(content.parameters), return_spelling)
                )
            )
        return not returns or all(item == returns[0] for item in returns)
    except (_Invalid, _Unsupported, _Limit):
        return False


def _assess(content, values, reference_policy=None):
    _schema(content)
    if type(values) is not dict:
        raise _Invalid("Exact hypothetical argument object required")
    if len(values) > MAX_PARAMETERS:
        raise _Limit("Parameter ceiling")
    # One primitive-input snapshot feeds validation, predicates and proof output.
    values = values.copy()
    types = _parameters(content, values, reference_policy)
    return_spelling = _validated_integral_return(content, reference_policy)
    parsed, total = [], 0
    for kind, clauses, parser in (
        ("PRECONDITION", content.preconditions, _precondition),
        ("DECLARED_EXCEPTION", content.declared_exceptions, _exception),
        ("DOCUMENTED_RETURN", content.postconditions, _return),
    ):
        if type(clauses) is not tuple:
            raise _Invalid("Exact complete source clause tuple required")
        if len(clauses) > MAX_CLAUSES:
            raise _Limit("Source clause count ceiling")
        for source in clauses:
            total += _bytes(source, MAX_CLAUSE_BYTES)
            if total > MAX_TOTAL_CLAUSE_BYTES:
                raise _Limit("Aggregate source clause ceiling")
            text = _source_text(source)
            item = (
                parser(text, types, dict(content.parameters), return_spelling)
                if kind == "DOCUMENTED_RETURN"
                else parser(text, types)
            )
            parsed.append((kind, source, item))
    if not parsed:
        return {
            "status": "INSUFFICIENT_EVIDENCE",
            "value": None,
            "proof_steps": [],
            "reason": "No documented scenario obligation",
        }
    returns = [item for kind, _, item in parsed if kind == "DOCUMENTED_RETURN"]

    if returns and any(
        _return_identity(item) != _return_identity(returns[0]) for item in returns
    ):
        raise _Unsupported("Multiple distinct unconditional documented returns")
    pre, exceptions, steps = [], [], []
    for kind, source, item in parsed:
        if kind == "DOCUMENTED_RETURN":
            continue
        exception, predicate = item if kind == "DECLARED_EXCEPTION" else (None, item)
        met = _met(predicate, values)
        binding = {name: values[name] for name in predicate.names()}
        row = {
            "source_clause": source,
            "predicate": predicate.payload(),
            "condition_met": met,
        }
        if exception is not None:
            row["exception"] = exception
            exceptions.append(row)
        else:
            pre.append(row)
        steps.append({**row, "rule_kind": kind, "bindings": binding})
    violated, active = (
        any(not item["condition_met"] for item in pre),
        any(item["condition_met"] for item in exceptions),
    )
    result = None
    special = bool(returns) and type(returns[0]) in {_Choice, _RepeatText, _Partition}
    effect_proof = None
    return_guard_met = (
        _met(returns[0]["_guard"], values)
        if returns and not special and "_guard" in returns[0]
        else True
    )
    if special:
        result, effect_proof = _effect_result(
            returns[0], values, not violated and not active
        )
    elif not violated and not active and returns and return_guard_met:
        result = {key: value for key, value in returns[0].items() if key != "_guard"}
        if result["kind"] == "ARGUMENT_VALUE":
            result["value"] = values[result["parameter"]]
    for kind, source, item in parsed:
        if kind == "DOCUMENTED_RETURN":
            if special:
                steps.append(
                    {
                        **effect_proof,
                        "source_clause": source,
                        "bindings": {name: values[name] for name in sorted(values)},
                        "condition_met": not violated and not active,
                        "consequence": result
                        if result is not None
                        else {"kind": "SUPPRESSED_NOT_A_RETURN_PREDICTION"},
                    }
                )
                continue
            steps.append(
                {
                    "source_clause": source,
                    "rule_kind": kind,
                    "predicate": {
                        "kind": "ALL_DOCUMENTED_PRECONDITIONS_MET_AND_NO_MATCHING_DOCUMENTED_EXCEPTION"
                    }
                    if "_guard" not in item
                    else {
                        "kind": "DOCUMENTED_RETURN_GUARD_AND_DOCUMENTED_OBLIGATIONS",
                        "return_guard": item["_guard"].payload(),
                    },
                    "bindings": {item["parameter"]: values[item["parameter"]]}
                    if item["kind"] == "ARGUMENT_VALUE"
                    else {},
                    "condition_met": not violated and not active and return_guard_met,
                    "consequence": result
                    if result is not None
                    else {"kind": "SUPPRESSED_NOT_A_RETURN_PREDICTION"},
                }
            )
    application = (
        "PRECONDITION_VIOLATED"
        if violated
        else "DOCUMENTED_EXCEPTION_CONDITION_MET"
        if active
        else "DOCUMENTED_RESULT_CONSEQUENCE"
        if result is not None
        else "DOCUMENTED_OBLIGATIONS_ASSESSED"
    )
    argument_policy = {
        name: {
            "kind": "HYPOTHETICAL_OPAQUE_REFERENCE_TOKEN",
            "documented_type": dict(content.parameters)[name],
            "java_runtime_type_verified": False,
        }
        for name in types
        if types[name][0] is _OpaqueReference
    }
    if argument_policy:
        for step in steps:
            step["argument_policy"] = {
                name: argument_policy[name]
                for name in step["bindings"]
                if name in argument_policy
            }
    result = {
        "status": "DOCUMENTED_API_SCENARIO",
        "value": {
            "arguments": {name: values[name] for name in sorted(values)},
            "assumptions_are_hypothetical": True,
            "preconditions": pre,
            "declared_exception_consequences": exceptions,
            "result_consequence": result,
            "application_status": application,
            "exception_assessment": "matching_documented_exception"
            if active
            else "no_matching_documented_exception",
            "unlisted_exceptions_excluded": False,
            "independently_verified": False,
            "source_code_executed": False,
            "scope": SCOPE,
        },
        "proof_steps": steps,
    }
    if argument_policy:
        result["value"].update(
            {
                "argument_policy": argument_policy,
                "reference_policy_hash": reference_policy.policy_hash,
                "java_runtime_type_verified": False,
            }
        )
    return result


def _description(text, types, spellings=None):
    match = re.fullmatch(rf"Parameters:\s*({_NAME})\s+-\s+(.+)", text, re.IGNORECASE)
    if not match or match[1] not in types:
        return False
    description, kind = match[2], types[match[1]][0]
    if kind is _OpaqueReference and re.fullmatch(
        r"an object reference", description, re.IGNORECASE
    ):
        return True
    if re.fullmatch(r"a boolean expression", description, re.IGNORECASE):
        return kind is bool
    if re.fullmatch(r"an? (?:integer|number)", description, re.IGNORECASE):
        return kind is int
    if re.fullmatch(r"an? (?:string|text)", description, re.IGNORECASE):
        return kind is str
    if re.fullmatch(r"a value", description, re.IGNORECASE):
        return True
    comparison = re.fullmatch(r"the (?:first|second) (byte|short|int|long) to compare",
                              description, re.IGNORECASE)
    if kind is int and comparison:
        # Informational only; never establishes an alias or comparison rule.
        return spellings is not None and spellings.get(match[1]) == comparison[1]
    if kind is int and re.fullmatch(
        r"(?:a user-supplied index identifying (?:an element|a (?:starting |ending )?position)"
        r" (?:of|in) an array, list or string|the size of that array, list or string)",
        description,
        re.IGNORECASE,
    ):
        return True
    return (
        kind is str
        and re.fullmatch(
            r"the text to use to describe this index in an error message",
            description,
            re.IGNORECASE,
        )
        is not None
    )


def _purpose(text, types, spellings=None):
    # These finite documentary purpose forms do NOT become preconditions,
    # caller-state facts, inferred aliases or normal-completion guarantees.
    comparison = re.fullmatch(r"Compares? two (byte|short|int|long) values", text, re.IGNORECASE)
    if comparison:
        return (len(types) == 2 and spellings is not None
                and all(kind is int and spellings.get(name) == comparison[1]
                        for name,(kind,_) in types.items()))
    if re.fullmatch(
        r"Ensures that an object reference passed as a parameter to the calling method is not null",
        text,
        re.IGNORECASE,
    ):
        return any(kind is _OpaqueReference for kind, _ in types.values())
    if re.fullmatch(
        r"Ensures the truth of an expression involving "
        r"(?:one or more parameters to the calling method|the state of the calling instance, "
        r"but not involving any parameters to the calling method)",
        text,
        re.IGNORECASE,
    ):
        return any(kind is bool for kind, _ in types.values())
    match = re.fullmatch(
        rf"Ensures that ({_NAME}) specifies a valid (element|position) "
        rf"in an array, list or string of size ({_NAME})\. "
        rf"An? (element|position) index may range from zero(?:, inclusive,)? "
        rf"to ({_NAME}), (inclusive|exclusive)",
        text,
        re.IGNORECASE,
    )
    if not match:
        return False
    # Do not resolve anaphora across arbitrary prose; the explicit bounds and
    # nouns in this one complete paragraph must agree syntactically.
    return (
        match[1] in types
        and match[3] in types
        and types[match[1]][0] is int
        and types[match[3]][0] is int
        and match[2].lower() == match[4].lower()
        and match[3] == match[5]
    )


def _classify(content, paragraphs, reference_policy=None):
    _schema(content)
    types = _parameter_types(content, reference_policy)
    return_spelling = _validated_integral_return(content, reference_policy)
    if type(paragraphs) is not tuple:
        raise _Invalid("Exact complete paragraph tuple required")
    if len(paragraphs) > MAX_SOURCE_PARAGRAPHS:
        raise _Limit("Associated source paragraph ceiling")
    buckets = {"preconditions": [], "postconditions": [], "declared_exceptions": []}
    classifications, total = [], 0
    for source in paragraphs:
        total += _bytes(source, MAX_CLAUSE_BYTES)
        if total > MAX_TOTAL_CLAUSE_BYTES:
            raise _Limit("Aggregate associated source ceiling")
        text = _source_text(source)
        role, parsed, bucket = "SOURCE_CONTEXT_NOT_ASSESSED", None, None
        if re.fullmatch(
            r"(?:Parameters|Type Parameters|Returns|Throws|Raises|Since|See Also):",
            text,
            re.IGNORECASE,
        ):
            role = "SECTION_HEADING_NOT_ASSESSED"
        elif re.match(r"Returns(?:\s|:)", text, re.IGNORECASE) or re.fullmatch(
            r"If\s+.+,\s*returns\s+.+;\s*otherwise\s+returns\s+.+", text, re.IGNORECASE
        ):
            parsed, bucket, role = (
                _return(text, types, dict(content.parameters), return_spelling),
                "postconditions",
                "DOCUMENTED_RETURN",
            )
        elif re.match(r"(?:Throws|Raises)(?:\s|:)|If\s", text, re.IGNORECASE):
            parsed, bucket, role = (
                _exception(text, types),
                "declared_exceptions",
                "DECLARED_EXCEPTION",
            )
        elif re.match(r"Requires\s", text, re.IGNORECASE) or re.fullmatch(
            rf"{_NAME}\s+must\s+(?:not\s+)?be\s+null", text, re.IGNORECASE
        ):
            parsed, bucket, role = (
                _precondition(text, types),
                "preconditions",
                "PRECONDITION",
            )
        elif _description(text, types, dict(content.parameters)) or _purpose(text, types, dict(content.parameters)):
            pass
        elif re.fullmatch(
            r"Since:\s*[0-9]{1,4}(?:\.[0-9]{1,4}){0,3}"
            r"(?: \(varargs overload since [0-9]{1,4}(?:\.[0-9]{1,4}){0,3}\))?",
            text,
            re.IGNORECASE,
        ):
            role = "VERSION_CONTEXT_NOT_ASSESSED"
        elif re.fullmatch(rf"See Also:\s*{_EXCEPTION}\(\)", text, re.IGNORECASE):
            role = "CROSS_REFERENCE_NOT_ASSESSED"
        else:
            raise _Unsupported("Unclassified associated paragraph or qualification")
        row = {
            "source_clause": source,
            "role": role,
            # Classification is never itself an assessment or truth proof.
            "assessed": False,
            "inference_authority": False,
        }
        if bucket is not None:
            buckets[bucket].append(source)
            if len(buckets[bucket]) > MAX_CLAUSES:
                raise _Limit("Source clause count ceiling")
            predicate = (
                parsed[1]
                if role == "DECLARED_EXCEPTION"
                else parsed
                if role == "PRECONDITION"
                else parsed.guard
                if type(parsed) is _Choice
                else None
                if type(parsed) in {_RepeatText, _Partition}
                else parsed.get("_guard")
            )
            if predicate is not None:
                row["predicate"] = predicate.payload()
            if type(parsed) is _Partition:
                row["predicate"] = {
                    "operator":"UNORDERED_EXHAUSTIVE_INTEGRAL_PARTITION",
                    "branches":[{"guard":guard.payload(),"leaf":dict(leaf)}
                                for guard,leaf in parsed.branches],
                }
        classifications.append(row)
    return {
        "status": "COMPLETE",
        "classifications": classifications,
        **{name: tuple(clauses) for name, clauses in buckets.items()},
        "source_context_is_not_assessed": True,
        "inference_authority": False,
    }


def _failure(error):
    return {
        "status": "INVALID_REQUEST"
        if type(error) is _Invalid
        else "RESOURCE_LIMIT"
        if type(error) is _Limit
        else "NEEDS_NEW_CAPABILITY",
        "value": None,
        "proof_steps": [],
        "reason": str(error),
    }


def classify_documented_api_paragraphs(
    content: ClaimSchemaContent, paragraphs: tuple[str, ...], *, reference_policy=None
) -> dict:
    """Classify ALL exact associated paragraphs, without hypothetical values.

    COMPLETE means finite source grammar coverage, not assessed context or API
    execution. Metadata/parameter/purpose contexts remain explicitly unassessed.
    A negative result exposes no partially usable buckets or classifications.
    The caller must still establish exact source provenance, math/quote guards
    and the completeness of the supplied associated paragraph inventory.
    """
    try:
        return _classify(content, paragraphs, reference_policy)
    except (_Invalid, _Unsupported, _Limit) as error:
        return _failure(error)


def assess_documented_scenario(
    content: ClaimSchemaContent, values: dict, *, reference_policy=None
) -> dict:
    """No pack/source IO, execution, NLP completion or background knowledge.

    Preconditions and exception conditions are evaluated only under caller-owned
    hypothetical arguments. A positive result never guarantees normal execution
    or excludes undocumented exceptions. Every required clause must be understood.
    """
    try:
        return _assess(content, values, reference_policy)
    except (_Invalid, _Unsupported, _Limit) as error:
        return _failure(error)
