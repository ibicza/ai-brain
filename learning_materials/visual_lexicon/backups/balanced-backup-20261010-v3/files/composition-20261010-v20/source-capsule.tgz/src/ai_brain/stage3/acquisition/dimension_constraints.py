"""Finite dimensional constraints; no inferred units, scales or source licence."""
from __future__ import annotations

import ast
import re
from dataclasses import asdict, fields
from fractions import Fraction

from ai_brain.stage3.knowledge_ir.records import DimensionVector


def solve_dimensions(equations, anchors, *, dimensionless_literals=False):
    """Require a unique integral dimension for every explicitly occurring symbol.

    Anchors are caller-proved dimensions, not unit spelling or SI scale. Numeric
    coefficients are allowed only under an explicit dimensionless-literal policy.
    This function cannot establish documentary scalar/model/qualification scope.
    """
    if type(equations) is not tuple or not 1 <= len(equations) <= 32:
        raise ValueError("bounded tuple of equations required")
    if type(anchors) is not dict or not anchors or len(anchors) > 16:
        raise ValueError("explicit dimension anchors required")
    if type(dimensionless_literals) is not bool:
        raise ValueError("literal policy must be explicit boolean")
    dimensions = tuple(field.name for field in fields(DimensionVector))
    if any(type(key) is not str or type(value) is not DimensionVector
           or any(type(exponent) is not int or abs(exponent) > 24
                  for exponent in asdict(value).values())
           for key, value in anchors.items()):
        raise ValueError("invalid bounded dimension anchor")
    trees = []
    for equation in equations:
        if (type(equation) is not str or len(equation) > 1000
            or equation.count("=") != 1
            or not re.fullmatch(r"[A-Za-z0-9_()+*/=.%\- \t\r\n]+", equation)):
            raise ValueError("one bounded equality required")
        try:
            sides = tuple(ast.parse(side.strip(), mode="eval").body for side in equation.split("="))
        except (SyntaxError, RecursionError, ValueError) as error:
            raise ValueError("invalid scalar equation") from error
        if sum(1 for side in sides for _ in ast.walk(side)) > 160:
            raise ValueError("scalar node limit")
        trees.append(sides)
    names = sorted({node.id for sides in trees for side in sides
                    for node in ast.walk(side) if isinstance(node, ast.Name)})
    if not names or len(names) > 16 or not set(anchors).issubset(names):
        raise ValueError("bounded occurring anchor symbols required")
    indexes = {name: index for index, name in enumerate(names)}
    size = len(names)
    rows = []
    zero = lambda: [Fraction(0) for _ in names]

    def difference(left, right):
        return [a - b for a, b in zip(left, right)]

    def equality(left, right):
        rows.append(difference(left, right) + [Fraction(0)] * len(dimensions))

    def expression(node, depth=0):
        if depth > 24:
            raise ValueError("scalar depth limit")
        if isinstance(node, ast.Name):
            if not node.id.isascii() or not node.id.isidentifier() or node.id.startswith("_"):
                raise ValueError("unsupported scalar identifier")
            result = zero()
            result[indexes[node.id]] = Fraction(1)
            return result
        if isinstance(node, ast.Constant):
            if not dimensionless_literals or type(node.value) is not int or abs(node.value) > 10**9:
                raise ValueError("unlicensed scalar literal")
            return zero()
        if isinstance(node, ast.UnaryOp) and isinstance(node.op, (ast.UAdd, ast.USub)):
            return expression(node.operand, depth + 1)
        if not isinstance(node, ast.BinOp):
            raise ValueError("unsupported scalar node")
        left = expression(node.left, depth + 1)
        if isinstance(node.op, ast.Pow):
            power = node.right
            sign = 1
            if isinstance(power, ast.UnaryOp) and isinstance(power.op, ast.USub):
                sign, power = -1, power.operand
            if not isinstance(power, ast.Constant) or type(power.value) is not int or not -12 <= sign * power.value <= 12:
                raise ValueError("bounded literal integer exponent required")
            return [value * sign * power.value for value in left]
        right = expression(node.right, depth + 1)
        if isinstance(node.op, (ast.Add, ast.Sub)):
            equality(left, right)
            return left
        if isinstance(node.op, ast.Mult):
            return [a + b for a, b in zip(left, right)]
        if isinstance(node.op, ast.Div):
            return difference(left, right)
        raise ValueError("unsupported scalar operator")

    for left, right in trees:
        equality(expression(left), expression(right))
    for name, dimension in anchors.items():
        row = zero()
        row[indexes[name]] = Fraction(1)
        rows.append(row + [Fraction(getattr(dimension, key)) for key in dimensions])
    pivot = 0
    pivot_columns = []
    for column in range(size):
        candidate = next((index for index in range(pivot, len(rows)) if rows[index][column]), None)
        if candidate is None:
            continue
        rows[pivot], rows[candidate] = rows[candidate], rows[pivot]
        divisor = rows[pivot][column]
        rows[pivot] = [value / divisor for value in rows[pivot]]
        for index, row in enumerate(rows):
            if index != pivot and row[column]:
                factor = row[column]
                rows[index] = [value - factor * other for value, other in zip(row, rows[pivot])]
        pivot_columns.append(column)
        pivot += 1
    if any(not any(row[:size]) and any(row[size:]) for row in rows):
        raise ValueError("inconsistent dimension constraints")
    if len(pivot_columns) != size:
        raise ValueError("underdetermined dimension constraints")
    result = {}
    for row_index, column in enumerate(pivot_columns):
        exponents = rows[row_index][size:]
        if any(value.denominator != 1 or abs(value) > 24 for value in exponents):
            raise ValueError("nonintegral or oversized inferred dimension")
        result[names[column]] = DimensionVector(**dict(zip(dimensions, (int(value) for value in exponents))))
    return result
