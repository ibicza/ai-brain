"""Replay reserved inert paragraph records against their exact excerpt and anchor.

This validates documentary retention, not raw-byte alignment, speaker identity,
same-subject ownership or empirical truth. Installation separately replays CAS.
No evaluation, source execution, inference or alias construction occurs here.
"""

from __future__ import annotations

import re
import unicodedata
from dataclasses import asdict

from ai_brain.stage2.facts.canonical import content_hash
from ai_brain.stage3.acquisition.documentary_clauses import (
    extract_definition_reported_paragraphs,
)
from ai_brain.stage3.acquisition.documentary_logic import _documentary_provenance_scope
from ai_brain.stage3.acquisition.source_descriptions import REPORTED_PARAGRAPH_CONTEXT
from ai_brain.stage3.knowledge_ir.records import (
    ConceptContent,
    EpistemicCharacter,
    InterpretationContent,
    KnowledgeKind,
)


def _anchor_key(text):
    # Exactly the existing documentary term-key policy, not synonym resolution.
    value = " ".join(unicodedata.normalize("NFKC", text).casefold().split()).strip(
        " .:;"
    )
    return re.sub(r"^(?:a|an|the)\s+", "", value)


def _validate_lineage(record, source, source_bindings):
    if source_bindings is None:
        # Candidate provenance consists of exact segment IDs, before compiler
        # remaps each proposal to its own distinct SourceBinding identity.
        if record.provenance_refs != source.provenance_refs:
            raise ValueError(
                "reported paragraph candidate lineage differs from excerpt"
            )
        return
    # Import only at the installed boundary, after domains initialization.
    from ai_brain.stage3.domains.manifest import SourceBinding

    if type(source_bindings) is not tuple or any(
        type(binding) is not SourceBinding or type(binding.binding_id) is not str
        for binding in source_bindings
    ):
        raise ValueError("reported paragraph source bindings require exact tuples")
    bindings = {binding.binding_id: binding for binding in source_bindings}
    if len(bindings) != len(source_bindings):
        raise ValueError("reported paragraph duplicate source binding identity")
    projection = []
    for row in (source, record):
        if len(row.provenance_refs) != 1:
            raise ValueError("reported paragraph requires one exact excerpt lineage")
        binding = bindings.get(row.provenance_refs[0])
        if binding is None:
            raise ValueError("reported paragraph source binding missing")
        for values in (
            binding.document_hashes,
            binding.segment_hashes,
            binding.evidence_hashes,
            binding.source_hashes,
        ):
            if (
                type(values) is not tuple
                or len(values) != 1
                or any(
                    type(value) is not str
                    or re.fullmatch(r"[0-9a-f]{64}", value) is None
                    for value in values
                )
            ):
                raise ValueError("reported paragraph malformed excerpt lineage")
        if (
            binding.fact_memory_refs != ()
            or binding.claim_refs != ()
            or binding.derivation_hashes != ()
            or type(binding.field_evidence) is not tuple
            or any(
                type(item) is not tuple
                or len(item) != 2
                or any(type(value) is not str for value in item)
                for item in binding.field_evidence
            )
        ):
            raise ValueError("reported paragraph requires documentary field lineage")
        expected_evidence = tuple(
            (f"content.{field}", digest)
            for digest in binding.evidence_hashes
            for field in sorted(asdict(row.content))
        )
        if (
            binding.field_evidence != expected_evidence
            or binding.source_chain_hash
            != content_hash(
                (binding.document_hashes, binding.segment_hashes, expected_evidence)
            )
            or binding.binding_hash
            != content_hash(
                {
                    key: value
                    for key, value in asdict(binding).items()
                    if key != "binding_hash"
                }
            )
        ):
            raise ValueError("reported paragraph field/source chain mismatch")
        projection.append(
            (
                binding.document_hashes,
                binding.segment_hashes,
                binding.evidence_hashes,
                binding.source_hashes,
            )
        )
    if projection[0] != projection[1]:
        raise ValueError("reported paragraph installed lineage differs from excerpt")


def validate_reported_context_record(
    record, by_id, *, parsed_by_source=None, source_bindings=None
):
    """Require one exact excerpt plus its anchor target; return the fresh envelope."""
    # Keep the pack validator's import graph independent of retrieval/runtime.
    from ai_brain.stage3.domains.document_retrieval import excerpt_payload

    content = record.content
    if not isinstance(content, InterpretationContent) or (
        content.perspective != REPORTED_PARAGRAPH_CONTEXT
    ):
        raise ValueError("not a reserved reported paragraph record")
    for values in (
        content.supported_record_ids,
        content.contrast_record_ids,
        record.dependencies,
        record.required_capability_ids,
        record.applicability_refs,
        record.provenance_refs,
    ):
        if type(values) is not tuple or any(type(value) is not str for value in values):
            raise ValueError("reported paragraph references require exact tuples")
    if (
        record.kind is not KnowledgeKind.INTERPRETATION
        or record.epistemic_character is not EpistemicCharacter.INTERPRETIVE
        or len(content.supported_record_ids) != 1
        or content.contrast_record_ids
        or record.required_capability_ids
        or record.applicability_refs
        or len(record.dependencies) != 2
        or len(set(record.dependencies)) != 2
        or record.dependencies[1:] != content.supported_record_ids
    ):
        raise ValueError("reported paragraph must be inert excerpt/anchor support only")
    source_id, target_id = record.dependencies
    source, target = by_id.get(source_id), by_id.get(target_id)
    if source is None or target is None:
        raise ValueError("reported paragraph source/anchor dependency missing")
    if source.knowledge_id != source_id or target.knowledge_id != target_id:
        raise ValueError("reported paragraph dependency mapping identity mismatch")
    for row in (record, source, target):
        if (
            type(row.provenance_refs) is not tuple
            or not row.provenance_refs
            or any(type(value) is not str or not value for value in row.provenance_refs)
        ):
            raise ValueError("reported paragraph requires exact nonempty provenance")
    if (
        source.domain_id != record.domain_id
        or target.domain_id != record.domain_id
        or source.kind is not KnowledgeKind.CONCEPT
        or source.dependencies
        or source.required_capability_ids
        or source.applicability_refs
        or target.kind is not KnowledgeKind.CONCEPT
        or not isinstance(target.content, ConceptContent)
        or type(target.content.canonical_name_en) is not str
        or type(target.content.canonical_name_ru) is not str
        or excerpt_payload(target) is not None
    ):
        raise ValueError("reported paragraph requires local source and named anchor")
    origin = excerpt_payload(source)
    if (
        origin is None
        or type(origin.get("original_bytes_hash")) is not str
        or re.fullmatch(r"[0-9a-f]{64}", origin["original_bytes_hash"]) is None
        or origin.get("quotation") is not False
    ):
        raise ValueError("reported paragraph requires exact documentary excerpt")
    # Provenance shape only: not conditional eligibility or verified raw bytes.
    _documentary_provenance_scope(origin)
    cache = parsed_by_source if parsed_by_source is not None else {}
    if source_id not in cache:
        cache[source_id] = extract_definition_reported_paragraphs(
            origin["text"], metadata=origin
        )
    matches = [
        context
        for context in cache[source_id]
        if context.paragraph.text == content.claim_text
        and _anchor_key(context.subject)
        == _anchor_key(target.content.canonical_name_en)
        == _anchor_key(target.content.canonical_name_ru)
    ]
    if len(matches) != 1:
        raise ValueError("reported paragraph text/target differs from source replay")
    _validate_lineage(record, source, source_bindings)
    return matches[0]


def validate_reported_context_records(records, *, source_bindings=None):
    """Bounded source replay at pack installation, load and runtime facades."""
    selected = tuple(
        record
        for record in records
        if isinstance(record.content, InterpretationContent)
        and record.content.perspective == REPORTED_PARAGRAPH_CONTEXT
    )
    if not selected:
        return
    by_id = {record.knowledge_id: record for record in records}
    if len(by_id) != len(records):
        raise ValueError("duplicate reported context dependency identity")
    cache = {}
    for record in selected:
        validate_reported_context_record(
            record, by_id, parsed_by_source=cache, source_bindings=source_bindings
        )
