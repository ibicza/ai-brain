"""Deterministic lexical retrieval over installed records, with quoted evidence.

This is not a generative model, semantic translator, or a rule extractor.
Documentary excerpts remain attributed source text, not universal truths.
"""

from __future__ import annotations

import json
import math
import re
import unicodedata
from collections import Counter
from dataclasses import asdict

from ai_brain.stage3.domains.request_verification import custody_evidence
from ai_brain.stage3.knowledge_ir.records import ConceptContent

_PREFIX = "DIRECT_SOURCE_EXCERPT_V1\n"
_STOP = frozenset(
    [
        "what",
        "which",
        "how",
        "when",
        "where",
        "why",
        "is",
        "are",
        "was",
        "were",
        "the",
        "a",
        "an",
        "of",
        "for",
        "to",
        "and",
        "in",
        "on",
        "does",
        "do",
        "can",
        "could",
        "please",
        "explain",
        "что",
        "такое",
        "какой",
        "какая",
        "какие",
        "как",
        "когда",
        "где",
        "почему",
        "это",
        "для",
        "или",
        "объясни",
        "расскажи",
        "о",
        "об",
        "по",
        "в",
        "на",
        "с",
        "и",
        "из",
        "у",
    ]
)


def excerpt_payload(record):
    content = record.content
    if not isinstance(content, ConceptContent) or not content.description_en.startswith(
        _PREFIX
    ):
        return None
    payload = json.loads(content.description_en[len(_PREFIX) :])
    if (
        type(payload) is not dict
        or type(payload.get("schema_version")) is not int
        or payload.get("schema_version") != 1
        or payload.get("scope") != "DOCUMENTARY_EVIDENCE_NOT_EXECUTION_AUTHORITY"
        or type(payload.get("text")) is not str
        or (
            "documentary_math_presence" in payload
            and type(payload["documentary_math_presence"]) is not bool
        )
    ):
        raise ValueError("invalid documentary payload")
    return payload


def _tokens(text):
    text = re.sub(r"([a-z])([A-Z])", r"\1 \2", text)
    words = re.findall(
        r"[^\W_]+", unicodedata.normalize("NFKC", text).casefold(), re.UNICODE
    )
    result = []
    for word in words:
        if word in _STOP:
            continue
        if re.fullmatch(r"[а-яё]+", word) and len(word) > 4:
            stem = re.sub(
                r"(?:иями|ями|ами|ого|ему|ыми|ая|ое|ые|ой|ий|ых|ом|ам|ах|ов|ев|ы|и|а|я|у|ю|е|ь)$",
                "",
                word,
            )
            if len(stem) >= 4:
                word = stem
        elif (
            word.isascii()
            and word.endswith("s")
            and len(word) > 4
            and not word.endswith("ss")
        ):
            word = word[:-1]
        result.append(word)
    return result


def search_installed_records(packs, question, limit=5):
    from ai_brain.stage3.domains.document_limits import (
        MAX_DOCUMENTARY_PACK_RECORDS,
        MAX_DOCUMENTARY_QUERY_RECORDS,
    )

    if (
        type(question) is not str
        or not question.strip()
        or len(question) > 1024
        or type(limit) is not int
        or not 1 <= limit <= 20
    ):
        return {
            "status": "INVALID_REQUEST",
            "hits": [],
            "reason": "bounded question and limit 1..20 required",
        }
    query = set(_tokens(question))
    if not query or len(query) > 64:
        return {
            "status": "INVALID_REQUEST",
            "hits": [],
            "reason": "question needs 1..64 searchable terms",
        }
    entries, document_frequency = [], Counter()
    for pack in packs:
        if len(pack.knowledge_records) > MAX_DOCUMENTARY_PACK_RECORDS:
            return {"status": "RESOURCE_LIMIT", "hits": []}
        bindings = {binding.binding_id: binding for binding in pack.source_bindings}
        for record in pack.knowledge_records:
            payload = excerpt_payload(record)
            if payload:
                quote = payload["text"]
                context = " ".join(
                    str(payload.get(key) or "")
                    for key in ("title", "symbol", "signature")
                )
                text = context + "\n" + quote
            else:
                quote = asdict(record.content)
                text = json.dumps(quote, ensure_ascii=False)
            tokens = _tokens(text)
            counts = Counter(tokens)
            document_frequency.update(set(tokens) & query)
            entries.append((pack, record, payload, quote, counts, bindings))
            if len(entries) > MAX_DOCUMENTARY_QUERY_RECORDS:
                return {"status": "RESOURCE_LIMIT", "hits": []}
    if not entries:
        return {"status": "INSUFFICIENT_EVIDENCE", "hits": []}
    average = sum(sum(item[4].values()) for item in entries) / len(entries) or 1
    hits = []
    for pack, record, payload, quote, counts, bindings in entries:
        matched = query & counts.keys()
        coverage = len(matched) / len(query)
        if not matched or coverage < 0.5:
            continue
        score = 0.0
        for term in matched:
            frequency = counts[term]
            rarity = math.log(
                1
                + (len(entries) - document_frequency[term] + 0.5)
                / (document_frequency[term] + 0.5)
            )
            score += (
                rarity
                * frequency
                * 2.2
                / (frequency + 1.2 * (0.25 + 0.75 * sum(counts.values()) / average))
            )
        sources = [asdict(bindings[identity]) for identity in record.provenance_refs]
        hit = {
            "domain_id": pack.manifest.domain_id,
            "pack_version": pack.manifest.pack_version,
            "pack_hash": pack.manifest.pack_content_hash,
            "knowledge_id": record.knowledge_id,
            "record_hash": record.content_hash,
            "epistemic_character": record.epistemic_character.value,
            "score": f"{score:.8f}",
            "term_coverage": f"{coverage:.4f}",
            "matched_terms": sorted(matched),
            "quote": quote,
            "evidence_mode": "DOCUMENTARY_QUOTE"
            if payload
            else "INSTALLED_STRUCTURED_RECORD",
            "origin": {
                key: payload[key]
                for key in (
                    "file",
                    "original_bytes_hash",
                    "source_url",
                    "format",
                    "page",
                    "line_start",
                    "line_end",
                    "heading_path",
                    "symbol",
                    "signature",
                    "reader_profile",
                )
            }
            if payload
            else None,
            "source_bindings": sources,
            **custody_evidence(pack),
        }
        hits.append(hit)
    hits.sort(
        key=lambda hit: (-float(hit["score"]), hit["domain_id"], hit["knowledge_id"])
    )
    domains = {}
    for hit in hits:
        domains.setdefault(
            hit["domain_id"],
            {
                key: hit[key]
                for key in ("domain_id", "score", "term_coverage", "matched_terms")
            },
        )
    return {
        "status": "RETRIEVED" if hits else "INSUFFICIENT_EVIDENCE",
        "hits": hits[:limit],
        "matching_record_count": len(hits),
        "domain_candidates": list(domains.values()),
        "retrieval_mode": "LEXICAL_BM25_WITH_BOUNDED_TERM_COVERAGE",
        "truth_status": "SOURCE_ATTRIBUTION_NOT_INDEPENDENT_FACT_VERIFICATION",
    }
