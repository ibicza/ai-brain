"""Compatibility exports; the inert renderer belongs to the cold runtime."""

from ai_brain.stage3.domains.javadoc_clause_view import (
    MAX_CLAUSE_BYTES,
    documentary_clause_view,
    has_hidden_controls,
)

__all__ = ["MAX_CLAUSE_BYTES", "documentary_clause_view", "has_hidden_controls"]
