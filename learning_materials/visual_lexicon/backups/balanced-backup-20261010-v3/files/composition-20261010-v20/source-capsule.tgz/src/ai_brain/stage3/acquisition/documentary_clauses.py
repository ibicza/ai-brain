"""Exact documentary definition context, never formal inference authority.

A following sentence is kept only within its original paragraph and with an
explicit local subject marker. Pronouns are documentary adjacency markers, not
resolved entity references. Definition bodies and explanatory context remain
separate: a caller must not install ``full_description`` as a formal definition.
No topic vocabulary, source execution, normalization or external lookup is used.
"""

from __future__ import annotations

import re
from collections.abc import Mapping
from dataclasses import dataclass, field

SOURCE_DESCRIPTION_ONLY = "SOURCE_DESCRIPTION_ONLY"
UNRESOLVED_SOURCE_PARAGRAPH = "UNRESOLVED_SOURCE_PARAGRAPH"
MAX_DEFINITION_PARAGRAPH = 1600
MAX_DOCUMENTARY_INPUT = 100_000
_SUBJECT = r"[\w][\w ./'’()–-]{0,100}?"
_DEFINITION = re.compile(
    rf"(?P<subject>{_SUBJECT})\s+"
    r"(?P<predicate>is defined as|are defined as|refers to|means|is|are)\s+"
    r"(?P<body>.+)",
    re.IGNORECASE | re.DOTALL,
)
_ABBREVIATIONS = frozenset(
    {
        "e.g.",
        "i.e.",
        "etc.",
        "vs.",
        "cf.",
        "approx.",
        "fig.",
        "dr.",
        "mr.",
        "mrs.",
        "ms.",
        "prof.",
        "sr.",
        "jr.",
    }
)
_REFERENCE = re.compile(
    r"^(?:it|they|this|that|these|those|he|she|we|you)\b", re.IGNORECASE
)
_REPORTING = re.compile(
    r"\b(?:according to|claims?|claimed|believes?|believed|says?|said|"
    r"argues?|argued|reports?|reported|writes?|wrote)\b",
    re.IGNORECASE,
)
_PASSIVE_REPORT = re.compile(r"\b(?:is|are|was|were)\s+said\s+to\s+be\b", re.IGNORECASE)
_NOUN_BODY = re.compile(
    r"(?:(?:not|never|only|possibly|sometimes|currently|approximately)\s+)*"
    r"(?:a|an|the)\s+\S",
    re.IGNORECASE,
)
_OTHER_COPULA = re.compile(
    rf"\b(?:and|but|while|whereas)\s+({_SUBJECT})\s+"
    r"(?:is defined as|are defined as|refers to|means|is|are)\b",
    re.IGNORECASE,
)


@dataclass(frozen=True)
class SourceSpan:
    """Half-open character offsets into the exact supplied source string."""

    text: str
    start: int
    end: int
    scope: str = field(default=SOURCE_DESCRIPTION_ONLY, init=False)
    inference_authority: bool = field(default=False, init=False)


@dataclass(frozen=True)
class DefinitionContext:
    subject: str
    definition: SourceSpan
    full_description: SourceSpan
    sentences: tuple[SourceSpan, ...]
    scope: str = field(default=SOURCE_DESCRIPTION_ONLY, init=False)
    inference_authority: bool = field(default=False, init=False)


@dataclass(frozen=True)
class DefinitionParagraphEnvelope:
    """An exact adjacent passage, not owned assertions or resolved references.

    Only ``definition`` is the first strictly parsed definition body. Later
    sentences retain their own source spelling and subjects; this envelope
    supplies neither additional definitions nor aliases or logical premises.
    """

    subject: str
    definition: SourceSpan
    paragraph: SourceSpan
    sentences: tuple[SourceSpan, ...]
    context_relation: str = field(default=UNRESOLVED_SOURCE_PARAGRAPH, init=False)
    scope: str = field(default=SOURCE_DESCRIPTION_ONLY, init=False)
    inference_authority: bool = field(default=False, init=False)


@dataclass(frozen=True)
class ReportedDefinitionParagraphEnvelope(DefinitionParagraphEnvelope):
    """Exact reported adjacency; neither speaker nor statement ownership resolved."""

    reported_context: bool = field(default=True, init=False)
    attribution_resolution: str = field(default="UNRESOLVED", init=False)


def _span(text: str, start: int, end: int) -> SourceSpan:
    while start < end and text[start].isspace():
        start += 1
    while end > start and text[end - 1].isspace():
        end -= 1
    return SourceSpan(text[start:end], start, end)


def _well_formed(text: object) -> bool:
    if type(text) is not str or not text.strip() or len(text) > MAX_DOCUMENTARY_INPUT:
        return False
    if any(ord(char) < 32 and char not in "\t\r\n" for char in text):
        return False
    stack = []
    pairs = {")": "(", "]": "[", "}": "{"}
    for char in text:
        if char in "([{":
            stack.append(char)
            if len(stack) > 8:
                return False
        elif char in pairs and (not stack or stack.pop() != pairs[char]):
            return False
    return not stack


def _protected_period(text: str, index: int) -> bool:
    # Decimal points and qualified names (including Java references) are not
    # sentence boundaries, even when a member happens to begin with a capital.
    if (
        0 < index < len(text) - 1
        and text[index - 1].isalnum()
        and text[index + 1].isalnum()
    ):
        return True
    token = re.search(r"[\w.]+$", text[max(0, index - 24) : index + 1])
    if token and token[0].casefold() in _ABBREVIATIONS:
        return True
    if token and re.fullmatch(r"(?:[A-Za-z]\.){2,6}", token[0]):
        return True
    # A typographic initial before another capitalized word is conservative;
    # no name dictionary or topic-specific abbreviation list is consulted.
    if token and re.fullmatch(r"[A-Z]\.", token[0]):
        return bool(re.match(r"\s+[A-Z]\w", text[index + 1 :]))
    return False


def _split(text: str, *, clauses: bool) -> tuple[SourceSpan, ...]:
    if not _well_formed(text):
        return ()
    spans, start, depth = [], 0, 0
    for index, char in enumerate(text):
        if char in "([{":
            depth += 1
        elif char in ")]}":
            depth -= 1
        if depth or char not in (".!?;" if clauses else ".!?"):
            continue
        if char == "." and _protected_period(text, index):
            continue
        if index + 1 < len(text) and not text[index + 1].isspace():
            continue
        span = _span(text, start, index + 1)
        if span.text:
            spans.append(span)
        start = index + 1
    final = _span(text, start, len(text))
    if final.text:
        spans.append(final)
    return tuple(spans)


def split_documentary_sentences(text: str) -> tuple[SourceSpan, ...]:
    """Split bounded text without changing characters or dotted references."""
    return _split(text, clauses=False)


def split_documentary_clauses(text: str) -> tuple[SourceSpan, ...]:
    """Also split top-level semicolons; preserve parenthetical qualifications."""
    return _split(text, clauses=True)


def _allowed_metadata(metadata: Mapping[str, object] | None) -> bool:
    if metadata is None:
        return True
    if not isinstance(metadata, Mapping):
        return False
    role = metadata.get("documentary_role")
    if role is not None and type(role) is not str:
        return False
    return not (
        metadata.get("quotation")
        or metadata.get("signature")
        or metadata.get("code")
        or role
        in {"LITERAL_EXAMPLE", "CODE_EXAMPLE", "CODE", "SOURCE_CODE", "QUOTATION"}
    )


def _paragraphs(text: str) -> tuple[SourceSpan, ...]:
    result, start = [], 0
    for separator in re.finditer(r"\r?\n[ \t]*(?:\r?\n)+", text):
        span = _span(text, start, separator.start())
        if span.text:
            result.append(span)
        start = separator.end()
    span = _span(text, start, len(text))
    if span.text:
        result.append(span)
    return tuple(result)


def _owned(clause: str, subject: str) -> bool:
    clause = re.sub(
        r"^(?:(?:and|but|however|therefore)\b[, ]*)", "", clause, flags=re.IGNORECASE
    )
    if clause.startswith(subject) and len(clause) > len(subject):
        return clause[len(subject)].isspace() or clause[len(subject) :].startswith(
            "'s "
        )
    # This preserves an adjacent source passage, not a resolved assertion that
    # "it" or "they" denotes the definition's entity in the world.
    return bool(re.match(r"^(?:It|They|it|they)\s+\S", clause))


def _context(text: str, paragraph: SourceSpan) -> DefinitionContext | None:
    value = paragraph.text
    if len(value) > MAX_DEFINITION_PARAGRAPH or any(
        mark in value for mark in ('"', "“", "”", "«", "»", "`")
    ):
        return None
    if re.search(r"(?m)^\s*(?:>|#|[-*+]\s|\d+[.)]\s)", value) or _REPORTING.search(
        value
    ):
        return None
    sentences = split_documentary_sentences(value)
    clauses = split_documentary_clauses(value)
    if not sentences or not clauses:
        return None
    first = clauses[0]
    terminal = first.end - (1 if first.text.endswith((".", "!", "?", ";")) else 0)
    first_value = value[first.start : terminal]
    match = _DEFINITION.fullmatch(first_value)
    if not match:
        return None
    subject = match["subject"]
    if _REFERENCE.search(subject) or "\n" in subject or "\r" in subject:
        return None
    if re.search(r"\b(?:and|or)\b", subject, re.IGNORECASE) or re.match(
        r"^(?:if|when|unless|except|for|while|because|although|as)\b",
        subject,
        re.IGNORECASE,
    ):
        return None
    if match["predicate"].casefold() in {"is", "are"} and not _NOUN_BODY.match(
        match["body"]
    ):
        return None
    if not match["body"].strip() or first.text.endswith("?"):
        return None
    for clause in clauses:
        for other in _OTHER_COPULA.finditer(clause.text):
            if other[1] != subject and other[1].casefold() not in {"it", "they"}:
                return None
    if any(not _owned(clause.text, subject) for clause in clauses[1:]):
        return None
    # Offsets always refer to the caller's original string, including CRLF and
    # PDF line wraps; neither whitespace nor subject spelling is normalized.
    definition = _span(
        text,
        paragraph.start + first.start + match.start("body"),
        paragraph.start + first.start + match.end("body"),
    )
    original_sentences = tuple(
        _span(text, paragraph.start + span.start, paragraph.start + span.end)
        for span in sentences
    )
    return DefinitionContext(subject, definition, paragraph, original_sentences)


def extract_definition_contexts(
    text: str,
    *,
    metadata: Mapping[str, object] | None = None,
) -> tuple[DefinitionContext, ...]:
    """Return explicit first-clause definitions with complete locally owned context.

    Unsupported grammar and ambiguous/mixed-subject paragraphs are rejected as
    a whole. This is not general anaphora, truth verification or world knowledge.
    Callers should pass the original excerpt's quotation/code metadata.
    """
    if not _allowed_metadata(metadata) or not _well_formed(text):
        return ()
    # Do not let a blank line inside a fenced example create an apparent prose
    # paragraph. A source reader should give individual prose excerpts instead.
    if "```" in text or "~~~" in text:
        return ()
    return tuple(
        context
        for paragraph in _paragraphs(text)
        if (context := _context(text, paragraph)) is not None
    )


def _paragraph_metadata(metadata: Mapping[str, object] | None) -> bool:
    # An omitted metadata argument denotes plain text. Once source metadata is
    # supplied, do not treat a missing/unknown role or false-like value as prose.
    if metadata is None:
        return True
    if not isinstance(metadata, Mapping):
        return False
    role = metadata.get("documentary_role")
    signature = metadata.get("signature")
    return (
        type(role) is str
        and role == "PROSE"
        and metadata.get("quotation", False) is False
        and metadata.get("code", False) is False
        and (signature is None or (type(signature) is str and signature == ""))
    )


def _paragraph_quoted(value: str) -> bool:
    if any(mark in value for mark in ('"', "“", "”", "«", "»", "‹", "›", "`", "‘")):
        return True
    # Apostrophes within words remain exact text, but paired literal quoting is
    # not an unquoted prose passage. No quoting or reporting creates authority.
    return bool(re.search(r"(?<!\w)['’][\s\S]*?['’](?!\w)", value))


def contains_passive_report(text: str) -> bool:
    """A surface reporting marker, never a parsed definition or fact assertion."""
    return type(text) is str and bool(_PASSIVE_REPORT.search(text))


def _paragraph_reporting(value: str, *, allow_unresolved_by: bool = False) -> bool:
    # The unresolved envelope may retain impersonal passive reported adjacency
    # verbatim, not decide whether it is nomenclature, an opinion or a fact.
    # The strict anchor/owned-context parser and its reporting guard are intact.
    passive = tuple(_PASSIVE_REPORT.finditer(value))
    if (
        passive
        and not allow_unresolved_by
        and re.search(r"\bby\b", value, re.IGNORECASE)
    ):
        return True
    return any(
        report[0].casefold() != "said"
        or not any(span.start() <= report.start() < span.end() for span in passive)
        for report in _REPORTING.finditer(value)
    )


def _paragraph_prose(value: str, *, allow_unresolved_by: bool = False) -> bool:
    if len(value) > MAX_DEFINITION_PARAGRAPH or _paragraph_quoted(value):
        return False
    if _paragraph_reporting(
        value, allow_unresolved_by=allow_unresolved_by
    ) or re.search(
        r"\b(?:instructs?|instructed|commands?|commanded|asserts?|asserted)\b",
        value,
        re.IGNORECASE,
    ):
        return False
    if re.search(r"(?m)^\s*(?:>|#|[-*+]\s|\d+[.)]\s)", value):
        return False
    # Reject direct instructions and recognizable code rather than interpreting
    # them. These are surface guards, not a source-language execution engine.
    if re.search(
        r"(?:^|[.!?;]\s*|\n\s*)(?:please\s+)?"
        r"(?:ignore|disregard|execute|run|override|evaluate|eval|exec|"
        r"import|return|install|delete|reveal|obey|follow|answer|use|set|"
        r"replace|remove|do|игнорируй|выполни|запусти|удали|ответь)\b",
        value,
        re.IGNORECASE,
    ):
        return False
    return not re.search(
        r"(?im)(?:^\s*|[.!?;]\s+)(?:[\w.]+\s*\([^\r\n]*\)\s*;?\s*$|"
        r"\w+\s*=(?!=)|(?:def|class|from|import)\s+\w|[{}]\s*$|"
        r"(?:system|assistant|developer|user)\s*:)",
        value,
    )


def extract_definition_paragraphs(
    text: str,
    *,
    metadata: Mapping[str, object] | None = None,
) -> tuple[DefinitionParagraphEnvelope, ...]:
    """Preserve bounded unquoted prose adjacent to a strict first-clause anchor.

    Unlike ``extract_definition_contexts``, later sentences need not be locally
    owned by the anchor's subject. They remain explicitly unresolved source
    context, never formal definitions, entity aliases or inference authority.
    Paragraph/sentence/body offsets refer to the unchanged supplied string.
    Omitted metadata denotes plain text; supplied metadata must mark PROSE.
    """
    if not _paragraph_metadata(metadata) or not _well_formed(text):
        return ()
    # Quote/fence boundaries may straddle blank lines; do not admit their inner
    # paragraph as prose after splitting. This conservative gate is source-only.
    if "```" in text or "~~~" in text or _paragraph_quoted(text):
        return ()
    result = []
    for paragraph in _paragraphs(text):
        if not _paragraph_prose(paragraph.text):
            continue
        clauses = split_documentary_clauses(paragraph.text)
        if not clauses:
            continue
        first = clauses[0]
        anchor = _context(
            text,
            _span(text, paragraph.start + first.start, paragraph.start + first.end),
        )
        if anchor is None:
            continue
        sentences = tuple(
            _span(text, paragraph.start + span.start, paragraph.start + span.end)
            for span in split_documentary_sentences(paragraph.text)
        )
        result.append(
            DefinitionParagraphEnvelope(
                anchor.subject, anchor.definition, paragraph, sentences
            )
        )
    return tuple(result)


def extract_definition_reported_paragraphs(
    text: str,
    *,
    metadata: Mapping[str, object] | None = None,
) -> tuple[ReportedDefinitionParagraphEnvelope, ...]:
    """Retain exact passive/by wording under explicitly unresolved attribution.

    Only the first complete definition clause supplies a strict anchor. A later
    `(is|are|was|were) said to be` is a surface marker, not a parsed fact, resolved
    speaker or same-subject assertion. Other reporting/quote/instruction guards
    remain unchanged. Existing owned/plain paragraph APIs retain their policy.
    """
    if not _paragraph_metadata(metadata) or not _well_formed(text):
        return ()
    if metadata is not None and metadata.get("quotation") is not False:
        return ()
    if "```" in text or "~~~" in text or _paragraph_quoted(text):
        return ()
    result = []
    for paragraph in _paragraphs(text):
        if not _paragraph_prose(paragraph.text, allow_unresolved_by=True):
            continue
        clauses = split_documentary_clauses(paragraph.text)
        if len(clauses) < 2:
            continue
        first = clauses[0]
        anchor = _context(
            text,
            _span(text, paragraph.start + first.start, paragraph.start + first.end),
        )
        if anchor is None or not any(
            contains_passive_report(clause.text) for clause in clauses[1:]
        ):
            continue
        sentences = tuple(
            _span(text, paragraph.start + span.start, paragraph.start + span.end)
            for span in split_documentary_sentences(paragraph.text)
        )
        result.append(
            ReportedDefinitionParagraphEnvelope(
                anchor.subject, anchor.definition, paragraph, sentences
            )
        )
    return tuple(result)


def complete_definition_span(
    text: str,
    subject: str,
    initial_description: str,
    *,
    metadata: Mapping[str, object] | None = None,
) -> DefinitionContext | None:
    """Find one exact source definition; refuse mismatch or duplicate anchors.

    ``initial_description`` must be the complete first-clause body, optionally
    including its terminal full stop. A partial, normalized or paraphrased body
    cannot anchor a source span. ``full_description`` remains documentary only.
    """
    if type(subject) is not str or type(initial_description) is not str:
        return None
    if not subject.strip() or not initial_description.strip():
        return None
    matches = []
    for context in extract_definition_contexts(text, metadata=metadata):
        if context.subject != subject:
            continue
        body = context.definition
        if initial_description == body.text or (
            initial_description == body.text + "."
            and text[body.end : body.end + 1] == "."
        ):
            matches.append(context)
    return matches[0] if len(matches) == 1 else None
