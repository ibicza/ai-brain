"""One ephemeral verification scope per public request, never a global trust cache."""

from __future__ import annotations

from contextvars import ContextVar
from dataclasses import dataclass, field, fields, is_dataclass
from functools import wraps

from ai_brain.stage2.facts.canonical import canonical_json, canonicalize

_CURRENT = ContextVar("m33_request_verification", default=None)


@dataclass
class RequestVerification:
    budget: object
    packs: dict = field(default_factory=dict)


def current_request():
    return _CURRENT.get()


def custody_evidence(pack):
    descriptor = getattr(pack, "documentary_custody", None)
    if descriptor is None:
        return {}
    return {
        "source_verification": {
            "status": "RAW_SOURCE_CUSTODY_VERIFIED",
            "reader_view": "REPLAY_VERIFIED_RENDERED_NOT_VERBATIM",
            "manifest_hash": descriptor.manifest_hash,
            "inventory_hash": descriptor.inventory_hash,
            "grants_inference_authority": False,
            "authenticates_declared_author": False,
        }
    }


def _dataclass_values(instance, members):
    for member in members:
        yield getattr(instance, member.name)


def _output_size(value, remaining):
    from ai_brain.stage3.domains.documentary_custody import (
        ResourceLimitError,
        _canonical_size,
    )

    # Iterator frames avoid a second breadth-sized copy of the output structure.
    pending, size, visited = [(iter((value,)), 0)], 0, 0
    while pending:
        iterator, depth = pending[-1]
        try:
            item = next(iterator)
        except StopIteration:
            pending.pop()
            continue
        visited += 1
        if depth > 128 or visited > 1_000_000:
            raise ResourceLimitError("Output structure ceiling exceeded")
        if type(item) is dict:
            size += 2 + max(0, len(item) - 1) + len(item)
            if any(type(k) is not str for k in item):
                raise ValueError("Public output keys must be strings")
            pending.append((iter(item), depth + 1))
            pending.append((iter(item.values()), depth + 1))
        elif type(item) in (tuple, list):
            size += 2 + max(0, len(item) - 1)
            pending.append((iter(item), depth + 1))
        elif is_dataclass(item) and not isinstance(item, type):
            members = fields(item)
            size += 2 + max(0, len(members) - 1) + len(members)
            pending.append((iter(f.name for f in members), depth + 1))
            pending.append((_dataclass_values(item, members), depth + 1))
        else:
            # Canonicalize only an individual primitive, never a whole tree.
            if isinstance(item, (dict, tuple, list)):
                raise ValueError("Public output containers must have exact types")
            primitive = canonicalize(item)
            if type(primitive) not in (str, int, bool, type(None)):
                raise ValueError("Unsupported public output primitive")
            size += _canonical_size(primitive)
        if size > remaining:
            raise ResourceLimitError("Output byte ceiling exceeded before encoding")
    return size


def verified_request(function):
    @wraps(function)
    def wrapper(*args, **kwargs):
        from ai_brain.stage3.domains.documentary_custody import (
            QueryBudget,
            ResourceLimitError,
        )

        scope = _CURRENT.get()
        token = None
        if scope is None:
            scope = RequestVerification(QueryBudget())
            token = _CURRENT.set(scope)
        try:
            result = function(*args, **kwargs)
            # Validate cached snapshots again BEFORE any public result escapes.
            for snapshot, _ in scope.packs.values():
                snapshot.assert_current()
            # A bounded return envelope, not measured serializer peak RAM.
            remaining = (
                scope.budget.limits.query_output_bytes - scope.budget.counts["output"]
            )
            size = _output_size(result, remaining)
            scope.budget.reserve(output=size, payload=3 * size)
            encoded = canonical_json(result).encode("utf-8")
            if len(encoded) != size:
                raise ValueError("Output envelope canonical size mismatch")
            return result
        except ResourceLimitError:
            return {
                "status": "RESOURCE_LIMIT",
                "hits": [],
                "reason": "Cumulative verification/output budget exceeded",
            }
        except (ValueError, OSError):
            return {
                "status": "STALE_AUTHORITY",
                "hits": [],
                "reason": "Installed snapshot changed or verification failed",
            }
        finally:
            if token is not None:
                _CURRENT.reset(token)

    return wrapper
