"""Bounded scalar notation decoder, not a TeX engine or a program interpreter.

Only an explicit algebraic subset is converted. Vectors, functions, derivatives,
unknown commands and malformed markup remain unsupported. Units/applicability
must still be supplied by the source and validated by the semantic compiler.
"""

from __future__ import annotations

import re
import xml.etree.ElementTree as ET
from itertools import pairwise

MAX_NOTATION = 12000
MAX_DEPTH = 24
GREEK = {
    "α": "alpha",
    "β": "beta",
    "γ": "gamma",
    "δ": "delta",
    "ε": "epsilon",
    "θ": "theta",
    "κ": "kappa",
    "λ": "lambda_",
    "μ": "mu",
    "ν": "nu",
    "ρ": "rho",
    "σ": "sigma",
    "τ": "tau",
    "φ": "phi",
    "ω": "omega",
}
COMMANDS = {name.rstrip("_"): name for name in GREEK.values()}


def normalize_symbols(text):
    for symbol, name in GREEK.items():
        text = text.replace(symbol, name)
    return text


def _algebra(text):
    text = normalize_symbols(text).replace("−", "-").replace("×", "*").replace("·", "*")
    text = text.replace("²", "^2").replace("³", "^3")
    if not text or len(text) > MAX_NOTATION:
        raise ValueError("notation length limit")
    tokens = re.findall(r"[A-Za-z_][A-Za-z_0-9]*|\d+(?:\.\d+)?|[()+*/^=\-]", text)
    if "".join(tokens) != re.sub(r"\s+", "", text) or len(tokens) > 160:
        raise ValueError("unsupported scalar symbols")
    if tokens.count("=") > 1:
        raise ValueError("chained equality requires another policy")
    # Adjacent distinct notation tokens mean multiplication, not Python calls.
    # Plain documentary equations are never passed through this normalizer.
    result = []
    for token in tokens:
        if result:
            previous = result[-1]
            left = previous == ")" or re.fullmatch(r"[\w.]+", previous)
            right = token == "(" or re.fullmatch(r"[\w.]+", token)
            if left and right:
                result.append("*")
        result.append(token)
    return " ".join(result)


def latex_scalar(text, *, bindings=None):
    """Decode finite scalar syntax; opt-in aliases require caller-owned evidence.

    A binding is representation only, not a declaration of units, applicability,
    scalar type, or a licence to execute the denoted function. No alias is guessed.
    """
    if not text or len(text) > MAX_NOTATION:
        raise ValueError("notation length limit")
    text = text.strip()
    if "@" in text:
        raise ValueError("unsupported scalar marker")
    atoms = {}
    if bindings is not None:
        if type(bindings) is not dict or not 1 <= len(bindings) <= 16:
            raise ValueError("bounded explicit notation bindings required")
        source_atom = r"[A-Za-z](?:_(?:[A-Za-z0-9]{1,8}|\{[A-Za-z0-9]{1,8}\}))?(?:\([A-Za-z]\))?"
        if any(
            type(original) is not str or not re.fullmatch(source_atom, original)
            or not any(character in original for character in "_(")
            or type(canonical) is not str
            or not re.fullmatch(r"[A-Za-z][A-Za-z_0-9]{0,31}", canonical)
            or canonical in {"sin", "cos", "tan", "exp", "log", "ln"}
            for original, canonical in bindings.items()
        ) or len(set(bindings.values())) != len(bindings):
            raise ValueError("unsafe or ambiguous notation binding")
        # A target already spelled independently in the equation would create
        # an unproved identity between two source quantities.
        stripped = text
        originals = sorted(bindings, key=len, reverse=True)
        pattern = re.compile(r"(?<![A-Za-z0-9_\\])(?:" + "|".join(re.escape(key) for key in originals) + r")(?![_({])")
        stripped = pattern.sub(" ", stripped)
        if any(re.search(r"(?<![A-Za-z0-9_])" + re.escape(value) + r"(?![A-Za-z0-9_])", stripped) for value in bindings.values()):
            raise ValueError("binding collides with independently spelled quantity")
        def bind(match):
            marker = "@" + str(len(atoms)) + "@"
            atoms[marker] = bindings[match[0]]
            return marker
        text = pattern.sub(bind, text)
    if re.search(r"\b(?:sin|cos|tan|exp|log|ln)\b|[A-Za-z]\s*(?:\\left\s*)?\(", text):
        raise ValueError("function-like TeX notation requires explicit binding")
    for opening, closing in (("$$", "$$"), ("$", "$"), (r"\[", r"\]"), (r"\(", r"\)")):
        if text.startswith(opening) and text.endswith(closing):
            text = text[len(opening) : -len(closing)].strip()
            break
    cursor = 0

    def parse(stop=None, depth=0):
        nonlocal cursor
        if depth > MAX_DEPTH:
            raise ValueError("notation nesting limit")
        pieces = []
        while cursor < len(text):
            char = text[cursor]
            if char == "@":
                marker = re.match(r"@\d+@", text[cursor:])
                if not marker or marker[0] not in atoms:
                    raise ValueError("unknown notation binding marker")
                cursor += len(marker[0])
                pieces.append(" " + atoms[marker[0]] + " ")
                continue
            if char == "}":
                if stop != "}":
                    raise ValueError("unmatched TeX brace")
                cursor += 1
                return "".join(pieces)
            if char == "{":
                cursor += 1
                pieces.append("(" + parse("}", depth + 1) + ")")
            elif char == "\\":
                command = re.match(r"\\([A-Za-z]+|[,;! ])", text[cursor:])
                if not command:
                    raise ValueError("unsupported TeX escape")
                cursor += len(command[0])
                name = command[1]
                if name in {"frac", "dfrac", "tfrac"}:
                    arguments = []
                    for _ in range(2):
                        while cursor < len(text) and text[cursor].isspace():
                            cursor += 1
                        if cursor >= len(text) or text[cursor] != "{":
                            raise ValueError("fraction requires two braced arguments")
                        cursor += 1
                        arguments.append(parse("}", depth + 1))
                    pieces.append(f"(({arguments[0]})/({arguments[1]}))")
                elif name in COMMANDS:
                    pieces.append(" " + COMMANDS[name] + " ")
                elif name in {"cdot", "times"}:
                    pieces.append("*")
                elif name in {"left", "right", "displaystyle", ",", ";", "!", " "}:
                    pieces.append(" ")
                else:
                    raise ValueError("unsupported TeX command: " + name)
            elif char == "_":
                raise ValueError("subscripts require explicit symbol binding")
            else:
                if char.isascii() and char.isalpha():
                    if re.match(r"[A-Za-z]{3,}", text[cursor:]):
                        raise ValueError("unbound multi-letter TeX identifier/function")
                    pieces.append(" " + char + " ")
                else:
                    pieces.append(char)
                cursor += 1
        if stop is not None:
            raise ValueError("unclosed TeX brace")
        return "".join(pieces)

    return _algebra(parse())


def mathml_scalar(markup):
    if len(markup) > MAX_NOTATION or "<!" in markup:
        raise ValueError("unsupported or oversized MathML")
    try:
        root = ET.fromstring(markup)
    except ET.ParseError as error:
        raise ValueError("malformed MathML") from error
    if sum(1 for _ in root.iter()) > 160:
        raise ValueError("MathML node limit")

    def render(node, depth=0):
        if depth > MAX_DEPTH:
            raise ValueError("notation nesting limit")
        tag = node.tag.rsplit("}", 1)[-1]
        style = re.sub(r"\s+", "", node.attrib.get("style", "")).casefold()
        if (
            "hidden" in node.attrib
            or node.attrib.get("aria-hidden") == "true"
            or "display:none" in style
            or "visibility:hidden" in style
        ):
            raise ValueError("hidden MathML token cannot establish visible algebra")
        if node.attrib.get("mathvariant") in {"bold", "bold-italic"}:
            raise ValueError("vector/tensor notation is not scalar")
        children = list(node)
        if tag in {"mi", "mn", "mo"} and not children:
            value = (node.text or "").strip()
            if tag == "mi" and not re.fullmatch(
                r"[A-Za-z_][A-Za-z_0-9]{0,15}|[α-ω]", value
            ):
                raise ValueError("unsupported MathML identifier")
            if tag == "mn" and not re.fullmatch(r"[+-]?\d+(?:\.\d+)?", value):
                raise ValueError("unsupported MathML number")
            if tag == "mo" and value not in {
                "+",
                "-",
                "−",
                "*",
                "×",
                "·",
                "/",
                "^",
                "=",
                "(",
                ")",
                "\u2062",
            }:
                raise ValueError("unsupported MathML operator")
            if tag == "mi" and value in {"sin", "cos", "tan", "exp", "log", "ln"}:
                raise ValueError("function notation is not scalar algebra")
            if tag == "mo" and value == "\u2062":
                return "*"
            return value
        if tag in {"math", "mrow", "mstyle", "mpadded"}:
            if any(
                left.tag.rsplit("}", 1)[-1] == "mi"
                and right.tag.rsplit("}", 1)[-1] == "mo"
                and (right.text or "").strip() == "("
                for left, right in pairwise(children)
            ):
                raise ValueError("function-like MathML requires explicit binding")
            if any(
                left.tag.rsplit("}", 1)[-1] == "mi"
                and right.tag.rsplit("}", 1)[-1] == "mfenced"
                for left, right in pairwise(children)
            ):
                raise ValueError("function-like MathML requires explicit binding")
            if any(
                left.tag.rsplit("}", 1)[-1] == "mi"
                and right.tag.rsplit("}", 1)[-1] == "mrow"
                and len(right)
                and right[0].tag.rsplit("}", 1)[-1] == "mo"
                and (right[0].text or "").strip() == "("
                for left, right in pairwise(children)
            ):
                raise ValueError("function-like MathML requires explicit binding")
            if (node.text or "").strip() or any(
                (child.tail or "").strip() for child in children
            ):
                raise ValueError("mixed MathML text")
            return " ".join(render(child, depth + 1) for child in children)
        if tag == "semantics" and children:
            # An annotation is documentary metadata, not an alternate executable
            # equation silently substituted for the presentation branch.
            return render(children[0], depth + 1)
        if tag in {"mfrac", "msup"} and len(children) == 2:
            left, right = (render(child, depth + 1) for child in children)
            return f"(({left}){'/' if tag == 'mfrac' else '^'}({right}))"
        if (
            tag == "mfenced"
            and node.attrib.get("open", "(") == "("
            and node.attrib.get("close", ")") == ")"
            and len(children) == 1
        ):
            return "(" + render(children[0], depth + 1) + ")"
        if tag == "mspace":
            return " "
        raise ValueError("unsupported MathML element: " + tag)

    return _algebra(render(root))
