"""Shared bounded record budgets for practical documentary packs.

A book's retained passages and their semantic projections consume the same
budget. Reader byte/passage limits remain independent and are not relaxed.
"""

MAX_DOCUMENTARY_PACK_RECORDS = 16384
MAX_DOCUMENTARY_QUERY_RECORDS = 65536
