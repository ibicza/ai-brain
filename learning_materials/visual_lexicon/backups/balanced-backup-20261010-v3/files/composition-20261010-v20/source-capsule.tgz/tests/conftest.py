"""Bound automatic scalar parameter IDs without changing test inputs.

Windows limits environment values (including PYTEST_CURRENT_TEST). Pytest's
default string ID can otherwise prevent an oversized-input assertion from even
running. Explicit fixture IDs and ordinary small-value IDs are unchanged.
"""

import hashlib

MAX_AUTOMATIC_ID_VALUE_LENGTH = 128


def pytest_make_parametrize_id(val: object) -> str | None:
    if type(val) not in {str, bytes} or len(val) <= MAX_AUTOMATIC_ID_VALUE_LENGTH:
        return None
    raw = val.encode("utf-8", errors="surrogatepass") if type(val) is str else val
    return (
        f"{type(val).__name__}-len{len(val)}-sha256-{hashlib.sha256(raw).hexdigest()}"
    )
