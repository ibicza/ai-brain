"""Incremental own-weight relations pilot, fresh splits and first-block replay."""

from __future__ import annotations

import argparse
import json
import os
import time
from pathlib import Path

import numpy as np
import torch
from m33_primary_zero_pilot import counterfactuals as old_counterfactuals
from m33_primary_zero_pilot import sha256, write_json
from torch.nn import functional as F

from ai_brain.training import primary_relations as r
from ai_brain.training import primary_zero as b

STARTER_SHA256 = "501e1f2ef71c4b187d084294908f4386785206ba7ab87bfa8b65db7209043439"
STARTER_THRESHOLDS = {"count": 0.8, "shape": 0.5, "color": 0.995}
WARM_SHA256 = "867c88ca14fd600632914c6a7e0370a296b67ee29b782b245c596a83fb8c1286"


class Prepared:
    def __init__(self, rows: list[r.Sample], device: torch.device):
        scenes, pixels, indices = {}, [], []
        for row in rows:
            # Include pixel digest in cache key so counterfactual identity errors
            # cannot silently substitute one image for another.
            key = (row.scene.scene_id, row.image_sha256)
            if key not in scenes:
                scenes[key] = len(pixels)
                pixels.append(b.render(row.scene)[0])
            indices.append(scenes[key])
        # uint8 GPU storage limits the growing replay corpus memory footprint.
        self.images = torch.from_numpy(np.stack(pixels)).permute(0, 3, 1, 2).to(device)
        self.indices = torch.tensor(indices, device=device)
        self.questions = torch.tensor(
            [r.encode_question(row.question) for row in rows], device=device
        )
        self.answers = torch.tensor([row.answer for row in rows], device=device)
        self.intents = torch.tensor(
            [r.TASKS.index(row.task) for row in rows], device=device
        )
        self.rows = rows

    def batch(self, ids):
        return (
            self.images[self.indices[ids]].float() / 255,
            self.questions[ids],
            self.answers[ids],
        )


def brightness_view(images: torch.Tensor) -> torch.Tensor:
    # Orientation-preserving invertible photometric change, not a mirror.
    return images * 0.97 + 0.01


def translated_view(images: torch.Tensor, dx: int, dy: int) -> torch.Tensor:
    if dx not in {-1, 0, 1} or dy not in {-1, 0, 1}:
        raise ValueError("translation outside admitted one-pixel margin")
    padded = F.pad(images, (1, 1, 1, 1), mode="replicate")
    return padded[:, :, 1 - dy : 1 - dy + b.IMAGE_SIZE, 1 - dx : 1 - dx + b.IMAGE_SIZE]


@torch.no_grad()
def probabilities(
    model, data: Prepared, *, mode="normal", consensus=False, view_policy="all_five"
):
    model.eval()
    outputs = []
    for start in range(0, len(data.rows), 128):
        ids = torch.arange(
            start, min(start + 128, len(data.rows)), device=data.answers.device
        )
        images, questions, _ = data.batch(ids)
        if mode == "blank":
            images = torch.zeros_like(images)
        elif mode == "shuffled":
            images = (
                data.images[(data.indices[ids] + 17) % len(data.images)].float() / 255
            )
        elif mode != "normal":
            raise ValueError("unknown evaluation mode")
        primary = model(images, questions).softmax(-1).cpu().tolist()
        if consensus:
            views = [primary]
            for view in (
                brightness_view(images),
                translated_view(images, 1, 1),
                translated_view(images, -1, -1),
            ):
                views.append(model(view, questions).softmax(-1).cpu().tolist())
            views.append(
                model(images.flip(-1), r.mirror_questions(questions))
                .softmax(-1)
                .cpu()
                .tolist()
            )
            selected_views = []
            for row, items in zip(
                data.rows[start : start + 128], zip(*views, strict=True), strict=True
            ):
                # Policy follows the supported question, never gold/scene metadata.
                policy = (
                    view_policy
                    if isinstance(view_policy, str)
                    else view_policy[r.question_task(row.question)]
                )
                ids = {
                    "mirror_only": (0, 4),
                    "photometric_four": (0, 1, 2, 3),
                    "all_five": (0, 1, 2, 3, 4),
                }
                if policy not in ids:
                    raise ValueError("unsupported view policy")
                selected_views.append(
                    r.consensus_probabilities([items[i] for i in ids[policy]])
                )
            primary = selected_views
        outputs.extend(primary)
    return outputs


def summarize(rows, probs, thresholds=None):
    predicted = [
        r.select_answer(p, thresholds[row.task] if thresholds else 0)
        for row, p in zip(rows, probs, strict=True)
    ]
    result = {"all": r.metrics([row.answer for row in rows], predicted)}
    for task in r.TASKS:
        ids = [i for i, row in enumerate(rows) if row.task == task]
        if ids:
            result[task] = r.metrics(
                [rows[i].answer for i in ids], [predicted[i] for i in ids]
            )
    result["invalid_raw_tokens"] = sum(
        int(np.argmax(p)) not in r.ANSWER_TEXT for p in probs
    )
    return result


def counterfactuals(round_id, groups=30):
    rows = [
        r.Sample(s.scene, s.image_sha256, s.task, s.question, s.answer)
        for s in old_counterfactuals(100 + round_id, groups)
    ]
    for group in range(groups):
        rng = np.random.default_rng(400_000_000 + round_id * 10000 + group)
        shapes = list(rng.choice(b.SHAPES, 2, replace=False))
        colors = list(rng.choice(b.COLORS, 2, replace=False))
        radius = float(rng.uniform(8, 12))
        angle = float(rng.uniform(-0.2, 0.2))
        shift = float(rng.uniform(-5, 5))
        for task in r.NEW_TASKS:
            for variant in range(4):
                shape2 = shapes[0] if variant % 2 == 0 else shapes[1]
                color2 = colors[0] if variant // 2 == 0 else colors[1]
                positions = [(24 + shift, 24), (72 + shift, 72)]
                if task in r.DIRECTIONS:
                    shape2, color2 = shapes[1], colors[1]
                    if variant % 2:
                        positions = positions[::-1]
                objects = tuple(
                    b.ObjectSpec(str(shape), str(color), x, y, radius, angle)
                    for shape, color, (x, y) in zip(
                        (shapes[0], shape2), (colors[0], color2), positions, strict=True
                    )
                )
                scene = b.Scene(
                    f"counterfactual/{task}/{group}/{variant}",
                    400_000_000 + round_id * 10000 + group,
                    "filled" if group % 2 else "outlined",
                    "normal",
                    objects,
                )
                if task in r.DIRECTIONS:
                    rows.append(
                        r.sample(
                            scene,
                            task,
                            -1,
                            str(colors[0]),
                            str(colors[1]),
                            r.DIRECTIONS[task][variant // 2],
                        )
                    )
                else:
                    rows.append(r.sample(scene, task, -1))
    for row in rows:
        row.validate()
    return rows


@torch.no_grad()
def starter_regression(checkpoint, rows, device):
    """Historical starter policy on fresh test scenes, evaluated after freezing."""
    model = b.ZeroClassModel(width=checkpoint["width"]).to(device).eval()
    model.load_state_dict(checkpoint["model"])
    selected = {task: [] for task in b.TASKS}
    gold = {task: [] for task in b.TASKS}
    data = Prepared([row for row in rows if row.task in b.TASKS], device)
    for start in range(0, len(data.rows), 128):
        ids = torch.arange(start, min(start + 128, len(data.rows)), device=device)
        images, questions, _ = data.batch(ids)
        primary = model(images, questions).softmax(-1).cpu().tolist()
        mirror = model(images.flip(-1), questions).softmax(-1).cpu().tolist()
        for row, a, c in zip(
            data.rows[start : start + 128], primary, mirror, strict=True
        ):
            selected[row.task].append(
                b.select_answer(
                    b.consensus_probabilities([a, c]), STARTER_THRESHOLDS[row.task]
                )
            )
            gold[row.task].append(row.answer)
    return {task: b.metrics(gold[task], selected[task]) for task in b.TASKS}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--starter", type=Path, required=True)
    parser.add_argument("--warm-checkpoint", type=Path)
    parser.add_argument("--device", choices=("cpu", "cuda"), default="cuda")
    parser.add_argument("--steps", type=int, default=40000)
    parser.add_argument("--train-scenes", type=int, default=6000)
    parser.add_argument("--holdout-scenes", type=int, default=1200)
    parser.add_argument("--batch-size", type=int, default=64)
    parser.add_argument("--round-id", type=int, default=1)
    parser.add_argument("--eval-every", type=int, default=1000)
    parser.add_argument("--learning-rate", type=float, default=0.0004)
    args = parser.parse_args()
    if args.output.exists():
        raise ValueError("refuse existing experiment")
    if sha256(args.starter) != STARTER_SHA256:
        raise ValueError("starter is not verified v3 checkpoint")
    if args.warm_checkpoint and sha256(args.warm_checkpoint) != WARM_SHA256:
        raise ValueError("unverified own seven-skill warm checkpoint")
    if min(args.steps, args.batch_size, args.eval_every) < 1 or args.learning_rate <= 0:
        raise ValueError("invalid training budget")
    device = torch.device(args.device)
    if args.device == "cuda" and not torch.cuda.is_available():
        raise ValueError("CUDA unavailable; no silent fallback")
    torch.set_num_threads(2)
    torch.manual_seed(20261008 + args.round_id * 11)
    np.random.seed(20261008 + args.round_id * 11)
    if device.type == "cuda":
        torch.cuda.reset_peak_memory_stats()
    args.output.mkdir(parents=True)
    protocol = {
        "scope": "INCREMENTAL_OWN_SYNTHETIC_RU_RELATIONS_NOT_TEXTBOOK_OR_M33_CLOSURE",
        "config": {
            k: str(v) if isinstance(v, Path) else v for k, v in vars(args).items()
        },
        "starter_sha256": STARTER_SHA256,
        "weights": "CONTINUE_VERIFIED_OWN_V3; APPEND_ONLY_WORD_AND_ANSWER_IDS; NO_EXTERNAL_WEIGHTS",
        "warm_checkpoint_sha256": WARM_SHA256 if args.warm_checkpoint else None,
        "retention_recovery": "when warm: all already supported legacy aliases are replayed on fresh pixels; half batch color, half joint; own 3-skill/7-skill teachers filtered against procedural gold; not new legacy-language generalization",
        "learned_inputs": "RGB pixels and supported question only; oracle/reference/task IDs are labels, never forward inputs",
        "skills": list(r.TASKS),
        "comparison": "same most-specific prototype name, not exclusion of mathematical superclass",
        "spatial": "unique color references; disjoint axis pixel extents only; missing/ambiguous/axis-overlap UNKNOWN",
        "replay": "fresh first-block scenes; own frozen v3 training-only soft targets on correctly predicted examples; no previous final examples used for training",
        "augmentation": "brightness, one-pixel translations, horizontal mirror WITH leftee/rightee token swap; all admitted truth labels preserved",
        "selection": "minimum dev cross entropy; separate calibration; original, brightness, +/-1-pixel translation and logical mirrored-question views must agree",
        "binary_safety_floor": "YES/NO skills fixed threshold grid .99/.995/.999/.9995/.9999; 0 observed calibration errors does not justify .6 confidence acceptance",
        "sampling": "style, geometry, comparison labels, references, directions and teaching question orders randomized independently; held-out questions unchanged",
        "gate": "each skill final/transfer >=50 accepted, zero false assertions, answerable recall>=.80, UNKNOWN recall>=.90; pixel blank/shuffle recall drop>=.15; counterfactual recall>=.80 and zero false assertions",
        "retention": "first-block final/transfer recall no more than .02 below frozen starter on same fresh scenes; zero accepted errors still required",
        "final_use": "only after weights and calibration frozen; old failures immutable; not independent external sources",
        "limits": "one procedural family; finite dependent examples; no general truth guarantee, OCR, real pictures or PDF admission",
        "capsule_sha256": os.environ.get("AI_BRAIN_CAPSULE_SHA256", "LOCAL_NO_CAPSULE"),
    }
    write_json(args.output / "protocol.json", protocol)
    splits = r.corpus(
        train_scenes=args.train_scenes,
        holdout_scenes=args.holdout_scenes,
        round_id=args.round_id,
        legacy_all_aliases=args.warm_checkpoint is not None,
    )
    write_json(args.output / "split-audit.json", r.audit_splits(splits))
    for split, rows in splits.items():
        write_json(
            args.output / f"{split}-examples.json",
            [r.sample_record(row) for row in rows],
        )
    starter = torch.load(args.starter, map_location="cpu", weights_only=True)
    model = r.RelationsModel(width=starter["width"])
    warm = (
        torch.load(args.warm_checkpoint, map_location="cpu", weights_only=True)
        if args.warm_checkpoint
        else None
    )
    if warm:
        model.load_state_dict(warm["model"])
    else:
        model.load_starter(starter["model"])
    model.to(device)
    train, dev = (Prepared(splits[name], device) for name in ("train", "dev"))
    # Frozen OWN prior model, used only as a retention target on train. It never
    # sees final/calibration and never annotates new relation examples.
    teacher = b.ZeroClassModel(width=starter["width"]).to(device).eval()
    teacher.load_state_dict(starter["model"])
    teacher_probs = torch.zeros(
        len(train.rows), r.VOCAB_SIZE if warm else b.VOCAB_SIZE, device=device
    )
    teacher_eligible = torch.zeros(len(train.rows), dtype=torch.bool, device=device)
    replay_ids = torch.nonzero(train.intents < len(b.TASKS)).flatten()
    with torch.no_grad():
        for start in range(0, len(replay_ids), 128):
            ids = replay_ids[start : start + 128]
            pixels, words, labels = train.batch(ids)
            target = teacher(pixels, words).softmax(-1)
            teacher_probs[ids, : b.VOCAB_SIZE] = target
            teacher_eligible[ids] = (target.argmax(-1) == labels) & (
                target.max(-1).values >= 0.98
            )
    del teacher
    if warm:
        teacher = r.RelationsModel(width=starter["width"]).to(device).eval()
        teacher.load_state_dict(warm["model"])
        relation_ids = torch.nonzero(train.intents >= len(b.TASKS)).flatten()
        with torch.no_grad():
            for start in range(0, len(relation_ids), 128):
                ids = relation_ids[start : start + 128]
                pixels, words, labels = train.batch(ids)
                target = teacher(pixels, words).softmax(-1)
                teacher_probs[ids] = target
                teacher_eligible[ids] = (target.argmax(-1) == labels) & (
                    target.max(-1).values >= 0.98
                )
        del teacher
    write_json(
        args.output / "replay-teacher-audit.json",
        {
            "starter_sha256": STARTER_SHA256,
            "train_only": True,
            "eligible": int(teacher_eligible.sum().item()),
            "replay_examples": len(replay_ids),
            "new_relation_pseudolabels": 0,
            "warm_teacher_sha256": WARM_SHA256 if warm else None,
            "warm_relation_targets_are_retention_only": bool(warm),
        },
    )
    optimizer = torch.optim.AdamW(
        model.parameters(), lr=args.learning_rate, weight_decay=0.01
    )
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
        optimizer, T_max=args.steps, eta_min=args.learning_rate * 0.1
    )
    frequency = (
        torch.bincount(train.answers, minlength=r.VOCAB_SIZE).clamp_min(1).float()
    )
    weights = (len(train.rows) / frequency).sqrt()
    weights /= weights[list(r.ANSWER_TEXT)].mean()
    history, best_loss = [], float("inf")
    color_ids = torch.nonzero(train.intents == r.TASKS.index("color")).flatten()
    started = time.monotonic()
    for step in range(1, args.steps + 1):
        model.train()
        ids = torch.randint(len(train.rows), (args.batch_size,), device=device)
        if warm:
            ids[: args.batch_size // 2] = color_ids[
                torch.randint(len(color_ids), (args.batch_size // 2,), device=device)
            ]
        images, words, labels = train.batch(ids)
        if torch.rand((), device=device).item() < 0.5:
            images = brightness_view(images)
        if torch.rand((), device=device).item() < 0.5:
            delta = 1 if torch.rand((), device=device).item() < 0.5 else -1
            images = translated_view(images, delta, delta)
        if torch.rand((), device=device).item() < 0.5:
            images = images.flip(-1)
            words = r.mirror_questions(words)
        optimizer.zero_grad(set_to_none=True)
        logits, intents = model(images, words, return_intent=True)
        loss = F.cross_entropy(logits, labels, weight=weights) + 0.2 * F.cross_entropy(
            intents, train.intents[ids]
        )
        eligible = teacher_eligible[ids]
        if eligible.any():
            loss = loss + F.kl_div(
                F.log_softmax(logits[eligible, : teacher_probs.shape[1]], -1),
                teacher_probs[ids[eligible]],
                reduction="batchmean",
            )
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1)
        optimizer.step()
        scheduler.step()
        if step % args.eval_every == 0 or step == args.steps:
            probs = probabilities(model, dev)
            dev_loss = float(
                -np.mean(
                    [
                        np.log(max(p[row.answer], 1e-30))
                        for row, p in zip(dev.rows, probs, strict=True)
                    ]
                )
            )
            stats = summarize(dev.rows, probs)
            history.append(
                {
                    "step": step,
                    "loss": float(loss.item()),
                    "dev_loss": dev_loss,
                    "dev": stats,
                    "seconds": time.monotonic() - started,
                }
            )
            print(
                json.dumps(
                    {
                        "step": step,
                        "dev_loss": dev_loss,
                        "accuracy": {task: stats[task]["accuracy"] for task in r.TASKS},
                        "seconds": round(time.monotonic() - started, 1),
                    }
                ),
                flush=True,
            )
            if dev_loss < best_loss:
                best_loss = dev_loss
                torch.save(
                    {
                        "model": model.state_dict(),
                        "width": starter["width"],
                        "step": step,
                        "starter_sha256": STARTER_SHA256,
                    },
                    args.output / "best.pt",
                )
    chosen = torch.load(args.output / "best.pt", map_location=device, weights_only=True)
    model.load_state_dict(chosen["model"])
    calibration = Prepared(splits["calibration"], device)
    cal_probs = probabilities(model, calibration, consensus=True)
    thresholds = r.calibrate(calibration.rows, cal_probs)
    write_json(
        args.output / "frozen-calibration.json",
        {
            "thresholds": thresholds,
            "checkpoint_sha256": sha256(args.output / "best.pt"),
            "protocol_sha256": sha256(args.output / "protocol.json"),
        },
    )
    report = {
        "schema": 1,
        "protocol_sha256": sha256(args.output / "protocol.json"),
        "checkpoint_sha256": sha256(args.output / "best.pt"),
        "starter_sha256": STARTER_SHA256,
        "parameters": sum(p.numel() for p in model.parameters()),
        "best_step": chosen["step"],
        "thresholds": thresholds,
        "history": history,
        "calibration": summarize(calibration.rows, cal_probs, thresholds),
        "scope": protocol["scope"],
        "tests": {},
    }
    for split in ("final", "transfer"):
        data = Prepared(splits[split], device)
        raw = probabilities(model, data)
        probs = probabilities(model, data, consensus=True)
        report["tests"][split] = {
            "raw": summarize(data.rows, raw),
            "selected": summarize(data.rows, probs, thresholds),
        }
        for name, mode in (("blank_image", "blank"), ("shuffled_image", "shuffled")):
            report["tests"][split][name] = summarize(
                data.rows,
                probabilities(model, data, mode=mode, consensus=True),
                thresholds,
            )
        report["tests"][split]["frozen_starter_regression_baseline"] = (
            starter_regression(starter, data.rows, device)
        )
        write_json(
            args.output / f"{split}-predictions.json",
            [
                {
                    "scene_id": row.scene.scene_id,
                    "task": row.task,
                    "gold": r.ANSWER_TEXT[row.answer],
                    "selected": r.ANSWER_TEXT[r.select_answer(p, thresholds[row.task])],
                    "probabilities": p,
                }
                for row, p in zip(data.rows, probs, strict=True)
            ],
        )
    pairs = counterfactuals(args.round_id)
    cf_probs = probabilities(model, Prepared(pairs, device), consensus=True)
    report["counterfactual"] = summarize(pairs, cf_probs, thresholds)
    write_json(
        args.output / "counterfactual-examples.json",
        [r.sample_record(row) for row in pairs],
    )
    write_json(
        args.output / "counterfactual-predictions.json",
        [
            {
                "scene_id": row.scene.scene_id,
                "task": row.task,
                "gold": r.ANSWER_TEXT[row.answer],
                "selected": r.ANSWER_TEXT[r.select_answer(p, thresholds[row.task])],
                "probabilities": p,
            }
            for row, p in zip(pairs, cf_probs, strict=True)
        ],
    )
    gates, retention = {}, {}
    for task in r.TASKS:
        passed = True
        retained = True
        for split in ("final", "transfer"):
            result = report["tests"][split]
            stats = result["selected"][task]
            passed &= (
                stats["accepted"] >= 50
                and stats["false_assertions"] == 0
                and (stats["answerable_recall"] or 0) >= 0.8
                and (stats["unknown_recall"] or 0) >= 0.9
            )
            for control in ("blank_image", "shuffled_image"):
                passed &= (stats["answerable_recall"] or 0) - (
                    result[control][task]["answerable_recall"] or 0
                ) >= 0.15
            if task in b.TASKS:
                retained &= (stats["answerable_recall"] or 0) >= (
                    result["frozen_starter_regression_baseline"][task][
                        "answerable_recall"
                    ]
                    or 0
                ) - 0.02
        cf = report["counterfactual"][task]
        passed &= cf["false_assertions"] == 0 and (cf["answerable_recall"] or 0) >= 0.8
        gates[task] = bool(passed)
        if task in b.TASKS:
            retention[task] = bool(retained)
    report.update(
        {
            "skill_gates": gates,
            "retention_gates": retention,
            "status": "BOUNDED_INCREMENTAL_GATE_PASSED_NOT_PRODUCTION"
            if all(gates.values()) and all(retention.values())
            else "REJECTED_NOT_PRODUCTION",
            "elapsed_seconds": time.monotonic() - started,
            "torch": torch.__version__,
            "device": str(device),
            "peak_cuda_allocated_bytes": torch.cuda.max_memory_allocated()
            if device.type == "cuda"
            else None,
            "peak_cuda_reserved_bytes": torch.cuda.max_memory_reserved()
            if device.type == "cuda"
            else None,
        }
    )
    write_json(args.output / "report.json", report)
    print(
        json.dumps(
            {
                key: report[key]
                for key in (
                    "status",
                    "skill_gates",
                    "retention_gates",
                    "thresholds",
                    "parameters",
                    "elapsed_seconds",
                    "peak_cuda_allocated_bytes",
                )
            }
        ),
        flush=True,
    )


if __name__ == "__main__":
    main()
