"""Bounded random-init visual pilot; no PDF training, M33 gold or production writes."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import time
from pathlib import Path

import numpy as np
import torch
from torch.nn import functional as F

from ai_brain.training.primary_zero import (
    ANSWERS,
    COLORS,
    IMAGE_SIZE,
    QUESTIONS,
    SHAPES,
    TASKS,
    VOCAB_SIZE,
    ObjectSpec,
    Sample,
    Scene,
    ZeroClassModel,
    audit_splits,
    calibrate,
    consensus_probabilities,
    corpus,
    encode_question,
    metrics,
    render,
    sample_record,
    select_answer,
)


def write_json(path: Path, data: object) -> None:
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(data, stream, ensure_ascii=False, indent=2)
        stream.write("\n")


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


class Prepared:
    def __init__(self, rows: list[Sample], device: torch.device):
        scenes, pixels, indices = {}, [], []
        for row in rows:
            if row.scene.scene_id not in scenes:
                scenes[row.scene.scene_id] = len(pixels)
                pixels.append(render(row.scene)[0])
            indices.append(scenes[row.scene.scene_id])
        self.images = (
            torch.from_numpy(np.stack(pixels))
            .permute(0, 3, 1, 2)
            .float()
            .div_(255)
            .to(device)
        )
        self.indices = torch.tensor(indices, device=device)
        self.questions = torch.tensor(
            [encode_question(r.question) for r in rows], device=device
        )
        self.answers = torch.tensor([r.answer for r in rows], device=device)
        self.intents = torch.tensor([TASKS.index(r.task) for r in rows], device=device)
        self.rows = rows

    def batch(
        self, indices: torch.Tensor
    ) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        return (
            self.images[self.indices[indices]],
            self.questions[indices],
            self.answers[indices],
        )


@torch.no_grad()
def probabilities(
    model: ZeroClassModel,
    data: Prepared,
    *,
    mode: str = "normal",
    consensus: bool = False,
) -> list[list[float]]:
    model.eval()
    outputs = []
    for start in range(0, len(data.rows), 128):
        ids = torch.arange(
            start, min(start + 128, len(data.rows)), device=data.answers.device
        )
        images, questions, _ = data.batch(ids)
        if mode == "blank":
            images = torch.zeros_like(images)
        elif mode == "shuffled":
            images = data.images[(data.indices[ids] + 17) % len(data.images)]
        elif mode != "normal":
            raise ValueError("unknown evaluation mode")
        primary = model(images, questions).softmax(-1).cpu().tolist()
        if consensus:
            mirror = model(images.flip(-1), questions).softmax(-1).cpu().tolist()
            primary = [
                consensus_probabilities([a, b])
                for a, b in zip(primary, mirror, strict=True)
            ]
        outputs.extend(primary)
    return outputs


def summarize(
    rows: list[Sample], probs: list[list[float]], thresholds: dict | None = None
) -> dict:
    predicted = [
        select_answer(p, thresholds[row.task] if thresholds else 0)
        for row, p in zip(rows, probs, strict=True)
    ]
    result = {"all": metrics([r.answer for r in rows], predicted)}
    for task in TASKS:
        indices = [i for i, row in enumerate(rows) if row.task == task]
        result[task] = metrics(
            [rows[i].answer for i in indices], [predicted[i] for i in indices]
        )
    result["invalid_raw_tokens"] = sum(int(np.argmax(p)) >= len(ANSWERS) for p in probs)
    return result


def counterfactuals(round_id: int, groups: int = 30) -> list[Sample]:
    rows = []
    for group in range(groups):
        rng = np.random.default_rng(round_id * 8_000_000 + group)
        cells = rng.permutation(6)
        shift_x, shift_y = float(rng.uniform(-1, 1)), float(rng.uniform(-2, 2))
        angle = float(rng.uniform(-0.25, 0.25))
        base_radius = float(rng.uniform(12, 13.5))
        for task in TASKS:
            for value in range(6):
                count = value if task == "count" else 1
                shape = SHAPES[value] if task == "shape" else "круг"
                color = COLORS[value] if task == "color" else "красный"
                # Comparable total filled area across counts, not just a large-area cue.
                radius = base_radius / np.sqrt(max(count, 1)) if task == "count" else 9
                objects = tuple(
                    ObjectSpec(
                        shape,
                        color,
                        19 + (cells[i] % 3) * 29 + shift_x,
                        25 + (cells[i] // 3) * 45 + shift_y,
                        float(radius),
                        angle,
                    )
                    for i in range(count)
                )
                scene = Scene(
                    f"counterfactual/{task}/{group}/{value}",
                    round_id * 8_000_000 + group,
                    "filled" if group % 2 else "outlined",
                    "normal",
                    objects,
                )
                image, _ = render(scene)
                rows.append(
                    Sample(
                        scene,
                        hashlib.sha256(image.tobytes()).hexdigest(),
                        task,
                        QUESTIONS[task][-1],
                        scene.gold(task),
                    )
                )
    return rows


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--device", choices=("cpu", "cuda"), default="cuda")
    parser.add_argument("--steps", type=int, default=20000)
    parser.add_argument("--train-scenes", type=int, default=8000)
    parser.add_argument("--holdout-scenes", type=int, default=700)
    parser.add_argument("--batch-size", type=int, default=64)
    parser.add_argument("--width", type=int, default=96)
    parser.add_argument("--round-id", type=int, default=1)
    parser.add_argument("--eval-every", type=int, default=1000)
    parser.add_argument("--learning-rate", type=float, default=0.0007)
    args = parser.parse_args()
    if args.output.exists():
        raise ValueError("refuse existing experiment output")
    if min(args.steps, args.batch_size, args.eval_every) < 1 or args.learning_rate <= 0:
        raise ValueError("invalid training budget")
    device = torch.device(args.device)
    if args.device == "cuda" and not torch.cuda.is_available():
        raise ValueError("requested CUDA unavailable; no silent CPU fallback")
    torch.set_num_threads(2)
    torch.manual_seed(20261008 + args.round_id)
    np.random.seed(20261008 + args.round_id)
    if device.type == "cuda":
        torch.cuda.reset_peak_memory_stats()
    args.output.mkdir(parents=True)
    protocol = {
        "scope": "OWN_SYNTHETIC_RU_ZERO_CLASS_NOT_M33_BLIND_OR_TEXTBOOK_SUCCESS",
        "config": {
            k: str(v) if isinstance(v, Path) else v for k, v in vars(args).items()
        },
        "weights": "RANDOM_INITIALIZATION_NO_EXTERNAL_PRETRAINING",
        "architecture": "CNN spatial patches + learned RU starter word tokens + existing TinyCausalTransformer",
        "image_size": IMAGE_SIZE,
        "question_auxiliary": "training-only learned intent target (0.2 CE); never a forward input",
        "augmentation": "random horizontal mirror preserves admitted geometric semantics",
        "selection_policy": "original + mirrored image must agree; weakest probability kept, remaining mass UNKNOWN; thresholds use separate calibration",
        "learned_inputs": "RGB pixels and question only; no scene IDs, oracle, labels or task IDs",
        "development_selection": "minimum dev cross entropy only",
        "calibration": "separate split; per-skill fixed grid, >=50 accepted and zero observed false assertions",
        "gate": "per skill: >=50 accepted, zero false assertions, answerable recall >=0.80, unknown recall >=0.90 in final and transfer; counterfactual recall >=0.80; blank/shuffle answerable recall drop >=0.15",
        "limitations": "finite dependent procedural samples; no universal truth/safety guarantee; constant empty/masked/missing controls shared; no textbook/photographic/OOD admission",
        "final_use": "read only after model selection and calibration; failures remain failed",
        "capsule_sha256": os.environ.get(
            "AI_BRAIN_CAPSULE_SHA256", "LOCAL_NO_REMOTE_CAPSULE"
        ),
    }
    write_json(args.output / "protocol.json", protocol)
    splits = corpus(
        train_scenes=args.train_scenes,
        holdout_scenes=args.holdout_scenes,
        round_id=args.round_id,
    )
    audit = audit_splits(splits)
    write_json(args.output / "split-audit.json", audit)
    for split, rows in splits.items():
        write_json(
            args.output / f"{split}-examples.json", [sample_record(r) for r in rows]
        )
    # No final pixels/tensors or probabilities are constructed in the training loop.
    train, dev = (Prepared(splits[name], device) for name in ("train", "dev"))
    model = ZeroClassModel(width=args.width).to(device)
    optimizer = torch.optim.AdamW(
        model.parameters(), lr=args.learning_rate, weight_decay=0.01
    )
    frequencies = (
        torch.bincount(train.answers, minlength=VOCAB_SIZE).clamp_min(1).float()
    )
    weights = (len(train.rows) / frequencies).sqrt()
    weights /= weights[: len(ANSWERS)].mean()
    history, best_loss = [], float("inf")
    started = time.monotonic()
    for step in range(1, args.steps + 1):
        model.train()
        ids = torch.randint(len(train.rows), (args.batch_size,), device=device)
        images, questions, labels = train.batch(ids)
        optimizer.zero_grad(set_to_none=True)
        if torch.rand((), device=device).item() < 0.5:
            images = images.flip(-1)
        logits, intent_logits = model(images, questions, return_intent=True)
        loss = F.cross_entropy(logits, labels, weight=weights) + 0.2 * F.cross_entropy(
            intent_logits, train.intents[ids]
        )
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1)
        optimizer.step()
        if step % args.eval_every == 0 or step == args.steps:
            probs = probabilities(model, dev)
            dev_loss = float(
                -np.mean(
                    [
                        np.log(max(p[row.answer], 1e-30))
                        for row, p in zip(dev.rows, probs, strict=True)
                    ]
                )
            )
            stats = summarize(dev.rows, probs)
            history.append(
                {
                    "step": step,
                    "train_loss": float(loss.item()),
                    "dev_loss": dev_loss,
                    "dev": stats,
                    "seconds": time.monotonic() - started,
                }
            )
            print(
                json.dumps(
                    {
                        "step": step,
                        "train_loss": float(loss.item()),
                        "dev_loss": dev_loss,
                        "accuracy": stats["all"]["accuracy"],
                        "seconds": round(time.monotonic() - started, 1),
                    }
                ),
                flush=True,
            )
            if dev_loss < best_loss:
                best_loss = dev_loss
                torch.save(
                    {"model": model.state_dict(), "width": args.width, "step": step},
                    args.output / "best.pt",
                )
    state = torch.load(args.output / "best.pt", map_location=device, weights_only=True)
    model.load_state_dict(state["model"])
    calibration = Prepared(splits["calibration"], device)
    cal_probs = probabilities(model, calibration, consensus=True)
    thresholds = calibrate(calibration.rows, cal_probs)
    write_json(
        args.output / "frozen-calibration.json",
        {
            "thresholds": thresholds,
            "checkpoint_sha256": sha256(args.output / "best.pt"),
            "protocol_sha256": sha256(args.output / "protocol.json"),
        },
    )
    report = {
        "schema": 1,
        "protocol_sha256": sha256(args.output / "protocol.json"),
        "checkpoint_sha256": sha256(args.output / "best.pt"),
        "best_step": state["step"],
        "parameters": sum(p.numel() for p in model.parameters()),
        "device": str(device),
        "torch": torch.__version__,
        "thresholds": thresholds,
        "calibration": summarize(calibration.rows, cal_probs, thresholds),
        "history": history,
        "scope": protocol["scope"],
        "tests": {},
    }
    for split in ("final", "transfer"):
        data = Prepared(splits[split], device)
        raw_probs = probabilities(model, data)
        probs = probabilities(model, data, consensus=True)
        report["tests"][split] = {
            "raw": summarize(data.rows, raw_probs),
            "selected": summarize(data.rows, probs, thresholds),
            "blank_image": summarize(
                data.rows,
                probabilities(model, data, mode="blank", consensus=True),
                thresholds,
            ),
            "shuffled_image": summarize(
                data.rows,
                probabilities(model, data, mode="shuffled", consensus=True),
                thresholds,
            ),
        }
        write_json(
            args.output / f"{split}-predictions.json",
            [
                {
                    "scene_id": r.scene.scene_id,
                    "task": r.task,
                    "gold": ANSWERS[r.answer],
                    "selected": ANSWERS[select_answer(p, thresholds[r.task])],
                    "probabilities": p,
                }
                for r, p in zip(data.rows, probs, strict=True)
            ],
        )
    pairs = counterfactuals(args.round_id)
    cf_data = Prepared(pairs, device)
    cf_probs = probabilities(model, cf_data, consensus=True)
    report["counterfactual"] = summarize(pairs, cf_probs, thresholds)
    write_json(
        args.output / "counterfactual-examples.json", [sample_record(r) for r in pairs]
    )
    gate = {}
    for task in TASKS:
        passed = True
        for split in ("final", "transfer"):
            results = report["tests"][split]
            stats = results["selected"][task]
            passed &= (
                stats["accepted"] >= 50
                and stats["false_assertions"] == 0
                and (stats["answerable_recall"] or 0) >= 0.8
                and (stats["unknown_recall"] or 0) >= 0.9
            )
            for control in ("blank_image", "shuffled_image"):
                passed &= (stats["answerable_recall"] or 0) - (
                    results[control][task]["answerable_recall"] or 0
                ) >= 0.15
        passed &= (
            report["counterfactual"][task]["answerable_recall"] or 0
        ) >= 0.8 and report["counterfactual"][task]["false_assertions"] == 0
        gate[task] = bool(passed)
    report["skill_gates"] = gate
    report["status"] = (
        "BOUNDED_SYNTHETIC_GATE_PASSED_NOT_PRODUCTION"
        if all(gate.values())
        else "REJECTED_NOT_PRODUCTION"
    )
    report["elapsed_seconds"] = time.monotonic() - started
    report["peak_cuda_allocated_bytes"] = (
        torch.cuda.max_memory_allocated() if device.type == "cuda" else None
    )
    report["peak_cuda_reserved_bytes"] = (
        torch.cuda.max_memory_reserved() if device.type == "cuda" else None
    )
    write_json(args.output / "report.json", report)
    print(
        json.dumps(
            {
                k: report[k]
                for k in (
                    "status",
                    "skill_gates",
                    "thresholds",
                    "parameters",
                    "elapsed_seconds",
                    "peak_cuda_allocated_bytes",
                )
            }
        ),
        flush=True,
    )


if __name__ == "__main__":
    main()
