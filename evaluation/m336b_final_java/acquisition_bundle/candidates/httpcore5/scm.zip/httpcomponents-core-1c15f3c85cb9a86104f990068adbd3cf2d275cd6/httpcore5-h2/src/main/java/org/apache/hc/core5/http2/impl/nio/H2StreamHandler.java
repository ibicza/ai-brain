/*
 * ====================================================================
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 * ====================================================================
 *
 * This software consists of voluntary contributions made by many
 * individuals on behalf of the Apache Software Foundation.  For more
 * information on the Apache Software Foundation, please see
 * <http://www.apache.org/>.
 *
 */
package org.apache.hc.core5.http2.impl.nio;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.List;

import org.apache.hc.core5.http.Header;
import org.apache.hc.core5.http.HttpException;
import org.apache.hc.core5.http.nio.AsyncPushConsumer;
import org.apache.hc.core5.http.nio.HandlerFactory;
import org.apache.hc.core5.http.nio.ResourceHolder;

interface H2StreamHandler extends ResourceHolder {

    boolean isOutputReady();

    void produceOutput() throws HttpException, IOException;

    void consumePromise(List<Header> headers) throws HttpException, IOException;

    void consumeHeader(List<Header> headers, boolean endStream) throws HttpException, IOException;

    void updateInputCapacity() throws IOException;

    void consumeData(ByteBuffer src, boolean endStream) throws HttpException, IOException;

    HandlerFactory<AsyncPushConsumer> getPushHandlerFactory();

    void failed(Exception cause);

    void handle(final HttpException ex, final boolean endStream) throws HttpException, IOException;

}
